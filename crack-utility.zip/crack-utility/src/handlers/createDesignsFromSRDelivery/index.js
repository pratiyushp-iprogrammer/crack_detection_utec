const DesignService = require('./service');
let designService = new DesignService();


exports.handler = async (event, context) => {
    try {
        const SQSrecords = event.Records ? event.Records : [];
        const records = await designService.recordsParser(SQSrecords);
        const params = records[0];
        console.log(JSON.stringify({ file: 'index.js', line: 10, value: params }));
        const response = await designService.createPayload(params);
        console.log(JSON.stringify({ file: 'index.js', line: 12, value: response }));
        if (!response.status) {
            throw new Error("Invalid request");
        }
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 17, message: error?.message, error }));
        throw error;
    }
}