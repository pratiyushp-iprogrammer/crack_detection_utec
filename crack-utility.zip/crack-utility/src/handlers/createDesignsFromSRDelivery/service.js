const Design = require('../../models/planStyleDesigns');
// const DesignUsageData = require('../../models/designUsageData');
const payloadDefault = require('./payload');
const DBConnector = require('../../common/dbConnector');
const mongoDatabase = require('../../common/database');
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const v8 = require('v8');
let objDatabase = new mongoDatabase();

if (typeof client === 'undefined') var client = objDatabase.connect();
const dbConnector = new DBConnector();
let domainName = "https://assets-utec.utecbuild.com/";
let cloudURL = "https://d2l724nx2yy7j2.cloudfront.net/";
const DEPLOYMENT = process.env?.DEPLOYMENT || "production";
const buckets = {
    "dev": "utec-test-container",
    "stage": "utec-stage-container",
    "preprod": "utec-stage-container",
    "production": "utec-prod-container"
}
class DesignService {
    async createDesign(data) {
        try {
            const objStyle = new Design(data);
            const result = await objStyle.save();
            if (result) {
                return result;
            }
            return false;
        } catch (error) {
            console.log(JSON.stringify({ line: 23, message: error?.message, error }));
            throw error;
        }
    }

    async findNextUniqueId() {
        try {
            const result = await Design.find({}, { unique_id: 1 }).sort({ unique_id: -1 }).limit(1);
            if (result === null) return [];
            return result;
        } catch (error) {
            console.log(JSON.stringify({ line: 34, message: error?.message, error }));
            throw error;
        }
    }

    // async createLog(data) {
    //     try {
    //         const objUsageData = new DesignUsageData(data);
    //         const result = await objUsageData.save();
    //         return result;
    //     } catch (error) {
    //         console.log(JSON.stringify({ line: 45, message: error?.message, error }));
    //         throw error;
    //     }
    // }

    async findBySRNumber(srNumber, option) {
        try {
            const result = await Design.findOne({ sr_number: srNumber, option_number: option });
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(JSON.stringify({ line: 56, message: error?.message, error }));
            throw error;
        }
    }

    async updateDesign(params) {
        try {
            let result = await Design.updateOne({ sr_number: params.sr_number }, params, { upsert: true })
            return result;
        } catch (error) {
            console.log(JSON.stringify({ line: 66, message: error?.message, error }));
            throw error;
        }
    }

    async recordsParser(records) {
        try {
            console.log(JSON.stringify({ file: 'service.js', line: 68, records }));
            let arrayOfMessages = [];
            for (const item of records) {
                const message = JSON.parse(item?.body);
                arrayOfMessages.push(message);
            }
            return arrayOfMessages;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 76, message: error?.message }));
            throw error;
        }
    }

    async createPayload(params) {
        try {
            // (2D Layout = 18 and 3D Elevation = 19)
            if (["18", "19", 18, 19].includes(params.request_type_id) && params.sku_type === "Basic") {
                const payload = v8.deserialize(v8.serialize(payloadDefault));
                // console.log("LOG FOR PAYLOAD START :", payload);
                let serviceRequestId = params.linked_id ? params.linked_id : params.SRId;
                let fileMappings = [];
                // const srDetailsQuery = 'SELECT * FROM service_request_details where service_requests_id = ?;'
                const srDetailsQuery = `
                    WITH jd_data AS (
                        SELECT
                            srd.sr_info as sr_info, jd.isDeleted, jd.iterationCount, jd.options, jd.files, srd.service_requests_id AS service_requests_id,
                            MAX(jd.iterationCount) OVER (PARTITION BY srd.service_requests_id) AS max_count
                        FROM service_request_details srd
                        LEFT JOIN JSON_TABLE(srd.delivery, '$[*]'
                            COLUMNS (
                                files json PATH '$.files',
                                iterationCount INT PATH '$.iterationCount',
                                options VARCHAR(50) PATH '$.options',
                                isDeleted INT PATH '$.isDeleted'
                            )
                        ) AS jd ON 1 = 1
                        WHERE (jd.isDeleted = 0 OR jd.isDeleted IS NULL) AND srd.service_requests_id = ?
                    )
                    SELECT 
                        service_requests_id, 
                        sr_info, 
                        JSON_ARRAYAGG(
                            JSON_OBJECT(
                            'files', files, 
                            'options', CASE
                                WHEN options = 'option1' OR options = '' OR options IS NULL THEN 1
                                WHEN options = 'option2' THEN 2
                                WHEN options = 'option3' THEN 3
                                ELSE options
                            END, 
                            'iterationCount', iterationCount, 
                            'isDeleted', isDeleted
                            )
                        ) AS delivery
                    FROM jd_data
                    WHERE (iterationCount = max_count) OR (iterationCount IS NULL AND max_count IS NULL)
                    GROUP BY service_requests_id
                `

                const srDetailsValue = await dbConnector.queryExecute(srDetailsQuery, [params.SRId]);
                const srDetails = srDetailsValue[0];
                console.log(JSON.stringify({ file: 'service.js', line: 96, value: srDetails }));
                const srInfo = srDetails?.sr_info || [];

                // payload.is_active = 0;
                payload.source = "Service Request";
                payload.sr_number = params.linked_id ? params.linked_id : params.SRId;

                /* Plot Details */
                payload.plot_details.plot_area = srInfo?.plotDimensions?.plotArea || null;
                payload.plot_details.plot_area_unit = srInfo?.plotDimensions?.plotAreaUnit || null;
                // payload.plot_details.plot_length = srInfo?.plotDimensions?.plotLength || null;
                let plotLength = srInfo?.plotDimensions?.plotArea / srInfo?.plotDimensions?.plotWidth;
                payload.plot_details.plot_length = plotLength ? plotLength.toFixed(2) : null;
                payload.plot_details.plot_width = srInfo?.plotDimensions?.plotWidth || null;
                payload.plot_details.plot_length_width_unit = srInfo?.plotDimensions?.plotWidthUnit || null;
                payload.plot_details.plot_shape = srInfo?.plotDimensions?.plotShape || null;
                payload.plot_details.front_set_back = srInfo?.sideGap?.one || null;
                payload.plot_details.right_set_back = srInfo?.sideGap?.two || null;
                payload.plot_details.rear_set_back = srInfo?.sideGap?.three || null;
                payload.plot_details.left_set_back = srInfo?.sideGap?.four || null;

                let plotSideFacing = 0, sharedWall = 0, noFloors;
                for (let key in srInfo?.plotSideFacing) {
                    if (srInfo?.plotSideFacing[key] === "Vacant Plot") {
                        plotSideFacing += 1;
                    }
                    if (srInfo?.plotSideFacing[key]?.includes("Shared Wall")) {
                        sharedWall = 1;
                    }
                }
                payload.project_details.shared_wall = sharedWall;
                payload.plot_details.open_sides_of_the_plot = plotSideFacing;

                /* Project Details */
                payload.project_details.typology = srInfo?.purposeOfHomeBuilding || null;
                // payload.project_details.builtup_area = srInfo?.plotDimensions?.builtUpArea || null;
                payload.project_details.floors = srInfo?.houseDetails?.floorCount || null;
                // payload.project_details.bedrooms = srInfo?.projectDetails?.numberOfBedRooms || null;
                if (srInfo?.houseDetails?.floorCount != null) {
                    let floorCase = srInfo.houseDetails.floorCount.toLowerCase();
                    floorCase = floorCase.replace(/\s/g, '');
                    const floorCountMap = {
                        'groundfloor': 0,
                        'ground+1floor': 1,
                        'ground+2floors': 2,
                        'ground+3floors': 3,
                        'ground+4floors': 4,
                        'ground+5floors': 5,
                        'stiltfloor': 0,
                        'stilt+1floor': 1,
                        'stilt+2floors': 2,
                        'stilt+3floors': 3,
                        'stilt+4floors': 4,
                        'stilt+5floors': 5,
                    };
                    noFloors = floorCountMap[floorCase] !== undefined ? floorCountMap[floorCase] : null;
                }
                payload.project_details.no_floors = noFloors;
                if (srInfo?.plotDetails?.stairCaseType?.includes("External")) {
                    payload.project_details.staircase_external = 1;
                    payload.project_details.staircase_internal = 0;
                } else if (srInfo?.plotDetails?.stairCaseType?.includes("Internal")) {
                    payload.project_details.staircase_external = 0;
                    payload.project_details.staircase_internal = 1;
                }

                /* Geography */
                const geographyQuery = `SELECT 
                        ult.state_name,
                        ult.city_name,
                        ult.district_name,
                        ult.latitude,
                        ult.longitude,
                        ult.pincode
                    FROM service_requests AS sr
                    INNER JOIN user_locations_table AS ult ON sr.pincode_id = ult.id 
                    WHERE sr.id = ? `;

                const geography = await dbConnector.queryExecute(geographyQuery, [params.SRId]);

                console.log(JSON.stringify({ file: 'service.js', line: 166, value: geography }));

                payload.geography.state = geography[0]?.state_name || null;
                payload.geography.city = geography[0]?.city_name || null;
                payload.geography.district = geography[0]?.district_name || null;
                payload.geography.geo_coordinates = `${geography[0]?.latitude || 0}, ${geography[0]?.longitude || 0}`;
                payload.geography.pincode = geography[0]?.pincode || null;
                payload.project_details.buildup_area_unit = srInfo?.plotDimensions?.plotAreaUnit || null;
                // let builtupArea = 0;
                // if (builtupArea == 0 || builtupArea == null) {
                // logic to calculate build_up area
                let plotAreaTotal = srInfo?.plotDimensions?.plotArea || null;
                let totalBUA;
                if (plotAreaTotal == null || noFloors == null) {
                    totalBUA = null;
                } else {
                    totalBUA = (plotAreaTotal * 0.75) * (noFloors + 1);
                }
                if (totalBUA) {
                    totalBUA = Number(totalBUA)?.toFixed(2);
                }
                payload.project_details.builtup_area = totalBUA;
                // }

                /* Family Details */
                payload.family_details.total_family_members = srInfo?.familyDetails?.memberCount || null;
                payload.family_details.number_of_senior_citizen = srInfo?.familyDetails?.seniorCitizens || null;
                payload.family_details.number_of_adults = srInfo?.familyDetails?.adults || null;
                payload.family_details.number_of_children = srInfo?.familyDetails?.kids || null;
                payload.family_details.number_of_infants = srInfo?.familyDetails?.infants || null;

                /* Parking */
                srInfo?.bikeParking?.numberOfBikes || srInfo?.bikeParking?.numberOfBikes === 0 ? payload.parking.two_wheeler_parking = !isNaN(Number(srInfo?.bikeParking?.numberOfBikes)) ? Number(srInfo?.bikeParking?.numberOfBikes) : null : null;
                srInfo?.carParking?.numberOfCars || srInfo?.carParking?.numberOfCars === 0 ? payload.parking.four_wheeler_parking = !isNaN(Number(srInfo?.carParking?.numberOfCars)) ? Number(srInfo?.carParking?.numberOfCars) : null : null;

                /* Senior citizen friendly */
                payload.senior_citizen_friendly.provision_of_ramp = srInfo?.plotDetails?.specialRequirement?.includes("Wheelchair Ramp") ? "Yes" : "No"

                /* Room */
                let senior_citizen = 0, designId;
                let roomsWithRoomCountOne, numberOfBedRooms = 0;
                if (srInfo?.houseDetails?.roomCount) {
                    roomsWithRoomCountOne = Object.entries(srInfo?.houseDetails?.roomCount)
                        .reduce((rooms, [floor, floorRooms]) => {
                            const mappedRoom = {
                                index: null,
                                total_bathrooms: null,
                                attached_bathrooms: null,
                                split_bathrooms: null,
                                combined_bathrooms: null,
                                common_bathrooms: null,
                                dining_room: null,
                                living_room: null,
                                kitchen: null,
                                master_bedroom: null,
                                family_room: null,
                                store_room: null,
                                pooja_room: null,
                                shops: null
                            };

                            if (floor === "groundFloor") {
                                mappedRoom.index = 0;
                            } else if (floor === "firstFloor") {
                                mappedRoom.index = 1;
                            } else if (floor === "secondFloor") {
                                mappedRoom.index = 2;
                            } else if (floor === "thirdFloor") {
                                mappedRoom.index = 3;
                            } else if (floor === "fourthFloor") {
                                mappedRoom.index = 4;
                            } else if (floor === "fifthFloor") {
                                mappedRoom.index = 5;
                            }

                            floorRooms.forEach(room => {
                                if (room?.roomName === "Common Bathroom" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.common_bathrooms = room.roomCount;
                                    mappedRoom.total_bathrooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Shop" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.shops = room.roomCount;
                                }
                                if (room?.roomName === "Separate Bathroom & Toilet" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.split_bathrooms = room.roomCount;
                                    mappedRoom.total_bathrooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Bedroom" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.family_room = room.roomCount;
                                    numberOfBedRooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Dining Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.dining_room = room.roomCount;
                                }
                                if (room?.roomName === "Kitchen" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.kitchen = room.roomCount;
                                }
                                if (room?.roomName === "Living Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.living_room = room.roomCount;
                                }
                                if (room?.roomName === "Master Bedroom" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.master_bedroom = room.roomCount;
                                    numberOfBedRooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Pooja Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.pooja_room = room.roomCount;
                                }
                                if (room?.roomName === "Store Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.store_room = room.roomCount;
                                }
                                if (room?.roomName === "Wash Area" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.combined_bathrooms = room.roomCount;
                                }
                                if ((room?.roomName === "Common Bathroom" || room?.roomName === "Separate Bathroom & Toilet") && room?.floorNumber === "groundFloor" && parseInt(room?.roomCount) > 0) {
                                    senior_citizen += 1;
                                }
                                if ((room?.roomName === "Bedroom" || room?.roomName === "Master Bedroom") && room?.floorNumber === "groundFloor" && parseInt(room?.roomCount) > 0) {
                                    senior_citizen += 1;
                                }
                                if (room?.roomName === "Kitchen" && room?.floorNumber === "groundFloor" && parseInt(room?.roomCount) > 0) {
                                    senior_citizen += 1;
                                }

                                payload.open_areas_configuration.balcony = room?.roomName === "Balcony" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.porch = room?.roomName === "Porch" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.verandah = room?.roomName === "Verandah" && parseInt(room?.roomCount) > 0 && params.request_type_id == 18 ? "Yes" : "No";


                                payload.open_areas_configuration.garden = room?.roomName === "Garden" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.courtyard = room?.roomName === "Courtyard" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.frontyard = room?.roomName === "Frontyard" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.backyard = room?.roomName === "Backyard" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.terrace = room?.roomName === "Terrace" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.open_areas_configuration.type_of_entrance = room?.roomName === "Type Of Entrance" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.special_amenities.library = room?.roomName === "Library" && parseInt(room?.roomCount) > 0 && params.request_type_id == 18 ? "Yes" : "No";

                                payload.special_amenities.home_theatre = room?.roomName === "Home Theatre" && parseInt(room?.roomCount) > 0 && params.request_type_id == 18 ? "Yes" : "No";

                                payload.special_amenities.pool = room?.roomName === "Pool" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.special_amenities.gym = room?.roomName === "Gym" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.special_amenities.study_room = room?.roomName === "Study Room" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                payload.special_amenities.game_room = room?.roomName === "Game Room" && parseInt(room?.roomCount) > 0 && params.request_type_id == 18 ? "Yes" : "No";
                            });

                            return rooms.concat(mappedRoom);
                        }, []).filter(mappedRoom => mappedRoom.index !== null);
                    roomsWithRoomCountOne = roomsWithRoomCountOne.sort((obj1, obj2) => obj1.index - obj2.index);
                }

                // const resultObject = await this.getMaxIterationObject(srDetails?.delivery);
                const resultObject = await this.getFilesFiltered(srDetails?.delivery);

                console.log(JSON.stringify({ file: 'service.js', line: 305, value: resultObject }));

                payload.senior_citizen_friendly.one_bhk_on_ground_floor = senior_citizen === 3 ? "Yes" : "No"

                // payload.is_approved = 0; // Default value
                payload.created_by = params?.created_by || null;
                payload.updated_by = params?.updated_by || null;

                for (let delivery of resultObject) {
                    let alreadyExists = false, nextUniqueId = 0, isApproved = 0, checkAvailability = false;
                    checkAvailability = await this.findBySRNumber(serviceRequestId, delivery.options);
                    if (checkAvailability) {
                        alreadyExists = true;
                        nextUniqueId = checkAvailability?.unique_id;
                    } else {
                        let source = params?.source || null;
                        if (source == "updateDCFlow") {
                            return { status: true, value: [], message: "The design has not been delivered yet." };
                        }
                        let lastUniqueId = await this.findNextUniqueId();
                        // console.log(JSON.stringify({ file: 'service.js', line: 356, lastUniqueId: lastUniqueId }));
                        if (!lastUniqueId || !lastUniqueId.length) {
                            nextUniqueId = 1;
                        } else {
                            nextUniqueId = lastUniqueId[0]?.unique_id + 1;
                        }
                        console.log(JSON.stringify({ file: 'service.js', line: 371, "nextUniqueId": nextUniqueId }));
                    }

                    if (params.request_type_id == 18) {
                        /* Files */
                        if (delivery?.files) {
                            payload.files = v8.deserialize(v8.serialize(payload.files));
                            const groundFloor = [], groundPlusOne = [], groundPlusTwo = [], groundPlusThree = [], groundPlusFour = [], groundPlusFive = [], twoDPdf = [], linkedDwg = [];
                            for (let value of delivery.files) {
                                let imageLink = null;
                                imageLink = value?.link || null;
                                if (imageLink) {
                                    // isApproved = 1;
                                    let imageArray = imageLink.split("/");
                                    let arrayLength = imageArray.length;
                                    imageLink = `delivery_catalog/${nextUniqueId}/${imageArray[2]}/${imageArray[arrayLength - 1]}`;
                                    fileMappings.push({
                                        sourceKey: value.link,
                                        destinationKey: imageLink
                                    });
                                }
                                if (value?.category === "Ground Floor Design") {
                                    isApproved = 1;
                                    groundFloor.push(imageLink);
                                } else if (value?.category === "First Floor Design") {
                                    isApproved = 1;
                                    groundPlusOne.push(imageLink);
                                } else if (value?.category === "Second Floor Design") {
                                    isApproved = 1;
                                    groundPlusTwo.push(imageLink);
                                } else if (value?.category === "Third Floor Design") {
                                    isApproved = 1;
                                    groundPlusThree.push(imageLink);
                                } else if (value?.category === "Fourth Floor Design") {
                                    isApproved = 1;
                                    groundPlusFour.push(imageLink);
                                } else if (value?.category === "Fifth Floor Design") {
                                    isApproved = 1;
                                    groundPlusFive.push(imageLink);
                                } else if (value?.category === "Pdf File") {
                                    twoDPdf.push(imageLink);
                                } else if (value?.category === "Raw File") {
                                    linkedDwg.push(imageLink);
                                }
                            }
                            payload.files.two_d_rendered_plan_jpg.ground = groundFloor;
                            payload.files.two_d_rendered_plan_jpg.ground_plus_one = groundPlusOne;
                            payload.files.two_d_rendered_plan_jpg.ground_plus_two = groundPlusTwo;
                            payload.files.two_d_rendered_plan_jpg.ground_plus_three = groundPlusThree;
                            payload.files.two_d_rendered_plan_jpg.ground_plus_four = groundPlusFour;
                            payload.files.two_d_rendered_plan_jpg.above_ground_plus_four = groundPlusFive;
                            payload.files.two_d_rendered_plan_pdf.two_d_rendered_plan_pdf_link = twoDPdf;
                            payload.files.linked_dwg_file.linked_dwg_file_id = linkedDwg;
                        }

                        /* Room */
                        payload.rooms = roomsWithRoomCountOne;
                        payload.project_details.bedrooms = numberOfBedRooms ? numberOfBedRooms : null;
                        /* Vaastu */
                        payload.vaastu_compliancy.entry_direction = srInfo?.mainRoadDirection?.value || null;
                        payload.element_type = "Layout";
                    } else {
                        payload.rooms = null;
                        payload.project_details.bedrooms = null;
                        payload.element_type = "Elevations";

                        /* Roof */
                        payload.roof.roof_type = srInfo?.projectDetails?.roofType || null;

                        /* Files*/
                        if (delivery?.files) {
                            payload.files = v8.deserialize(v8.serialize(payload.files));
                            let groundIso = [], firstIso = [], secondIso = [], thirdIso = [], fourthIso = [], fifthIso = [], rawIso = [], threeDPdf = [];
                            for (let value of delivery.files) {
                                let imageLink = null;
                                imageLink = value?.link || null;
                                if (imageLink) {
                                    // isApproved = 1;
                                    let imageArray = imageLink.split("/");
                                    let arrayLength = imageArray.length;
                                    imageLink = `delivery_catalog/${nextUniqueId}/${imageArray[2]}/${imageArray[arrayLength - 1]}`;
                                    fileMappings.push({
                                        sourceKey: value.link,
                                        destinationKey: imageLink
                                    });
                                }
                                if (value?.category === "Front Elevation") {
                                    payload.files.three_d_design_id.front = imageLink || null;
                                } else if (value?.category === "Right Elevation") {
                                    payload.files.three_d_design_id.right_side = imageLink || null;
                                } else if (value?.category === "Left Elevation") {
                                    payload.files.three_d_design_id.left_side = imageLink || null;
                                } else if (value?.category === "Rear Elevation") {
                                    payload.files.three_d_design_id.rear_side = imageLink || null;
                                } else if (value?.category === "Internal Elevation") {
                                    payload.files.three_d_design_id.internal = imageLink || null;
                                } else if (value?.category === "Ground Floor Cut-Iso") {
                                    isApproved = 1;
                                    groundIso.push(imageLink);
                                } else if (value?.category === "First Floor Cut-Iso") {
                                    isApproved = 1;
                                    firstIso.push(imageLink);
                                } else if (value?.category === "Second Floor Cut-Iso") {
                                    isApproved = 1;
                                    secondIso.push(imageLink);
                                } else if (value?.category === "Third Floor Cut-Iso") {
                                    isApproved = 1;
                                    thirdIso.push(imageLink);
                                } else if (value?.category === "Fourth Floor Cut-Iso") {
                                    isApproved = 1;
                                    fourthIso.push(imageLink);
                                } else if (value?.category === "Fifth Floor Cut-Iso") {
                                    isApproved = 1;
                                    fifthIso.push(imageLink);
                                } else if (value?.category === "Raw File") {
                                    rawIso.push(imageLink);
                                } else if (value?.category === "Pdf File") {
                                    threeDPdf.push(imageLink);
                                }
                            }
                            payload.files.three_d_cut_iso_jpg.ground = groundIso;
                            payload.files.three_d_cut_iso_jpg.ground_plus_one = firstIso;
                            payload.files.three_d_cut_iso_jpg.ground_plus_two = secondIso;
                            payload.files.three_d_cut_iso_jpg.ground_plus_three = thirdIso;
                            payload.files.three_d_cut_iso_jpg.ground_plus_four = fourthIso;
                            payload.files.three_d_cut_iso_jpg.above_ground_plus_four = fifthIso;
                            payload.files.linked_sketch_up_file.sketch_up_file_id = rawIso;
                            payload.files.three_d_delivery_pdf.three_d_delivery_pdf_link = threeDPdf;
                        }

                        /* Color*/
                        let color = "";
                        if (srInfo?.color?.primary?.name && srInfo.color.primary.name !== "No preferences") {
                            color += srInfo.color.primary.name;
                        }

                        if (srInfo?.color?.secondary?.name && srInfo.color.secondary.name !== "No preferences") {
                            if (color) {
                                color += `,${srInfo.color.secondary.name}`;
                            } else {
                                color += srInfo.color.secondary.name;
                            }
                        }

                        if (color) payload.colors.color_used = color;
                    }
                    payload.option_number = delivery.options || null;
                    payload.unique_id = nextUniqueId;
                    // To ensure all newly added designs start in an unpublished state, simply remove the line below if you want to retain the previous logic.
                    isApproved = 0;
                    payload.is_approved = isApproved ? isApproved : 0;
                    payload.publish_date = payload.is_approved ? new Date() : null;
                    let response;
                    console.log("LOG FOR PAYLOAD", payload);
                    if (!alreadyExists) {
                        response = await this.createDesign(payload);
                    } else {
                        if (params?.linked_id) {
                            payload.element_type = "Bundle Elevations";
                        } else {
                            payload.element_type = checkAvailability?.element_type || null;
                        }
                        payload.is_approved = isApproved || (checkAvailability.is_approved ? checkAvailability.is_approved : isApproved);
                        payload.publish_date = payload.is_approved ? checkAvailability.publish_date : null;
                        if (params.request_type_id == 18) {
                            payload.roof.roof_type = checkAvailability?.roof?.roof_type || payload.roof.roof_type;
                            payload.files.three_d_design_id = checkAvailability?.files?.three_d_design_id || payload.files.three_d_design_id;
                            payload.files.three_d_cut_iso_jpg = checkAvailability?.files?.three_d_cut_iso_jpg || payload.files.three_d_cut_iso_jpg;
                            payload.files.linked_sketch_up_file = checkAvailability?.files?.linked_sketch_up_file || payload.files.linked_sketch_up_file;
                            payload.files.three_d_delivery_pdf = checkAvailability?.files?.three_d_delivery_pdf || payload.files.three_d_delivery_pdf;
                            payload.colors = checkAvailability?.colors || payload.colors;
                            payload.open_areas_configuration.type_of_entrance = checkAvailability?.open_areas_configuration?.type_of_entrance || payload.open_areas_configuration.type_of_entrance;
                            payload.material_treatment = checkAvailability?.material_treatment || payload.material_treatment;
                            payload.structural_elements = checkAvailability?.structural_elements || payload.structural_elements;
                        } else {
                            payload.files.two_d_rendered_plan_jpg = checkAvailability?.files?.two_d_rendered_plan_jpg || payload.files.two_d_rendered_plan_jpg;
                            payload.files.two_d_rendered_plan_pdf = checkAvailability?.files?.two_d_rendered_plan_pdf || payload.files.two_d_rendered_plan_pdf;
                            payload.files.linked_dwg_file = checkAvailability?.files?.linked_dwg_file || payload.files.linked_dwg_file;
                            payload.rooms = checkAvailability?.rooms || payload.rooms;
                            payload.project_details.bedrooms = checkAvailability?.project_details?.bedrooms || payload.project_details.bedrooms;
                            payload.vaastu_compliancy = checkAvailability?.vaastu_compliancy || payload.vaastu_compliancy;
                            payload.special_amenities.library = checkAvailability?.special_amenities?.library || payload.special_amenities.library;
                            payload.special_amenities.home_theatre = checkAvailability?.special_amenities?.home_theatre || payload.special_amenities.home_theatre;
                            payload.special_amenities.gym = checkAvailability?.special_amenities?.gym || payload.special_amenities.gym;
                            payload.special_amenities.study_room = checkAvailability?.special_amenities?.study_room || payload.special_amenities.study_room;
                            payload.special_amenities.game_room = checkAvailability?.special_amenities?.game_room || payload.special_amenities.game_room;
                        }
                        response = await this.updateDesign(payload);
                    }

                    console.log(JSON.stringify({ file: 'service.js', line: 399, value: response }));

                    if (!response)
                        return { status: false, value: [], message: "Something went wrong." };

                    let promiseResult = await this.copyS3Files(fileMappings); //file copy from one bucket to other bucket
                    // console.log(JSON.stringify({ file: 'service.js', line: 536, promiseResult}));
                    // promiseResult.forEach((result, index) => {
                    //     if (result.status === 'fulfilled') {
                    //         console.log(`Promise ${index + 1} resolved: ${result.value}`);
                    //     } else {
                    //         console.error(`Promise ${index + 1} rejected: ${result.reason}`);
                    //     }
                    // });

                    // const designId = !alreadyExists ? response?._id : checkAvailability?._id;
                    // let planStyleUniqueId = !alreadyExists ? response?.unique_id : checkAvailability?.unique_id;
                    // console.log(JSON.stringify({ file: 'service.js', line: 406, value: planStyleUniqueId }));
                    // const logData = {
                    //     plan_style_designs_unique_id: planStyleUniqueId,
                    //     design_id: designId,
                    //     sr_tracker_number: params.linked_id ? params.linked_id : params.SRId,
                    //     created_by: params.created_by,
                    //     action: 'create'
                    // };
                    // if (alreadyExists) {
                    //     logData.action = 'update';
                    // }
                    // console.log(JSON.stringify({ file: 'service.js', line: 416, value: logData }));
                    // await this.createLog(logData);
                }

                return { status: true, message: "Design added successfully!" };
            } else {
                console.log(JSON.stringify({ file: 'service.js', line: 425 }));
                return null;
            }
        } catch (error) {
            return { status: false, value: error?.message, message: "Something went wrong." };
        }
    }

    async getMaxIterationObject(data) {
        if (!Array.isArray(data) || data.length === 0) {
            return null;
        }

        const filteredData = data.filter(obj => obj.isDeleted === 0);
        if (filteredData.length === 0) {
            return null;
        }

        const validIterationData = filteredData.filter(obj => obj.iterationCount !== null);
        if (validIterationData.length === 0) {
            return filteredData.reduce((prev, curr) => (curr.updatedAt > prev.updatedAt ? curr : prev));
        }

        const maxIterationObject = validIterationData.reduce((prev, curr) =>
            (curr.iterationCount > prev.iterationCount ? curr : prev)
        );
        return maxIterationObject;
    }

    getFilesFiltered(data) {
        if (data.length == 1 && data[0].files === null && data[0].isDeleted === null && data[0].iterationCount === null && [1, '1'].includes(data[0].options)) {
            return data;
        }
        const modified = data.map(el => {
            const filtered = el.files.filter(file => file.isDeleted === 0)
            return ({ ...el, files: filtered })
        })
        return modified;
    }

    copyS3Files(fileMappings) {
        let isUtecContainerImage = false, utecContainerLink = null;
        let bucketName = buckets[DEPLOYMENT];
        let polarisBucketName = process.env.POLARIS_S3_BUCKET ? process.env.POLARIS_S3_BUCKET : "polaris-tasc-panel-prod";
        let destinationBucket = process.env.UPLOAD_S3_BUCKET ? process.env.UPLOAD_S3_BUCKET : "design-management-prod";
        // Use Promise.all to parallelize the copy operations
        const copyPromises = fileMappings.map((mapping) => {
            // Check if the lowercase URL includes the lowercase specific part
            if (mapping?.sourceKey?.toLowerCase().includes(domainName) || mapping?.sourceKey?.toLowerCase().includes(cloudURL)) {
                isUtecContainerImage = true;
                utecContainerLink = mapping?.sourceKey?.replace(domainName, "");
                utecContainerLink = utecContainerLink?.replace(cloudURL, "");
            }
            let imageURL = isUtecContainerImage ? utecContainerLink : mapping.sourceKey;
            let sourceBucket = isUtecContainerImage ? bucketName : polarisBucketName;
            const params = {
                CopySource: `/${sourceBucket}/${encodeURIComponent(imageURL)}`,
                Bucket: destinationBucket,
                Key: mapping.destinationKey
            };

            // return new Promise((resolve, reject) => {
            //     s3.copyObject(params, (err, data) => {
            //         if (err) {
            //             reject(`Error copying file ${mapping.sourceKey}: ${err}`);
            //         } else {
            //             resolve(`File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`);
            //         }
            //     });
            // });

            let copyObjectCommand = new CopyObjectCommand(params);
            return s3Client.send(copyObjectCommand)
                .then((data) => {
                    return `File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`;
                })
                .catch((err) => {
                    throw new Error(`Error copying file ${mapping.sourceKey}: ${err.message}`);
                });
        });

        return Promise.allSettled(copyPromises)
        // .then((results) => {
        //     console.log(results);
        // })
        // .catch((error) => {
        //     console.error(error);
        // });
    }
}

module.exports = DesignService;