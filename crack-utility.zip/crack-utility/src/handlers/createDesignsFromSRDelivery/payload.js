const payload = {
    "source": null,
    "unique_id": null,
    "element_type": null,
    "sr_number": null,
    "option_number": null,
    "files": {
        "two_d_rendered_plan_jpg": {
            "ground": null,
            "ground_plus_one": null,
            "ground_plus_two": null,
            "ground_plus_three": null,
            "ground_plus_four": null,
            "above_ground_plus_four": null,
            "others": null
        },
        "two_d_rendered_plan_pdf": {
            "two_d_rendered_plan_pdf_link": null
        },
        "three_d_design_id": {
            "front": null,
            "right_side": null,
            "left_side": null,
            "rear_side": null,
            "internal": null
        },
        "three_d_cut_iso_jpg": {
            "ground": null,
            "ground_plus_one": null,
            "ground_plus_two": null,
            "ground_plus_three": null,
            "ground_plus_four": null,
            "above_ground_plus_four": null,
            "others": null
        },
        "three_d_delivery_pdf" : {
            "three_d_delivery_pdf_link": null,
       },
        // "linked_estimation_id": {
        //     "estimation_id": null
        // },
        "linked_sketch_up_file": {
            "sketch_up_file_id": null
        },
        "linked_dwg_file": {
            "linked_dwg_file_id": null
        },
        // "linked_psd_file": {
        //     "linked_psd_file_id": null
        // },
    },
    "plot_details": {
        "plot_area": null,
        "plot_length": null,
        "plot_width": null,
        "plot_shape": null,
        "left_set_back": null,
        "right_set_back": null,
        "front_set_back": null,
        "rear_set_back": null,
        "open_sides_of_the_plot": null
    },
    "project_details": {
        "typology": null,
        "estimated_cost_of_construction": null,
        "builtup_area": null,
        "buildup_area_unit" : null,
        "floor_plate_area_of_ground_floor": null,
        "floor_plate_length": null,
        "floor_plate_width": null,
        "floors": null,
        "no_floors": null,
        "bedrooms": null,
        "shared_wall": null,
        "for_two_shared_wall_adjacent_parallel": null,
        "space_allocation": null,
        "style": null,
        "staircase_internal": null,
        "staircase_external": null,
    },
    "geography": {
        "weather_condition": null,
        "state": null,
        "city": null,
        "district": null,
        "geo_coordinates": null,
        "pincode": null,
    },
    "family_details": {
        "total_family_members": null,
        "number_of_senior_citizen": null,
        "number_of_adults": null,
        "number_of_children": null,
        "number_of_infants": null
    },
    "parking": {
        "basement": null,
        "stilts": null,
        "two_wheeler_parking": null,
        "four_wheeler_parking": null
    },
    "senior_citizen_friendly": {
        "max_three_stairs_to_enter_the_ground_floor": null,
        "one_bhk_on_ground_floor": null,
        "provision_of_ramp": null
    },
    "vaastu_compliancy": {
        "vaastu_compliant": null,
        "entry_direction": null,
        "orientation_of_kitchen": null,
        "orientation_of_pooja_room": null,
        "orientation_of_master_bedroom": null
    },
    "rooms": [{
        "index": null,
        "total_bathrooms": null,
        "attached_bathrooms": null,
        "split_bathrooms": null,
        "combined_bathrooms": null,
        "common_bathrooms": null,
        "dining_room": null,
        "living_room": null,
        "kitchen": null,
        "master_bedroom": null,
        "family_room": null,
        "store_room": null,
        "pooja_room": null,
        "shops": null
    }],
    "open_areas_configuration": {
        "balcony": null,
        "porch": null,
        "verandah": null,
        "garden": null,
        "courtyard": null,
        "frontyard": null,
        "backyard": null,
        "terrace": null,
        "type_of_entrance": null
    },
    "roof": {
        "roof_type": null
    },
    "stylized": {
        "stylized_configuration": null
    },
    "special_amenities": {
        "library": null,
        "home_theatre": null,
        "pool": null,
        "gym": null,
        "study_room": null,
        "game_room": null
    },
    "material_treatment": {
        "brick": null,
        "stone": null,
        "wood": null,
        "tile": null,
        "aluminium_composite_panel": null,
        "glass_curtain_wall": null
    },
    "structural_elements": {
        "pergola": null,
        "jaali": null,
        "green_wall": null,
        "planter": null,
        "vault": null,
        "double_height_open_area": null,
        "elevation_element": null
    },
    "colors": {
        "color_scheme": null,
        "color_used": null
    },
    // "is_active": null,
    // "is_approved": null,
    "publish_date" : null,
    "created_by": null,
    "updated_by": null
}

module.exports = payload;