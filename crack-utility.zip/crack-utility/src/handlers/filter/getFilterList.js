const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const FilterService = require('../../services/filterDataService');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
let filterService = new FilterService();
let baseResponse = new BaseResponse();
let adminDetails = new AdminDetails();

exports.getFilterHandler = async (event) => {
  console.log("API: getFilterHandler", event);
  try {
    event = Common.reqSanitize(event);

    let email = "";
    if (event.requestContext.authorizer) {
      let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
      email = authorizerResponse.email;
    }
    // let email = "";
    // let authorizationToken = event.headers.Authorization;
    // const details = await adminDetails.getAdminDetails(authorizationToken);
    // email = details ? details.name : '';

    console.log("user email:", email);
    const params = JSON.parse(event.body);
    console.log("filterService findByUserId:", email, params);
    const result = await filterService.findByUserId(email,params.type);
    if (result) {
      const filterDetails = await filterService.fetchFilterDetails(email, params.type);
      console.log("filterService filterDetails:", filterDetails);
      const sorted_result = filterDetails.pop();
      sorted_result.filterList = JSON.parse(sorted_result.filterList);
      console.log("sorted_result", sorted_result);
      return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, sorted_result, "Filter details fetched successfully.");
    }
    return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No record found.');
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
}
