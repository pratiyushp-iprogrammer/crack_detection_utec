const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const FilterService = require('../../services/filterDataService');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
let filterService = new FilterService();
let baseResponse = new BaseResponse();
let adminDetails = new AdminDetails();

exports.createFilterHandler = async (event) => {
  // const createFilterHandler = async () => {
  try {
    event = Common.reqSanitize(event);
    // const event = {}
    // event.body = {
    //   "userId": "testing4@gmail.com",
    //   "adminPanel": 1,    
    //   "type": "plans",//"styles"
    //   "columnsVisible": [],
    //   "filterList": {
    //     "plot_details.plot_area": [
    //       {
    //         "min": 500,
    //         "max": 749
    //       },
    //       {
    //         "min": 750,
    //         "max": 999
    //       }
    //     ]
    //   },
    //   "editFilterList": [
    //     "plot Length",
    //     "plot shape"
    //   ]
    // }
    let email = "";
    if (event.requestContext.authorizer) {
      let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
      email = authorizerResponse.email;
    }
    // let authorizationToken = event.headers.Authorization;
    // const details = await adminDetails.getAdminDetails(authorizationToken);
    // email = details ? details.name : '';

    console.log("Inside createFilterHandler");
    const params = JSON.parse(event.body);
    params.filterList = JSON.stringify(params.filterList);
    params.userId = email;
    const response = await filterService.createFilter(params);
    console.log('response', response);
    if (response) {
      return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Filter details added successfully!");
    }
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
}
// createFilterHandler();