const Joi = require("joi");

const schema = Joi.object({
    designId: Joi.number().required(),
    userId: Joi.number().required(),
    mobileNumber: Joi.string().required(),
    role: Joi.string().required(),
    platformId: Joi.number().required()
});

module.exports = schema;