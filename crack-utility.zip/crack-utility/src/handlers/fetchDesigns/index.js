const BaseResponse = require('../../common/baseResponse');
const HTTP_CODE = require('../../common/constants');
const schema = require('./schema');
const GetDesigns = require('./service');
const service = new GetDesigns();
let baseResponse = new BaseResponse();

exports.handler = async (event) => {
    try {
        const requestBody = typeof event?.body === 'string' ? JSON.parse(event.body) : event?.body || {};
        console.log(JSON.stringify({ file: 'controller.js', line: 10, requestBody }));
        const isRequestValid = schema.validate(requestBody);
        if (isRequestValid?.error) {
            console.log(JSON.stringify({ file: 'service.js', comment: "Validation Error ", line: 14, isRequestValid: isRequestValid }));
            return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, isRequestValid?.error?.details, "Invalid Request");
        }
        const designResult = await service.fetchAllDesigns(requestBody);
        console.log(JSON.stringify({ file: 'controller.js', line: 18, designResult }));
        if (designResult) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, designResult, 'Designs Fetched Successfully.');
        } else {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Error in to featched design');
        }
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 26, message: error?.message, error }));
        return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], error);
    }
};