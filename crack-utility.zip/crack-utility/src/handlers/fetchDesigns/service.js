const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
const Design = require('../../models/planStyleDesigns');

class GetDesigns {

    async fetchAllDesigns(requestBody) {
        try {
            let page = requestBody.pagination?.page ? requestBody.pagination.page : 1;
            let limitCount = requestBody.pagination?.fetchLimit ? requestBody.pagination.fetchLimit : 0;
            let skipCount = (page - 1) * limitCount;
            let filters = requestBody.filters ? requestBody.filters : {};
            const hasKeys = Object.keys(filters).length;
            let query = { "is_active": 1 };
            if (hasKeys) {
                let filesMissing = filters.filesMissing ? filters.filesMissing : "";
                let status = filters.status ? filters.status : "";
                let designType = filters.designType ? filters.designType.toLowerCase() : "";
                let designId = filters.designId ? filters.designId : "";
                let plotAreaMin = filters.plotAreaMin ? filters.plotAreaMin : "";
                let plotAreaMax = filters.plotAreaMax ? filters.plotAreaMax : "";
                let plotWidthMin = filters.plotWidthMin ? filters.plotWidthMin : "";
                let plotWidthMax = filters.plotWidthMax ? filters.plotWidthMax : "";
                let plotDepthMin = filters.plotDepthMin ? filters.plotDepthMin : "";
                let plotDepthMax = filters.plotDepthMax ? filters.plotDepthMax : "";
                let floors = filters.floors ? filters.floors : "";
                let bedrooms = filters.bedrooms ? filters.bedrooms : "";
                let dateFilterOn = filters.dateFilterOn ? filters.dateFilterOn : "";
                let dateFrom = filters.dateFrom ? filters.dateFrom : "";
                let dateTo = filters.dateTo ? filters.dateTo : "";

                if (filesMissing && filesMissing.length) {
                    if (filesMissing.includes("2D-JPG")) {
                        if (!query["$and"]) query["$and"] = [];
                        query["$and"].push(
                            {
                                "files.two_d_rendered_plan_jpg.ground": { $in: [null, [], ""] }
                            },
                            {
                                "files.two_d_rendered_plan_jpg.ground_plus_one": { $in: [null, [], ""] }
                            },
                            {
                                "files.two_d_rendered_plan_jpg.ground_plus_two": { $in: [null, [], ""] }
                            },
                            {
                                "files.two_d_rendered_plan_jpg.ground_plus_three": { $in: [null, [], ""] }
                            },
                            {
                                "files.two_d_rendered_plan_jpg.ground_plus_four": { $in: [null, [], ""] }
                            },
                            {
                                "files.two_d_rendered_plan_jpg.above_ground_plus_four": { $in: [null, [], ""] }
                            },
                            {
                                "files.two_d_rendered_plan_jpg.others": { $in: [null, [], ""] }
                            }
                        );
                    }
                    if (filesMissing.includes("2D-RAW")) {
                        query["files.linked_dwg_file.linked_dwg_file_id"] = { $in: [null, [], ""] };
                    }
                    if (filesMissing.includes("3D-JPG")) {
                        if (!query["$and"]) query["$and"] = [];
                        query["$and"].push(
                            {
                                "files.three_d_design_id.front": { $in: [null, [], ""] }
                            },
                            {
                                "files.three_d_design_id.right_side": { $in: [null, [], ""] }
                            },
                            {
                                "files.three_d_design_id.left_side": { $in: [null, [], ""] }
                            },
                            {
                                "files.three_d_design_id.rear_side": { $in: [null, [], ""] }
                            },
                            {
                                "files.three_d_design_id.internal": { $in: [null, [], ""] }
                            }
                        );
                    }
                    if (filesMissing.includes("3D-RAW")) {
                        query["files.linked_sketch_up_file.sketch_up_file_id"] = { $in: [null, [], ""] };
                    }
                }

                if (status) {
                    if (status == "published") {
                        query["is_approved"] = 1;
                    } else if (status == "unpublished") {
                        query["is_approved"] = 0;
                    }
                }

                if(designType) {                   
                    if (designType == "2d") {
                        query["element_type"] = "Layout";
                    } else if (designType == "3d") {
                        query["element_type"] = "Elevations";
                    } else if(designType == "bundle") {
                        query["element_type"] = "Bundle Elevations";
                    }
                }

                if (designId) {
                    query["$or"] = [];
                    // we need to search SR IDs as well.
                    query["$or"].push(
                        { "unique_id": designId },
                        { "sr_number": designId }
                    );
                }

                if (dateFilterOn) {
                    const fieldMap = {
                        "created": "created_at",
                        "modified": "updated_at",
                        "published": "publish_date"
                    };
                    const fieldName = fieldMap[dateFilterOn];

                    if (fieldName) {
                        // Extend the query object with the date range filter if applicable
                        Object.assign(query, this.createDateRangeFilter(fieldName, dateFrom, dateTo));
                    }
                }

                if (plotAreaMin && plotAreaMax) {
                    query["plot_details.plot_area"] = { $gte: plotAreaMin, $lte: plotAreaMax };
                } else if (plotAreaMin) {
                    query["plot_details.plot_area"] = { $gte: plotAreaMin }
                } else if (plotAreaMax) {
                    query["plot_details.plot_area"] = { $lte: plotAreaMax }
                }

                if (plotWidthMin && plotWidthMax) {
                    query["plot_details.plot_width"] = { $gte: plotWidthMin, $lte: plotWidthMax };
                } else if (plotWidthMin) {
                    query["plot_details.plot_width"] = { $gte: plotWidthMin }
                } else if (plotWidthMax) {
                    query["plot_details.plot_width"] = { $lte: plotWidthMax }
                }

                if (plotDepthMin && plotDepthMax) {
                    query["plot_details.plot_length"] = { $gte: plotDepthMin, $lte: plotDepthMax };
                } else if (plotDepthMin) {
                    query["plot_details.plot_length"] = { $gte: plotDepthMin }
                } else if (plotDepthMax) {
                    query["plot_details.plot_length"] = { $lte: plotDepthMax }
                }

                if (floors) {
                    if (floors >= 7) {
                        query["project_details.no_floors"] = { $gte: floors - 1 }; // Apply $gte condition
                    } else {
                        query["project_details.no_floors"] = floors - 1; // Apply $eq condition
                    }
                }

                if (bedrooms) {
                    if (bedrooms >= 7) {
                        query["project_details.bedrooms"] = { $gte: bedrooms }; // Apply $gte condition
                    } else {
                        query["project_details.bedrooms"] = bedrooms; // Apply $eq condition
                    }
                }
            }
            console.log(JSON.stringify({ file: 'service.js', line: 137, message: `finial query`, query }));
            //to count the documents that match the criteria
            const totalCount = await Design.countDocuments(query);
            const result = await Design.find(query, { "files.three_d_cut_iso_jpg": 0 }).sort({ created_at: -1 }).skip(skipCount).limit(limitCount).exec();
            const S3BaseURL = process.env.S3_BUCKET_PATH ? `${process.env.S3_BUCKET_PATH}/` : 'https://assets-dm.utecbuild.com/';

            if (result === null) return { "response": [], "totalCount": 0, "s3BasePath": S3BaseURL };
            return { "response": result, "totalCount": totalCount, "s3BasePath": S3BaseURL };;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 144, message: error?.message, error }));
            throw error;
        }
    }

    createDateRangeFilter(fieldName, dateFrom, dateTo) {
        if (!dateFrom || !dateTo) {
            // If either dateFrom or dateTo is not provided, return an empty object
            return {};
        }

        return {
            [fieldName]: {
                $gte: new Date(`${dateFrom}T00:00:00.000Z`),
                $lte: new Date(`${dateTo}T23:59:59.999Z`)
            }
        };
    }
}

module.exports = GetDesigns;