const Joi = require("joi");

const schema = Joi.object().keys({
    pagination: Joi.object().keys({
        fetchLimit: Joi.number().required(),
        page: Joi.number().required()
    }).required(),
    filters: Joi.object().keys({
        filesMissing: Joi.array().optional(),
        status: Joi.string().optional().allow(""),
        designType: Joi.string().optional().allow(""),
        designId: Joi.string().optional().allow(""),
        plotAreaMin: Joi.string().optional().allow(""),
        plotAreaMax: Joi.string().optional().allow(""),
        plotWidthMin: Joi.string().optional().allow(""),
        plotWidthMax: Joi.string().optional().allow(""),
        plotDepthMin: Joi.string().optional().allow(""),
        plotDepthMax: Joi.string().optional().allow(""),
        floors: Joi.string().optional().allow(""),
        bedrooms: Joi.string().optional().allow(""),
        dateFrom: Joi.string().optional().when('dateFilterOn', {
            is: Joi.string().not(Joi.valid('')).required(),
            then: Joi.required(),
            otherwise: Joi.optional().allow("")
        }),
        dateTo: Joi.string().optional().when('dateFilterOn', {
            is: Joi.string().not(Joi.valid('')).required(),
            then: Joi.required(),
            otherwise: Joi.optional().allow("")
        }),
        dateFilterOn: Joi.string().valid("created", "modified", "published").optional().allow("")
    }).required().allow({})
});

module.exports = schema;