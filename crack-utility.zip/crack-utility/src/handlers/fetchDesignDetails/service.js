const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
const planStyleDesigns = require('../../models/planStyleDesigns');

class GetDesigns {

    async fetchDesignDetails(requestBody) {
        try {
            let designId = requestBody.designId ? requestBody.designId : 0;
            let query = { "is_active": 1, "unique_id": designId };
            const result = await planStyleDesigns.find(query, { "files.three_d_cut_iso_jpg": 0 }).lean().exec();
            const S3BaseURL = process.env.S3_BUCKET_PATH ? `${process.env.S3_BUCKET_PATH}/` : 'https://assets-dm.utecbuild.com/';
            if (result && result.length) return { "response": result[0], "s3BasePath": S3BaseURL };
            return null;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 19, message: error?.message, error }));
            throw error;
        }
    }

    async fetchDesignDetailsv2(requestBody) {
        try {
            let designId = requestBody?.designId ? Number(requestBody.designId) : 0;
            let userId= requestBody?.userId ? Number(requestBody.userId) :null 
            let query = [
                {
                    "$lookup": {
                        "from": "design_gallery_bookmarks",
                        "localField": "unique_id",
                        "foreignField": "designId",
                        "as": "favInfo"
                    }
                }
                ,
                {
                    "$unwind": {
                        "path": "$favInfo",
                        "preserveNullAndEmptyArrays": true
                    }
                }
                ,
                {
                    "$match": {
                        "is_active": 1,
                        "unique_id": designId
                    }
                },
                {
                    "$project": {
                        "plot_details": 1, "element_type": 1, "files.three_d_cut_iso_jpg": 1, "files.two_d_rendered_plan_jpg": 1, "files.three_d_design_id": 1, "vaastu_compliancy": 1, "unique_id": 1, "project_details": 1, "is_active": 1,
                        "isFav": { $cond: { if: { $and: [{ $eq: ['$favInfo.isBookmark', 1] }, { $eq: ['$favInfo.userId', userId] }] }, then: true, else: false } } 
                    }
                }


            ];
            console.log(JSON.stringify({ file: 'service.js', line: 66, mongoQuery:query }));
            
            const result = await planStyleDesigns.aggregate(query).allowDiskUse(true).exec()
            const S3BaseURL = process.env.S3_BUCKET_PATH ? `${process.env.S3_BUCKET_PATH}/` : 'https://assets-dm.utecbuild.com/';
            console.log(JSON.stringify({ file: 'service.js', line: 68, results:result }));
            
            if (result && result.length) return { "response": result, "s3BasePath": S3BaseURL };
            return null;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 19, message: error?.message, error }));
            throw error;
        }
    }
}

module.exports = GetDesigns;