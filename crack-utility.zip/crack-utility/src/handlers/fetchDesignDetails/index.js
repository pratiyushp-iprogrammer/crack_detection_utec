const BaseResponse = require('../../common/baseResponse');
const HTTP_CODE = require('../../common/constants');
const schema = require('./schema');
const GetDesigns = require('./service');
const service = new GetDesigns();
let baseResponse = new BaseResponse();

exports.handler = async (event) => {
    try {
        const requestBody = event?.queryStringParameters?.jsonQuery ? JSON.parse(event?.queryStringParameters?.jsonQuery) : {};
        console.log(JSON.stringify({ file: 'controller.js', line: 10, requestBody }));
        const isRequestValid = schema.validate(requestBody);
        if (isRequestValid?.error) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, isRequestValid?.error?.details, "Invalid Request");
        }

        if(event.resource === "/v2/fetch-design-details"){
            const designResult = await service.fetchDesignDetailsv2(requestBody);   
            console.log(JSON.stringify({ file: 'controller.js', line: 19, designResult }));
            if (designResult) {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, designResult, 'Design Details Fetched Successfully.');
            } else {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, [], 'Design Details Not Found.');
            }
        }
        const designResult = await service.fetchDesignDetails(requestBody);
        console.log(JSON.stringify({ file: 'controller.js', line: 27, designResult }));
        if (designResult) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, designResult, 'Design Details Fetched Successfully.');
        } else {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, [], 'Design Details Not Found.');
        }
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 26, message: error?.message, error }));
        return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], error);
    }
};