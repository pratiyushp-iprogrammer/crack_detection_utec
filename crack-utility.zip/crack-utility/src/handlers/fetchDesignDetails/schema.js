const Joi = require("joi");

const schema = Joi.object().keys({
    designId: Joi.number().required(),
    userId:Joi.number().optional().allow(null)
});

module.exports = schema;