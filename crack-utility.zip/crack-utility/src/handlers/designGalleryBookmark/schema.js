const Joi = require("joi");

const schema = Joi.object().keys({
uniqueId:Joi.number().required(),
isBookmark:Joi.boolean().required(),
userName:Joi.string().required().allow(""),
platformId:Joi.number().required(),
action:Joi.string().required().valid("bookmark")
});

module.exports = schema;