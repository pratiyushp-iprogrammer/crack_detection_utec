const DBConnector = require('../../common/dbConnector');
const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
if (typeof client === 'undefined') var client = objDatabase.connect();
const dbConnector = new DBConnector();

const Design = require('../../models/designGalleryBookmark');

class GetDesigns {

    async favrouites(requestBody) {
        try {
            let srDetailsQuery = `select ud.mobile,ud.platform_id from user_details ud where ud.user_id=? and ud.is_deleted=0`;
            let result = await dbConnector.queryExecute(srDetailsQuery, [requestBody.userId]);
            console.log("result :",JSON.stringify(result))
            const userDetails = result;
            if (userDetails.length > 0) {
                const result = await this.updateAdminDetails(userDetails[0], requestBody)
                return result
            }
            else {
                throw new Error("data not present ")
            }
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 144, message: error?.message, error }));
            throw error;
        }
    }
    async updateAdminDetails(params, requestBody) {
        try {
            const options = {
                upsert: true, // Create a new document if no document matches the query
                new: true, // Return the updated document
                setDefaultsOnInsert: true // Ensure defaults are applied if upserting
            };
            const filter = {
                userId: requestBody.userId,
                designId: requestBody.uniqueId
            };
            const update = {
                userId: requestBody.userId,
                designId: requestBody.uniqueId,
                userDetails: {
                    userName: requestBody.userName,
                    mobileNumber: JSON.stringify(params.mobileNumber),
                    isAdmin: 0
                },
                platformId: requestBody.platformId,
                action: requestBody.action,
                isBookmark: requestBody.isBookmark
            };
            console.log(JSON.stringify({ file: 'service.js', line: 53, mongoQuery: update}));
            ;
            let result = await Design.findOneAndUpdate(filter, update, options)
            console.log(JSON.stringify({ file: 'service.js', line: 56, resultData:result }));
            
            return result;
        } catch (error) {
            console.log(error);
        }
    }

}

module.exports = GetDesigns;