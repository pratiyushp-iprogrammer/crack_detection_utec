const Joi = require("joi");

const schema = Joi.object({
    designId: Joi.array().required(),
    status: Joi.string().valid("published", "unpublished").required(),
    adminEmail: Joi.string().required()
});

module.exports = schema;