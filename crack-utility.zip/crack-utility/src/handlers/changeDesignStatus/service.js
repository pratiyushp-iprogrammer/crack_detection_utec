const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
const Design = require('../../models/planStyleDesigns');
const LogUserActivity = require('../common/logUserActivity');
const logDownloadInfo = new LogUserActivity();

class UpdateDesigns {
    async changeDesignStatus(requestBody) {
        try {
            let designIds = requestBody.designId ? requestBody.designId : [];
            let adminEmail = requestBody.adminEmail ? requestBody.adminEmail : "";
            let designStatus = requestBody.status ? requestBody.status : "";
            if (!designIds || !designIds.length) {
                throw new Error("designIds required");
            }
            let status, activityName, updateResult;
            if (designStatus == "published") {
                status = 1;
                activityName = "publish";
                updateResult = await Design.updateMany(
                    { unique_id: { $in: designIds } }, // Filter condition
                    { $set: { is_approved: status, publish_date: new Date() } } // Update operation
                );
            } else if (designStatus == "unpublished") {
                status = 0;
                activityName = "unpublish";
                updateResult = await Design.updateMany(
                    { unique_id: { $in: designIds } }, // Filter condition
                    { $set: { is_approved: status, publish_date: null } } // Update operation
                );
            }
            console.log(JSON.stringify({ file: 'service.js', line: 24, message: `updateResult`, updateResult }));
            if (updateResult) {
                let logParams = { designId: designIds, adminEmail, activityName }
                await logDownloadInfo.logUserActivity(logParams);
                return updateResult;
            } else {
                return false;
            }

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 144, message: error?.message, error }));
            throw error;
        }
    };
}

module.exports = UpdateDesigns;