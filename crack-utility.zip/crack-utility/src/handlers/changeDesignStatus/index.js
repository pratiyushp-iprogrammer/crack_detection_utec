const BaseResponse = require('../../common/baseResponse');
const HTTP_CODE = require('../../common/constants');
const schema = require('./schema');
const UpdateDesigns = require('./service');
const service = new UpdateDesigns();
let baseResponse = new BaseResponse();

exports.handler = async (event) => {
    try {
        const requestBody = typeof event?.body === 'string' ? JSON.parse(event.body) : event?.body || {};
        if (event.requestContext.authorizer) {
            let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            requestBody.adminEmail = authorizerResponse?.email || "";
        }
        console.log(JSON.stringify({ file: 'index.js', line: 15, requestBody }));
        const isRequestValid = schema.validate(requestBody);
        if (isRequestValid?.error) {
            console.log(JSON.stringify({ file: 'index.js', comment: "Validation Error ", line: 14, isRequestValid: isRequestValid }));
            return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, isRequestValid?.error?.details, "Invalid Request");
        }
        const result = await service.changeDesignStatus(requestBody);
        if (!result) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, [], 'Unable to Update Design Status.');
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Design Status Updated Successfully');
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 26, message: error?.message, error }));
        return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], error);
    }
};