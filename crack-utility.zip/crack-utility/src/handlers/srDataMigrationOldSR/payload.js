const payload = {
    // "unique_id": null,
    // "element_type": null,
    // "sr_number": null,
    // "option_number": null,
    "files": {
        "two_d_rendered_plan_jpg": {
            "ground": null,
            "ground_plus_one": null,
            "ground_plus_two": null,
            "ground_plus_three": null,
            "ground_plus_four": null,
            "above_ground_plus_four": null,
            "others": null
        },
        "two_d_rendered_plan_pdf": {
            "two_d_rendered_plan_pdf_link": null
        },
        "three_d_design_id": {
            "front": null,
            "right_side": null,
            "left_side": null,
            "rear_side": null,
            "internal": null
        },
        "three_d_cut_iso_jpg": {
            "ground": null,
            "ground_plus_one": null,
            "ground_plus_two": null,
            "ground_plus_three": null,
            "ground_plus_four": null,
            "above_ground_plus_four": null,
            "others": null
        },
        "three_d_delivery_pdf" : {
            "three_d_delivery_pdf_link": null,
       },
        // "linked_estimation_id": {
        //     "estimation_id": null
        // },
        "linked_sketch_up_file": {
            "sketch_up_file_id": null
        },
        "linked_dwg_file": {
            "linked_dwg_file_id": null
        },
        // "linked_psd_file": {
        //     "linked_psd_file_id": null
        // },
    }
}

module.exports = payload;