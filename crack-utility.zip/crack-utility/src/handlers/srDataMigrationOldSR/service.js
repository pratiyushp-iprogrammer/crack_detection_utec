const DatabaseSql = require('./db/mysql-conn');
const dbConnector = new DatabaseSql();
const DatabaseMongo = require('./db/docdb-conn');
const PlanStyleDesigns = require('./models/planStyleDesigns');
let payload = require('./payload');
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: 'ap-south-1'});
const v8 = require('v8');
const { ENV = "dev" } = process.env;
const buckets = {
    "dev": {
        source: "utec-test-container",
        destination: "design-management-test"
    },
    "stage": {
        source: "utec-stage-container",
        destination: "design-management-stage"
    },
    "preprod": {
        source: "utec-stage-container",
        destination: "design-management-stage"
    },
    "production": {
        source: "utec-prod-container",
        destination: "design-management-prod"
    }
}

const domain = {
    "dev": {
        name: "dm8w611fhi3t8.cloudfront.net",
        cloudFrontURL: "dm8w611fhi3t8.cloudfront.net"
    },
    "stage": {
        name: "d1m14n9wult4fq.cloudfront.net",
        cloudFrontURL: "d1m14n9wult4fq.cloudfront.net"
    },
    "preprod": {
        name: "d1m14n9wult4fq.cloudfront.net",
        cloudFrontURL: "d1m14n9wult4fq.cloudfront.net"
    },
    "production": {
        name: "assets-utec.utecbuild.com",
        cloudFrontURL: "d2l724nx2yy7j2.cloudfront.net"
    }
}

class srDataMigration {
    async dataTransfer(startDesignId, endDesignId) {
        try {
            const mongoConnInstance = new DatabaseMongo();
            await mongoConnInstance.connect()

            let fileMappings = [];
            let domainInfo = domain[ENV];
            if (!domainInfo) throw new Error("no domain information specified");
            let domainName = domainInfo.name;
            let cloudURL = domainInfo.cloudFrontURL;
            let startId = startDesignId ? parseInt(startDesignId) : 0;
            let endId = endDesignId ? parseInt(endDesignId) : 0;
            for (let i = 0; i <= endId-startId; i++) {
                let nextUniqueId = startId + i;
                let [initialResult = null] = await PlanStyleDesigns.find({ unique_id: nextUniqueId });
                if (!initialResult || !initialResult.unique_id || !initialResult.sr_number) {
                    console.log(JSON.stringify({ file: 'service.js', line: 65, msg: `unique_id ${nextUniqueId} or sr_number ${initialResult.sr_number} is not found` }));
                    continue;
                }
                let srNumber = initialResult?.sr_number;

                let query = `SELECT * FROM temp_DM_SrMigration WHERE sr_id = ${srNumber};`;
                let srMigration = await dbConnector.queryExecute(query, []);
                if (!srMigration || !srMigration.length) {
                    console.log(JSON.stringify({ file: 'service.js', line: 73, msg: `temp_DM_SrMigration sr_number ${srNumber} is not found` }));
                    continue;
                }
                let result = srMigration[0];
                let transformedData = [];
                let isUtecContainerImage = true;
                // for (let result of srMigration) {
                let obj = v8.deserialize(v8.serialize(payload));
                // obj.sr_number = result?.sr_id;
                if (result?.delivery?.length) {
                    let resultObject = await this.getFilesFiltered(result.delivery);
                    for (let delivery of resultObject) {
                        if (result?.request_type_id == "18") {
                            if (delivery?.files) {
                                obj.files = v8.deserialize(v8.serialize(obj.files));
                                let groundFloor = [], groundPlusOne = [], groundPlusTwo = [], groundPlusThree = [], groundPlusFour = [], groundPlusFive = [], twoDPdf = [], linkedDwg = [];
                                for (let value of delivery.files) {
                                    // Check if the lowercase URL includes the lowercase specific part
                                    if (!value?.link?.toLowerCase().includes(domainName) && !value?.link?.toLowerCase().includes(cloudURL)) {
                                        isUtecContainerImage = false;
                                    }

                                    if (value?.category === "Ground Floor Design") {
                                        groundFloor.push(value?.link);
                                    } else if (value?.category === "First Floor Design") {
                                        groundPlusOne.push(value?.link);
                                    } else if (value?.category === "Second Floor Design") {
                                        groundPlusTwo.push(value?.link);
                                    } else if (value?.category === "Third Floor Design") {
                                        groundPlusThree.push(value?.link);
                                    } else if (value?.category === "Fourth Floor Design") {
                                        groundPlusFour.push(value?.link);
                                    } else if (value?.category === "Fifth Floor Design") {
                                        groundPlusFive.push(value?.link);
                                    } else if (value?.category === "Pdf File") {
                                        twoDPdf.push(value?.link);
                                    } else if (value?.category === "Raw File") {
                                        linkedDwg.push(value?.link);
                                    }
                                }
                                obj.files.two_d_rendered_plan_jpg.ground = groundFloor;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_one = groundPlusOne;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_two = groundPlusTwo;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_three = groundPlusThree;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_four = groundPlusFour;
                                obj.files.two_d_rendered_plan_jpg.above_ground_plus_four = groundPlusFive;
                                obj.files.two_d_rendered_plan_pdf.two_d_rendered_plan_pdf_link = twoDPdf;
                                obj.files.linked_dwg_file.linked_dwg_file_id = linkedDwg;
                            }
                        } else {
                            /* Files*/
                            if (delivery?.files) {
                                obj.files = v8.deserialize(v8.serialize(obj.files));
                                let groundIso = [], firstIso = [], secondIso = [], thirdIso = [], fourthIso = [], fifthIso = [], rawIso = [], pdfIso = [];
                                for (let value of delivery.files) {

                                    // Check if the lowercase URL includes the lowercase specific part
                                    if (!value?.link?.toLowerCase().includes(domainName) && !value?.link?.toLowerCase().includes(cloudURL)) {
                                        isUtecContainerImage = false;
                                    }

                                    if (value?.category === "Front Elevation") {
                                        obj.files.three_d_design_id.front = value?.link || null;
                                    } else if (value?.category === "Right Elevation") {
                                        obj.files.three_d_design_id.right_side = value?.link || null;
                                    } else if (value?.category === "Left Elevation") {
                                        obj.files.three_d_design_id.left_side = value?.link || null;
                                    } else if (value?.category === "Rear Elevation") {
                                        obj.files.three_d_design_id.rear_side = value?.link || null;
                                    } else if (value?.category === "Internal Elevation") {
                                        obj.files.three_d_design_id.internal = value?.link || null;
                                    } else if (value?.category === "Ground Floor Cut-Iso") {
                                        groundIso.push(value?.link);
                                    } else if (value?.category === "First Floor Cut-Iso") {
                                        firstIso.push(value?.link);
                                    } else if (value?.category === "Second Floor Cut-Iso") {
                                        secondIso.push(value?.link);
                                    } else if (value?.category === "Third Floor Cut-Iso") {
                                        thirdIso.push(value?.link);
                                    } else if (value?.category === "Fourth Floor Cut-Iso") {
                                        fourthIso.push(value?.link);
                                    } else if (value?.category === "Fifth Floor Cut-Iso") {
                                        fifthIso.push(value?.link);
                                    } else if (value?.category === "Raw File") {
                                        rawIso.push(value?.link);
                                    } else if (value?.category === "Pdf File") {
                                        pdfIso.push(value?.link);
                                    }
                                }
                                obj.files.three_d_cut_iso_jpg.ground = groundIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_one = firstIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_two = secondIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_three = thirdIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_four = fourthIso;
                                obj.files.three_d_cut_iso_jpg.above_ground_plus_four = fifthIso;
                                obj.files.linked_sketch_up_file.sketch_up_file_id = rawIso;
                                obj.files.three_d_delivery_pdf.three_d_delivery_pdf_link = pdfIso;
                            }
                        }

                        if (isUtecContainerImage) {
                            // obj.option_number = delivery.options || null;
                            transformedData.push({ ...obj });
                        } else {
                            continue;
                        }
                    }
                } else {
                    transformedData.push({ ...obj });
                }
                // };
                console.log(JSON.stringify({ file: 'service.js', line: 184, msg: 'data has old images or not', dataCount: transformedData.length }));
                // let mergedObjects = await this.mergeObjectsWithCommonSrNumber(transformedData);
                // console.log(JSON.stringify({ file: 'service.js', line: 400, dataCount: mergedObjects.length }));
                if (transformedData.length > 0) {
                    for (let i = 0; i < transformedData.length; i++) {
                        // Define the properties to process dynamically
                        const propertiesToProcess = [
                            'two_d_rendered_plan_jpg.ground',
                            'two_d_rendered_plan_jpg.ground_plus_one',
                            'two_d_rendered_plan_jpg.ground_plus_two',
                            'two_d_rendered_plan_jpg.ground_plus_three',
                            'two_d_rendered_plan_jpg.ground_plus_four',
                            'two_d_rendered_plan_jpg.above_ground_plus_four',
                            'two_d_rendered_plan_pdf.two_d_rendered_plan_pdf_link',
                            'linked_dwg_file.linked_dwg_file_id',
                            'three_d_cut_iso_jpg.ground',
                            'three_d_cut_iso_jpg.ground_plus_one',
                            'three_d_cut_iso_jpg.ground_plus_two',
                            'three_d_cut_iso_jpg.ground_plus_three',
                            'three_d_cut_iso_jpg.ground_plus_four',
                            'three_d_cut_iso_jpg.above_ground_plus_four',
                            'linked_sketch_up_file.sketch_up_file_id',
                            'three_d_delivery_pdf.three_d_delivery_pdf_link',
                            'three_d_design_id.front',
                            'three_d_design_id.right_side',
                            'three_d_design_id.left_side',
                            'three_d_design_id.rear_side',
                            'three_d_design_id.internal'
                        ];

                        // Process each property dynamically
                        propertiesToProcess.forEach(property => {
                            let splitProperty = property.split('.');
                            let propertyValue = transformedData[i].files[splitProperty[0]][splitProperty[1]];
                            if (Array.isArray(propertyValue)) {
                                // Handle arrays
                                transformedData[i].files[property] = propertyValue.map(item => {
                                    let imageLink = null;
                                    imageLink = item ? item : null;
                                    if (imageLink) {
                                        let imageArray = imageLink.split("/");
                                        let arrayLength = imageArray.length;
                                        let folderName = (imageArray[arrayLength - 3] && imageArray[arrayLength - 3] != domainName && imageArray[arrayLength - 3] != cloudURL && imageArray[arrayLength - 3] != '/') ? imageArray[arrayLength - 3] : "oldImages";
                                        imageLink = `delivery_catalog/${nextUniqueId}/${folderName}/${imageArray[arrayLength - 1]}`;
                                        fileMappings.push({
                                            sourceKey: item,
                                            destinationKey: imageLink
                                        });
                                    }
                                    return imageLink; // Return the modified value
                                });

                            } else if (typeof propertyValue === 'string') {
                                // Handle strings
                                let imageLink = null;
                                imageLink = propertyValue ? propertyValue : null;
                                if (imageLink) {
                                    let imageArray = imageLink.split("/");
                                    let arrayLength = imageArray.length;
                                    let folderName = (imageArray[arrayLength - 3] && imageArray[arrayLength - 3] != domainName && imageArray[arrayLength - 3] != cloudURL && imageArray[arrayLength - 3] != '/') ? imageArray[arrayLength - 3] : "oldImages";
                                    imageLink = `delivery_catalog/${nextUniqueId}/${folderName}/${imageArray[arrayLength - 1]}`;
                                    fileMappings.push({
                                        sourceKey: propertyValue,
                                        destinationKey: imageLink
                                    });
                                }
                                transformedData[i].files[property] = imageLink;
                            }
                        });
                        await this.updateDesign(nextUniqueId, transformedData[i]);
                    }

                    // promiseResult.forEach((result, index) => {
                    //     if (result.status === 'fulfilled') {
                    //         console.log(`Promise ${index + 1} resolved: ${result.value}`);
                    //     } else {
                    //         console.error(`Promise ${index + 1} rejected: ${result.reason}`);
                    //     }
                    // });
                    // return true;
                    // const batchSize = 50; // Set an appropriate batch size
                    // for (let i = 0; i < mergedObjects.length; i += batchSize) {
                    //     const batch = mergedObjects.slice(i, i + batchSize);
                    // await this.insertion(batch);
                    // }
                    // return true;

                    // else {
                    //     return false;
                    // }

                }
                continue;
            }

            console.log(JSON.stringify({ file: 'service.js', line: 286, msg: "Data updation done, S3 file upload started" }));

            let batch = fileMappings.length / 5000;
            let finalResolution = [];

            for (let i = 0; i <= batch; i++) {
                let slicedArray = fileMappings.slice(i * 5000, 5000 * (i + 1));
                let promiseResult = await this.copyS3Files(slicedArray); //file copy from one bucket to other bucket
                finalResolution.push(promiseResult);
                console.log(JSON.stringify({ file: 'service.js', line: 288, promiseResult: promiseResult.length }));
            }

            console.log(finalResolution);
            // console.log(JSON.stringify({ file: 'service.js', line: 292, finalResolution: finalResolution.length }));
        }
        catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 295, message: error.message, error }));
            throw error;
        }
    }

    async updateDesign(designId, filesData) {
        try {
            let result = await PlanStyleDesigns.updateOne({ unique_id: designId }, {
                $set: { ...filesData }
            })
            return result;
        } catch (error) {
            console.log(JSON.stringify({ line: 315, message: error?.message, error }));
            throw error;
        }
    }

    getFilesFiltered(data) {
        if (data.length == 1 && data[0].files === null && data[0].isDeleted === null && data[0].iterationCount === null && [1, '1'].includes(data[0].options)) {
            return data;
        }
        const modified = data.map(el => {
            const filtered = el.files.filter(file => file.isDeleted === 0)
            return ({ ...el, files: filtered })
        })
        return modified;
    }

    copyS3Files(fileMappings) {
        let bucketInfo = buckets[ENV];
        if (!bucketInfo) throw new Error("no bucket information specified");
        let sourceBucket = bucketInfo.source;
        let destinationBucket = bucketInfo.destination;
        let domainInfo = domain[ENV];
        if (!domainInfo) throw new Error("no domain information specified");
        let domainName = domainInfo.name;
        let cloudURL = domainInfo.cloudFrontURL;
        // Use Promise.all to parallelize the copy operations
        const copyPromises = fileMappings.map((mapping) => {
            let withoutDomain = mapping.sourceKey.replace('https://'+ cloudURL +'/', '');
            let stringWithoutUrls = withoutDomain.replace('https://'+ domainName +'/', '');
            const params = {
                CopySource: `/${sourceBucket}/${stringWithoutUrls}`,
                Bucket: destinationBucket,
                Key: mapping.destinationKey
            };

            // return new Promise((resolve, reject) => {
            //     s3.copyObject(params, (err, data) => {
            //         if (err) {
            //             reject(`Error copying file ${mapping.sourceKey}: ${err}`);
            //         } else {
            //             resolve(`File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`);
            //         }
            //     });
            // });
            let copyObjectCommand = new CopyObjectCommand(params);    
            return s3Client.send(copyObjectCommand)
                .then((data) => {
                    return `File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`;
                })
                .catch((err) => {
                    throw new Error(`Error copying file ${mapping.sourceKey}: ${err.message}`);
                });
        });

        return Promise.allSettled(copyPromises)
        // .then((results) => {
        //     console.log(results);
        // })
        // .catch((error) => {
        //     console.error(error);
        // });
    }

}

module.exports = srDataMigration;
