const mongoose = require('mongoose');
const {CONN_STRING, USER, PWD} = process.env;
const path = require('path')

class Database {
	connect(
		dbConnString = CONN_STRING,
		authSource = 'admin',
		user = USER,
		pwd = PWD
	) {
		try {
			const connectionConfig = {
				useNewUrlParser: true,
				useUnifiedTopology: true,
				retryWrites: false,
				authSource: authSource,
				user: user,
				pass: pwd,
				// poolSize: poolSize
			};
			// const env_deploy = process.env.DEPLOYMENT;
			dbConnString = `mongodb://${dbConnString}/plansManagement?retryWrites=false&maxPoolSize=10`;
			console.log(dbConnString);

			let ca = path.join(__dirname, '/ca.pem');
			// connectionConfig.ssl = true;
			// connectionConfig.sslValidate = true;
			// connectionConfig.sslCA = ca;
			connectionConfig.tlsInsecure = false;
			connectionConfig.tls = true;
			connectionConfig.tlsCAFile = ca;

			console.log(dbConnString);
			console.log(JSON.stringify(connectionConfig));

			return mongoose.connect(dbConnString, connectionConfig);
		} catch (err) {
			console.log(err);
			return err;
		}
	}
}
module.exports = Database;
