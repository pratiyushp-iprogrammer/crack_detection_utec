const mysql = require('mysql2');

const {DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, DB_PORT} = process.env;
// create the connection
const pool = mysql.createPool({
    host: DB_HOST,
    database: DB_NAME,
    user: DB_USER,
    password: DB_PASSWORD,
    port: DB_PORT
});

class Database {

    queryExecute = async (query, params) => {
        try {
            const promisePool = pool.promise();
            const [queryResult] = await promisePool.query(query, params);
            if (!queryResult) {
                return false;
            }
            return queryResult;
        } catch (error) {
            console.log("Error in dbConnector file: ", error);
            throw error;
        }

    }
}
module.exports = Database;
