const srDataTransfer = require('./service');
const service = new srDataTransfer;
const { STARTID, ENDID } = process.env;

async function execute() {
    try {
        const tranferResult = await service.dataTransfer(STARTID, ENDID);
        return tranferResult;
    } catch (error) {
        throw error;
    }
}

execute().then(response => {
    console.log(JSON.stringify({ file: 'index.js', line: 14, tranferResult: response }));
}).catch(error => {
    console.log(JSON.stringify({ file: 'index.js', line: 16, error }));
})