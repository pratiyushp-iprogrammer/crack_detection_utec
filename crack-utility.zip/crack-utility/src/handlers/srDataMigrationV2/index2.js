const srDataTransfer = require('./service2');
const service2 = new srDataTransfer;
// const {LIMIT, OFFSET} = process.env;

async function execute() {
    try {
        // const params = {fetchLimit: LIMIT, fetchOffset: OFFSET};
        const tranferResult = await service2.dataTransfer();
        return tranferResult;
    } catch (error) {
        throw error;
    }
}

execute().then(response=>{
    console.log(JSON.stringify({ file: 'index2.js', line: 14, tranferResult: response }));
}).catch(error=>{
    console.log(JSON.stringify({ file: 'index2.js', line: 16, error }));
})