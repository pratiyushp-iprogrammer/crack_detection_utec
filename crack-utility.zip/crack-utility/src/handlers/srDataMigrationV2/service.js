const Database = require('./db/mysql-conn');
const dbConnector = new Database();

class srDataMigration {
    async dataInsert(params) {
        try {
            let procedureQuery = `CALL sqlToMongoMigration(?);`;
            let paramsString  = `{"OFFSET":${params.insertOffset},"LIMIT":${params.insertLimit}}`;
            let srMigration = await dbConnector.queryExecute(procedureQuery, [paramsString]);
            console.log(JSON.stringify({ file: 'service.js', line: 10, data: srMigration }));
            return srMigration;
        }
        catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 14, message: error.message, error }));
            throw error;
        }
    }
}

module.exports = srDataMigration;