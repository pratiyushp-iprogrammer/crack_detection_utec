const DatabaseSql = require('./db/mysql-conn');
const dbConnector = new DatabaseSql();
const DatabaseMongo = require('./db/docdb-conn');
const Design = require('./models/planStyleDesigns');
let payload = require('./payload');
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const v8 = require('v8');

class srDataMigration {
    async dataTransfer(params) {
        try {

            const mongoConnInstance = new DatabaseMongo();
            await mongoConnInstance.connect()

            // let query = `SELECT * FROM temp_DM_SrMigration LIMIT ? OFFSET ?;`;
            const query = `
                WITH jd_data AS (
                    SELECT
                        srd.sr_id AS sr_id,
                        srd.sr_info as sr_info, 
                        srd.linked_id as linked_id, 
                        srd.request_type_id as request_type_id,
                        srd.latitude as latitude,
                        srd.longitude as longitude,
                        srd.geo_pincode as geo_pincode,
                        srd.district_name as district_name,
                        srd.city_name as city_name,
                        srd.state_name as state_name,
                        jd.isDeleted, 
                        jd.iterationCount, 
                        jd.options, 
                        jd.files, 
                        MAX(jd.iterationCount) OVER (PARTITION BY srd.sr_id) AS max_count
                    FROM temp_DM_SrMigration srd
                    LEFT JOIN JSON_TABLE(srd.delivery, '$[*]'
                        COLUMNS (
                            files json PATH '$.files',
                            iterationCount INT PATH '$.iterationCount',
                            options VARCHAR(50) PATH '$.options',
                            isDeleted INT PATH '$.isDeleted'
                        )
                    ) AS jd ON 1 = 1
                    WHERE (jd.isDeleted = 0 OR jd.isDeleted IS NULL)
                )
                SELECT 
                    sr_id, 
                    sr_info,
                    linked_id,
                    request_type_id,
                    latitude,
                    longitude,
                    geo_pincode,
                    district_name,
                    city_name,
                    state_name,
                    JSON_ARRAYAGG(
                        JSON_OBJECT(
                        'files', files, 
                        'options', CASE
                            WHEN options = 'option1' OR options = '' OR options IS NULL THEN 1
                            WHEN options = 'option2' THEN 2
                            WHEN options = 'option3' THEN 3
                            ELSE options
                        END, 
                        'iterationCount', iterationCount, 
                        'isDeleted', isDeleted
                        )
                    ) AS delivery
                FROM jd_data
                WHERE (iterationCount = max_count) OR (iterationCount IS NULL AND max_count IS NULL)
                GROUP BY sr_id
            `

            let srMigration = await dbConnector.queryExecute(query, []);
            const transformedData = [];
            let fileMappings = [];
            for (let result of srMigration) {
                let obj = v8.deserialize(v8.serialize(payload));
                obj.sr_number = result?.linked_id ? result?.linked_id : result?.sr_id;
                // obj.is_active = 0;
                obj.source = "Service Request";
                /* Plot Details */
                result?.sr_info?.plotDimensions?.plotArea ? obj.plot_details.plot_area = result?.sr_info?.plotDimensions?.plotArea : null;
                result?.sr_info?.plotDimensions?.plotAreaUnit ? obj.plot_details.plot_area_unit = result?.sr_info?.plotDimensions?.plotAreaUnit : null;
                result?.sr_info?.plotDimensions?.plotLength ? obj.plot_details.plot_length = result?.sr_info?.plotDimensions?.plotLength : null;
                let plotLength = result?.sr_info?.plotDimensions?.plotArea / result?.sr_info?.plotDimensions?.plotWidth;
                obj.plot_details.plot_length = plotLength ? plotLength.toFixed(2) : null;
                result?.sr_info?.plotDimensions?.plotWidth ? obj.plot_details.plot_width = result?.sr_info?.plotDimensions?.plotWidth : null;
                result?.sr_info?.plotDimensions?.plotWidthUnit ? obj.plot_details.plot_length_width_unit = result?.sr_info?.plotDimensions?.plotWidthUnit : null;
                result?.sr_info?.plotDimensions?.plotShape ? obj.plot_details.plot_shape = result?.sr_info?.plotDimensions?.plotShape : null;
                result?.sr_info?.sideGap?.one ? obj.plot_details.front_set_back = result?.sr_info?.sideGap?.one : null;
                result?.sr_info?.sideGap?.two ? obj.plot_details.right_set_back = result?.sr_info?.sideGap?.two : null;
                result?.sr_info?.sideGap?.three ? obj.plot_details.rear_set_back = result?.sr_info?.sideGap?.three : null;
                result?.sr_info?.sideGap?.four ? obj.plot_details.left_set_back = result?.sr_info?.sideGap?.four : null;
                let plotSideFacing = 0, sharedWall = 0;

                if (result?.sr_info?.plotSideFacing) {
                    for (let key in result?.sr_info?.plotSideFacing) {
                        if (result?.sr_info?.plotSideFacing[key] === "Vacant Plot") {
                            plotSideFacing += 1;
                        }
                        if (result?.sr_info?.plotSideFacing[key]?.includes("Shared Wall")) {
                            sharedWall = 1;
                        }
                    }

                    obj.plot_details.open_sides_of_the_plot = plotSideFacing;
                }
                obj.project_details.shared_wall = sharedWall;

                /* Project Details */
                result?.sr_info?.purposeOfHomeBuilding ? obj.project_details.typology = result?.sr_info?.purposeOfHomeBuilding : null;
                // result?.total_built_up_area ? obj.project_details.builtup_area = result?.total_built_up_area : null;
                result?.sr_info?.houseDetails?.floorCount ? obj.project_details.floors = result?.sr_info?.houseDetails?.floorCount : null;
                // result?.sr_info?.projectDetails?.numberOfBedRooms ? obj.project_details.bedrooms = result?.sr_info?.projectDetails?.numberOfBedRooms : null;
                if (result?.sr_info?.houseDetails?.floorCount != null) {
                    let floorCase = result?.sr_info?.houseDetails?.floorCount?.toLowerCase();
                    floorCase = floorCase.replace(/\s/g,'');
                    const floorCountMap = {
                        'groundfloor': 0,
                        'ground+1floor': 1,
                        'ground+2floors': 2,
                        'ground+3floors': 3,
                        'ground+4floors': 4,
                        'ground+5floors': 5,
                        'stiltfloor': 0,
                        'stilt+1floor': 1,
                        'stilt+2floors': 2,
                        'stilt+3floors': 3,
                        'stilt+4floors': 4,
                        'stilt+5floors': 5,
                    };
                    obj.project_details.no_floors = floorCountMap[floorCase] !== undefined ? floorCountMap[floorCase] : null;
                }
                if (result?.sr_info?.plotDetails?.stairCaseType) {
                    if (result?.sr_info?.plotDetails?.stairCaseType?.includes("External")) {
                        obj.project_details.staircase_external = 1;
                        obj.project_details.staircase_internal = 0;
                    } else if (result?.sr_info?.plotDetails?.stairCaseType?.includes("Internal")) {
                        obj.project_details.staircase_external = 0;
                        obj.project_details.staircase_internal = 1;
                    }
                }
                let longitude = 0;
                let latitude = 0;
                result?.latitude ? latitude = result?.latitude : 0;
                result?.longitude ? longitude = result?.longitude : 0;
                result?.state_name ? obj.geography.state = result?.state_name : null;
                result?.city_name ? obj.geography.city = result?.city_name : null;
                result?.district_name ? obj.geography.district = result?.district_name : null;
                obj.geography.geo_coordinates = `${latitude},${longitude}`;
                result?.geo_pincode ? obj.geography.pincode = result?.geo_pincode : null;
                /* Family Details */
                result?.sr_info?.familyDetails?.memberCount ? obj.family_details.total_family_members = result?.sr_info?.familyDetails?.memberCount : null;
                result?.sr_info?.familyDetails?.seniorCitizens ? obj.family_details.number_of_senior_citizen = result?.sr_info?.familyDetails?.seniorCitizens : null;
                result?.sr_info?.familyDetails?.adults ? obj.family_details.number_of_adults = result?.sr_info?.familyDetails?.adults : null;
                result?.sr_info?.familyDetails?.kids ? obj.family_details.number_of_children = result?.sr_info?.familyDetails?.kids : null;
                result?.sr_info?.familyDetails?.infants ? obj.family_details.number_of_infants = result?.sr_info?.familyDetails?.infants : null;

                /* Parking */
                result?.sr_info?.bikeParking?.numberOfBikes || result?.sr_info?.bikeParking?.numberOfBikes === 0 ? obj.parking.two_wheeler_parking = !isNaN(Number(result?.sr_info?.bikeParking?.numberOfBikes)) ? Number(result?.sr_info?.bikeParking?.numberOfBikes) : null : null;
                result?.sr_info?.carParking?.numberOfCars || result?.sr_info?.carParking?.numberOfCars === 0 ? obj.parking.four_wheeler_parking = !isNaN(Number(result?.sr_info?.carParking?.numberOfCars)) ? Number(result?.sr_info?.carParking?.numberOfCars) : null : null;

                /* Senior citizen friendly */
                result?.sr_info?.plotDetails?.specialRequirement?.includes("Wheelchair Ramp") ? obj.senior_citizen_friendly.provision_of_ramp = "Yes" : "No";

                /* Room */
                let senior_citizen = 0;
                let roomsWithRoomCountOne, numberOfBedRooms = 0;
                if (result?.sr_info?.houseDetails?.roomCount) {
                    roomsWithRoomCountOne = Object.entries(result?.sr_info?.houseDetails?.roomCount)
                        .reduce((rooms, [floor, floorRooms]) => {
                            const mappedRoom = {
                                index: null,
                                total_bathrooms: null,
                                attached_bathrooms: null,
                                split_bathrooms: null,
                                combined_bathrooms: null,
                                common_bathrooms: null,
                                dining_room: null,
                                living_room: null,
                                kitchen: null,
                                master_bedroom: null,
                                family_room: null,
                                store_room: null,
                                pooja_room: null,
                                shops: null
                            };
                            if (floor === "groundFloor") {
                                mappedRoom.index = 0;
                            } else if (floor === "firstFloor") {
                                mappedRoom.index = 1;
                            } else if (floor === "secondFloor") {
                                mappedRoom.index = 2;
                            } else if (floor === "thirdFloor") {
                                mappedRoom.index = 3;
                            } else if (floor === "fourthFloor") {
                                mappedRoom.index = 4;
                            } else if (floor === "fifthFloor") {
                                mappedRoom.index = 5;
                            }

                            floorRooms.forEach(room => {
                                if (room?.roomName === "Common Bathroom" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.common_bathrooms = room.roomCount;
                                    mappedRoom.total_bathrooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Shop" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.shops = room.roomCount;
                                }
                                if (room?.roomName === "Separate Bathroom & Toilet" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.split_bathrooms = room.roomCount;
                                    mappedRoom.total_bathrooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Bedroom" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.family_room = room.roomCount;
                                    numberOfBedRooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Dining Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.dining_room = room.roomCount;
                                }
                                if (room?.roomName === "Kitchen" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.kitchen = room.roomCount;
                                }
                                if (room?.roomName === "Living Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.living_room = room.roomCount;
                                }
                                if (room?.roomName === "Master Bedroom" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.master_bedroom = room.roomCount;
                                    numberOfBedRooms += parseInt(room.roomCount);
                                }
                                if (room?.roomName === "Pooja Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.pooja_room = room.roomCount;
                                }
                                if (room?.roomName === "Store Room" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.store_room = room.roomCount;
                                }
                                if (room?.roomName === "Wash Area" && parseInt(room?.roomCount) > 0) {
                                    mappedRoom.combined_bathrooms = room.roomCount;
                                }
                                if ((room?.roomName === "Common Bathroom" || room?.roomName === "Separate Bathroom & Toilet") && room?.floorNumber === "groundFloor" && parseInt(room?.roomCount) > 0) {
                                    senior_citizen += 1;
                                }
                                if ((room?.roomName === "Bedroom" || room?.roomName === "Master Bedroom") && room?.floorNumber === "groundFloor" && parseInt(room?.roomCount) > 0) {
                                    senior_citizen += 1;
                                }
                                if (room?.roomName === "Kitchen" && room?.floorNumber === "groundFloor" && parseInt(room?.roomCount) > 0) {
                                    senior_citizen += 1;
                                }

                                obj.open_areas_configuration.balcony = room?.roomName === "Balcony" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.porch = room?.roomName === "Porch" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.verandah = room?.roomName === "Verandah" && parseInt(room?.roomCount) > 0 && result?.request_type_id == "18" ? "Yes" : "No";


                                obj.open_areas_configuration.garden = room?.roomName === "Garden" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.courtyard = room?.roomName === "Courtyard" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.frontyard = room?.roomName === "Frontyard" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.backyard = room?.roomName === "Backyard" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.terrace = room?.roomName === "Terrace" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.open_areas_configuration.type_of_entrance = room?.roomName === "Type Of Entrance" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.special_amenities.library = room?.roomName === "Library" && parseInt(room?.roomCount) > 0 && result?.request_type_id == "18" ? "Yes" : "No";

                                obj.special_amenities.home_theatre = room?.roomName === "Home Theatre" && parseInt(room?.roomCount) > 0 && result?.request_type_id == "18" ? "Yes" : "No";

                                obj.special_amenities.pool = room?.roomName === "Pool" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.special_amenities.gym = room?.roomName === "Gym" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.special_amenities.study_room = room?.roomName === "Study Room" && parseInt(room?.roomCount) > 0 ? "Yes" : "No";

                                obj.special_amenities.game_room = room?.roomName === "Game Room" && parseInt(room?.roomCount) > 0 && result?.request_type_id == "18" ? "Yes" : "No";
                            });

                            return rooms.concat(mappedRoom);
                        }, []);
                    roomsWithRoomCountOne = roomsWithRoomCountOne.sort((obj1, obj2) => obj1.index - obj2.index);
                };
                if (result?.request_type_id == "18") {
                    obj.rooms = roomsWithRoomCountOne;
                    obj.project_details.bedrooms = numberOfBedRooms ? numberOfBedRooms : null;
                    result?.sr_info?.mainRoadDirection?.value ? obj.vaastu_compliancy.entry_direction = result?.sr_info?.mainRoadDirection?.value : null;

                } else {
                    obj.rooms = null;
                    obj.project_details.bedrooms = null;
                    obj.element_type = "Elevations";
                    /* Roof */
                    result?.sr_info?.projectDetails?.roofType ? obj.roof.roof_type = result?.sr_info?.projectDetails?.roofType : null;
                    let color = "";

                    if (result?.sr_info?.color?.primary?.name && result.sr_info.color.primary.name !== "No preferences") {
                        color += result.sr_info.color.primary.name;
                    }

                    if (result?.sr_info?.color?.secondary?.name && result.sr_info.color.secondary.name !== "No preferences") {
                        if (color) {
                            color += `,${result.sr_info.color.secondary.name}`;
                        } else {
                            color += result.sr_info.color.secondary.name;
                        }
                    }

                    if (color) obj.colors.color_used = color;
                }
                obj.senior_citizen_friendly.one_bhk_on_ground_floor = senior_citizen === 3 ? "Yes" : "No"

                // obj.is_approved = 0; // Default value
                result?.sr_info?.created_by ? obj.created_by = result?.sr_info?.created_by : null;
                result?.sr_info?.updated_by ? obj.updated_by = result?.sr_info?.updated_by : null;

                if (result?.delivery) {
                    // const resultObject = await this.getMaxIterationObject(result?.delivery);
                    const resultObject = await this.getFilesFiltered(result.delivery);

                    for (let delivery of resultObject) {
                        if (result?.request_type_id == "18") {
                            if (delivery?.files) {
                                obj.files = v8.deserialize(v8.serialize(obj.files));
                                const groundFloor = [], groundPlusOne = [], groundPlusTwo = [], groundPlusThree = [], groundPlusFour = [], groundPlusFive = [], twoDPdf = [], linkedDwg = [];
                                for (let value of delivery.files) {
                                    if (value?.category === "Ground Floor Design") {
                                        groundFloor.push(value?.link);
                                    } else if (value?.category === "First Floor Design") {
                                        groundPlusOne.push(value?.link);
                                    } else if (value?.category === "Second Floor Design") {
                                        groundPlusTwo.push(value?.link);
                                    } else if (value?.category === "Third Floor Design") {
                                        groundPlusThree.push(value?.link);
                                    } else if (value?.category === "Fourth Floor Design") {
                                        groundPlusFour.push(value?.link);
                                    } else if (value?.category === "Fifth Floor Design") {
                                        groundPlusFive.push(value?.link);
                                    } else if (value?.category === "Pdf File") {
                                        twoDPdf.push(value?.link);
                                    } else if (value?.category === "Raw File") {
                                        linkedDwg.push(value?.link);
                                    }
                                }
                                obj.files.two_d_rendered_plan_jpg.ground = groundFloor;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_one = groundPlusOne;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_two = groundPlusTwo;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_three = groundPlusThree;
                                obj.files.two_d_rendered_plan_jpg.ground_plus_four = groundPlusFour;
                                obj.files.two_d_rendered_plan_jpg.above_ground_plus_four = groundPlusFive;
                                obj.files.two_d_rendered_plan_pdf.two_d_rendered_plan_pdf_link = twoDPdf;
                                obj.files.linked_dwg_file.linked_dwg_file_id = linkedDwg;
                            }
                            /* Room */

                            /* Vaastu */
                        } else {
                            /* Files*/
                            if (delivery?.files) {
                                obj.files = v8.deserialize(v8.serialize(obj.files));
                                let groundIso = [], firstIso = [], secondIso = [], thirdIso = [], fourthIso = [], fifthIso = [], rawIso = [], pdfIso = [];
                                for (let value of delivery.files) {
                                    if (value?.category === "Front Elevation") {
                                        obj.files.three_d_design_id.front = value?.link || null;
                                    } else if (value?.category === "Right Elevation") {
                                        obj.files.three_d_design_id.right_side = value?.link || null;
                                    } else if (value?.category === "Left Elevation") {
                                        obj.files.three_d_design_id.left_side = value?.link || null;
                                    } else if (value?.category === "Rear Elevation") {
                                        obj.files.three_d_design_id.rear_side = value?.link || null;
                                    } else if (value?.category === "Internal Elevation") {
                                        obj.files.three_d_design_id.internal = value?.link || null;
                                    } else if (value?.category === "Ground Floor Cut-Iso") {
                                        groundIso.push(value?.link);
                                    } else if (value?.category === "First Floor Cut-Iso") {
                                        firstIso.push(value?.link);
                                    } else if (value?.category === "Second Floor Cut-Iso") {
                                        secondIso.push(value?.link);
                                    } else if (value?.category === "Third Floor Cut-Iso") {
                                        thirdIso.push(value?.link);
                                    } else if (value?.category === "Fourth Floor Cut-Iso") {
                                        fourthIso.push(value?.link);
                                    } else if (value?.category === "Fifth Floor Cut-Iso") {
                                        fifthIso.push(value?.link);
                                    } else if (value?.category === "Raw File") {
                                        rawIso.push(value?.link);
                                    } else if (value?.category === "Pdf File") {
                                        pdfIso.push(value?.link);
                                    }
                                }
                                obj.files.three_d_cut_iso_jpg.ground = groundIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_one = firstIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_two = secondIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_three = thirdIso;
                                obj.files.three_d_cut_iso_jpg.ground_plus_four = fourthIso;
                                obj.files.three_d_cut_iso_jpg.above_ground_plus_four = fifthIso;
                                obj.files.linked_sketch_up_file.sketch_up_file_id = rawIso;
                                obj.files.three_d_delivery_pdf.three_d_delivery_pdf_link = pdfIso;
                            }
                        }
                        obj.option_number = delivery.options || null;
                        transformedData.push({ ...obj });
                    }
                } else {
                    transformedData.push({ ...obj });
                }
            };
            console.log(JSON.stringify({ file: 'service.js', line: 398, dataCount: transformedData.length }));
            let mergedObjects = await this.mergeObjectsWithCommonSrNumber(transformedData);
            console.log(JSON.stringify({ file: 'service.js', line: 400, dataCount: mergedObjects.length }));
            if (mergedObjects.length > 0) {
                let uniqueIdCount = 1;
                for (let i = 0; i < mergedObjects.length; i++) {
                    const nextUniqueId = uniqueIdCount + i;
                    mergedObjects[i].unique_id = nextUniqueId;

                    // Define the properties to process dynamically
                    const propertiesToProcess = [
                        'two_d_rendered_plan_jpg.ground',
                        'two_d_rendered_plan_jpg.ground_plus_one',
                        'two_d_rendered_plan_jpg.ground_plus_two',
                        'two_d_rendered_plan_jpg.ground_plus_three',
                        'two_d_rendered_plan_jpg.ground_plus_four',
                        'two_d_rendered_plan_jpg.above_ground_plus_four',
                        'two_d_rendered_plan_pdf.two_d_rendered_plan_pdf_link',
                        'linked_dwg_file.linked_dwg_file_id',
                        'three_d_cut_iso_jpg.ground',
                        'three_d_cut_iso_jpg.ground_plus_one',
                        'three_d_cut_iso_jpg.ground_plus_two',
                        'three_d_cut_iso_jpg.ground_plus_three',
                        'three_d_cut_iso_jpg.ground_plus_four',
                        'three_d_cut_iso_jpg.above_ground_plus_four',
                        'linked_sketch_up_file.sketch_up_file_id',
                        'three_d_delivery_pdf.three_d_delivery_pdf_link',
                        'three_d_design_id.front',
                        'three_d_design_id.right_side',
                        'three_d_design_id.left_side',
                        'three_d_design_id.rear_side',
                        'three_d_design_id.internal'
                    ];

                    // Process each property dynamically
                    propertiesToProcess.forEach(property => {
                        let splitProperty = property.split('.');
                        const propertyValue = mergedObjects[i].files[splitProperty[0]][splitProperty[1]];
                        if (Array.isArray(propertyValue)) {
                            // Handle arrays
                            mergedObjects[i].files[property] = propertyValue.map(item => {
                                let imageLink = null;
                                imageLink = item ? item : null;
                                if (imageLink) {
                                    let imageArray = imageLink.split("/");
                                    let arrayLength = imageArray.length;
                                    imageLink = `delivery_catalog/${nextUniqueId}/${imageArray[arrayLength - 3]}/${imageArray[arrayLength - 1]}`;
                                    fileMappings.push({
                                        sourceKey: item,
                                        destinationKey: imageLink
                                    });
                                }
                                return imageLink; // Return the modified value
                            });

                        } else if (typeof propertyValue === 'string') {
                            // Handle strings
                            let imageLink = null;
                            imageLink = propertyValue ? propertyValue : null;
                            if (imageLink) {
                                let imageArray = imageLink.split("/");
                                let arrayLength = imageArray.length;
                                imageLink = `delivery_catalog/${nextUniqueId}/${imageArray[arrayLength - 3]}/${imageArray[arrayLength - 1]}`;
                                fileMappings.push({
                                    sourceKey: propertyValue,
                                    destinationKey: imageLink
                                });
                            }
                            mergedObjects[i].files[property] = imageLink;
                        }
                    });
                    await this.insertionOne(mergedObjects[i]);
                }

                let batch = fileMappings.length/5000;

                let finalResolution = [];

                for(let i = 0; i <= batch; i++){
                    let slicedArray = fileMappings.slice(i * 5000, 5000 * (i + 1));
                    let promiseResult = await this.copyS3Files(slicedArray); //file copy from one bucket to other bucket
                    finalResolution.push(promiseResult);
                    console.log(JSON.stringify({ file: 'service.js', line: 472, promiseResult: promiseResult.length }));
                }

                console.log(finalResolution);

                // promiseResult.forEach((result, index) => {
                //     if (result.status === 'fulfilled') {
                //         console.log(`Promise ${index + 1} resolved: ${result.value}`);
                //     } else {
                //         console.error(`Promise ${index + 1} rejected: ${result.reason}`);
                //     }
                // });
                return true;
                // const batchSize = 50; // Set an appropriate batch size
                // for (let i = 0; i < mergedObjects.length; i += batchSize) {
                //     const batch = mergedObjects.slice(i, i + batchSize);
                // await this.insertion(batch);
                // }
                // return true;

                // else {
                //     return false;
                // }

            } else {
                return false;
            }
        }
        catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 497, message: error.message, error }));
            throw error;
        }
    }

    // Use the transformed data with insertMany in MongoDB
    async insertion(transformedData) {
        try {
            const options = { maxTimeMS: 60000 }; // Increase the timeout to 60 seconds (adjust as needed)
            const result = await Design.insertMany(transformedData, options);
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 510, error: error }));
            return false; // Return false if there was an error during insertion.
        }
    }
    // Use the transformed data with insertOne in MongoDB
    async insertionOne(transformedData) {
        try {
            const result = await Design.create(transformedData);
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 521, error: error }));
            return false; // Return false if there was an error during insertion.
        }
    }

    async getMaxIterationObject(data) {
        if (!Array.isArray(data) || data.length === 0) {
            return null;
        }

        // Filter out objects where isDeleted is not 0
        const filteredData = data.filter(obj => obj.isDeleted === 0);

        if (filteredData.length === 0) {
            // If all objects have isDeleted !== 0, return null
            return null;
        }

        // Filter out objects where iterationCount is null
        const validIterationData = filteredData.filter(obj => obj.iterationCount !== null);

        if (validIterationData.length === 0) {
            // If all objects have iterationCount === null, return the one with the latest updatedAt
            return filteredData.reduce((prev, curr) => (curr.updatedAt > prev.updatedAt ? curr : prev));
        }

        // Find the object with the maximum iterationCount
        const maxIterationObject = validIterationData.reduce((prev, curr) =>
            (curr.iterationCount > prev.iterationCount ? curr : prev)
        );

        return maxIterationObject;
    }
    async mergeObjectsWithCommonSrNumber(data) {
        const mergedData = {};

        data.forEach(async (item) => {
            const key = `${item.sr_number} + ${item.option_number}` || item.source; // Using 'sr_number' or 'source' as the key
            if (!mergedData[key]) {
                mergedData[key] = { ...item };
            } else {
                await this.mergeObjects(mergedData[key], item);
            }
        });

        return Object.values(mergedData);
    }

    async mergeObjects(target, source) {
        for (const key in source) {
            if (source[key] !== null && typeof source[key] === 'object') {
                if (!target[key]) {
                    target[key] = { ...source[key] };
                } else {
                    await this.mergeObjects(target[key], source[key]);
                }
            } else if (source[key] !== null) {
                target[key] = source[key];
            }

        }
    }

    getFilesFiltered(data) {
        if (data.length == 1 && data[0].files === null && data[0].isDeleted === null && data[0].iterationCount === null && [1, '1'].includes(data[0].options)) {
            return data;
        }
        const modified = data.map(el => {
            const filtered = el.files.filter(file => file.isDeleted === 0)
            return ({ ...el, files: filtered })
        })
        return modified;
    }

    copyS3Files(fileMappings) {
        let sourceBucket = "polaris-tasc-panel-prod"; // "polaris-tasc-panel-prod";
        let destinationBucket = "design-management-prod"; // "design-management-prod";
        // Use Promise.all to parallelize the copy operations
        const copyPromises = fileMappings.map((mapping) => {
            const params = {
                CopySource: `/${sourceBucket}/${mapping.sourceKey}`,
                Bucket: destinationBucket,
                Key: mapping.destinationKey
            };

            // return new Promise((resolve, reject) => {
            //     s3.copyObject(params, (err, data) => {
            //         if (err) {
            //             reject(`Error copying file ${mapping.sourceKey}: ${err}`);
            //         } else {
            //             resolve(`File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`);
            //         }
            //     });
            // });

            let copyObjectCommand = new CopyObjectCommand(params);    
            return s3Client.send(copyObjectCommand)
                .then((data) => {
                    return `File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`;
                })
                .catch((err) => {
                    throw new Error(`Error copying file ${mapping.sourceKey}: ${err.message}`);
                });
        });

        return Promise.allSettled(copyPromises)
        // .then((results) => {
        //     console.log(results);
        // })
        // .catch((error) => {
        //     console.error(error);
        // });
    }

}

module.exports = srDataMigration;
