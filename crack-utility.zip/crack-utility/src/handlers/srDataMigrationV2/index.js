const srDataMigration = require('./service');
const service = new srDataMigration;
const {LIMIT, OFFSET} = process.env;

async function execute() {
    try {
        const params = {insertLimit: LIMIT, insertOffset: OFFSET}
        const insertResult = await service.dataInsert(params);
        return insertResult;
    } catch (error) {
        throw error;
    }
}

execute().then(response=>{
    console.log(JSON.stringify({ file: 'index.js', line: 14, insertResult: response }));
}).catch(error=>{
    console.log(JSON.stringify({ file: 'index.js', line: 16, error }));
})
