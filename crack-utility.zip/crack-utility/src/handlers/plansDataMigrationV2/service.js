// const mongoose = require('mongoose');
const { PlansManagement } = require('./models/source');
const { PlanStyleDesigns } = require('./models/destination');
// const { UserProfile } = require('./models/upadModel');
const { clonedDoc } = require('./payload');
const v8 = require('v8');
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client();
const fs = require('fs');
// const { ObjectId } = mongoose.Types;
const { BATCH_S3, ENV = "dev" } = process.env;

const buckets = {
    "dev": {
        source: "design-management-test",
        destination: "design-management-test"
    },
    "stage": {
        source: "design-management-stage",
        destination: "design-management-stage"
    },
    "preprod": {
        source: "design-management-stage",
        destination: "design-management-stage"
    },
    "production": {
        source: "design-management-prod",
        destination: "design-management-prod"
    }
}

// const floorMapping = {
//     "G": { title: "Ground floor", count: 0 },
//     "G+0": { title: "Ground floor", count: 0 },
//     "G+1": { title: "Ground + 1 floor", count: 1 },
//     "G+2": { title: "Ground + 2 floors", count: 2 },
//     "G+3": { title: "Ground + 3 floors", count: 3 },
//     "G+4": { title: "Ground + 4 floors", count: 4 },
//     "Above G+4": { title: "Ground + 5 floors", count: 5 },
//     "": { title: "", count: null }
// }

const pathMapping = {
    "ground": "groundFloor",
    "ground_plus_one": "firstFloor",
    "ground_plus_two": "secondFloor",
    "ground_plus_three": "thirdFloor",
    "ground_plus_four": "fourthFloor",
    "front": "front",
    "right_side": "rightSide",
    "left_side": "leftSide",
    "rear_side": "rearSide",
    "internal": "internal",
    "rawFile": "rawFile",
    "others": "others"
}

const falsyVals = [undefined, null, ""];
function checkValue(value) {
    return !falsyVals.includes(value) ? value : null;
}
const falsyVals2 = [undefined, null];
function checkValue2(value) {
    return !falsyVals2.includes(value) ? value : null;
}

class PlansDataMigration {

    async uploadFilesToS3(s3Params) {
        try {
            if (!s3Params.length) throw new Error("no files to be uploaded");

            const batchSize = BATCH_S3 || 3000;
            const batchCount = s3Params.length / batchSize;
            const uploadTrack = [];

            for (let i = 0; i < batchCount; i++) {
                let paramsChunk = s3Params.slice(batchSize * i, batchSize * (i + 1));
                const promises = paramsChunk.map(params => {
                    // return new Promise((resolve, reject) => {

                    //     s3.copyObject(params, (err, data) => {
                    //         if (err) {
                    //             reject(`Error copying file ${params.CopySource}: ${err}`)
                    //         } else {
                    //             resolve(`File ${params.CopySource} copied successfully to ${params.Key}`);
                    //         }
                    //     });
                    // });
                    let copyObjectCommand = new CopyObjectCommand(params);    
                    return s3Client.send(copyObjectCommand)
                        .then((data) => {
                            return `File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`;
                        })
                        .catch((err) => {
                            throw new Error(`Error copying file ${mapping.sourceKey}: ${err.message}`);
                        });
                })
                const uploadResp = await Promise.allSettled(promises);
                console.log(JSON.stringify({ file: 'service.js', line: 18, message: `files uploaded successfully for batch ${i}`, uploadFilesToS3: uploadResp.length }));
                uploadTrack.push(...uploadResp);
            }

            fs.writeFileSync(`./result_track/upload_track_${ENV}.json`, JSON.stringify(uploadTrack));

            return true;
        } catch (error) {
            console.log({ step: "uploadFilesS3", error })
            throw error;
        }
    }

    async postDataToDestination(processedData) {
        try {
            const { data, s3Params } = processedData;

            const updationTrack = [];

            const dataSize = data.length;

            if (!dataSize) throw new Error("no data to post to destination");

            for (let i = 0; i < dataSize; i++) {
                let value = data[i];
                let srNumber = value.sr_number;
                let optionNumber = value.option_number;
                let updatedBy = value.updated_by;
                delete value.sr_number;
                delete value.option_number;
                delete value.updated_by;
                // ******************** update the data using sr_number and option number ****************
                console.log({ "value": value, "srNumber": srNumber, "optionNumber": optionNumber, "updatedBy": updatedBy });
                const updationResp = await PlanStyleDesigns.updateMany({ sr_number: srNumber, option_number: optionNumber, updated_by: updatedBy }, {
                    $set: {
                       "files.two_d_rendered_plan_jpg" : value.files.two_d_rendered_plan_jpg,
                       "files.two_d_line_drawing_jpg" : value.files.two_d_line_drawing_jpg
                    }
                });
                if (!updationResp) {
                    console.log(value);
                    throw new Error(`updation failed on ${i} iteration`);
                }

                updationTrack.push({ ...updationResp });
            }

            fs.writeFileSync(`./result_track/updation_track_${ENV}.json`, JSON.stringify(updationTrack));

            console.log({ message: "data insertion finished, starting files upload..." });

            await this.uploadFilesToS3(s3Params);

            return true;
        } catch (error) {
            console.log({ step: "postDataToDestination", error })
            throw error;
        }
    }

    makeS3Params(destinationKey, sourceKey) {
        const bucketInfo = buckets[ENV];
        try {
            const params = {
                CopySource: `/${bucketInfo.source}/${sourceKey}`,
                Bucket: bucketInfo.destination,
                Key: destinationKey
            };

            return params;
        } catch (error) {
            console.log({ step: "makeS3Params", error });
            throw error;
        }
    }

    newUploadPathS3(sourcePath, nextUniqueId, ref) {
        try {
            const splited = sourcePath.split(",");
            const toReturn = { params: [], newPaths: [] };
            splited.forEach(path => {
                const sourceKey = path.trim();
                const suffix = sourceKey.split('/').pop();
                const destinationKey = `delivery_catalog/${nextUniqueId}/${pathMapping[ref]}/${suffix}`;
                const params = this.makeS3Params(destinationKey, sourceKey);
                toReturn.params.push(params);
                toReturn.newPaths.push(destinationKey);
            })
            // const suffix = sourcePath.split('/').pop();
            // const destinationPath = `delivery_catalog/${nextUniqueId}/${pathMapping[ref]}/${suffix}`;
            return toReturn;
        } catch (error) {
            console.log({ step: "newUploadPathS3", error });
            throw error;
        }
    }

    async processData(data) {
        try {

            const processedData = { data: [], s3Params: [] };

            for (let i = 0; i < data.length; i++) {
                let targetDoc = v8.deserialize(v8.serialize(clonedDoc));

                let sourceDoc = JSON.parse(JSON.stringify(data[i]));

                // mapping root level fields 
                let srNumber = null, optionNumber = null, updatedBy = null;
                srNumber = checkValue(sourceDoc?.['sr_number']);
                optionNumber = checkValue(sourceDoc?.['option_number']);
                updatedBy = checkValue(sourceDoc?.['updated_by']);
                targetDoc['sr_number'] = srNumber;
                targetDoc['option_number'] = optionNumber;
                targetDoc['updated_by'] = updatedBy;

                //  get the unique_id from planStyleDesigns
                let [initialResult = null] = await PlanStyleDesigns.find({ sr_number: srNumber, option_number: optionNumber, updated_by: updatedBy }, { unique_id: 1 });
                console.log(JSON.stringify({ file: 'service.js', line: 206, initialResult }));
                if (!initialResult || !initialResult.unique_id) {
                    console.log(JSON.stringify({ file: 'service.js', line: 214, msg: `unique id(initialId) is null, for srNumber=${srNumber} and optionNumber=${optionNumber}` }));
                    continue;
                }
                let initialId = initialResult?.unique_id;
                const firstLevel = ["two_d_rendered_plan_jpg", "two_d_line_drawing_jpg"];
                const secondLevel2d = ['ground', 'ground_plus_one', 'ground_plus_two', 'ground_plus_three', 'ground_plus_four', 'above_ground_plus_four'];


                firstLevel.forEach(firstKey => {
                    secondLevel2d.forEach(secondKey => {
                        if (sourceDoc?.['files']?.[firstKey]?.[secondKey]) {
                            const value = sourceDoc['files'][firstKey][secondKey];
                            let { params, newPaths } = this.newUploadPathS3(value, (initialId), secondKey);
                            processedData.s3Params.push(...params);
                            targetDoc['files'][firstKey][secondKey].push(...newPaths);
                        }
                    })
                })

                const value2 = checkValue(sourceDoc["files"]?.['two_d_rendered_plan_jpg']?.['others']);
                if(value2) {
                    let { params, newPaths } = this.newUploadPathS3(value2, (initialId), "others");
                    processedData.s3Params.push(...params);
                    targetDoc['files']["two_d_rendered_plan_jpg"]["others"] = newPaths[0];
                }
                const value3 = checkValue(sourceDoc["files"]?.['two_d_line_drawing_jpg']?.['others']);
                if(value3) {
                    let { params, newPaths } = this.newUploadPathS3(value3, (initialId), "others");
                    processedData.s3Params.push(...params);
                    targetDoc['files']["two_d_line_drawing_jpg"]["others"] = newPaths[0];
                }              

                // targetDoc["files"]["two_d_rendered_plan_jpg"]["others"] = checkValue(sourceDoc["files"]?.['two_d_rendered_plan_jpg']?.['others']);

                // targetDoc["files"]["two_d_line_drawing_jpg"]["others"] = checkValue(sourceDoc["files"]?.['two_d_line_drawing_jpg']?.['others']);

                processedData.data.push(targetDoc);
            }

            return processedData;
        } catch (error) {
            console.log({ step: "processData", error })
            throw error;
        }
    }

    async getDataFromSource() {
        try {

            const bucketInfo = buckets[ENV];

            console.log({ environment: ENV, buckets: buckets[ENV] });
            if (!bucketInfo) throw new Error("no bucket information specified");

            const result = await PlansManagement.find({ "files.two_d_line_drawing_jpg.ground": { $exists: true, $ne: null, $ne: "" } });
            console.log(JSON.stringify({ file: 'service.js', line: 30, message: "data fetched successfully from source", getDataFromSource: result?.length ? result.length : result }));

            if (!result || !result?.length) throw new Error("data coundn't be fetched or no data found");

            const processedData = await this.processData(result);

            console.log(JSON.stringify({ file: 'service.js', line: 370, processedData_data: processedData.data.length }));
            console.log(JSON.stringify({ file: 'service.js', line: 371, processedData_s3Params: processedData.s3Params.length }));

            return processedData;
        } catch (error) {
            console.log({ step: "getDataFromSource", error })
            throw error;
        }

    }
}

module.exports = PlansDataMigration;