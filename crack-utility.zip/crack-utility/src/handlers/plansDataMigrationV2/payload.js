exports.clonedDoc = {
    "sr_number": null,
    "option_number": null,
    "updated_by" : null,
    "files": {
        "two_d_rendered_plan_jpg": {
            "ground": [],
            "ground_plus_one": [],
            "ground_plus_two": [],
            "ground_plus_three": [],
            "ground_plus_four": [],
            "above_ground_plus_four": [],
            "others": null
        },
        // not used anywhere but for ref keep data 
        "two_d_line_drawing_jpg": {
            "ground": [],
            "ground_plus_one": [],
            "ground_plus_two": [],
            "ground_plus_three": [],
            "ground_plus_four": [],
            "above_ground_plus_four": [],
            "others": null
        }
    }
}