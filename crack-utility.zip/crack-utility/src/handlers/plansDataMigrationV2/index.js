const ConnectMongo = require('./db/docdb-conn');
const PlansDataMigration = require('./service');
const service = new PlansDataMigration();

async function execute() {
    try {

        const instance = new ConnectMongo();
        await instance.connect();

        const fetchResult = await service.getDataFromSource();
        await service.postDataToDestination(fetchResult);

        return ({ status: 200, message: "Migration Successfull!" });
    } catch (error) {
        console.log(error);
        throw error;
    }
}

execute().then(response => {
    console.log({ file: 'index.js', line: 22, executionResult: response });
}).catch(error => {
    console.log(error);
})
