const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StylesService = require('../../services/stylesService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const ObjectId = require('mongodb').ObjectId;
const UserProfileActionService = require('../../services/userProfileActionsService');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let stylesService = new StylesService();
let userProfileActionService = new UserProfileActionService();

exports.popularContentHandler = async(event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let s3BasePath = `${process.env.S3_BUCKET_PATH}/`;

        const designElementList = await stylesService.fetchDesignElements(event);
        console.log(JSON.stringify(designElementList));
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { "data": designElementList, "s3BasePath": s3BasePath, "count": designElementList.totalRecordsCount }, 'Styles Images listed successfully.');
        // const promise1 = await new Promise(async(resolve, reject) => {
        //     const designElementList = await stylesService.fetchDesignElements(event);
        //     if (designElementList) {
        //         let i = 0;
        //         designElementList.listing.forEach(async element => {
        //             let autoGenId = new ObjectID(element._id);
        //             const count = await userProfileActionService.getActionCountData(autoGenId);
        //             const isFavourite = await userProfileActionService.checkRecord(autoGenId, "", 'style', 'favourite');
        //             const isLiked = await userProfileActionService.checkRecord(autoGenId, "", 'style', 'like');
        //             console.log("count=>",count);
        //             console.log("isFavourite=>",isFavourite);
        //             console.log("isLiked=>",isLiked);
        //             response.push({ "imageUrl": element.files ? element.files.three_d_design_id.front : element.image_files, "likeCount": count.like, "isFavourite": isFavourite ? true : false, "isLiked": isLiked ? true : false, "viewCount": 0, "unique_id": element.unique_id });
        //             i++;
        //             if (i == designElementList.listing.length) {
        //                 resolve(baseResponse.getResponseObject(event,true, HTTP_CODE.SUCCESS, { "data": response, "s3BasePath": s3BasePath, "count": designElementList.count }, 'Styles Images listed successfully.'));
        //             }
        //         });
        //     } else {
        //         resolve(baseResponse.getResponseObject(event,true, HTTP_CODE.SUCCESS, [], 'No records found.'));
        //     }
        // })
        // return promise1;
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
};
// popularContentHandler()