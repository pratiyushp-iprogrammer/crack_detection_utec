const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StyleService = require('../../services/stylesService');
const UserProfileActionService = require('../../services/userProfileActionsService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const ViewStyleSchema = require('../../schema/viewStyleDetail');
const ObjectId = require('mongodb').ObjectId;


let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let styleService = new StyleService();
let userProfileActionService = new UserProfileActionService();

exports.designElementDetailsHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        let userId = "";
        let authorizerResponse;
        if (event.requestContext.authorizer) {
            authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            userId = authorizerResponse.userId;
        }
        console.log("user id:", userId);
        const params = JSON.parse(event.body);
        var validation = ViewStyleSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        const result = await styleService.findByUniqueId(params.unique_id);
        console.log("result", JSON.stringify(result))
        if (result) {
            // let styleDetails = await styleService.findByUniqueIdGetData(params.unique_id);
            // console.log("styleDetails", JSON.stringify(styleDetails))
            // var styleId = new ObjectID(styleDetails._id);
            // const count = await userProfileActionService.getActionCountData(styleId);
            // const isFavourite = await userProfileActionService.checkRecord(styleId, userId, 'style', 'favourite');
            // const isLiked = await userProfileActionService.checkRecord(styleId, userId, 'style', 'like');
            // let response = {
            //     "data": {
            //         "_id": styleDetails._id,
            //         // "image": styleDetails.files ? styleDetails?.files?.three_d_design_id?.front ? styleDetails?.files?.three_d_design_id?.front : styleDetails?.image_files :  "",
            //         "image": styleDetails?.files ? styleDetails?.files?.three_d_design_id?.front  : styleDetails?.image_files,
            //         "detailData": [{
            //             "title": "About",
            //             "detail": {
            //                 "Wood": styleDetails.material_treatment ? styleDetails.material_treatment.wood : "",
            //                 "Concrete": "",
            //                 "Paint Plaster": "",
            //                 "Element No.": "",
            //                 "Stone": styleDetails.material_treatment ? styleDetails.material_treatment.stone : "",
            //                 "Style": styleDetails.style ? styleDetails.style : "",
            //                 "Metal": "",
            //                 "Brick": styleDetails.material_treatment ? styleDetails.material_treatment.brick : "",
            //                 "nomenclature": ""
            //             }
            //         }],
            //         "imageCarousel": [styleDetails.files ? styleDetails.files.three_d_design_id.front : ""],
            //         "isFavourite": isFavourite ? true : false,
            //         "isLiked": isLiked ? true : false,
            //         "likeCount": count.like,
            //         "viewCount": 0
            //     }
            // };
            let response = await styleService.getStyleDesignDetails(params.unique_id, Number(userId));
            console.log("response", JSON.stringify(response))
            response.s3BasePath = `${process.env.S3_BUCKET_PATH}/`;
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, response, "Style details fetched successfully.");
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No record found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}