const BaseResponse = require("../../common/baseResponse");
const common = require('../../common/common');
let Common = new common()
const StylesService = require('../../services/stylesService');
const HTTP_CODE = require("../../common/constants");
const Database = require("../../common/database");
const json_structure = require('./styles.json');
// AWS.config.update({
//   accessKeyId: "AKIAXBXKDH5EBYK757WO",
//   secretAccessKey: "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",
//   region: "ap-south-1"
// });

const { S3Client, PutObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();

let objDatabase = new Database();
if (typeof client === "undefined") var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let stylesService = new StylesService();
exports.downloadStylesHandler = async (event, context, callback) => {
  // const downloadStylesHandler = async () => {// For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);
    // const event = {};
    // event.body = { "searchString": "", "filters": {}, "arrRequiredColumns": ["element_type", "files.two_d_rendered_plan_jpg.ground", "files.two_d_rendered_plan_jpg.ground_plus_one", "files.two_d_rendered_plan_jpg.ground_plus_two", "files.two_d_rendered_plan_jpg.ground_plus_three", "files.two_d_rendered_plan_jpg.ground_plus_four", "files.two_d_rendered_plan_jpg.above_ground_plus_four", "files.two_d_rendered_plan_jpg.others", "files.two_d_line_drawing_jpg.ground", "files.two_d_line_drawing_jpg.ground_plus_one", "files.two_d_line_drawing_jpg.ground_plus_two", "files.two_d_line_drawing_jpg.ground_plus_three", "files.two_d_line_drawing_jpg.ground_plus_four", "files.two_d_line_drawing_jpg.above_ground_plus_four", "files.two_d_line_drawing_jpg.others", "files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id", "files.three_d_design_id.front", "files.three_d_design_id.right_side", "files.three_d_design_id.left_side", "files.three_d_design_id.rear_side", "files.three_d_design_id.internal", "files.three_d_cut_iso_jpg.ground", "files.three_d_cut_iso_jpg.ground_plus_one", "files.three_d_cut_iso_jpg.ground_plus_two", "files.three_d_cut_iso_jpg.ground_plus_three", "files.three_d_cut_iso_jpg.ground_plus_four", "files.three_d_cut_iso_jpg.above_ground_plus_four", "files.three_d_cut_iso_jpg.others", "files.linked_estimation_id.estimation_id", "files.linked_stetch_up_file.sketch_up_file_id", "files.linked_dwg_file.linked_dwg_file_id", "files.linked_psd_file.linked_psd_file_id", "files.linked_ppt_file.linked_ppt_file_id", "files.utec_pro_link.utec_pro_link_id", "plot_details.plot_entrance_width_range", "plot_details.plot_area", "plot_details.plot_length", "plot_details.plot_width", "plot_details.plot_shape", "plot_details.left_set_back", "plot_details.right_set_back", "plot_details.front_set_back", "plot_details.rear_set_back", "plot_details.close_sides_of_the_plot", "project_details.typology", "project_details.estimated_cost_of_construction", "project_details.builtup_area", "project_details.floor_plate_area_of_ground_floor", "project_details.floor_plate_length", "project_details.floor_plate_width", "project_details.floors", "project_details.bedrooms", "project_details.shared_wall", "project_details.for_two_shared_wall_adjacent_parallel", "project_details.style", "project_details.low_range_budget", "project_details.high_range_budget", "geography.state", "geography.city", "geography.district", "geography.geo_coordinates", "geography.pincode", "family_details.total_family_members", "family_details.number_of_senior_citizen", "family_details.number_of_adults", "family_details.number_of_children", "family_details.number_of_infants", "parking.basement", "parking.stilts", "parking.two_wheeler_parking", "parking.four_wheeler_parking", "senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor", "senior_citizen_friendly.one_bhk_on_ground_floor", "senior_citizen_friendly.provision_of_ramp", "open_areas_configuration.balcony", "open_areas_configuration.porch", "open_areas_configuration.garden", "open_areas_configuration.courtyard", "open_areas_configuration.frontyard", "open_areas_configuration.backyard", "open_areas_configuration.terrace", "roof.roof_type", "special_amenities.pool", "material_treatment.brick", "material_treatment.stone", "material_treatment.wood", "material_treatment.tile", "material_treatment.aluminium_composite_panel", "material_treatment.glass_curtain_wall", "structural_elements.pergola", "structural_elements.jaali", "structural_elements.green_wall", "structural_elements.planter", "structural_elements.vault", "structural_elements.double_height_open_area", "structural_elements.elevation_element", "colors.color_scheme", "colors.color_used", "partner_details.partner_id", "partner_details.partner_name", "unique_id", "source", "sr_number", "option_number", "design_name", "design_short_description", "design_long_description", "stylized.stylized_configuration", "reference_images", "element_name", "style", "shape", "material", "location", "shutter", "operation", "material_finish", "accessibility", "height", "type", "railing", "construction", "accessible_terrace", "privacy", "railing_style", "staircase_material", "railing_material", "image_files", "raw_files_availability", "raw_files"], "pagination": { "page": 1, "limit": 247 } }
    const result = await stylesService.fetch(event);
    console.log("fetching results", JSON.stringify(result));
    if (result) {
      // result.forEach((items) => {
      //   // let newdata = ({ ...items }._doc);
      //   let newdata = items;
      //   delete newdata._id;
      //   delete newdata.__v;
      //   // const iterate = (obj) => {
      //   //   Object.keys(obj).forEach(key => {
      //   //     if (obj[key] !== null) {
      //   //       if (typeof (obj[key]) === 'string' && obj[key].includes('styles/') && obj[key]) {
      //   //         const res1 = obj[key].split(",");
      //   //         const res3 = res1.map(item => {
      //   //           const res2 = item.split("/").pop();
      //   //           return res2;
      //   //         })
      //   //         obj[key] = res3.join(",");
      //   //       }
      //   //       if (typeof obj[key] === 'object') {
      //   //         iterate(obj[key])
      //   //       }
      //   //     }
      //   //   })
      //   // }
      //   // iterate(newdata);
      // });
      const objRequest = JSON.parse(event.body);
      const fields = objRequest.arrRequiredColumns;
      const columnNameWithKeys = [];
      for (let names in json_structure) {
        const jsonData = {}
        jsonData[json_structure[names].key_name] = names;
        columnNameWithKeys.push(jsonData);
      }
      const columnNames = [];
      fields.forEach(item => {
        var findColName = columnNameWithKeys.find(function (post) {
          if (Object.keys(post)[0] === item)
            return true;
        });
        if (findColName) {
          let keyNames = Object.keys(findColName)[0];
          keyNames = keyNames.split(".");
          let field = {};
          // let A = keyNames[0];
          // let B = keyNames[1];
          // let C = keyNames[2];
          // let D = keyNames[3];
          let [A, B, C, D] = keyNames;
          field.label = Object.values(findColName)[0];
          if (B && C && D)
            field.value = row => (row[A] ? row[A][B][C][D] || '' : '');
          else if (B && C)
            field.value = row => (row[A] ? row[A][B][C] || '' : '');
          else if (B)
            field.value = row => (row[A] ? row[A][B] || '' : '');
          else
            field.value = row => (row[A] ? row[A] || '' : '');
          columnNames.push(field)
        }
      })
      var xlsx = require('json-as-xlsx');
      var download = false;
      var settings = {
        fileName: 'Styles',
      }
      const res = xlsx(columnNames, result, settings, download)
      try {
        const filePath = `temp/exported/styles/styles-${baseResponse.currentDatetime()}-${baseResponse.generateFourDigitUniqueID()}.xlsx`;
        var params = {
          // ACL: "public-read-write",
          Bucket: process.env.UPLOAD_S3_BUCKET,
          // Bucket: 'design-management-assets',
          Key: filePath,
          Body: res,
          ContentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel",
          CacheControl: "public, max-age=86400",
        };
        const command = new PutObjectCommand(params);
        const objS3Response = await s3Client.send(command);
        if (objS3Response) {
          console.log(filePath, " uploaded sucessfully on s3", objS3Response);
          const downloadURL = `${process.env.S3_BUCKET_PATH}/${filePath}`;

          let arrResponse = [{ filePath: downloadURL, s3Response: objS3Response }];

          return baseResponse.getResponseObject(
            event,
            true,
            HTTP_CODE.SUCCESS,
            arrResponse,
            "Styles list exported to excel successfully."
          );
        } else {
          let arrResponse = [{ filePath: "", s3Response: objS3Response }];
          return baseResponse.getResponseObject(
            event,
            false,
            HTTP_CODE.INTERNAL_SERVER_ERROR,
            arrResponse,
            "Error while putting excel file to s3 "
          );
        }
      } catch (err) {
        console.error(err);
        return baseResponse.getResponseObject(
          event,
          false,
          HTTP_CODE.INTERNAL_SERVER_ERROR,
          [],
          "Error while generating excel file: " + err.message
        );
      }
    } else {
      return baseResponse.getResponseObject(
        event,
        true,
        HTTP_CODE.SUCCESS,
        [],
        "No records found."
      );
    }

  } catch (e) {
    // TODO - Need to enhance catch block
    console.log('Error in downloadStylesHandler', e);
    return baseResponse.getResponseObject(
      event,
      false,
      HTTP_CODE.BAD_REQUEST,
      [],
      "Error while connecting to db: " + e.message
    );
  }
};
// downloadStylesHandler();
