const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const {LambdaClient, InvokeAsyncCommand} =  require("@aws-sdk/client-lambda");
const lambdaClient = new LambdaClient({region: process.env.AWS_REGION_NAME});
const HTTP_CODE = require('../../common/constants');
const { nanoid } = require('nanoid');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');
const cacheResponse = require('../../common/cacheResponse');
const uploadStylesSchema = require('../../schema/uploadStyles.js');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const StatusService = require('../../services/statusService');
let statusService = new StatusService();
let adminDetails = new AdminDetails();
let CacheResponse = new cacheResponse();
// {
//   accessKeyId: process.env.ACCESS_KEY_ID,
//   secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   region: process.env.DM_AWS_REGION
//   // region: "ap-south-1",
// }
let baseResponse = new BaseResponse();

exports.uploadStylesHandler = async (event, context) => {
  // const uploadStylesHandler = async () => {//For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);
    //Generated Queue ID.
    const queue_id = nanoid(10);
    const transaction_id = nanoid(10);
    const params = JSON.parse(event.body);
    var validation =  uploadStylesSchema.validate(params);
    if (validation.error) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], validation.error);
    }
    let email = "";
    let authorizationToken = event.headers.Authorization;
    const details = await adminDetails.getAdminDetails(authorizationToken);
    email = details ? details.name : '';
    if (event.requestContext.authorizer) {
      let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
      email = authorizerResponse.email;
    }
    // const params = {
    //   "payload": {
    //     "file_link": "temp/NewExcelStyles.xlsx",
    //     "file_link_list": []
    //   }
    // }//For local testing uncomment this code
    //TODO Call this function excelToJsonParse() using lambda.invoke
    const lambda_payload = {
      // created_by: params.payload.created_by,
      created_by: email,
      file_link: params.payload.file_link,
      file_link_list_array: params.payload.file_link_list,
      queue_id,
      transaction_id
    }
    var lambda_params = {
      FunctionName: process.env.DM_STYLE_EXCEL_PARSING_LAMBDA_ARN,
      // InvocationType: "Event",
      // Payload: JSON.stringify(lambda_payload),
      // Qualifier: "1"
      InvokeArgs: JSON.stringify(lambda_payload)
    };
    console.log('lambda_params', lambda_params);
    // lambda.invokeAsync(lambda_params, function (err, data) {
    //   console.log("Inside lambda.invoke");
    //   if (err) console.log(".......err.....", err, err.stack);
    //   else console.log(".............", data);
    // });    
    const command = new InvokeAsyncCommand(lambda_params);
    const lambdaResponse = await lambdaClient.send(command);
    console.log('lambdaResponse', lambdaResponse);
    const response_data = {
      created_by: params.payload.created_by,
      type: "Styles",
      queueId: queue_id,
      transaction_id: transaction_id,
      status_code: 1,
      message: "Import process initiated(#0001)",
      lambdaResponse
    }
    console.log('response_data', response_data);
    const result = await statusService.insertStatus(response_data);
    response_data.s3BasePath = `${process.env.S3_BUCKET_PATH}/`
    if (result) {
      // await CacheResponse.clearCache(null, event, null);
      await CacheResponse.clearRelevantCache(null, event, null);
      return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, response_data, "Bulk data upload parsing Excel data Initiated");
    } else {
      return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, "No data found for Bulk data from excel file");
    }
  } catch (error) {
    // TODO - Need to enhance catch block
    console.log("Error in upload file code ..........", error);
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error for bulk upload API: " + error.message);
  }
};
// uploadStylesHandler();//For local testing uncomment this code