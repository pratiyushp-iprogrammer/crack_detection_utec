const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StyleElevationsService = require('../../services/styleElevationsService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const UpdateStyleElevationSchema = require('../../schema/updateStyleElevation');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let styleElevationsService = new StyleElevationsService();

exports.updateStyleElevationHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        const params = JSON.parse(event.body);
        params.updated_by = 1;
        var validation = UpdateStyleElevationSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        const result = await styleElevationsService.findByUniqueId(params.unique_id);
        if (result) {
            await styleElevationsService.updateStyleElevation(params);
            const updatedResult = await styleElevationsService.findByUniqueIdGetData(params.unique_id);
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [updatedResult], "Style details saved successfully!");
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No record found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}