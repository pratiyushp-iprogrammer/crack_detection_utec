const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StylesService = require('../../services/stylesService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let stylesService = new StylesService();

exports.listStylesHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        var response = await stylesService.fetch(event);
        if (response) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { response, "totalCount": response["totalRecordsCount"] }, 'Styles listed successfully.');
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No records found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}