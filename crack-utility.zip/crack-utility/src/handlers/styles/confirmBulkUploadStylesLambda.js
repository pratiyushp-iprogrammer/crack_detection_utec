const Database = require("../../common/database");
let objDatabase = new Database();
if (typeof client === "undefined") var client = objDatabase.connect();
const StyleService = require("../../services/stylesService");
const styleService = new StyleService();
const StatusService = require("../../services/statusService");
const StylesServiceDummy = require('../../services/styleServiceDummy.js');
let stylesServiceDummy = new StylesServiceDummy();
let statusService = new StatusService();
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({region: process.env.AWS_REGION_NAME});
const set = require('lodash/set');
const common = require('../../common/common');
let Common = new common()
// AWS.config.update({
// accessKeyId: "AKIAXBXKDH5EBYK757WO",
// secretAccessKey: "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",
// region: "ap-south-1"
// });
exports.confirmBulkUploadStylesLambdaHandler = async (event, context) => {
  // const confirmBulkUploadStylesLambdaHandler = async () => {//For local testing uncomment this code
  console.log("Inside confirmBulkUploadStylesLambdaHandler Function");
  const start = new Date();
  console.log("start", start);
  // const event = {
  //   transaction_id: "UU_p2rCh0a",
  //   supporting_files_links: "temp/testingRecords/images",
  //   queue_id: "tFqUPShgo3"
  // }
  const { transaction_id, supporting_files_links, queue_id } = event;
  console.log("------------", event);
  let updateQueueStatus = '';
  try {
    // event = Common.reqSanitize(event);
    const links = [];
    const errorLinks = [];

    const result = await stylesServiceDummy.findByTransactionId(transaction_id);
    const confirmUploadProcessInitiated = {
      queueId: queue_id,
      status_code: 4,
      message: "Import process initiated(#0004)",
      total_valid_records: result.length
    }
    updateQueueStatus = await statusService.updateStatus(confirmUploadProcessInitiated);
    var first = new Date();
    console.log("first:", first);
    await result.map(async (style) => {
      for (let item in style) {
        if (style["valid"] || style["duplicate"]) {
          let link_path;
          if (item === "files") {
            if (style["files"]["two_d_rendered_plan_jpg"]["ground"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["ground"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/G-0/${ele}`;
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.ground", res.join(','));
            }
            if (style["files"]["two_d_rendered_plan_jpg"]["ground_plus_one"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["ground_plus_one"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/G-1/${ele}`;
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.ground_plus_one", res.join(','));
            }
            if (style["files"]["two_d_rendered_plan_jpg"]["ground_plus_two"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["ground_plus_two"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/G-2/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.ground_plus_two", res.join(','));
            }
            if (style["files"]["two_d_rendered_plan_jpg"]["ground_plus_three"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["ground_plus_three"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/G-3/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.ground_plus_three", res.join(','));
            }
            if (style["files"]["two_d_rendered_plan_jpg"]["ground_plus_four"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["ground_plus_four"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/G-4/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.ground_plus_four", res.join(','));
            }
            if (style["files"]["two_d_rendered_plan_jpg"]["above_ground_plus_four"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["above_ground_plus_four"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/G-5/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.above_ground_plus_four", res.join(','));
            }
            if (style["files"]["two_d_rendered_plan_jpg"]["others"]) {
              const res = style["files"]["two_d_rendered_plan_jpg"]["others"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_rendered_plan_jpg/others/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_rendered_plan_jpg.others", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["ground"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["ground"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/G-0/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.ground", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["ground_plus_one"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["ground_plus_one"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/G-1/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.ground_plus_one", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["ground_plus_two"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["ground_plus_two"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/G-2/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.ground_plus_two", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["ground_plus_three"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["ground_plus_three"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/G-3/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.ground_plus_three", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["ground_plus_four"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["ground_plus_four"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/G-4/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.ground_plus_four", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["above_ground_plus_four"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["above_ground_plus_four"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/G-5/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.above_ground_plus_four", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_jpg"]["others"]) {
              const res = style["files"]["two_d_line_drawing_jpg"]["others"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_jpg/others/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_jpg.others", res.join(','));
            }
            if (style["files"]["linked_estimation_id"]["estimation_id"]) {
              const res = style["files"]["linked_estimation_id"]["estimation_id"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/linked_estimation_id/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.linked_estimation_id.estimation_id", res.join(','));
            }
            if (style["files"]["linked_stetch_up_file"]["sketch_up_file_id"]) {
              const res = style["files"]["linked_stetch_up_file"]["sketch_up_file_id"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/linked_stetch_up_file/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.linked_stetch_up_file.sketch_up_file_id", res.join(','));
            }
            if (style["files"]["linked_dwg_file"]["linked_dwg_file_id"]) {
              const res = style["files"]["linked_dwg_file"]["linked_dwg_file_id"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/linked_dwg_file/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.linked_dwg_file.linked_dwg_file_id", res.join(','));
            }
            if (style["files"]["linked_psd_file"]["linked_psd_file_id"]) {
              const res = style["files"]["linked_psd_file"]["linked_psd_file_id"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/linked_psd_file/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.linked_psd_file.linked_psd_file_id", res.join(','));
            }
            if (style["files"]["linked_ppt_file"]["linked_ppt_file_id"]) {
              const res = style["files"]["linked_ppt_file"]["linked_ppt_file_id"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/linked_ppt_file/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.linked_ppt_file.linked_ppt_file_id", res.join(','));
            }
            if (style["files"]["two_d_line_drawing_pdf"]["two_d_line_drawing_pdf_id"]) {
              const res = style["files"]["two_d_line_drawing_pdf"]["two_d_line_drawing_pdf_id"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/2d/two_d_line_drawing_pdf/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id", res.join(','));
            }
            if (style["files"]["three_d_design_id"]["front"]) {
              const res = style["files"]["three_d_design_id"]["front"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_design_id/front/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_design_id.front", res.join(','));
            }
            if (style["files"]["three_d_design_id"]["right_side"]) {
              const res = style["files"]["three_d_design_id"]["right_side"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_design_id/right/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_design_id.right_side", res.join(','));
            }
            if (style["files"]["three_d_design_id"]["left_side"]) {
              const res = style["files"]["three_d_design_id"]["left_side"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_design_id/left/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_design_id.left_side", res.join(','));
            }
            if (style["files"]["three_d_design_id"]["rear_side"]) {
              const res = style["files"]["three_d_design_id"]["rear_side"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_design_id/rear/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_design_id.rear_side", res.join(','));
            }
            if (style["files"]["three_d_design_id"]["internal"]) {
              const res = style["files"]["three_d_design_id"]["internal"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_design_id/internal/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_design_id.internal", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["ground"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["ground"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/G-0/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.ground", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["ground_plus_one"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["ground_plus_one"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/G-1/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.ground_plus_one", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["ground_plus_two"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["ground_plus_two"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/G-2/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.ground_plus_two", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["ground_plus_three"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["ground_plus_three"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/G-3/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.ground_plus_three", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["ground_plus_four"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["ground_plus_four"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/G-4/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.ground_plus_four", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["above_ground_plus_four"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["above_ground_plus_four"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/G-5/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.above_ground_plus_four", res.join(','));
            }
            if (style["files"]["three_d_cut_iso_jpg"]["others"]) {
              const res = style["files"]["three_d_cut_iso_jpg"]["others"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/3d/three_d_cut_iso_jpg/others/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "files.three_d_cut_iso_jpg.others", res.join(','));
            }
          }
          if (item === "reference_images") {
            if (style["reference_images"]) {
              const res = style["reference_images"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/reference_images/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "reference_images", res.join(','));
            }
          }
          if (item === 'image_files') {
            if (style["image_files"]) {
              const res = style["image_files"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/image_files/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "image_files", res.join(','));
            }
          }
          if (item === 'raw_files') {
            if (style["raw_files"]) {
              const res = style["raw_files"].split(',').map(ele => {
                ele = ele.trim();
                link_path = `styles/${style["unique_id"]}/raw_files/${ele}`
                links.push(link_path);
                return link_path;
              });
              set(style, "raw_files", res.join(','));
            }
          }
        }
      };
    });
    var second = new Date();
    console.log("second:", second);
    var difference1 = (second.getTime() - first.getTime()) / 1000;
    console.log("difference1", difference1);
    const third = new Date();
    console.log("third", third);
    console.log("links", links);
    await Promise.all(
      links.map(async (link, index) => {
        const confirmImageUploadInitiated = {
          queueId: queue_id,
          status_code: 5,
          message: "Importing assets and updating records is in progress(#0005)",
          total_valid_images_uploaded: links.length,
          image_upload_progress: index + 1
        }
        updateQueueStatus = await statusService.updateStatus(confirmImageUploadInitiated);
        // const link_temp = supporting_files_links.split("/").splice(1, 2);
        // const link_path = link_temp[0].split(".").splice(0, 1);
        // const keyName = `temp/${link_path[0]}`;
        const get_source_link = link.split("/").pop();
        let copyPath = process.env.UPLOAD_S3_BUCKET + "/" + supporting_files_links + "/" + get_source_link;
        // let copyPath = "design-management-assets" + "/" + supporting_files_links + "/" + get_source_link;
        if (copyPath.includes("+")) {
          copyPath = copyPath.replace("+", "%2B")
        }
        console.log('copyPath', copyPath);
        var params = {
          // Bucket: "design-management-assets",
          Bucket: process.env.UPLOAD_S3_BUCKET,
          CopySource: copyPath,
          Key: link
        };
        try {
          let copyObjectCommand = new CopyObjectCommand(params);    
          await s3Client.send(copyObjectCommand)
        }
        catch (err) {
          console.log('err', err);
          errorLinks.push(link);
        }
      })
    );
    console.log("errorLinks", errorLinks);
    const confirmImageUploadDone = {
      queueId: queue_id,
      status_code: 6,
      message: "Importing assets and updating records completed successfully(#0006)",
      total_valid_images_uploaded: links.length,
      errorLinks
    }
    updateQueueStatus = await statusService.updateStatus(confirmImageUploadDone);
    const forth = new Date();
    console.log("forth", forth);
    const difference2 = (forth.getTime() - third.getTime()) / 1000;
    console.log("difference2", difference2);
    const fifth = new Date();
    console.log("fifth", fifth);
    const finalArray = [];
    const duplicateArray = [];
    await result.forEach(style => {
      if (style.valid) {
        finalArray.push(style);
      }
      if (style.duplicate) {
        let newdata = ({ ...style }._doc);
        delete newdata._id;
        duplicateArray.push(newdata);
      }
    });

    console.log('duplicateArray', duplicateArray);
    const updateDateResult = duplicateArray.map(async (item) => {
      const queryResponse = await styleService.updateStyle(item);
      return queryResponse;
    });
    console.log('updateDateResult', updateDateResult);
    console.log('finalArray', finalArray);
    const res = await styleService.insert_many(finalArray).then(async (data) => {
      if (data !== true) {
        console.log("err", data);
        let errorStatus = {
          queueId: queue_id,
          status_code: 100,
          message: data,
        }
        updateQueueStatus = await statusService.updateStatus(errorStatus);
      } else return data;
    });
    const sixth = new Date();
    console.log("sixth", sixth);
    const difference3 = (sixth.getTime() - fifth.getTime()) / 1000;
    console.log("difference3", difference3);
    const end = new Date();
    console.log("end", end);
    const total_time = (end.getTime() - start.getTime()) / 1000;
    console.log("total_time", total_time);
    if (res) {
      console.log("res", res);
      const confirmStylesInsertedDone = {
        queueId: queue_id,
        status_code: 7,
        message: "Import process completed successfully(#0007)",
        total_valid_records: result.length
      }
      updateQueueStatus = await statusService.updateStatus(confirmStylesInsertedDone);
      return true;
    } else {
      return false;
    }
  } catch (err) {
    console.log("Error in confirmUploadStyles:", err);
    let errorStatus = {
      queueId: queue_id,
      status_code: 100,
      message: err,
    }
    updateQueueStatus = await statusService.updateStatus(errorStatus);
    console.log('updateQueueStatus', updateQueueStatus)
    return err;
  }
};
// confirmBulkUploadStylesLambdaHandler();
