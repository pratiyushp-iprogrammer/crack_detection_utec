const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const StyleFilterMatrix = require('../../common/styleFilterMatrix.json');
const StylesService = require('../../services/stylesService');
const Database = require('../../common/database');
const cacheResponse = require('../../common/cacheResponse');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();


let baseResponse = new BaseResponse();
let stylesService = new StylesService();
let CacheResponse = new cacheResponse();

exports.styleFilterMatrixHandler = async (event, context) => {
    try {
        event = Common.reqSanitize(event);
        let cacheResponse = await CacheResponse.getCacheResponse(null, event);
        if (cacheResponse.status) {
          return cacheResponse.data;
        }
        for (var data in StyleFilterMatrix) {
            const obj = StyleFilterMatrix[data];
            if (obj.key === 'unique' || obj.key === 'freeText') {
                const result = await stylesService.getDistictValues(obj.dbKey);
                if (Array.isArray(result) && result.length > 0) {
                    obj.value = result.sort((a, b) => a - b);
                } else {
                    obj.value = [];
                }
            }
        }
        return CacheResponse.respond(event, true, HTTP_CODE.SUCCESS, StyleFilterMatrix, "Styles filters fetched successfully!");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Internal server error: " + e.message);
    }
}