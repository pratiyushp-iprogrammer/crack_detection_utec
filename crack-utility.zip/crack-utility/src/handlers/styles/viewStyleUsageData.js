const mongoose = require('mongoose');
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StyleUsageDataService = require('../../services/styleUsageDataService');
const StylesService = require('../../services/stylesService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');


let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

const SyleViewUsageDataSchema = require('../../schema/viewStyleUsageData');
let baseResponse = new BaseResponse();
let styleDesignActionService = new StyleUsageDataService();
let stylesService = new StylesService();
let adminDetails = new AdminDetails();

exports.viewStyleUsageDataHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        let email = "";
        let isAdmin = false;
        if (event.requestContext.authorizer) {
            let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            isAdmin = authorizerResponse.isAdmin;
            email = authorizerResponse.email;
        }
        // let authorizationToken = event.headers.Authorization;
        // const details = await adminDetails.getAdminDetails(authorizationToken);
        // email = details ? details.name : '';

        const params = JSON.parse(event.body);
        params['user_id'] = email;
        params['is_admin'] = isAdmin;

        var validation = SyleViewUsageDataSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.NOT_FOUND, [], "Invalid request.");
        }
        var styleId = new mongoose.Types.ObjectId(params.style_id);
        const styleData = await styleDesignActionService.getDataFromStyles(styleId);
        const count = await styleDesignActionService.getActionCount(styleId, email);
        const reusedStyles = await styleDesignActionService.getReusedStyles(styleId);
        if (styleData || count || reusedStyles) {
            let result = [{ styleData: styleData ? styleData : [], count: count, reusedStyles: reusedStyles }]
            let updateCountObj = {
                unique_id: styleData.unique_id,
                number_of_times_reused: count.reuse,
                number_of_times_viewed: count.view
            };
            await stylesService.updateStyle(updateCountObj);
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, result, "Style Usage data fetched successfully!");
        }
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}