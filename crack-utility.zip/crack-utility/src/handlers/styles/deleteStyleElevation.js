const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StyleElevationsService = require('../../services/styleElevationsService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const DeleteStyleElevationSchema = require('../../schema/deleteStyleElevation');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let styleElevationsService = new StyleElevationsService();

exports.deleteStyleElevationHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        const params = JSON.parse(event.body);
        params.is_active = 2;
        params.updated_by = 1;
        var validation = DeleteStyleElevationSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid request.");
        }
        const result = await styleElevationsService.findByUniqueId(params.unique_id);
        if (result) {
            await styleElevationsService.updateStyleElevation(params);
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Style details deleted successfully!");
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No record found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}