const {LambdaClient, InvokeAsyncCommand} =  require("@aws-sdk/client-lambda");
const lambdaClient = new LambdaClient({region: process.env.AWS_REGION_NAME});
const Database = require('../../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants.js');
const StylesServiceDummy = require('../../services/styleServiceDummy.js');
const StatusService = require('../../services/statusService');
let statusService = new StatusService();
let baseResponse = new BaseResponse();
let stylesService = new StylesServiceDummy();
// {
//   accessKeyId: process.env.ACCESS_KEY_ID,
//   secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   region: process.env.DM_AWS_REGION
//   // region: "ap-south-1",
// }
exports.confirmUploadStylesHandler = async (event, context) => {
  // const confirmUploadStylesHandler = async () => {//For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);
    console.log("Inside confirmUploadStylesHandler");
    const params = JSON.parse(event.body);
    console.log("params:", params);
    // const params = {
    //   "payload": {
    //     "transaction_id": "UU_p2rCh0a",
    //     "supporting_files_links": "temp/demo.zip",
    //     "queue_id": "_ZBRldc8Zr"
    //   }
    // }//For local testing uncomment this code
    const result = await stylesService.findByTransactionId(params.payload.transaction_id);
    console.log("result:", result)
    if (!result) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "No data found for transaction id: " + params.payload.transaction_id);
    }
    //TODO Call this function confirmUploadStyles() using lambda.invoke
    const lambda_payload = {
      transaction_id: params.payload.transaction_id,
      supporting_files_links: params.payload.supporting_files_links,
      queue_id: params.payload.queue_id
    }
    var lambda_params = {
      FunctionName: process.env.DM_STYLE_CONFIRM_UPLOAD_PLANS_LAMBDA_ARN,
      // InvocationType: "Event",
      // Payload: JSON.stringify(lambda_payload),
      // Qualifier: "1"
      InvokeArgs: JSON.stringify(lambda_payload)
    };
    console.log('lambda_params', lambda_params.FunctionName);
    // lambda.invokeAsync(lambda_params, function (err, data) {
    //   console.log("Inside lambda.invoke");
    //   if (err) console.log(".......err.....", err, err.stack);
    //   else console.log(".............", data);
    // });
    const command = new InvokeAsyncCommand(lambda_params);
    const lambdaResponse = await lambdaClient.send(command);
    console.log('lambdaResponse', lambdaResponse);
    // confirmUploadStyles(result, params.payload.supporting_files_links, params.payload.queue_id);
    let confirmUploadProcessInitiated = {
      queueId: params.payload.queue_id,
      status_code: 4,
      message: "Confirm upload process initiated",
      total_valid_records: result.length,
      lambdaResponse
    }
    console.log('confirmUploadProcessInitiated', confirmUploadProcessInitiated);
    const updateQueueStatus = await statusService.updateStatus(confirmUploadProcessInitiated);
    console.log('updateQueueStatus', updateQueueStatus);
    return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, confirmUploadProcessInitiated, "Confirm Bulk Style(s) added Initiated!");
  } catch (e) {
    // TODO - Need to enhance catch block
    let confirmUploadProcessInitiated = {
      queueId: params.payload.queue_id,
      status_code: 100,
      message: e.message,
    }
    console.log('confirmUploadProcessInitiated', confirmUploadProcessInitiated);
    const updateQueueStatus = await statusService.updateStatus(confirmUploadProcessInitiated);
    console.log('updateQueueStatus', updateQueueStatus);
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
}
// confirmUploadStylesHandler();