const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StylesService = require('../../services/stylesService');
const StyleUsageDataService = require('../../services/styleUsageDataService');
const HTTP_CODE = require('../../common/constants');
const UpdateStyleSchema = require('../../schema/updateStyle');
const Database = require('../../common/database');
var ObjectId = require('mongodb').ObjectId;
const AdminDetails = require('../common/getAdminDetails');
const cacheResponse = require('../../common/cacheResponse');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let stylesService = new StylesService();
let styleUsageDataService = new StyleUsageDataService();
let adminDetails = new AdminDetails();
let CacheResponse = new cacheResponse();

exports.updateStyleHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        let email = "";
        let isAdmin = false;
        if (event.requestContext.authorizer) {
            let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            isAdmin = authorizerResponse.isAdmin;
            email = authorizerResponse.email;
        }
        // let authorizationToken = event.headers.Authorization;
        // const details = await adminDetails.getAdminDetails(authorizationToken);
        // email = details ? details.name : '';

        const params = JSON.parse(event.body);
        params.updated_by = email;
        const plotEntranceWidthRange = baseResponse.getRange(params.plot_details.plot_width, 'plot_details.plot_width', 'styles');
        params.plot_details.plot_entrance_width_range = plotEntranceWidthRange;
       
        const floorPlateWidthRange = baseResponse.getRange(params.project_details.floor_plate_width,'project_details.floor_plate_width','styles');
        params.project_details.floor_plate_width_range = floorPlateWidthRange;
        // console.log("request : ",params)
        var validation = UpdateStyleSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        var _id = new ObjectId(params._id);
        //const result = await stylesService.findOneById(_id);
        const result = await stylesService.findByUniqueId(params.unique_id);
        if (result) {
            await stylesService.updateStyle(params);
            const updatedResult = await stylesService.findOneById(_id);
            let logData = {
                style_id: updatedResult._id,
                sr_tracker_number: "",
                event_for: 'styles',
                app_id: 1,
                is_admin: isAdmin,
                user_id: email,
                action: 'update'
            };
            await styleUsageDataService.create(logData);
            // await CacheResponse.clearCache(null, event, null);
            await CacheResponse.clearRelevantCache(null, event, null);
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, updatedResult, "Style details saved successfully!");
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "No record found");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}