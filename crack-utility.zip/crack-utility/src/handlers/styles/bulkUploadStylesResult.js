const Database = require('../../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants.js');
const StylesServiceDummy = require('../../services/styleServiceDummy');
let baseResponse = new BaseResponse();
let stylesService = new StylesServiceDummy();
exports.bulkUploadStylesResultHandler = async (event, context) => {
  // const bulkUploadStylesResultHandler = async () => {//For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);
    console.log("Inside bulkUploadStylesResultHandler");
    const params = JSON.parse(event.body);
    // const params = {
    //   "payload": {
    //     "transaction_id": "8pMPHWQ7VY"
    //   }
    // }//For local testing uncomment this code
    const result = await stylesService.findByAllTransactionId(params.payload.transaction_id);
    if (!result) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "No data found for transaction id: " + params.payload.transaction_id);
    }
    const valid_styles = [];
    const duplicate_styles = [];
    const invalid_styles = [];
    result.forEach(data => {
      if (data.temp) {
        data = JSON.parse(data.temp);
      }
      if (data.valid) valid_styles.push(data);
      if (data.duplicate) duplicate_styles.push(data);
      if (data.invalid) invalid_styles.push(data);
    });
    const final_result = {
      valid_styles,
      duplicate_styles,
      invalid_styles,
      valid_styles_count: valid_styles.length,
      duplicate_styles_count: duplicate_styles.length,
      invalid_styles_count: invalid_styles.length,
      s3BasePath: `${process.env.S3_BUCKET_PATH}/`
    }
    console.log('final_result', final_result)
    return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, final_result, "Fetched Bulk upload styles data");
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
}
// bulkUploadStylesResultHandler();