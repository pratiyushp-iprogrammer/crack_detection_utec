const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const StylesService = require('../../services/stylesService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let stylesService = new StylesService();

exports.deleteStyleRecordHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        const params = JSON.parse(event.body);
        const result = await stylesService.deleteRecord(params.unique_id);
        if (result) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Record deleted successfully!");
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, [], "Something went wrong.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}