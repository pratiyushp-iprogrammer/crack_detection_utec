const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });

exports.handler = async (event) => {
    try {
        if (!event || !event.Records[0]) {
            console.log("Invalid Event");
            return;
        }

        if (event.Records[0].s3) {
            console.log("Reading options from event:\n", event.Records[0].s3);

            // Get source Bucket Name
            const sourceBucket = event.Records[0].s3.bucket.name;
            console.log("sourceBucket: ", sourceBucket);

            const srcKeyName = decodeURIComponent(
                event.Records[0].s3.object.key
            );
            console.log("srcKeyName: ", srcKeyName);

            // Parameters for the destination buckets and file
            const destinationBucket = process.env.UPLOAD_S3_BUCKET;

            const params = {
                Bucket: destinationBucket,
                CopySource: `/${sourceBucket}/${srcKeyName}`,
                Key: srcKeyName
            };
            const copyObjectCommand = new CopyObjectCommand(params);
            const data = await s3Client.send(copyObjectCommand);
            console.log('File copied successfully:', data);
        }
        return;
    } catch (error) {
        console.error("Error while copying file..");
        console.log(JSON.stringify({ file: 'index.js catch block', line: 32, message: error?.message, error: error }));
        return;
    }
}