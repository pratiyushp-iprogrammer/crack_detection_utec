import boto3
from collections import defaultdict
import os
import cv2
import numpy as np
import pytesseract
from io import BytesIO

bucket_name = 'design-management-prod'
folder_path = 'optimized/delivery_catalog/'
# folder_path = 'delivery_catalog/'

# Declare max image coordinates
max_width = 5100
max_height = 2867
initial_x = 225
initial_y = 275
initial_width = 3685
initial_height = 2325

# Create an output directory if it doesn't exist
output_directory = 'CropImages/'
os.makedirs(output_directory, exist_ok=True)

# Create an S3 client
s3 = boto3.client('s3')

# Dictionary to store images grouped by dimensions
image_dimensions = defaultdict(list)


def getXCoordinate(image_path, tolerance=10):
    # Convert the image to grayscale
    gray = cv2.cvtColor(image_path, cv2.COLOR_BGR2GRAY)
    # Set the RGB value to be checked
    rgb_value = (255, 255, 255)

    # Get image dimensions
    height, width = gray.shape

    for x in range(width):
        for y in range(height):
            pixel_value = image_path[y, x]
            if not all(abs(a - b) <= tolerance for a, b in zip(pixel_value, rgb_value)):
                break
        else:
            width_ratio = (x / width) * 100
            if width_ratio > 50:
                print(f"Starting X-coordinate of the vertical line: {x}")
                return x

    # Return None if no suitable X-coordinate is found
    return None

def is_specific_text_present(img, target_text):
    # Convert the image to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Apply thresholding to enhance text
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    # Use pytesseract to extract text
    extracted_text = pytesseract.image_to_string(thresh, config='--psm 6')  # Adjust psm (page segmentation mode) as needed
    # Additional filtering (you can customize this based on your needs)
    extracted_text = ''.join(e for e in extracted_text if e.isalnum() or e.isspace())

    # Check if the target text is present in the extracted text
    return target_text.lower() in extracted_text.lower()

def crop_image(image, max_width, max_height, initial_x, initial_y, initial_width, initial_height):
    # Get the dimensions of the original image
    original_height, original_width = image.shape[:2]

    # Calculate the image width ratio
    image_width_ratio = max_width / original_width
    image_height_ratio = max_height / original_height

    # Get the x-coordinate using the getXCoordinate function
    x_coordinate = getXCoordinate(image)

    if x_coordinate is not None:
        percentage_ratio = (x_coordinate / original_width )* 100
        if(percentage_ratio > 95):
            print(f"crop from width is close to original width")
            if original_width == 1040:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_height_ratio)
                width = int(initial_width / image_width_ratio) - int(original_width/19.5)
                height = int(initial_height / image_width_ratio) - int(original_height/1.14)
            elif original_height == 1890:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_height_ratio)
                width = int(initial_width / image_width_ratio) - int(original_width/19.5)
                height = int(initial_height / image_height_ratio) - int(original_height/20)
            elif original_width == 3509:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_width_ratio)
                width = int(initial_width / image_width_ratio)
                height = int(initial_height / image_height_ratio) + int(original_height/100)
            else:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_width_ratio)
                width = int(initial_width / image_width_ratio) - int(original_width/19.5)
                height = int(initial_height / image_height_ratio) - int(original_height/28)
        else:
            if max_width % original_width == 0:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_width_ratio)
                width = x_coordinate - x
                height = int(initial_height / image_width_ratio)
            elif original_width == 1040:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_height_ratio)
                width = x_coordinate - x
                height = int(initial_height / image_width_ratio) - int(original_height/1.14)
            elif original_width == 3509:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_width_ratio)
                width = x_coordinate - x
                height = int(initial_height / image_height_ratio) + int(original_height/100)
            elif original_height == 1890:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_height_ratio)
                width = x_coordinate - x
                height = int(initial_height / image_height_ratio) - int(original_height/20)
            else:
                x = int(initial_x / image_width_ratio)
                y = int(initial_y / image_height_ratio)
                width = x_coordinate - x
                height = int(initial_height / image_height_ratio) - int(original_height/28)

    else:
        # Handle the case when getXCoordinate returns None
        print(f"Warning: getXCoordinate did not find a suitable value. Setting width to a default value.")
        x = 0
        y = 0
        width = original_width
        height = original_height

    # Crop the image
    cropped_image = image[y:y+height, x:x+width]
    return cropped_image

def list_objects_recursive(prefix, page_size, start_offset=None, limit=None):
    continuation_token = None
    total_objects = 0

    while True:
        # Set up the request with the continuation token, page size, and start offset if available
        list_objects_params = {
            'Bucket': bucket_name,
            'Prefix': prefix,
            'MaxKeys': page_size
        }
        if continuation_token:
            list_objects_params['ContinuationToken'] = continuation_token

        # Make the request to list objects
        response = s3.list_objects_v2(**list_objects_params)

        # Process the objects in the response
        objects = response.get('Contents', [])
        for obj in objects:
            if start_offset and total_objects < start_offset:
                total_objects += 1
                continue

            if obj['Key'].endswith('/'):
                print(f"folder name {obj['Key']} S3")
                list_objects_recursive(obj['Key'], page_size, start_offset, limit)
            elif obj['Key'].lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                # print(f"image key {obj['Key']}")
                image_key = obj['Key']
                image_data = s3.get_object(Bucket=bucket_name, Key=image_key)['Body'].read()
                image_np = np.frombuffer(image_data, dtype=np.uint8)
                total_objects += 1
                # Use try-except to handle potential decoding errors
                try:
                    image_cv2 = cv2.imdecode(image_np, cv2.IMREAD_COLOR)
                    if image_cv2 is not None:
                        # Specify the target text
                        target_text = 'Disclaimer'
                        target_text2 = 'SR'
                        width = image_cv2.shape[1]
                        height = image_cv2.shape[0]
                        # Split the image into four quadrants
                        split_point_x = width // 2
                        split_point_y = height // 2

                        top_left = image_cv2[:split_point_y, :split_point_x]
                        top_right = image_cv2[:split_point_y, split_point_x:]
                        bottom_left = image_cv2[split_point_y:, :split_point_x]
                        bottom_right = image_cv2[split_point_y:, split_point_x:]

                        # Check for specific text in the first half
                        if is_specific_text_present(bottom_left, target_text):
                            print(f"The text '{target_text}' is present in the image. '{image_key}'")
                            dimensions = (image_cv2.shape[1], image_cv2.shape[0])
                            image_dimensions[dimensions].append((image_key, image_cv2))
                        else:
                            if is_specific_text_present(top_right, target_text2):
                                print(f"The text '{target_text2}' is present in the image. '{image_key}'")
                                dimensions = (image_cv2.shape[1], image_cv2.shape[0])
                                image_dimensions[dimensions].append((image_key, image_cv2))
                            else:
                                print(f"The text '{target_text, target_text2 }' is not found in the image.'{image_key}'")
                        # dimensions = (image_cv2.shape[1], image_cv2.shape[0])
                        # image_dimensions[dimensions].append((image_key, image_cv2))
                        # total_objects += 1
                    else:
                        print(f"Failed to decode image: {image_key}")
                except Exception as e:
                    print(f"Error decoding image {image_key}: {str(e)}")

                # Check if the limit is reached
                if limit and total_objects >= limit:
                    return
            else:
                total_objects += 1
                continue

        # Check if there are more objects to retrieve
        continuation_token = response.get('NextContinuationToken')
        if not continuation_token:
            break

def upload_to_s3(image_data, bucket_name, object_key):
    # Get the file extension from the object key
    file_extension = object_key.split('.')[-1].lower() if '.' in object_key else 'jpg'

    # Encode the image with the correct format based on the file extension
    _, img_encoded = cv2.imencode(f'.{file_extension}', image_data)

    # Convert the encoded image to bytes
    image_bytes = img_encoded.tobytes()

    # Upload the image bytes to S3
    s3.upload_fileobj(BytesIO(image_bytes), bucket_name, object_key, ExtraArgs={'ContentType': 'image'})
    print(f"{object_key} uploaded successfully.")

# Get user input for page size, start offset, and limit
page_size = int(input("Enter the number of objects to retrieve per page: "))
start_offset = int(input("Enter the start offset (optional): ") or 0)
limit = int(input("Enter the limit (optional): ") or float('inf'))

limit = start_offset + limit
# Start listing objects from the root of the bucket
list_objects_recursive(folder_path, page_size, start_offset, limit)

# Save the images in folders based on dimensions using OpenCV
for dimensions, images in image_dimensions.items():
    # dimensions_folder = os.path.join(output_directory, f"{dimensions[0]}x{dimensions[1]}")
    # os.makedirs(dimensions_folder, exist_ok=True)

    for image_key, image_cv2 in images:
        output_path = os.path.join(output_directory, os.path.basename(image_key))
        cropped_image = crop_image(image_cv2, max_width, max_height, initial_x, initial_y, initial_width, initial_height)
        cv2.imwrite(output_path, cropped_image)
        # Upload the cropped image to S3
        upload_to_s3(cropped_image, bucket_name, image_key)