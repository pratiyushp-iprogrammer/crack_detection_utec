const BaseResponse = require('../../common/baseResponse');
const baseResponse = new BaseResponse();
const HTTP_CODE = require('../../common/constants');
const schema = require('./joi-schema');
const Services = require('./service');
const instance = new Services();

exports.handler = async (event) => {
    try {
        const params = JSON.parse(event.body);
        console.log(JSON.stringify({ file: 'index.js', line: 11, params }));
        const isRequestValid = schema.validate(params);
        if (isRequestValid?.error) {
            console.log(JSON.stringify({ file: 'index.js', comment: "Validation Error ", line: 18, isRequestValid: isRequestValid }));
            throw ({ message: new Error(isRequestValid.error).message, http_code: HTTP_CODE.BAD_REQUEST });
        }

        const response = await instance.saveInfo(params);
        if (!response) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, [], 'No files found in the specified S3 folder.');
        } else if(response == "download limit exceeded") {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'You can download up to 2 suggested plans from similar tab');
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { "zipFileURL": response }, 'Zip File Downloaded Successfully');
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 28, error, msg: error?.message }));
        return baseResponse.getResponseObject(event, false, error.http_code || HTTP_CODE.INTERNAL_SERVER_ERROR, [], error.message);
    };
};
