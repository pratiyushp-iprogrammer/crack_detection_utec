const Joi = require('joi')

const schema = Joi.object({
    sr_id: Joi.number().required(),
    design_id: Joi.number().required(),
    user_id: Joi.number().required(),
    relevance_score: Joi.number().required(),
    request_type_id: Joi.number().required(),
})

module.exports = schema;
