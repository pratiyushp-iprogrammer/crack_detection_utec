// const HTTP_CODE = require('../../common/constants');
const MongoConnection = require('../../common/database');
let instance = new MongoConnection();
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const { Upload } = require("@aws-sdk/lib-storage");
const fs = require('fs');
const archiver = require('archiver');
if (typeof client === 'undefined') var client = instance.connect();
const DesignDownload = require('../../models/designDownloadInfo');
const Design = require('../../models/planStyleDesigns');
const LogUserActivity = require('../common/logUserActivity');
const logDownloadInfo = new LogUserActivity();
class Services {
    async saveInfo(params) {
        try {
            const { sr_id, design_id, user_id, relevance_score, request_type_id } = params;
            let query = {
                'unique_id': design_id
            };
            let projection;
            if (request_type_id == 18) {
                projection = {
                    'files.linked_dwg_file': 1
                };
            } else if (request_type_id == 19) {
                projection = {
                    'files.linked_sketch_up_file': 1
                };
            } else {
                throw new Error("Invalid SR type")
            }

            let countQuery = {
                "sr_id": sr_id,
                "user_id": user_id
            }
            let totalCount = await DesignDownload.countDocuments(countQuery);
            totalCount = totalCount || 0;
            console.log(JSON.stringify({ file: 'service.js', line: 39, totalDownloadCountPerUser: totalCount }));
            if (totalCount >= 2) {
                let downloadQuery = {
                    "sr_id": sr_id,
                    "user_id": user_id,
                    'design_id': design_id
                }
                let exists = await DesignDownload.countDocuments(downloadQuery);
                exists = exists || 0;
                if (!exists) {
                    return "download limit exceeded";
                }
            }
            const result = await Design.find(query, projection).exec();
            // console.log(JSON.stringify({ file: 'service.js', line: 21, message: `result`, result }));
            let inputObject = result[0].files ? result[0].files : {};
            // const allFiles = this.getAllValues(inputObject);
            let allFiles;
            if (request_type_id == 18) {
                allFiles = inputObject?.linked_dwg_file?.linked_dwg_file_id || [];
            } else if (request_type_id == 19) {
                allFiles = inputObject?.linked_sketch_up_file?.sketch_up_file_id || [];
            }
            console.log(JSON.stringify({ file: 'service.js', line: 27, message: `files values`, allFiles }));
            if (typeof allFiles !== 'undefined' && allFiles.length > 0) {
                let filePath = await this.downloadZipFile(allFiles, design_id);
                const user_details = await logDownloadInfo.fetchUserDetails(user_id);
                delete user_details?.adminId;
                // console.log(JSON.stringify({ file: 'service.js', line: 59, user_details }));
                let updateResult = await DesignDownload.updateOne(
                    { sr_id, design_id, user_id },
                    { $inc: { download_count: 1 }, $set: { user_details, relevance_score } },
                    { upsert: true, setDefaultsOnInsert: true, new: true }
                );
                console.log(JSON.stringify({ file: 'service.js', line: 36, updateResult }));
                return filePath;
            } else {
                return false;
            }
        } catch (error) {
            throw error;
        }
    }

    getAllValues(obj) {
        const values = [];
        for (const key in obj) {
            if (typeof obj[key] === "function") {
                continue; // Skip functions
            }
            if (typeof obj[key] === "object" && obj[key] !== null) {
                const subValues = this.getAllValues(obj[key]);
                if (subValues.length > 0) {
                    values.push(...subValues);
                }
            } else if (obj[key] !== null && obj[key] !== "" && typeof obj[key] !== "boolean") {
                values.push(obj[key]);
            }
        }
        return values;
    }

    async downloadZipFile(filesToZip, designId) {
        const bucketName = process.env.UPLOAD_S3_BUCKET ? process.env.UPLOAD_S3_BUCKET : "design-management-prod";
        const zipFileName = `${designId}_design_raw_files_archive.zip`;
        // const archive = archiver('zip');
        const archive = archiver('zip', {
            zlib: { level: 1 } // Compression level (0 to 9)
        });
        // Create a writable stream to write the zip file
        const zipFilePath = '/tmp/' + zipFileName;
        const zipFileOutput = fs.createWriteStream(zipFilePath);
        try {
            for (const file of filesToZip) {
                try {
                    const fileName = file.split('/').pop(); // Extract the file name
                    const getObjectCommand = new GetObjectCommand({ Bucket: bucketName, Key: file });
                    const s3Object = await s3Client.send(getObjectCommand);
                    archive.append(s3Object.Body, { name: fileName });
                } catch (error) {
                    console.error(`Error downloading object ${file} from S3:`, error);
                }
            }

            archive.pipe(zipFileOutput);
            archive.finalize();
            await new Promise((resolve, reject) => {
                zipFileOutput.on('close', resolve);
                archive.on('error', reject);
            });
            const zipFileKey = `delivery_catalog/downloads/${zipFileName}`;
            const uploadParams = {
                Bucket: bucketName,
                Key: zipFileKey,
                Body: fs.createReadStream(zipFilePath)
            };

            const data = new Upload({
                client: new S3Client({}),
                params: uploadParams
            });

            data.on("httpUploadProgress", (progress) => {
                // console.log(progress);
            });

            const result = await data.done();
            console.log(JSON.stringify({ file: 'service.js', line: 106, message: `ZIP file uploaded to S3:`, location: result }));
            const S3FilePath = `${process.env.S3_BUCKET_PATH}/${zipFileKey}`;
            // Clean up the local zip file
            fs.unlinkSync(zipFilePath);

            return S3FilePath;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 113, message: error?.message, error }));
            throw error;
        }
    };

    // use common function so commenting this function 
    // async fetchUserDetails(admin_id){
    //     try {
    //         const query = `
    //             SELECT 
    //                 name, email, mobile AS contact, workgroup_name AS workgroup, role_name AS role 
    //             FROM 
    //                 admin_user_details aud
    //             LEFT JOIN 
    //                 admin_workgroups aw ON aud.workgroup_id = aw.id
    //             LEFT JOIN 
    //                 admin_workgroup_roles awr ON aud.workgroup_roles_id = awr.id
    //             WHERE 
    //                 admin_id = ?
    //         `
    //         const [data = null] = await dbConnector.queryExecute(query, [admin_id]);

    //         console.log(JSON.stringify({ file: 'service.js', line: 50, user_details: data }));

    //         if(!data) throw ({message: "User not found!", http_code: HTTP_CODE.BAD_REQUEST});
    //         return data;
    //     } catch (error) {
    //         throw error;
    //     }
    // }
}

module.exports = Services;
