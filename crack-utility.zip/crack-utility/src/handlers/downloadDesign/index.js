const BaseResponse = require('../../common/baseResponse');
const HTTP_CODE = require('../../common/constants');
const schema = require('./schema');
const DownloadDesign = require('./service');
const service = new DownloadDesign();
let baseResponse = new BaseResponse();

exports.handler = async (event) => {
    try {
        const requestBody = typeof event?.body === 'string' ? JSON.parse(event.body) : event?.body || {};
        if (event.requestContext.authorizer) {
            let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            requestBody.adminEmail = authorizerResponse?.email || "";
        }
        console.log(JSON.stringify({ file: 'index.js', line: 15, requestBody }));
        const isRequestValid = schema.validate(requestBody);
        if (isRequestValid?.error) {
            console.log(JSON.stringify({ file: 'index.js', comment: "Validation Error ", line: 14, isRequestValid: isRequestValid }));
            return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, isRequestValid?.error?.details, "Invalid Request");
        }
        const result = await service.downloadDesignFiles(requestBody);
        console.log(JSON.stringify({ file: 'index.js', line: 18, result }));
        if(!result) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, [], 'No files found in the specified S3 folder.');
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { "zipFileURL": result }, 'Zip File Downloaded Successfully');
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 26, message: error?.message, error }));
        return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], error);
    }
};