const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const { Upload } = require("@aws-sdk/lib-storage");
const fs = require('fs');
const archiver = require('archiver');
const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
const Design = require('../../models/planStyleDesigns');
const LogUserActivity = require('../common/logUserActivity');
const logDownloadInfo = new LogUserActivity();
class DownloadDesign {
    async downloadDesignFiles(requestBody) {
        try {
            let designId = requestBody.designId ? requestBody.designId : 0;
            let adminEmail = requestBody.adminEmail ? requestBody.adminEmail : "";
            let query = {
                'unique_id': designId
            };
            const projection = {
                'files': 1
            };
            const result = await Design.find(query, projection).exec();
            // console.log(JSON.stringify({ file: 'service.js', line: 21, message: `result`, result }));
            let inputObject = result[0].files ? result[0].files : {};
            const allFiles = this.getAllValues(inputObject);
            console.log(JSON.stringify({ file: 'service.js', line: 24, message: `files values`, allFiles }));
            if (typeof allFiles !== 'undefined' && allFiles.length > 0) {
                let filePath = await this.downloadZipFile(allFiles, designId);
                let logParams = { designId, adminEmail, activityName: "download" }
                await logDownloadInfo.logUserActivity(logParams);
                return filePath;
            } else {
                return false;
            }

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 144, message: error?.message, error }));
            throw error;
        }
    };

    getAllValues(obj) {
        const values = [];
        for (const key in obj) {
            if (typeof obj[key] === "function") {
                continue; // Skip functions
            }
            if (typeof obj[key] === "object" && obj[key] !== null) {
                const subValues = this.getAllValues(obj[key]);
                if (subValues.length > 0) {
                    values.push(...subValues);
                }
            } else if (obj[key] !== null && obj[key] !== "" && typeof obj[key] !== "boolean") {
                values.push(obj[key]);
            }
        }
        return values;
    }

    async downloadZipFile(filesToZip, designId) {
        const bucketName = process.env.UPLOAD_S3_BUCKET ? process.env.UPLOAD_S3_BUCKET : "design-management-prod";
        const zipFileName = `${designId}_design_all_files_archive.zip`;
        // const archive = archiver('zip');
        const archive = archiver('zip', {
            zlib: { level: 1 } // Compression level (0 to 9)
        });
        // Create a writable stream to write the zip file
        const zipFilePath = '/tmp/' + zipFileName;
        const zipFileOutput = fs.createWriteStream(zipFilePath);
        try {
            for (const file of filesToZip) {
                try {
                    const fileName = file.split('/').pop(); // Extract the file name
                    const getObjectCommand = new GetObjectCommand({ Bucket: bucketName, Key: file });
                    const s3Object = await s3Client.send(getObjectCommand);
                    archive.append(s3Object.Body, { name: fileName });
                } catch (error) {
                    console.error(`Error downloading object ${file} from S3:`, error);
                }
            }

            archive.pipe(zipFileOutput);
            archive.finalize();
            await new Promise((resolve, reject) => {
                zipFileOutput.on('close', resolve);
                archive.on('error', reject);
            });
            const zipFileKey = `delivery_catalog/downloads/${zipFileName}`;
            const uploadParams = {
                Bucket: bucketName,
                Key: zipFileKey,
                Body: fs.createReadStream(zipFilePath)
            };

            const data = new Upload({
                client: new S3Client({}),
                params: uploadParams
            });
            
            data.on("httpUploadProgress", (progress) => {
                // console.log(progress);
            });
            
            const result = await data.done();
            console.log(JSON.stringify({ file: 'service.js', line: 91, message: `ZIP file uploaded to S3:`, location: result }));
            const S3FilePath = `${process.env.S3_BUCKET_PATH}/${zipFileKey}`;
            // Clean up the local zip file
            fs.unlinkSync(zipFilePath);

            return S3FilePath;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 64, message: error?.message, error }));
            throw error;
        }
    };

}

module.exports = DownloadDesign;