const Joi = require("joi");

const schema = Joi.object({
    designId: Joi.number().required(),
    adminEmail: Joi.string().required()
});

module.exports = schema;