const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const unzipper = require('unzipper');
// const request = require('request');
const Database = require('../../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const fileLinks = require('../../services/fileLinksService');
const fileLinksService = new fileLinks();
// AWS.config.update({
//   accessKeyId: process.env.ACCESS_KEY_ID,
//   secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   region: process.env.DM_AWS_REGION,
// });

let baseResponse = new BaseResponse();
const { S3Client, PutObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();

exports.s3ZipFileUploadHandler = async (event, context) => {
  // const s3ZipFileUploadHandler = async () => {//For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);

    const entry_time = new Date();
    console.log('entry_time', entry_time);
    console.log("Inside s3ZipFileUploadHandler");
    const params = JSON.parse(event.body);
    // const params = {
    //   "payload": {
    //     "supporting_files_links": "temp/images.zip"
    //   }
    // }//For local testing uncomment this code
    console.log("Inside unzip_file");
    const first = new Date();
    console.log("first:", first);
    const s3_params = {
      Bucket: process.env.UPLOAD_S3_BUCKET,
      Key: params.payload.supporting_files_links,
    };
    const directory = await unzipper.Open.s3(s3, s3_params);
    if (directory) {
      const file_path = directory.files.map(async (file, index) => {
        const split_path = file.path.split("/");
        const file_path = split_path[split_path.length - 1];
        const content = await file.buffer();
        if (file_path.includes(".")) {
          const link = params.payload.supporting_files_links.split("/").splice(1, 2);
          const link_path = link[0].split(".").splice(0, 1);
          const keyName = `temp/${link_path[0]}/${file_path}`;
          const s3_params = {
            // ACL: 'public-read-write',
            Body: content,
            Key: keyName,
            Bucket: process.env.UPLOAD_S3_BUCKET
            // Bucket: 'design-management-assets',
          };
          const command = new PutObjectCommand(s3_params);
          const res = await s3Client.send(command);
          console.log(index, keyName, " uploaded sucessfully on s3", res);
        }
        return file_path;
      });
      const path = await Promise.all(file_path);
      console.log('path', path);
      const file_links_array = await path.filter((entry) => { return entry.trim() != '' });
      console.log('file_links_array', file_links_array);
      const second = new Date();
      console.log("second:", second);
      const difference1 = (second.getTime() - first.getTime()) / 1000;
      console.log('difference1', difference1);
      if (file_links_array.length > 0) {
        const third = new Date();
        console.log("third:", third);
        const element = {};
        element.file_links = file_links_array;
        const result = await fileLinksService.saveFileLinks(element);
        const forth = new Date();
        console.log("forth:", forth);
        const difference2 = (forth.getTime() - third.getTime()) / 1000;
        console.log('difference2', difference2);
        const exit_time = new Date();
        console.log('exit_time', exit_time);
        const total_run_time = (exit_time.getTime() - entry_time.getTime()) / 1000;
        console.log('total_run_time', total_run_time);
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [{ "id": result }], "Bulk data upload files unziped and uploaded on s3 sucessfully");
      }
      return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, "No file links found for Bulk data unzip file");
    } else {
      return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, "No data found for Bulk data unzip file");
    }
  } catch (error) {
    // TODO - Need to enhance catch block
    console.log("Error in upload file code ..........", error);
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error for bulk upload API: " + error.message);
  }
};
// s3ZipFileUploadHandler();//For local testing uncomment this code