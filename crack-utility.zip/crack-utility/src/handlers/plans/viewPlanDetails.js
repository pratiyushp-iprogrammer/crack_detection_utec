const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const PlansService = require('../../services/plansService');
const UsageDataService = require('../../services/designActionService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

const ViewPlanDetailSchema = require('../../schema/viewPlanDetails');
let baseResponse = new BaseResponse();
let plansService = new PlansService();
let usageDataService = new UsageDataService();

exports.viewPlanDetailsHandler = async(event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        event = Common.reqSanitize(event);
        const params = JSON.parse(event.body);
        var validation = ViewPlanDetailSchema.validate(params);

        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        const result = await plansService.findByUniqueId(params.unique_id);
        if (result) {
            let planDetails = await plansService.fetchPlanDetails(params.unique_id);
            planDetails.s3BasePath = `${process.env.S3_BUCKET_PATH}/`;
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [planDetails], "Plan details fetched successfully.");
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No record found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}