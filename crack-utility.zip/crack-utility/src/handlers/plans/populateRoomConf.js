const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
const PlansService = require('../../services/plansService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let Common = new common()
let baseResponse = new BaseResponse();
let plansService = new PlansService();

exports.populateInternalRoomConfiguration = async(event = {}) => {
        // const populateInternalRoomConfiguration = async() => {
        try {
            let distictFloors = await plansService.fetchUniqueFloors();
            distictFloors.sort();
            if (distictFloors.includes('Above G+4')) {
                distictFloors.push(distictFloors.shift());
            }
            console.log(distictFloors)
            if (!distictFloors) {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No record found.');
            }
            const existingFloorsArray = await plansService.getExistingFloorsRecord(distictFloors);
            if (!existingFloorsArray) {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No matching records found.');
            }
            console.log('length of array', existingFloorsArray.length);
            console.log(JSON.stringify(existingFloorsArray))

            for (const doc of existingFloorsArray) {
                const floorValue = doc.project_details.floors;
                const range = distictFloors.indexOf(floorValue) + 1;
                const rooms = [];
                for (var i = 0; i < range; i++) {
                    let room = {}
                    room = {
                        "index": i,
                        "floor": distictFloors[i],
                        "total_bathrooms": null,
                        "attached_bathrooms": null,
                        "split_bathrooms": null,
                        "combined_bathrooms": null,
                        "common_bathrooms": null,
                        "dining_room": null,
                        "living_room": null,
                        "kitchen": null,
                        "master_bedroom": null,
                        "family_room": null,
                        "store_room": null,
                        "pooja_room": null,
                        "shops": null
                    };
                    rooms.push(room);
                }
                doc.rooms = rooms;
            }
            console.log('after modification existingFloorsArray-----', JSON.stringify(existingFloorsArray))

            const updateRecords = await plansService.bulkUpdateRecords(existingFloorsArray);
            console.log('updateRecords----', JSON.stringify(updateRecords));
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, updateRecords, "Records updated successfully.");
        } catch (error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + error.message);
        }
    }
    // populateInternalRoomConfiguration()