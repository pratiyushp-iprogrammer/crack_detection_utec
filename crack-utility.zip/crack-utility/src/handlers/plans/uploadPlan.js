const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const {LambdaClient, InvokeAsyncCommand} =  require("@aws-sdk/client-lambda");
const lambdaClient = new LambdaClient({region: process.env.AWS_REGION_NAME});
const HTTP_CODE = require('../../common/constants');
const { nanoid } = require('nanoid');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');
const cacheResponse = require('../../common/cacheResponse');
// const {errorDetails} = require("../../common/utils/joi/joi-custom-types.custom");
const {uploadPlanSchema} = require("../../schema/uploadPlanSchema");
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const StatusService = require('../../services/statusService');
let statusService = new StatusService();
let adminDetails = new AdminDetails();
let CacheResponse = new cacheResponse();
// {
//   accessKeyId: process.env.ACCESS_KEY_ID,
//   secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   region: process.env.DM_AWS_REGION
//   // region: "ap-south-1",
// }
let baseResponse = new BaseResponse();

exports.uploadPlanHandler = async (event, context) => {
  // const uploadPlanHandler = async () => {//For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);
    //Generated Queue ID.
    const queue_id = nanoid(10);
    const transaction_id = nanoid(10);
    const params = JSON.parse(event.body);

    let validateSchema = await uploadPlanSchema.validate(params);
    if (validateSchema?.error) {
        console.log('Schema validation error', JSON.stringify(validateSchema.error));
        // const details = errorDetails(validateSchema?.error?.details);
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], validateSchema.error);
        // return helper.errorHandler(false,HTTP_CODE.BAD_REQUEST, [], validateSchema.error);
    }
   
    let email = "";
    // let authorizationToken = event.headers.Authorization;
    // const details = await adminDetails.getAdminDetails(authorizationToken);
    // email = details ? details.name : '';
    if (event.requestContext.authorizer) {
      let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
      email = authorizerResponse.email;
    }
    // const params = {
    //   "payload": {
    //     "file_link": "temp/NewExcelPlans.xlsx",
    //     "file_link_list": [
    //       "DG_1_linked_dwg_file.jpg",
    //       "DG_1_linked_ppt_file.jpg",
    //       "DG_1_linked_psd_file.jpg",
    //       "DG_1_linked_stetch_up_file.jpg",
    //       "DG_1_reference_images.jpg",
    //       "DG_1_three_d_cut_iso_jpg.jpg",
    //       "DG_1_three_d_design_id.jpg",
    //       "DG_1_two_d_line_drawing_jpg.jpg",
    //       "DG_1_two_d_rendered_plan_jpg.jpg",
    //       "DG_1_two_d_rendered_plan_pdf.jpg",
    //       "DG_1_utec_pro_link.jpg",
    //       "DG_2_linked_dwg_file.jpg",
    //       "DG_2_linked_ppt_file.jpg",
    //       "DG_2_linked_psd_file.jpg",
    //       "DG_2_linked_stetch_up_file.jpg",
    //       "DG_2_reference_images.jpg",
    //       "DG_2_three_d_cut_iso_jpg.jpg",
    //       "DG_2_three_d_design_id.jpg",
    //       "DG_2_two_d_line_drawing_jpg.jpg",
    //       "DG_2_two_d_rendered_plan_jpg.jpg",
    //       "DG_2_two_d_rendered_plan_pdf.jpg",
    //       "DG_2_utec_pro_link.jpg",
    //       "DG_3_linked_dwg_file.jpg",
    //       "DG_3_linked_ppt_file.jpg",
    //       "DG_3_linked_psd_file.jpg",
    //       "DG_3_linked_stetch_up_file.jpg",
    //       "DG_3_reference_images.jpg",
    //       "DG_3_three_d_cut_iso_jpg.jpg",
    //       "DG_3_three_d_design_id.jpg",
    //       "DG_3_two_d_line_drawing_jpg.jpg",
    //       "DG_3_two_d_rendered_plan_jpg.jpg",
    //       "DG_3_two_d_rendered_plan_pdf.jpg",
    //       "DG_3_utec_pro_link.jpg",
    //       "DG_4_linked_dwg_file.jpg",
    //       "DG_4_linked_ppt_file.jpg",
    //       "DG_4_linked_psd_file.jpg",
    //       "DG_4_linked_stetch_up_file.jpg",
    //       "DG_4_reference_images.jpg",
    //       "DG_4_three_d_cut_iso_jpg.jpg",
    //       "DG_4_three_d_design_id.jpg",
    //       "DG_4_two_d_line_drawing_jpg.jpg",
    //       "DG_4_two_d_rendered_plan_jpg.jpg",
    //       "DG_4_two_d_rendered_plan_pdf.jpg",
    //       "DG_4_utec_pro_link.jpg"
    //     ]
    //   }
    // }//For local testing uncomment this code
    //TODO Call this function excelToJsonParse() using lambda.invoke
    const lambda_payload = {
      // created_by: params.payload.created_by,
      created_by: email,
      file_link: params.payload.file_link,
      file_link_list_array: params.payload.file_link_list,
      queue_id,
      transaction_id
    }
    var lambda_params = {
      FunctionName: process.env.DM_EXCEL_PARSING_LAMBDA_ARN,
      // InvocationType: "Event",
      // Payload: JSON.stringify(lambda_payload),
      // Qualifier: "1"
      InvokeArgs: JSON.stringify(lambda_payload)
    };
    console.log('lambda_params', lambda_params);
    // lambda.invokeAsync(lambda_params, function (err, data) {
    //   console.log("Inside lambda.invoke");
    //   if (err) console.log(".......err.....", err, err.stack);
    //   else console.log(".............", data);
    // });    
    const command = new InvokeAsyncCommand(lambda_params);
    const lambdaResponse = await lambdaClient.send(command);
    console.log('lambdaResponse', lambdaResponse);
    const response_data = {
      created_by: params.payload.created_by,
      type: "Plans",
      queueId: queue_id,
      transaction_id: transaction_id,
      status_code: 1,
      message: "Import process initiated(#0001)",
      lambdaResponse
    }
    console.log('response_data', response_data);
    const result = await statusService.insertStatus(response_data);
    response_data.s3BasePath = `${process.env.S3_BUCKET_PATH}/`
    if (result) {
      // await CacheResponse.clearCache(null, event, null);
      await CacheResponse.clearRelevantCache(null, event, null);
      return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, response_data, "Bulk data upload parsing Excel data Initiated");
    } else {
      return baseResponse.getResponseObject(event, true, HTTP_CODE.NOT_FOUND, "No data found for Bulk data from excel file");
    }
  } catch (error) {
    // TODO - Need to enhance catch block
    console.log("Error in upload file code ..........", error);
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error for bulk upload API: " + error.message);
  }
};
// uploadPlanHandler();//For local testing uncomment this code