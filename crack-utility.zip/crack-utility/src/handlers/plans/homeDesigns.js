const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const PlansService = require('../../services/plansService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let plansService = new PlansService();

exports.homeDesignsHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        const path = event?.path || '/v1/plans/getHomeDesigns';
        let response;
        if(path == "/v1/plans/getHomeDesigns") {
            response = await plansService.fetchHomeDesigns(event);
        } else if(path == "/v2/plans/getHomeDesigns"){
            response = await plansService.fetchHomeDesignsV2(event);
        }
        if (response) {
            let s3BasePath = `${process.env.S3_BUCKET_PATH}/`;
            let s3BasePathThumbnail = `${process.env.S3_BUCKET_PATH}/thumbnails/`;
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { response, "totalCount": response["totalRecordsCount"], "s3BasePath": s3BasePath, "s3BasePathThumbnail": s3BasePathThumbnail }, 'Plans listed successfully.');
        } else {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No records found.');
        }
    } catch (e) {
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}