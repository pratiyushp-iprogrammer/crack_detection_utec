const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const StatusService = require('../../services/statusService');
const Database = require('../../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
let statusService = new StatusService();
let baseResponse = new BaseResponse();
exports.updateStatusHandler = async (event) => {
  // const updateStatusHandler = async () => {
  try {
    event = Common.reqSanitize(event);
    // const event = {};
    // event.body = {
    //   "queueId": "2LA2wMyThZ",
    //   "status_code": 99,
    //   "message": "Bulk Upload operation Aborted"
    // }
    console.log("Inside updateStatusHandler");
    console.log('event', event);
    console.log('typeof(event.body)', typeof (event.body));
    const params = JSON.parse(event.body);
    console.log('params', params);
    const response = await statusService.updateStatus(params);
    console.log('response', response);
    if (response) {
      return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Status details updated successfully!");
    }
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
}
// updateStatusHandler();