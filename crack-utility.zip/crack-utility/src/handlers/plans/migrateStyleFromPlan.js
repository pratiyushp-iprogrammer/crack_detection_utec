const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const PlansService = require('../../services/plansService');
const StylesService = require('../../services/stylesService');

const Plans = require('../../models/plans');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const UniqueIdGenerationService = require('../../services/uniqueIdGeneration');
let uniqueIdGenerationService = new UniqueIdGenerationService();
const MigrateStyleFromPlanSchema = require('../../schema/migrateStyleFromPlan');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let plansService = new PlansService();
let stylesService = new StylesService();

exports.migrateStyleFromPlanHandler = async (event, context) => {
    if (event.requestContext.authorizer) {
        let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
        console.log(authorizerResponse.email);
    }
    try {
        event = Common.reqSanitize(event);

        const objRequest = JSON.parse(event.body);
        var validation = MigrateStyleFromPlanSchema.validate(objRequest);
        console.log('validation.error', validation);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        let ipLimit = (objRequest && objRequest.limit) ? objRequest.limit : 0;
        console.log('ipLimit', ipLimit);
        var response = await Plans.find({
            $and: [
                {
                    $or: [
                        { $and: [{ 'files.three_d_cut_iso_jpg': { "$gt": {} } }, { 'files.three_d_cut_iso_jpg.ground': { "$ne": "" } }] },
                        { $and: [{ 'files.three_d_design_id': { "$gt": {} } }, { 'files.three_d_design_id.front': { "$ne": "" } }] },

                    ]
                },
                { "is_active": 1 }
            ]
        })
            .sort({ _id: -1 })
            .limit(ipLimit);
        var unprocessedPlans = [];
        for (let i = 0; i < response.length; i++) {
            const element = response[i];
            var styleObj = {};
            let params = {};
            params.source = 'SG';
            var unique_id = 'SG_' + Math.floor(1000 + Math.random() * 9000) + "_R";
            const responseUniqueId = await uniqueIdGenerationService.generateId(params);
            if (responseUniqueId) {
                const lastRecord = await uniqueIdGenerationService.getLastInsertedRecord();
                unique_id = `${params.source}_${lastRecord[0].id}`;
            } else {
                unprocessedPlans.push(element.unique_id);
                continue;
            }
            console.log('unique_id', unique_id);
            styleObj.source = element.source;
            if (element.source == "Design Gallery") {
                styleObj.source = "Styles Gallery";
            }
            styleObj.unique_id = unique_id;
            styleObj.element_type = "Elevations";
            styleObj.sr_number = element.sr_number;
            styleObj.is_active = 1;
            styleObj.option_number = 1;
            styleObj.design_name = element.design_name;
            styleObj.design_short_description = element.design_short_description;
            styleObj.design_long_description = element.design_long_description;

            //files
            styleObj.files = {};
            styleObj.files.three_d_design_id = element.files.three_d_design_id;
            styleObj.files.three_d_cut_iso_jpg = element.files.three_d_cut_iso_jpg;

            //plot_details
            styleObj.plot_details = {};
            styleObj.plot_details.plot_area = element.plot_details.plot_area;
            styleObj.plot_details.plot_length = element.plot_details.plot_length;
            styleObj.plot_details.plot_width = element.plot_details.plot_width;
            styleObj.plot_details.plot_shape = element.plot_details.plot_shape;
            styleObj.plot_details.open_sides_of_the_plot = element.plot_details.open_sides_of_the_plot;

            //project_details
            //styleObj.project_details = element.project_details;
            styleObj.project_details = {};
            styleObj.project_details.typology = element.project_details.typology;
            styleObj.project_details.estimated_cost_of_construction = element.project_details.estimated_cost_of_construction;
            styleObj.project_details.builtup_area = element.project_details.builtup_area;
            styleObj.project_details.floor_plate_area_of_ground_floor = element.project_details.floor_plate_area_of_ground_floor;
            styleObj.project_details.floor_plate_length = element.project_details.floor_plate_length;
            styleObj.project_details.floor_plate_width = element.project_details.floor_plate_width;
            styleObj.project_details.floors = element.project_details.floors;
            styleObj.project_details.bedrooms = element.project_details.bedrooms;
            styleObj.project_details.shared_wall = element.project_details.shared_wall;
            styleObj.project_details.for_two_shared_wall_adjacent_parallel = element.project_details.for_two_shared_wall_adjacent_parallel;
            styleObj.project_details.space_allocation = element.project_details.space_allocation;
            styleObj.project_details.style = element.project_details.style;
            if (element.project_details.low_range_budget) {
                styleObj.project_details.low_range_budget = element.project_details.low_range_budget;
            }
            if (element.project_details.high_range_budget) {
                styleObj.project_details.high_range_budget = element.project_details.high_range_budget;
            }

            //geography
            styleObj.geography = element.geography;

            //family_details
            styleObj.family_details = element.family_details;

            //parking
            styleObj.parking = element.parking;

            //senior_citizen_friendly
            styleObj.senior_citizen_friendly = element.senior_citizen_friendly;

            //vaastu_compliancy
            styleObj.vaastu_compliancy = element.vaastu_compliancy;

            //rooms
            styleObj.rooms = element.rooms;

            //open_areas_configuration
            styleObj.open_areas_configuration = element.open_areas;

            //special_amenities
            styleObj.special_amenities = element.special_amenities;

            //stylized
            styleObj.stylized = element.stylized;

            //roof
            styleObj.roof = element.roof;

            //material_treatment
            styleObj.material_treatment = element.material_treatment;

            //structural_elements
            styleObj.structural_elements = element.structural_elements;

            //colors
            styleObj.colors = element.colors;

            var insertResponse = await stylesService.createStyle(styleObj);
            console.log('insert response', insertResponse);
            console.log('plans unique id', element.unique_id);
            if (insertResponse) {
                var updatedPlanObj = {
                    "three_d_linked_design_id": [unique_id],
                    "files": {
                        "two_d_rendered_plan_jpg": element.files.two_d_rendered_plan_jpg,
                        "two_d_line_drawing_pdf": element.files.two_d_line_drawing_pdf,
                        "two_d_line_drawing_jpg": element.files.two_d_line_drawing_jpg,
                        "three_d_design_id": {},
                        "three_d_cut_iso_jpg": {},
                        "linked_estimation_id": element.files.linked_estimation_id,
                        "linked_stetch_up_file": element.files.linked_stetch_up_file,
                        "linked_dwg_file": element.files.linked_dwg_file,
                        "linked_psd_file": element.files.linked_psd_file,
                        "linked_ppt_file": element.files.linked_ppt_file,
                        "utec_pro_link": element.files.utec_pro_link
                    },
                    "unique_id": element.unique_id
                };
                await plansService.updatePlan(updatedPlanObj);
            }
        }
        console.log('The unprocessed plans are', JSON.stringify(unprocessedPlans));
        if (response) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { "totalCount": response["totalRecordsCount"] }, response.length + ' 3D Plans migrated successfully.');
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No records found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}