const Database = require('../../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants.js');
const PlansServiceDummy = require('../../services/plansServiceDummy.js');
let baseResponse = new BaseResponse();
let plansService = new PlansServiceDummy();
exports.deleteBulkUploadHandler = async (event, context) => {
  // const deleteBulkUploadHandler = async () => {//For local testing uncomment this code
  try {
    event = Common.reqSanitize(event);

    console.log("Inside deleteBulkUploadHandler");
    let params = JSON.parse(event.body);
    // const params = {
    //   "payload": {
    //     "transaction_id": "oTviCeqSFq",
    //     "delete_all": true,
    //     "unique_id": ""
    //   }
    // }//For local testing uncomment this code
    if (params.payload.delete_all === true)
      params.payload.unique_id = '';
    const result = await plansService.deleteRecords(params.payload.transaction_id, params.payload.unique_id);
    if (!result) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "No data found for transaction id: " + params.payload.transaction_id);
    }
    return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Data deleted successfully");
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
}
// deleteBulkUploadHandler();