const Database = require('../../common/database');
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const UniqueIdGenerationService = require('../../services/uniqueIdGeneration');
const GenerateUniqueIdSchema = require('../../schema/generateUniqueId');
const HTTP_CODE = require('../../common/constants');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let uniqueIdGenerationService = new UniqueIdGenerationService();

exports.generateUniqueIdHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);

        const params = JSON.parse(event.body);
        var validation = GenerateUniqueIdSchema.validate(params);

        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid request.");
        }
        const response = await uniqueIdGenerationService.generateId(params);
        if (response) {
            const lastRecord = await uniqueIdGenerationService.getLastInsertedRecord();
            let unique_id = `${params.source}_${lastRecord[0].id}`;
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [unique_id], "Id generated successfully!");
        }
        return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], "Something went wrong.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}