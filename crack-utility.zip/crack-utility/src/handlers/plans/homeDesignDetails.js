const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const PlansService = require('../../services/plansService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
// const ObjectId = require('mongodb').ObjectId;
const mongoose = require('mongoose')
const UserProfileActionService = require('../../services/userProfileActionsService');
const Styles = require('../../models/styles');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let plansService = new PlansService();
let userProfileActionService = new UserProfileActionService();

exports.homeDesignDetailsHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        let userId;
        let authorizerResponse;
        const path = event?.path || '/v1/plans/designDetails';
        console.log(path)
        if (event.requestContext.authorizer) {
            authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            userId = authorizerResponse.userId;

            const params = JSON.parse(event.body);

            var response;
            if(path === '/v1/plans/designDetails') {
                response = await plansService.findByUniqueId(params.unique_id);
            } else if (path === '/v2/plans/designDetails'){
                response = await plansService.findByUniqueIdV2(params.unique_id);   
            }
            
            if (response) {
                let planDetails;
                if(path === '/v1/plans/designDetails') {
                    planDetails = await plansService.fetchHomeDesignsDetails(params.unique_id);
                } else if (path === '/v2/plans/designDetails'){
                    planDetails = await plansService.fetchHomeDesignsDetailsV2(params.unique_id);   
                }

                // console.log("planDetails", JSON.stringify(planDetails))
                var planId = new mongoose.Types.ObjectId(planDetails[0]?._id);
        
                let seniorCitizenFriendly = false;
                if((planDetails[0]?.maxThreeStairs === "Yes" || planDetails[0]?.provisionOfRamp === "Yes") && planDetails[0]?.oneBhkOnGroundFloor ){
                    seniorCitizenFriendly = true;
                }

                let vaastuCompliant = false;
                let vaastuEntryDirection = (planDetails[0]?.facingEntry === "North" || planDetails[0]?.facingEntry === "East" || planDetails[0]?.facingEntry === "North East")? true : false;
                let orientationOfKitchen = (planDetails[0]?.orientationOfKitchen === "South East")? true : false;
                let orientationOfPoojaRoom = (planDetails[0]?.orientationOfPoojaRoom === "North" || planDetails[0]?.orientationOfPoojaRoom === "East" || planDetails[0]?.orientationOfPoojaRoom === "North East")? true : false;;
                let orientationOfMasterBedroom = (planDetails[0]?.orientationOfMasterBedroom === "South West")? true : false;
                
                if(vaastuEntryDirection === true && orientationOfKitchen === true && orientationOfPoojaRoom === true && orientationOfMasterBedroom === true){
                    vaastuCompliant = true;
                }

                let threeDLinkedDesign = null;
                if(planDetails[0]?.threeDLinkedDesignId?.length > 0 && Array.isArray(planDetails[0]?.threeDLinkedDesignId)  ){
                    let uniqueId = planDetails[0]?.threeDLinkedDesignId;
                    threeDLinkedDesign = await Styles.find({ unique_id:{$in:uniqueId }},{ image_files:1, "files.three_d_design_id.front":1 });
                }
                
                // const count = await userProfileActionService.getActionCountData(planId);
                // console.log("count", count)
                // const isFavourite = await userProfileActionService.checkRecord(planId, userId, 'plan', 'favourite');
                // const isLiked = await userProfileActionService.checkRecord(planId, userId, 'plan', 'like');

                const userResult = await userProfileActionService.getCountData(planId, Number(userId));
                console.log(JSON.stringify(userResult));
                let isFavourite = false;
                let isLiked = false;
                let likeCount = planDetails[0]?.numberOfLikes;
                let viewCount = planDetails[0]?.numberOfViews;
                if(userResult && userResult.length > 0) {
                    userResult.map((element) => {
                        if (element?._id?.action == 'like') {
                            isLiked = element.isLiked
                          }
                        
                          if (element?._id?.action == 'favourite') {
                            isFavourite = element.isFavourite
                          }
                    })
                    // isFavourite = userResult.isFavourite;
                    // isLiked = userResult.isLiked;
                    // likeCount = userResult.likeCount;
                }

                planDetails[0]['s3BasePath'] = `${process.env.S3_BUCKET_PATH}/`;

                if(path === '/v1/plans/designDetails') {
                    await plansService.viewCountHomeDesigns(planId);
                } else if (path === '/v2/plans/designDetails'){
                    await plansService.viewCountHomeDesignsV2(planId); 
                }

                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, {
                    data: planDetails, 
                    isFavourite: isFavourite, 
                    isLiked: isLiked, 
                    likeCount: likeCount, 
                    viewCount: viewCount,
                    seniorCitizenFriendly:seniorCitizenFriendly, 
                    vaastuCompliant:vaastuCompliant,
                    threeDLinkedDesign:threeDLinkedDesign}, "Plan details fetched successfully.");
            }
            return baseResponse.getResponseObject(event,true, HTTP_CODE.SUCCESS, [], 'No record found.');
        }
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event,false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }

}
