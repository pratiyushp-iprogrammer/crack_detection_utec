const json_structure = require('./plans.json');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const Database = require('../../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const hasIn = require("lodash/hasIn");
const set = require('lodash/set');
const uniqBy = require('lodash/uniqBy')
const readXlsxFile = require('read-excel-file/node');
const UniqueIdGenerationService = require('../../services/uniqueIdGeneration');
let uniqueIdGenerationService = new UniqueIdGenerationService();
const PlansServiceDummy = require('../../services/plansServiceDummy');
const tempPlanServiceDummy = new PlansServiceDummy();
const StatusService = require('../../services/statusService');
let statusService = new StatusService();
const PlansService = require('../../services/plansService');
const planService = new PlansService();
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
let baseResponse = new BaseResponse();
// AWS.config.update({
//     accessKeyId: "AKIAXBXKDH5EBYK757WO",
//     secretAccessKey: "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",
//     region: "ap-south-1"
// });
const check_file_link = async(data, file_links_array, file_type) => {
    try {
        const data_list = data.split(",");
        const result = data_list.map((data_item) => {
            let res = '';
            if (!file_type)
                res = (file_links_array.includes(obj)) ? true : false;
            else {
                console.log('data', data);
                const fileExt = String(data_item.split(".").pop()).toLowerCase().trim(" ");
                const obj = data_item.trim(" ")
                res = (file_links_array.includes(obj) && file_type.includes(fileExt)) ? true : false;
            }
            return res;
        });
        return result.includes(false) ? false : true;
    } catch (err) {
        return err;
    }
};
exports.excelToJsonParseHandler = async(event, context) => {
    // const excelToJsonParseHandler = async() => { // For local testing uncomment this code
    try {
        // event = Common.reqSanitize(event);
        let source_name = '';
        const regExq = /^(?!$|.*\'[^\x22]+$)(?:([0-9]+)\')?(?:([0-9]+)\x22?)?$/gm;
        const regExp2 = /[A-Za-z0-9'’‘’ _@./#%&+-,]+/g;
        const start = new Date();
        console.log('start', start);
        console.log("Inside excelToJsonParseHandler Function");
        // const event = {
        //     file_link: 'temp/bulkUpload/plans/ab5e1464-a2e7-4fd1-aba9-f670eab3aa65/PlansData_8_10_2021_new.xlsx',
        //     file_link: 'temp/file_1.xlsx',
        //     file_link_list_array: [],
        //     queue_id: 'fz_B8spxs4',
        //     transaction_id: 'ZZkIqKkQj6'
        // }
        console.log('event', event);
        const { file_link, file_link_list_array, queue_id, transaction_id, created_by } = event;
        const s3_params = {
            Bucket: process.env.UPLOAD_S3_BUCKET,
            // Bucket: 'design-management-assets',
            Key: file_link,
        };
        const file_link_list_array2 = file_link_list_array.map((element) => {
            const get_file_link = element.split("/");
            return get_file_link.pop();
        });
        // console.log('file_link_list_array2', file_link_list_array2);
        const getObjectCommand = new GetObjectCommand(s3_params);
        const { Body } = await s3Client.send(getObjectCommand);
        const excel_file_data = Body;
        const finalResult = await readXlsxFile(excel_file_data).then(async(rows) => {
            let rowsIndex = '';
            const first = new Date();
            console.log('first', first);
            rows.forEach((columns, index1) => {
                const res = columns.every(element => element === null)
                if (res) {
                    rowsIndex = index1 + 1;
                }
                return;
            });
            console.log('rowsIndex', rowsIndex);
            rows.splice(0, rowsIndex);
            const headers = rows.shift();
            console.log('headers.length', headers.length)
            const valid_data_result_array = [];
            const duplicate_id_result_array = [];
            const invalid_data_entry_array = [];
            const duplicate_record_unique_ids = [];
            let rooms;
            const distinctFloors = ['G', 'G+1', 'G+2', 'G+3', 'G+4'];

            function generateRoomsArray(floorValue) {
                let finalArr = [];
                let range = distinctFloors.indexOf(floorValue) + 1;
                for (var i = 0; i < range; i++) {
                    let roomsObj = {
                        "index": null,
                        "floor": null,
                        "total_bathrooms": null,
                        "attached_bathrooms": null,
                        "split_bathrooms": null,
                        "combined_bathrooms": null,
                        "common_bathrooms": null,
                        "dining_room": null,
                        "living_room": null,
                        "kitchen": null,
                        "master_bedroom": null,
                        "family_room": null,
                        "store_room": null,
                        "pooja_room": null,
                        "shops": null
                    };
                    roomsObj.index = i;
                    roomsObj.floor = distinctFloors[i];
                    finalArr.push(roomsObj)

                }
                return finalArr;
            }
            const floorIndex = headers.indexOf('Floors');
            let floorValue;
            let floorsToCheck;
            for (const [i, excel_item] of rows.entries()) {
                // i = 0
                // excel item  = 1st row
                const error_message = [];
                const construct_json_body = {};
                let duplicate_id_result = false;
                let invalid_data_entry = false;

                if (headers[floorIndex] === 'Floors') {
                    floorValue = excel_item[floorIndex];
                    if (floorValue !== null || floorValue !== '') {
                        rooms = await generateRoomsArray(floorValue);

                        var arr = [{
                                floorValue: "G",
                                valueToTraverse: ["G"]
                            },
                            {
                                floorValue: "G+1",
                                valueToTraverse: ["G", "G+1"]
                            },
                            {
                                floorValue: "G+2",
                                valueToTraverse: ["G", "G+1", "G+2"]
                            },
                            {
                                floorValue: "G+3",
                                valueToTraverse: ["G", "G+1", "G+2", "G+3"]
                            },
                            {
                                floorValue: "G+4",
                                valueToTraverse: ["G", "G+1", "G+2", "G+3", "G+4"]
                            }
                        ];

                        for (let i = 0; i < arr.length; i++) {
                            if (floorValue === arr[i].floorValue) {
                                floorsToCheck = arr[i].valueToTraverse;
                            }
                        }
                    }

                }

                for (const [ind, index] of excel_item.entries()) {
                    // ind  = index of 1st row
                    // index = row value
                    const i = excel_item.indexOf(index);
                    let data = excel_item[i];
                    const value = json_structure[headers[ind]]; //value={ type: 'string', key_name: 'unique_id', required: true }
                    const check = hasIn(json_structure, headers[ind]); //headers[ind]='Unique ID'
                    let roomObjectTemp = {};
                    if (check) {
                        if (value.type === 'string') {
                            if (data === null) {
                                data = '';
                            }
                        }
                        if (value.required === true) {
                            if (value.type === 'number') {
                                if (data === null) {
                                    data = 0;
                                }
                                let roomIndex;
                                if (headers[ind].indexOf("Total Bathrooms") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                            if(rooms.length > 0){
                                                rooms[roomIndex].total_bathrooms = excel_item[ind];
                                                set(construct_json_body, 'rooms', rooms);
                                            }
                                            
                                        // roomObjectTemp[''total_bathrooms] = excel_item[i];
                                        // console.log('roomObjectTemp.......', roomObjectTemp)
                                    }
                                }
                                // rooms[roomIndex] = roomObjectTemp;
                                // console.log(' at line 182.....', rooms);

                                if (headers[ind].indexOf("Attached Bathrooms") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].attached_bathrooms = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                        
                                    }
                                }

                                if (headers[ind].indexOf("Common Bathrooms") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].common_bathrooms = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[ind].indexOf("Dining Room") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].dining_room = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }


                                if (headers[ind].indexOf("Living Room") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].living_room = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[ind].indexOf("Family Room") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].family_room = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[ind].indexOf("Kitchen") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].kitchen = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[ind].indexOf("Store Room") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].store_room = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[ind].indexOf("Pooja Room") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].pooja_room = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[ind].indexOf("Shops") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].shops = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[ind].indexOf("Split Bathrooms") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].split_bathrooms = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[ind].indexOf("Combined Bathrooms") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].combined_bathrooms = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[ind].indexOf("Master Bedroom") !== -1) {
                                    let headerTitle = headers[ind];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if(rooms.length > 0){
                                            rooms[roomIndex].master_bedroom = excel_item[ind];
                                            set(construct_json_body, 'rooms', rooms);    
                                        }
                                    }
                                }

                                if (typeof(data) !== 'number') {
                                    invalid_data_entry = true;
                                    error_message.push('Incorrect Data Entry in field ' + headers[ind]);
                                    console.log('1.', headers[ind], "----------", data);
                                    if (headers[ind] === 'Suitable Plot Area')
                                        set(construct_json_body, 'plot_details.plot_area_range', '');
                                    if (headers[ind] === 'Suitable Plot Width')
                                        set(construct_json_body, 'plot_details.plot_entrance_width_range', '')
                                    if (headers[ind] === 'Floor Plate Width (Entrance Side)')
                                        set(construct_json_body, 'project_details.floor_plate_width_range', '');
                                } else if (headers[ind] === 'Suitable Plot Area') {
                                    const plotAreaRange = baseResponse.getRange(data, 'plot_details.plot_area', 'plans');
                                    set(construct_json_body, 'plot_details.plot_area_range', plotAreaRange);
                                } else if (headers[ind] === 'Suitable Plot Width') {
                                    const plotEntranceWidthRange = baseResponse.getRange(data, 'plot_details.plot_width', 'plans');
                                    set(construct_json_body, 'plot_details.plot_entrance_width_range', plotEntranceWidthRange);
                                } else if (headers[ind] === 'Floor Plate Width (Entrance Side)') {
                                    const floorPlateWidth = baseResponse.getRange(data, 'project_details.floor_plate_width', 'plans');
                                    set(construct_json_body, 'project_details.floor_plate_width_range', floorPlateWidth);
                                }
                            }
                            if (value.type === 'dropdown') {
                                if (data === null)
                                    data = '';
                                else {
                                    if (((String(data).toUpperCase() === "YES" || String(data).toUpperCase() === "NO" || data === '') && (headers[ind] !== 'Is Active'))) {
                                        if (value.values.includes(String(data).toUpperCase())) {
                                            if (String(data).toUpperCase() === 'YES') data = 'Yes';
                                            if (String(data).toUpperCase() === 'NO') data = "No";
                                            if (String(data).toUpperCase() === '') data = '';
                                        } else {
                                            invalid_data_entry = true;
                                            error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                            console.log('2.', headers[ind], "----------", data);
                                        }
                                    } else if (!(value.values.includes(data))) {
                                        invalid_data_entry = true;
                                        error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                        console.log('3.', headers[ind], "----------", data, typeof(data));
                                    }
                                }
                            }
                            if (value.type === 'image_link') {
                                if (data === null || data === undefined)
                                    data = '';
                                else {
                                    data = data.toLowerCase();
                                    console.log("image_link---", data);
                                    const result = await check_file_link(data, file_link_list_array2, value.file_type);
                                    if (!result) {
                                        invalid_data_entry = true;
                                        error_message.push('Incorrect/Missing supporting files in field ' + headers[ind])
                                        console.log('4.', headers[ind], "----------", data);
                                    }
                                }
                            }
                            if (headers[ind] === 'Source') {
                                if (data === null || data === '' || !(value.values.includes(data))) {
                                    source_name = '';
                                    invalid_data_entry = true;
                                    error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                    console.log('5.', headers[ind], "----------", data);
                                } else {
                                    source_name = data;
                                }
                            }
                            if (headers[ind] === 'Unique ID') {
                                const data_array = await planService.findByUniqueId(data);
                                if (data === null || data === undefined || data_array === false) {
                                    let params = {};
                                    if (source_name === 'Service Request' && (data === null || data === undefined || data === '')) {
                                        invalid_data_entry = true;
                                        error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                    }
                                    if (source_name === 'Design Gallery')
                                        params.source = 'DG';
                                    if (source_name === 'Crowd Sourced')
                                        params.source = 'CS';
                                    if (params.source) {
                                        const response = await uniqueIdGenerationService.generateId(params);
                                        if (response) {
                                            const lastRecord = await uniqueIdGenerationService.getLastInsertedRecord();
                                            let unique_id = `${params.source}_${lastRecord[0].id}`;
                                            data = unique_id;
                                        }
                                    }
                                } else if (source_name === '') {
                                    invalid_data_entry = true;
                                    error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                } else {
                                    duplicate_record_unique_ids.push(data);
                                    duplicate_id_result = true;
                                }
                            }
                            if (value.type === 'feetAndInches') {
                                if (data === null)
                                    data = '';
                                else {
                                    var regex = new RegExp(regExq, "g");
                                    if (!regex.test(data)) {
                                        invalid_data_entry = true;
                                        error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                        console.log('6.', headers[ind], "----------", data);
                                    }
                                }
                            }
                            if (value.type === 'geoPattern') {
                                var regex = new RegExp(regExp2, "g");
                                if (!regex.test(data)) {
                                    invalid_data_entry = true;
                                    error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                    console.log('7.', headers[ind], "----------", data);
                                } else if (data === null)
                                    data = '';
                            }
                            if (value.type === 'custom_dropdown') {
                                if (data === null)
                                    data = '';
                                else {
                                    const result = await check_file_link(data, value.values);
                                    if (!result && value.values.length > 0) {
                                        console.log(headers[ind], '----', value.values, "...........", data);
                                        invalid_data_entry = true;
                                        error_message.push('Incorrect Data Entry in field ' + headers[ind])
                                        console.log('8.', headers[ind], "----------", data, typeof(data));
                                    }
                                }
                            }
                            construct_json_body.transaction_id = transaction_id;
                            construct_json_body.created_by = created_by;
                            construct_json_body.updated_by = created_by;
                            construct_json_body.is_active = 1;
                            set(construct_json_body, value.key_name, data);
                        } else {
                            console.log(headers[ind], '----', value.key_name);
                        }
                    }
                }
                // console.log('construct_json_body', construct_json_body);
                // if (error_message.includes('Incorrect Data Entry') && error_message.includes('Incorrect/Missing supporting files'))
                //   construct_json_body.status = 'Incorrect/Missing supporting files, Incorrect Data Entry'
                // else if (error_message.includes('Incorrect Data Entry'))
                //   construct_json_body.status = 'Incorrect Data Entry'
                // else if (error_message.includes('Incorrect/Missing supporting files'))
                //   construct_json_body.status = 'Incorrect/Missing supporting files'
                // else
                //   construct_json_body.status = '';
                const parsingInprogressStatus = {
                    queueId: queue_id,
                    status_code: 2,
                    message: "Validating records and assets is in progress(#0002)",
                    total_records: rows.length,
                    total_images: file_link_list_array2.length,
                    parsing_progress: i
                }
                const updateQueueStatus = await statusService.updateStatus(parsingInprogressStatus);
                const check_queue_status = await statusService.findByQueueId(queue_id);
                if (check_queue_status.status_code == 99) {
                    return '';
                }
                if (duplicate_id_result === true && invalid_data_entry === false) {
                    construct_json_body.duplicate = true;
                    duplicate_id_result_array.push(construct_json_body);
                }
                if (invalid_data_entry) {
                    construct_json_body.invalid = true;
                    invalid_data_entry_array.push(construct_json_body);
                }
                if (duplicate_id_result === false && invalid_data_entry === false) {
                    construct_json_body.valid = true;
                    valid_data_result_array.push(construct_json_body);
                }
                const getUniqMessages = uniqBy(error_message)
                console.log('getUniqMessages', getUniqMessages)
                let incorrect_data = [];
                let incorrect_files = [];
                getUniqMessages.forEach(item => {
                    if (item.includes('Incorrect/Missing supporting files in field')) incorrect_files.push(item.replace('Incorrect/Missing supporting files in field', ''))
                    if (item.includes('Incorrect Data Entry in field')) incorrect_data.push(item.replace('Incorrect Data Entry in field', ''))
                });
                console.log("incorrect_data...", incorrect_data)
                console.log('incorrect_files', incorrect_files)
                if (incorrect_data.length > 0 && incorrect_files.length > 0)
                    construct_json_body.status = 'Incorrect data in field(s) ' + incorrect_data.join(',') + ' and Incorrect/Missing supporting files in field(s) ' + incorrect_files.join(',')
                else if (incorrect_data.length > 0)
                    construct_json_body.status = 'Incorrect data in field(s) ' + incorrect_data.join(',')
                else if (incorrect_files.length > 0)
                    construct_json_body.status = 'Incorrect/Missing supporting files in field(s) ' + incorrect_files.join(',')
                else
                    construct_json_body.status = '';
                console.log(".......................", construct_json_body.status)
            }
            //excel data parsed to JSON obejct
            const data_array = await planService.getUniqueIdDataSet(duplicate_record_unique_ids);
            const duplicate_id_set = data_array.map((ele) => {
                return ele.unique_id;
            });
            console.log('duplicate_id_set', duplicate_id_set);
            let difference = duplicate_record_unique_ids.filter(x => !duplicate_id_set.includes(x));
            console.log('difference', difference);
            const final_duplicate_array = [];

            duplicate_id_result_array.forEach((ele) => {
                //we need to shift ids in difference in either valid/invalid data set
                if (difference.includes(ele.unique_id)) {
                    // if (!ele.invalid) {
                    ele.duplicate = false;
                    ele.valid = true;
                    valid_data_result_array.push(ele)
                        // }
                } else {
                    ele.duplicate = true;
                    final_duplicate_array.push(ele);
                }
            });
            // console.log('final_duplicate_array', final_duplicate_array);
            // invalid_data_entry_array.forEach(ele => {
            //   if (duplicate_id_set.includes(ele.unique_id)) {
            //     if (ele.duplicate) {
            //       ele.duplicate = true;
            //       ele.invalid = true;
            //     }
            //   } else
            //     ele.duplicate = false;
            // })
            const demo = [];
            demo.push(valid_data_result_array, invalid_data_entry_array, final_duplicate_array);
            // console.log('demo', demo);
            const temp = demo.flat()
            const final = []
            temp.forEach((plan_items) => {
                let construct_demo = {}
                if (plan_items.duplicate) {
                    construct_demo.duplicate = true;
                    // construct_demo.temp = JSON.stringify(plan_items);
                    // construct_demo.unique_id = plan_items.unique_id;
                    // construct_demo.transaction_id = plan_items.transaction_id;
                    // construct_demo.source = plan_items.source;
                    // final.push(construct_demo);
                    final.push(plan_items);
                }
                if (plan_items.invalid) {
                    construct_demo.invalid = true;
                    construct_demo.temp = JSON.stringify(plan_items);
                    construct_demo.unique_id = plan_items.unique_id;
                    construct_demo.transaction_id = plan_items.transaction_id;
                    construct_demo.source = plan_items.source;
                    final.push(construct_demo);
                }
                if (plan_items.valid === true) {
                    final.push(plan_items);
                }
            });
            // console.log('final', final)
            var finalBulkUploadArray = uniqBy(final, function(x) {
                return x.unique_id;
            });

            console.log(valid_data_result_array.length, 'valid_data_result_array-------------', valid_data_result_array);
            console.log(invalid_data_entry_array.length, 'invalid_data_entry_array-------------', invalid_data_entry_array);
            console.log(final_duplicate_array.length, 'final_duplicate_array-------------', final_duplicate_array);
            const second = new Date();
            console.log('second', second);
            const difference1 = (second.getTime() - first.getTime()) / 1000;
            console.log('difference1', difference1);
            const third = new Date();
            console.log('third', third);
            console.log('finalBulkUploadArray--->', finalBulkUploadArray.length);
            await tempPlanServiceDummy.insert_many(finalBulkUploadArray);
            console.log("Data entered in DB sucessfully");
            const forth = new Date();
            console.log('forth', forth);
            const difference2 = (forth.getTime() - third.getTime()) / 1000;
            console.log('difference2', difference2);
            const end = new Date();
            console.log('end', end);
            const total_time = (end.getTime() - start.getTime()) / 1000;
            console.log('total_time', total_time);
            const parsingDoneStatus = {
                queueId: queue_id,
                status_code: 3,
                message: "Validating process completed, fetching details...(#0003)",
                total_records: rows.length,
                total_images: file_link_list_array2.length,
                parsing_progress: rows.length,
                total_valid_records: valid_data_result_array.length
            }
            console.log('parsingDoneStatus', parsingDoneStatus);
            const updateQueueStatusResult = await statusService.updateStatus(parsingDoneStatus);
            console.log('updateQueueStatusResult', updateQueueStatusResult);
            return ([{
                transaction_id,
                valid_data: valid_data_result_array,
                duplicate_plan: final_duplicate_array,
                plans_with_errors: invalid_data_entry_array,
                valid_data_length: valid_data_result_array.length,
                duplicate_plan_length: final_duplicate_array.length,
                plans_with_errors_length: invalid_data_entry_array.length,
            }]);
        }).catch(async(err) => {
            const errorStatus = {
                queueId: queue_id,
                status_code: 100,
                message: err,
            }
            console.log('errorStatus', errorStatus)
            updateQueueStatus = await statusService.updateStatus(errorStatus);
            return err;
        });
        return finalResult;
    } catch (err) {
        console.log("Error in excelToJsonParseHandler:", err);
        return err;
    }
}
// excelToJsonParseHandler();