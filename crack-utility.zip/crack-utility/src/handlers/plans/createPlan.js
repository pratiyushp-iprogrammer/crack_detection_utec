const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const PlansService = require('../../services/plansService');
const UsageDataService = require('../../services/designActionService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');
const cacheResponse = require('../../common/cacheResponse');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

const CreatePlanSchema = require('../../schema/createPlan');
let baseResponse = new BaseResponse();
let plansService = new PlansService();
let usageDataService = new UsageDataService();
let adminDetails = new AdminDetails();
let CacheResponse = new cacheResponse();

exports.createPlanHandler = async (event, context) => {
    try {
        event = Common.reqSanitize(event);
        let email = "";
        let isAdmin = false;
        if (event.requestContext.authorizer) {
            let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            isAdmin = authorizerResponse.isAdmin;
            email = authorizerResponse.email;
        }
        // let authorizationToken = event.headers.Authorization;
        // const details = await adminDetails.getAdminDetails(authorizationToken);
        // email = details ? details.name : '';

        const params = JSON.parse(event.body);
        params.created_by = email;
        params.updated_by = email;

        const plotAreaRange = baseResponse.getRange(params.plot_details.plot_area, 'plot_details.plot_area', 'plans');
        const plotEntranceWidthRange = baseResponse.getRange(params.plot_details.plot_width, 'plot_details.plot_width', 'plans');
        params.plot_details.plot_area_range = plotAreaRange;
        params.plot_details.plot_entrance_width_range = plotEntranceWidthRange;

        const floorPlateWidthRange = baseResponse.getRange(params.project_details.floor_plate_width, 'project_details.floor_plate_width', 'plans');
        params.project_details.floor_plate_width_range = floorPlateWidthRange;

        var validation = CreatePlanSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event,false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        const result = await plansService.findByUniqueId(params.unique_id);
        if (result) {
            return baseResponse.getResponseObject(event,false, HTTP_CODE.DUPLICATE, [], "Duplicate entry found.");
        }
        const response = await plansService.createPlan(params);
        if (response) {
            // let uniqueId = params.unique_id;
            // let ismatch = uniqueId.toLowerCase().match(/test/g);
            // if (Array.isArray(ismatch) && ismatch.length > 0) {
            //     await plansService.deleteRecord(uniqueId);
            //     return baseResponse.getResponseObject(event,true, HTTP_CODE.SUCCESS, [], "Test record deleted successfully!");
            // }
            const lastResult = await plansService.fetchPlanDetails(params.unique_id);
            let logData = {
                object_id: lastResult._id,
                sr_tracker_number: "",
                event_for: 'plan',
                app_id: 1,
                is_admin: isAdmin,
                user_id: email,
                action: 'create'
            };
            await usageDataService.create(logData);
            // await CacheResponse.clearCache(null, event, null);
            await CacheResponse.clearRelevantCache(null, event, null);
            return baseResponse.getResponseObject(event,true, HTTP_CODE.SUCCESS, [], "Plan added successfully!");
        }
        return baseResponse.getResponseObject(event,false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], "Something went wrong.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event,false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}