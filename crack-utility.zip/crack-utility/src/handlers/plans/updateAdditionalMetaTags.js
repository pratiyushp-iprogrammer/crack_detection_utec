const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
const PlansService = require('../../services/plansService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const readXlsxFile = require("read-excel-file/node");
const UpdateAdditionalMetaTagsSchema = require('../../schema/updateAdditionalMetaTagsSchema');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let Common = new common()
let baseResponse = new BaseResponse();
let plansService = new PlansService();
var fs = require('fs');
const path = require("path");

exports.updateAdditionalMetaTags = async(event) => {
        // const updateAdditionalMetaTags = async() => {
        try {
            // AWS.config.update({
            //     accessKeyId: "AKIAXBXKDH5EBYK757WO",
            //     secretAccessKey: "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",
            //     region: "ap-south-1"
            // });

            const params = JSON.parse(event.body);
            var validation = UpdateAdditionalMetaTagsSchema.validate(params);
            if (validation.error) {
                console.log(validation.error);
                return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
            }

            let filePath = `temp/${params.fileName}.xlsx`
            console.log('filePath', JSON.stringify(filePath));

            const s3_params = {
                Bucket: process.env.UPLOAD_S3_BUCKET,
                // Bucket: 'design-management-assets',
                Key: filePath
                    // Key: 'temp/plans_batch_file.xlsx'
            };
            const getObjectCommand = new GetObjectCommand(s3_params);
            const { Body } = await s3Client.send(getObjectCommand);
            const excel_file_data = Body;
            console.log('excel_file_data', excel_file_data)
            const processData = await readXlsxFile(excel_file_data).then(async(rows) => {
                let processedData = await plansService.processFileData(rows);
                return processedData;
            }).catch((err) => {
                return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error in reading data" + err);
            });
            const updateRecords = await plansService.bulkUpdateAdditionalMetaTags(processData);
            console.log('updateRecords...', updateRecords)
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, updateRecords, "records updated.");
        } catch (error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + error.message);
        }
    }
    // updateAdditionalMetaTags()