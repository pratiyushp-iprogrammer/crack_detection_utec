const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const PlansService = require('../../services/plansService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let plansService = new PlansService();

exports.listPlansHandler = async(event, context) => {
    
    if (event.requestContext.authorizer) {
        let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
        console.log(authorizerResponse.email);
    }

    try {
        event = Common.reqSanitize(event);
        var response = await plansService.fetch(event);
        if (response) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, { response, "totalCount": response["totalRecordsCount"] }, 'Plans listed successfully.');
        }
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'No records found.');
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}