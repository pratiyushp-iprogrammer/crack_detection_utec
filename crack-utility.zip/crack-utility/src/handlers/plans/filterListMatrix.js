const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const PlanFilterMatrix = require('../../common/planFilterMatrix.json');
const PlansService = require('../../services/plansService');
const Database = require('../../common/database');
const cacheResponse = require('../../common/cacheResponse');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();


let baseResponse = new BaseResponse();
let plansService = new PlansService();
let CacheResponse = new cacheResponse();

exports.filterListMatrixHandler = async (event, context) => {
    try {
        event = Common.reqSanitize(event);
        let cacheResponse = await CacheResponse.getCacheResponse(null, event);
        if (cacheResponse.status) {
          return cacheResponse.data;
        }
        for (var data in PlanFilterMatrix) {
            const obj = PlanFilterMatrix[data];
            if (obj.key === 'unique' || obj.key === 'freeText') {
                const result = await plansService.getDistictValues(obj.dbKey);
                if (Array.isArray(result) && result.length > 0) {
                    obj.value = result.sort((a, b) => a - b);
                } else {
                    obj.value = [];
                }
            }
        }
        return CacheResponse.respond(event, true, HTTP_CODE.SUCCESS, PlanFilterMatrix, "Plan filters fetched successfully!");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Internal server error: " + e.message);
    }
}