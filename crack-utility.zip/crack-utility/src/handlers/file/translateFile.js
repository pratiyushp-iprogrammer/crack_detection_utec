const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: process.env.AWS_REGION_NAME });
const readXlsxFile = require('read-excel-file/node');

// AWS.config.update({
//     accessKeyId: process.env.ACCESS_KEY_ID,
//     secretAccessKey: process.env.SECRET_ACCESS_KEY,
//     region: process.env.DM_AWS_REGION,
// });

let baseResponse = new BaseResponse();

exports.translateFileHandler = async (event, context) => {
    try {
        event = Common.reqSanitize(event);
        const params = JSON.parse(event.body);
        const s3_params = {
            Bucket: process.env.UPLOAD_S3_BUCKET,
            Key: params.translation_file_link
        };
        const getObjectCommand = new GetObjectCommand(s3_params);
        const { Body } = await s3Client.send(getObjectCommand);
        const excel_file_data = Body;
        const excel_data_to_json = await readXlsxFile(excel_file_data).then((data_list_items) => { return data_list_items });
        if (excel_data_to_json.length > 0) {
            return baseResponse.getResponseObject(event,true, HTTP_CODE.SUCCESS, excel_data_to_json);
        } else {
            return baseResponse.getResponseObject(event,true, HTTP_CODE.NOT_FOUND, "No data found for translation");
        }
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event,false, HTTP_CODE.BAD_REQUEST, [], "Error for translation API: " + e.message);
    }
}