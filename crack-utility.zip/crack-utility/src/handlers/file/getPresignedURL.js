const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');

const { getSignedUrl } =require("@aws-sdk/s3-request-presigner");
const { S3Client, PutObjectCommand } =require( "@aws-sdk/client-s3");
const s3Client = new S3Client({ region: process.env.DM_AWS_REGION });

// Change this value to adjust the signed URL's expiration
const URL_EXPIRATION_SECONDS = 21600    // 6 hours
let baseResponse = new BaseResponse();
// Main Lambda entry point
exports.getPresignedURL = async (event) => {
  return await getUploadURL(event)
}
let extensions = [
    'csv', 'xlsx', 'xls', 'rar', 'jpg', 'jpeg', 'png', 'mp4',
    'pdf', 'xlt', 'xla', 'zip', 'xlsm', 'xlsb', 'ppt', 'skp',
    'psd', 'dwg', 'avif', 'gif', 'jfif', 'pjpeg', 'pjp', '3ds',
    'dxf','mov' 
];

const getUploadURL = async function(event) {
    if(event.body){
    event = Common.reqSanitize(event);

        const params = JSON.parse(event.body);
        console.log('params ', JSON.stringify(params));

        if(params.fileObjects && params.fileObjects.length > 0){
            let arrUploadURL = [];
            //params.fileObjects.forEach(objFile => {
            for (const objFile of params.fileObjects) {
                const Key = objFile.url;
                let contentType = "";

                const extension = objFile.extension.toLowerCase();
                const filePathExtension = Key.split('.').pop().toLowerCase();
                if (extensions.includes(extension) && extension === filePathExtension) {
                    if (["pdf", "zip"].includes(extension)) {
                        contentType = "application/" + objFile.extension;
                    } else if (["xlsx", "xlsm", "xls", "xlsb"].includes(extension)) {
                        contentType = "application/vnd.ms-excel";
                    } else if (extension === "csv") {
                        contentType = "text/" + objFile.extension;
                    } else if (extension === "rar") {
                        contentType = "application/vnd.rar";
                    } else if(objFile.extension === "mp4") {
                        contentType = 'video/mp4';
                    } else if(objFile.extension === "mov") {
                        contentType = 'video/quicktime';
                    } else {
                        contentType = "image/" + objFile.extension;
                    }
                } else {
                    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid File Extension");
                }

                // Get signed URL from S3
                const s3Params = {
                    Bucket: process.env.UPLOAD_S3_BUCKET,
                    Key,
                    // Expires: URL_EXPIRATION_SECONDS,
                    ContentType: contentType,

                    // This ACL makes the uploaded object publicly readable. You must also uncomment
                    // the extra permission for the Lambda function in the SAM template.

                    // ACL: 'public-read'
                }
                
                const command = new PutObjectCommand(s3Params);
                objFile.uploadURL = await getSignedUrl(s3Client, command, { URL_EXPIRATION_SECONDS });
                arrUploadURL.push(objFile);
            };

            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, {
                s3BasePath: `${process.env.S3_BUCKET_PATH}/`,
                arrUploadURL: arrUploadURL
            });            
        } else {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid request body");
        }
    } else {
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid request body");
    }
  

  
}