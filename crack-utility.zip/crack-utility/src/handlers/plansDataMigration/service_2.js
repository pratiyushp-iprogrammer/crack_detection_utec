const { PlanStyleDesigns } = require('./models/destination');
const fs = require('fs');
const { ENV = "dev" } = process.env;
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;

const falsyVals = [null, undefined, false];

class PlanStyleDesignsUpdation {
    async updateRecords() {
        try {
            // "project_details.builtup_area": { $in: [null, 0] },
            const targetList = await PlanStyleDesigns.find(
                {
                    "plot_details.plot_area": { $ne: 0, $exists: true},
                    "project_details.no_floors": { $exists: true },
                },
                { _id: 1, "plot_details.plot_area": 1, "project_details.no_floors": 1 }
            ).lean();
            const updationTrack = [];
            const len = targetList.length;
            console.log('data size:', len);
            for (let i = 0; i < len; i++) {
                const { _id, plot_details: { plot_area }, project_details: { no_floors } } = targetList[i];
                let condition = (falsyVals.includes(plot_area) || falsyVals.includes(no_floors)) || (isNaN(Number(plot_area)) || isNaN(Number(no_floors))) ? false : true;
                if (condition) {
                    let value = Number(plot_area) * 0.75 * (Number(no_floors) + 1);
                    const updated = await PlanStyleDesigns.updateOne(
                        { _id: new ObjectId(_id) },
                        {
                            $set: {
                                "project_details.builtup_area": value
                            }
                        }
                    )
                    updationTrack.push(updated);
                } else {
                    console.log(plot_area, no_floors);
                }
            }
            fs.writeFileSync(`./result_track/records_updation_track_${ENV}.json`, JSON.stringify(updationTrack));
        } catch (error) {
            console.log({ step: "updateRecords", error });
            throw error;
        }

    }

}

module.exports = PlanStyleDesignsUpdation;