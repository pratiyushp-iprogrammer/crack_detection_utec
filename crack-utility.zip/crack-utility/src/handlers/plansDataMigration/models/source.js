const mongoose = require('mongoose');

exports.PlansManagement = mongoose.model('plans_managements', mongoose.Schema({}), 'plans_managements');