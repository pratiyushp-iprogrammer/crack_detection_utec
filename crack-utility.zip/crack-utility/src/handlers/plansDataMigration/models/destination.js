const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    "source": String,
    "unique_id": { type: Number, unique: true, required: true },
    "element_type": String,
    "sr_number": String,
    "option_number": String,
    "files": {
        "two_d_rendered_plan_jpg": {
            "ground": [],
            "ground_plus_one": [],
            "ground_plus_two": [],
            "ground_plus_three": [],
            "ground_plus_four": [],
            "above_ground_plus_four": [],
            "others": String
        },
        "two_d_rendered_plan_pdf": {
            "two_d_rendered_plan_pdf_link": []
        },
        "three_d_design_id": {
            "front": String,
            "right_side": String,
            "left_side": String,
            "rear_side": String,
            "internal": String
        },
        "three_d_cut_iso_jpg": {
            "ground": [],
            "ground_plus_one": [],
            "ground_plus_two": [],
            "ground_plus_three": [],
            "ground_plus_four": [],
            "above_ground_plus_four": [],
            "others": String
        },
        "three_d_delivery_pdf" : {
            "three_d_delivery_pdf_link": []
       },
        // "linked_estimation_id": {
        //     "estimation_id": String
        // },
        "linked_sketch_up_file": {
            "sketch_up_file_id": []
        },
        "linked_dwg_file": {
            "linked_dwg_file_id": []
        },
        // "linked_psd_file": {
        //     "linked_psd_file_id": String
        // },
        // "linked_ppt_file": {
        //     "linked_ppt_file_id": String
        // }
    },
    "plot_details": {
        "plot_area": Number,
        "plot_area_unit" : String,
        "plot_length": Number,
        "plot_width": Number,
        "plot_length_width_unit" : String,
        "plot_shape": String,
        "left_set_back": String,
        "right_set_back": String,
        "front_set_back": String,
        "rear_set_back": String,
        "open_sides_of_the_plot": Number
    },
    "project_details": {
        "typology": String,
        "estimated_cost_of_construction": Number,
        "builtup_area": Number,
        "buildup_area_unit": String,
        "floor_plate_area_of_ground_floor": Number,
        "floor_plate_length": String,
        "floor_plate_width": Number,
        "floors": String,
        "no_floors" : Number,
        "bedrooms": Number,
        "shared_wall": Number,
        "for_two_shared_wall_adjacent_parallel": String,
        "space_allocation": String,
        "style": String,
        // "low_range_budget": String,
        // "high_range_budget": String,
        // "floor_plate_width_range": String,
        "staircase_internal": Number,
        "staircase_external": Number,
    },
    "geography": {
        "weather_condition": String,
        "state": String,
        "city": String,
        "district": String,
        "geo_coordinates": String,
        "pincode": Number,
    },
    "family_details": {
        "total_family_members": Number,
        "number_of_senior_citizen": Number,
        "number_of_adults": Number,
        "number_of_children": Number,
        "number_of_infants": Number
    },
    "parking": {
        "basement": String,
        "stilts": String,
        "two_wheeler_parking": Number,
        "four_wheeler_parking": Number
    },
    "senior_citizen_friendly": {
        "max_three_stairs_to_enter_the_ground_floor": String,
        "one_bhk_on_ground_floor": String,
        "provision_of_ramp": String
    },
    "vaastu_compliancy": {
        "vaastu_compliant": String,
        "entry_direction": String,
        "orientation_of_kitchen": String,
        "orientation_of_pooja_room": String,
        "orientation_of_master_bedroom": String
    },
    // "rooms": [roomsSchema],
    "rooms": [{
        "index": { type: Number },
        "total_bathrooms": { type: Number, default: null },
        "attached_bathrooms": { type: Number, default: null },
        "split_bathrooms": { type: Number, default: null },
        "combined_bathrooms": { type: Number, default: null },
        "common_bathrooms": { type: Number, default: null },
        "dining_room": { type: Number, default: null },
        "living_room": { type: Number, default: null },
        "kitchen": { type: Number, default: null },
        "master_bedroom": { type: Number, default: null },
        "family_room": { type: Number, default: null },
        "store_room": { type: Number, default: null },
        "pooja_room": { type: Number, default: null },
        "shops": { type: Number, default: null }
    }],
    "open_areas_configuration": {
        "balcony": String,
        "porch": String,
        "verandah": String,
        "garden": String,
        "courtyard": String,
        "frontyard": String,
        "backyard": String,
        "terrace": String,
        "type_of_entrance": String
    },
    "roof": {
        "roof_type": String
    },
    "stylized": {
        "stylized_configuration": String
    },
    "special_amenities": {
        "library": String,
        "home_theatre": String,
        "pool": String,
        "gym": String,
        "study_room": String,
        "game_room": String
    },
    "material_treatment": {
        "brick": String,
        "stone": String,
        "wood": String,
        "tile": String,
        "aluminium_composite_panel": String,
        "glass_curtain_wall": String
    },
    "structural_elements": {
        "pergola": String,
        "jaali": String,
        "green_wall": String,
        "planter": String,
        "vault": String,
        "double_height_open_area": String,
        "elevation_element": String
    },
    "colors": {
        "color_scheme": String,
        "color_used": String
    },
    "is_active": { type : Number, default : 1 },  // 0 : inactive,  1 : active 
    "is_approved": { type : Number, default : 1 },  // 0 : unpublished ,  1 : published 
    "publish_date" : { type : Date, default : new Date() },
    "number_of_times_viewed": { type: Number, default: 0 },
    "number_of_times_liked": { type: Number, default: 0 },
    "created_by": String,
    "updated_by": String
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
}, {
    collection: "plan_style_designs"
});

exports.PlanStyleDesigns = mongoose.model('plan_style_designs', schema);