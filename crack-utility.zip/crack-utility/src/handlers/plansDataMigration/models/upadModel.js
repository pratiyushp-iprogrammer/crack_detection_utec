const mongoose = require('mongoose');

exports.UserProfile = mongoose.model('user_profile_action_datas', mongoose.Schema({}, { strict: false }), 'user_profile_action_datas');