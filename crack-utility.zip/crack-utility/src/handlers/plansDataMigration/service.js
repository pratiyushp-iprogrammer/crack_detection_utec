const mongoose = require('mongoose');
const { PlansManagement } = require('./models/source');
const { PlanStyleDesigns } = require('./models/destination');
const { UserProfile } = require('./models/upadModel');
const { clonedDoc } = require('./payload');
const v8 = require('v8');
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({ region: 'ap-south-1'});

const fs = require('fs')

const { ObjectId } = mongoose.Types;
const { BATCH_S3, ENV = "dev" } = process.env;

const buckets = {
    "dev": {
        source: "design-management-test",
        destination: "design-management-test"
    },
    "stage": {
        source: "design-management-stage",
        destination: "design-management-stage"
    },
    "preprod": {
        source: "design-management-stage",
        destination: "design-management-stage"
    },
    "production": {
        source: "design-management-prod",
        destination: "design-management-prod"
    }
}

const floorMapping = {
    "G": { title: "Ground floor", count: 0 },
    "G+0": { title: "Ground floor", count: 0 },
    "G+1": { title: "Ground + 1 floor", count: 1 },
    "G+2": { title: "Ground + 2 floors", count: 2 },
    "G+3": { title: "Ground + 3 floors", count: 3 },
    "G+4": { title: "Ground + 4 floors", count: 4 },
    "Above G+4": { title: "Ground + 5 floors", count: 5 },
    "": { title: "", count: null }
}

const pathMapping = {
    "ground": "groundFloor",
    "ground_plus_one": "firstFloor",
    "ground_plus_two": "secondFloor",
    "ground_plus_three": "thirdFloor",
    "ground_plus_four": "fourthFloor",
    "front": "front",
    "right_side": "rightSide",
    "left_side": "leftSide",
    "rear_side": "rearSide",
    "internal": "internal",
    "rawFile": "rawFile"
}
const falsyVals = [undefined, null, ""];
function checkValue(value) {
    return !falsyVals.includes(value) ? value : null;
}

class PlansDataMigration {

    async uploadFilesToS3(s3Params) {
        try {
            if (!s3Params.length) throw new Error("no files to be uploaded");

            const batchSize = BATCH_S3 || 3000;
            const batchCount = s3Params.length / batchSize;
            const uploadTrack = [];

            for (let i = 0; i < batchCount; i++) {
                let paramsChunk = s3Params.slice(batchSize * i, batchSize * (i + 1));
                const promises = paramsChunk.map(params => {
                    // return new Promise((resolve, reject) => {
                    //     s3.copyObject(params, (err, data) => {
                    //         if (err) {
                    //             reject(`Error copying file ${params.CopySource}: ${err}`)
                    //         } else {
                    //             resolve(`File ${params.CopySource} copied successfully to ${params.Key}`);
                    //         }
                    //     });
                    // });
                    let copyObjectCommand = new CopyObjectCommand(params);    
                    return s3Client.send(copyObjectCommand)
                        .then((data) => {
                            return `File ${mapping.sourceKey} copied successfully to ${mapping.destinationKey}`;
                        })
                        .catch((err) => {
                            throw new Error(`Error copying file ${mapping.sourceKey}: ${err.message}`);
                        });
                })
                const uploadResp = await Promise.allSettled(promises);
                console.log(JSON.stringify({ file: 'service.js', line: 18, message: `files uploaded successfully for batch ${i}`, uploadFilesToS3: uploadResp.length }));
                uploadTrack.push(...uploadResp);
            }

            fs.writeFileSync(`./result_track/upload_track_${ENV}.json`, JSON.stringify(uploadTrack));

            return true;
        } catch (error) {
            console.log({ step: "uploadFilesS3", error })
            throw error;
        }
    }

    async postDataToDestination(processedData) {
        try {
            const { data, s3Params, refIds } = processedData;

            const updationTrack = [];

            const dataSize = data.length;

            if (!dataSize) throw new Error("no data to post to destination");

            for (let i = 0; i < dataSize; i++) {
                const value = data[i];
                const object_id = refIds[i];
                const insertionResp = await PlanStyleDesigns.create(value);
                if (!insertionResp) {
                    console.log(value);
                    throw new Error(`insertion failed on ${i} iteration`);
                }
                const updationResp = await UserProfile.updateMany(
                    { object_id: new ObjectId(object_id) },
                    {
                        $set: {
                            object_id: new ObjectId(insertionResp._id)
                        }
                    }
                )
                if (!updationResp) {
                    console.log(insertionResp);
                    throw new Error(`object id updation failed on ${i} iteration`);
                }
                updationTrack.push({ ...updationResp, object_id, insertion_id: insertionResp._id });
            }

            fs.writeFileSync(`./result_track/updation_track_${ENV}.json`, JSON.stringify(updationTrack));

            console.log({ message: "data insertion finished, starting files upload..." });

            await this.uploadFilesToS3(s3Params);

            return true;
        } catch (error) {
            console.log({ step: "postDataToDestination", error })
            throw error;
        }
    }

    makeS3Params(destinationKey, sourceKey) {
        const bucketInfo = buckets[ENV];
        try {
            const params = {
                CopySource: `/${bucketInfo.source}/${sourceKey}`,
                Bucket: bucketInfo.destination,
                Key: destinationKey
            };

            return params;
        } catch (error) {
            console.log({ step: "makeS3Params", error });
            throw error;
        }
    }

    newUploadPathS3(sourcePath, nextUniqueId, ref) {
        try {
            const splited = sourcePath.split(",");
            const toReturn = { params: [], newPaths: [] };
            splited.forEach(path => {
                const sourceKey = path.trim();
                const suffix = sourceKey.split('/').pop();
                const destinationKey = `delivery_catalog/${nextUniqueId}/${pathMapping[ref]}/${suffix}`;
                const params = this.makeS3Params(destinationKey, sourceKey);
                toReturn.params.push(params);
                toReturn.newPaths.push(destinationKey);
            })
            // const suffix = sourcePath.split('/').pop();
            // const destinationPath = `delivery_catalog/${nextUniqueId}/${pathMapping[ref]}/${suffix}`;
            return toReturn;
        } catch (error) {
            console.log({ step: "newUploadPathS3", error });
            throw error;
        }
    }

    processData(data, initialId) {
        try {
            console.log(JSON.stringify({ file: 'service.js', line: 168, initialId }));

            const processedData = { data: [], s3Params: [], refIds: [] };

            for (let i = 0; i < data.length; i++) {
                let targetDoc = v8.deserialize(v8.serialize(clonedDoc));

                let sourceDoc = JSON.parse(JSON.stringify(data[i]));

                // mapping root level fields 
                targetDoc['unique_id'] = initialId + i;
                targetDoc['source'] = checkValue(sourceDoc?.['source']);
                targetDoc['sr_number'] = checkValue(sourceDoc?.['sr_number']);
                targetDoc['option_number'] = checkValue(sourceDoc?.['option_number']);
                targetDoc['is_active'] = checkValue(sourceDoc?.['is_active']);
                targetDoc['number_of_times_viewed'] = checkValue(sourceDoc?.['number_of_times_viewed']);
                targetDoc['number_of_times_liked'] = checkValue(sourceDoc?.['number_of_times_liked']);
                targetDoc['created_by'] = checkValue(sourceDoc?.['created_by']);
                targetDoc['updated_by'] = checkValue(sourceDoc?.['updated_by']);

                targetDoc['stylized']['stylized_configuration'] = checkValue(sourceDoc?.['stylized']?.['stylized_configuration']);
                targetDoc['roof']['roof_type'] = checkValue(sourceDoc?.['roof']?.['roof_type']);

                targetDoc['colors']['color_scheme'] = checkValue(sourceDoc?.['colors']?.['color_scheme']);
                targetDoc['colors']['color_used'] = checkValue(sourceDoc?.['colors']?.['color_used']);

                targetDoc['structural_elements']["pergola"] = checkValue(sourceDoc?.['structural_elements']?.["pergola"]);
                targetDoc['structural_elements']["jaali"] = checkValue(sourceDoc?.['structural_elements']?.["jaali"]);
                targetDoc['structural_elements']["green_wall"] = checkValue(sourceDoc?.['structural_elements']?.["green_wall"]);
                targetDoc['structural_elements']["planter"] = checkValue(sourceDoc?.['structural_elements']?.["planter"]);
                targetDoc['structural_elements']["vault"] = checkValue(sourceDoc?.['structural_elements']?.["vault"]);
                targetDoc['structural_elements']["double_height_open_area"] = checkValue(sourceDoc?.['structural_elements']?.["double_height_open_area"]);
                targetDoc['structural_elements']["elevation_element"] = checkValue(sourceDoc?.['structural_elements']?.["elevation_element"]);

                targetDoc['material_treatment']["brick"] = checkValue(sourceDoc?.['material_treatment']?.["brick"]);
                targetDoc['material_treatment']["stone"] = checkValue(sourceDoc?.['material_treatment']?.["stone"]);
                targetDoc['material_treatment']["wood"] = checkValue(sourceDoc?.['material_treatment']?.["wood"]);
                targetDoc['material_treatment']["tile"] = checkValue(sourceDoc?.['material_treatment']?.["tile"]);
                targetDoc['material_treatment']["aluminium_composite_panel"] = checkValue(sourceDoc?.['material_treatment']?.["aluminium_composite_panel"]);
                targetDoc['material_treatment']["glass_curtain_wall"] = checkValue(sourceDoc?.['material_treatment']?.["glass_curtain_wall"]);

                targetDoc['special_amenities']["library"] = checkValue(sourceDoc?.['special_amenities']?.["library"]);
                targetDoc['special_amenities']["home_theatre"] = checkValue(sourceDoc?.['special_amenities']?.["home_theatre"]);
                targetDoc['special_amenities']["pool"] = checkValue(sourceDoc?.['special_amenities']?.["pool"]);
                targetDoc['special_amenities']["gym"] = checkValue(sourceDoc?.['special_amenities']?.["gym"]);
                targetDoc['special_amenities']["study_room"] = checkValue(sourceDoc?.['special_amenities']?.["study_room"]);
                targetDoc['special_amenities']["game_room"] = checkValue(sourceDoc?.['special_amenities']?.["game_room"]);

                targetDoc['open_areas_configuration']["balcony"] = checkValue(sourceDoc?.['open_areas']?.["balcony"]);
                targetDoc['open_areas_configuration']["porch"] = checkValue(sourceDoc?.['open_areas']?.["porch"]);
                targetDoc['open_areas_configuration']["verandah"] = checkValue(sourceDoc?.['open_areas']?.["verandah"]);
                targetDoc['open_areas_configuration']["garden"] = checkValue(sourceDoc?.['open_areas']?.["garden"]);
                targetDoc['open_areas_configuration']["courtyard"] = checkValue(sourceDoc?.['open_areas']?.["courtyard"]);
                targetDoc['open_areas_configuration']["frontyard"] = checkValue(sourceDoc?.['open_areas']?.["frontyard"]);
                targetDoc['open_areas_configuration']["backyard"] = checkValue(sourceDoc?.['open_areas']?.["backyard"]);
                targetDoc['open_areas_configuration']["terrace"] = checkValue(sourceDoc?.['open_areas']?.["terrace"]);
                targetDoc['open_areas_configuration']["type_of_entrance"] = checkValue(sourceDoc?.['open_areas']?.["type_of_entrance"]);

                if (sourceDoc?.rooms?.length) {
                    targetDoc['rooms'] = sourceDoc.rooms.map((room, index) => ({
                        "index": index,
                        "total_bathrooms": checkValue(room?.["total_bathrooms"]),
                        "attached_bathrooms": checkValue(room?.["attached_bathrooms"]),
                        "split_bathrooms": checkValue(room?.["split_bathrooms"]),
                        "combined_bathrooms": checkValue(room?.["combined_bathrooms"]),
                        "common_bathrooms": checkValue(room?.["common_bathrooms"]),
                        "dining_room": checkValue(room?.["dining_room"]),
                        "living_room": checkValue(room?.["living_room"]),
                        "kitchen": checkValue(room?.["kitchen"]),
                        "master_bedroom": checkValue(room?.["master_bedroom"]),
                        "family_room": checkValue(room?.["family_room"]),
                        "store_room": checkValue(room?.["store_room"]),
                        "pooja_room": checkValue(room?.["pooja_room"]),
                        "shops": checkValue(room?.["shops"])
                    }))
                }

                targetDoc['vaastu_compliancy']["vaastu_compliant"] = checkValue(sourceDoc?.['vaastu_compliancy']?.["vaastu_compliant"]);
                targetDoc['vaastu_compliancy']["entry_direction"] = checkValue(sourceDoc?.['vaastu_compliancy']?.["entry_direction"]);
                targetDoc['vaastu_compliancy']["orientation_of_kitchen"] = checkValue(sourceDoc?.['vaastu_compliancy']?.["orientation_of_kitchen"]);
                targetDoc['vaastu_compliancy']["orientation_of_pooja_room"] = checkValue(sourceDoc?.['vaastu_compliancy']?.["orientation_of_pooja_room"]);
                targetDoc['vaastu_compliancy']["orientation_of_master_bedroom"] = checkValue(sourceDoc?.['vaastu_compliancy']?.["orientation_of_master_bedroom"]);

                targetDoc['senior_citizen_friendly']["max_three_stairs_to_enter_the_ground_floor"] = checkValue(sourceDoc?.['senior_citizen_friendly']?.["max_three_stairs_to_enter_the_ground_floor"]);
                targetDoc['senior_citizen_friendly']["one_bhk_on_ground_floor"] = checkValue(sourceDoc?.['senior_citizen_friendly']?.["one_bhk_on_ground_floor"]);
                targetDoc['senior_citizen_friendly']["provision_of_ramp"] = checkValue(sourceDoc?.['senior_citizen_friendly']?.["provision_of_ramp"]);

                targetDoc['parking']["basement"] = checkValue(sourceDoc?.['parking']?.["basement"]);
                targetDoc['parking']["stilts"] = checkValue(sourceDoc?.['parking']?.["stilts"]);
                targetDoc['parking']["two_wheeler_parking"] = !isNaN(Number(checkValue(sourceDoc?.['parking']?.["two_wheeler_parking"]))) ? Number(checkValue(sourceDoc?.['parking']?.["two_wheeler_parking"])) : null;
                targetDoc['parking']["four_wheeler_parking"] = !isNaN(Number(checkValue(sourceDoc?.['parking']?.["four_wheeler_parking"]))) ? Number(checkValue(sourceDoc?.['parking']?.["four_wheeler_parking"])) : null;

                targetDoc['family_details']["total_family_members"] = checkValue(sourceDoc?.['family_details']?.["total_family_members"]);
                targetDoc['family_details']["number_of_senior_citizen"] = checkValue(sourceDoc?.['family_details']?.["number_of_senior_citizen"]);
                targetDoc['family_details']["number_of_adults"] = checkValue(sourceDoc?.['family_details']?.["number_of_adults"]);
                targetDoc['family_details']["number_of_children"] = checkValue(sourceDoc?.['family_details']?.["number_of_children"]);
                targetDoc['family_details']["number_of_infants"] = checkValue(sourceDoc?.['family_details']?.["number_of_infants"]);

                targetDoc['geography']["weather_condition"] = checkValue(sourceDoc?.['geography']?.["weather_condition"]);
                targetDoc['geography']["state"] = checkValue(sourceDoc?.['geography']?.["state"]);
                targetDoc['geography']["city"] = checkValue(sourceDoc?.['geography']?.["city"]);
                targetDoc['geography']["district"] = checkValue(sourceDoc?.['geography']?.["district"]);
                targetDoc['geography']["geo_coordinates"] = checkValue(sourceDoc?.['geography']?.["geo_coordinates"]);
                targetDoc['geography']["pincode"] = checkValue(sourceDoc?.['geography']?.["pincode"]);

                targetDoc["project_details"]["typology"] = checkValue(sourceDoc?.['project_details']?.['typology']);
                targetDoc["project_details"]["estimated_cost_of_construction"] = checkValue(sourceDoc?.['project_details']?.['estimated_cost_of_construction']);
                targetDoc["project_details"]["builtup_area"] = checkValue(sourceDoc?.['project_details']?.['builtup_area']);
                targetDoc["project_details"]["floor_plate_area_of_ground_floor"] = checkValue(sourceDoc?.['project_details']?.['floor_plate_area_of_ground_floor']);
                targetDoc["project_details"]["floor_plate_length"] = checkValue(sourceDoc?.['project_details']?.['floor_plate_length']);
                targetDoc["project_details"]["floor_plate_width"] = checkValue(sourceDoc?.['project_details']?.['floor_plate_width']);
                targetDoc["project_details"]["bedrooms"] = checkValue(sourceDoc?.['project_details']?.['bedrooms']);
                targetDoc["project_details"]["shared_wall"] = checkValue(sourceDoc?.['project_details']?.['shared_wall']);
                targetDoc["project_details"]["for_two_shared_wall_adjacent_parallel"] = checkValue(sourceDoc?.['project_details']?.['for_two_shared_wall_adjacent_parallel']);
                targetDoc["project_details"]["space_allocation"] = checkValue(sourceDoc?.['project_details']?.['space_allocation']);
                targetDoc["project_details"]["style"] = checkValue(sourceDoc?.['project_details']?.['style']);
                targetDoc["project_details"]["staircase_internal"] = checkValue(sourceDoc?.['project_details']?.['staircase_internal']);
                targetDoc["project_details"]["staircase_external"] = checkValue(sourceDoc?.['project_details']?.['staircase_external']);

                targetDoc["plot_details"]["plot_area"] = checkValue(sourceDoc?.['plot_details']?.['plot_area']);
                targetDoc["plot_details"]["plot_length"] = !isNaN(Number(checkValue(sourceDoc?.['plot_details']?.['plot_length']))) ? Number(checkValue(sourceDoc?.['plot_details']?.['plot_length'])) : null;
                targetDoc["plot_details"]["plot_width"] = checkValue(sourceDoc?.['plot_details']?.['plot_width']);
                targetDoc["plot_details"]["plot_shape"] = checkValue(sourceDoc?.['plot_details']?.['plot_shape']);
                targetDoc["plot_details"]["left_set_back"] = checkValue(sourceDoc?.['plot_details']?.['left_set_back']);
                targetDoc["plot_details"]["right_set_back"] = checkValue(sourceDoc?.['plot_details']?.['right_set_back']);
                targetDoc["plot_details"]["front_set_back"] = checkValue(sourceDoc?.['plot_details']?.['front_set_back']);
                targetDoc["plot_details"]["rear_set_back"] = checkValue(sourceDoc?.['plot_details']?.['rear_set_back']);
                targetDoc["plot_details"]["open_sides_of_the_plot"] = checkValue(sourceDoc?.['plot_details']?.['open_sides_of_the_plot']);


                targetDoc["project_details"]["floors"] = !falsyVals.includes(sourceDoc?.['project_details']?.['floors']) ? floorMapping[sourceDoc.project_details.floors]['title'] : null;
                targetDoc["project_details"]["no_floors"] = !falsyVals.includes(sourceDoc?.['project_details']?.['floors']) ? floorMapping[sourceDoc.project_details.floors]['count'] : null;

                const firstLevel = ["two_d_rendered_plan_jpg", "two_d_line_drawing_jpg", "three_d_cut_iso_jpg"];
                const secondLevel2d = ['ground', 'ground_plus_one', 'ground_plus_two', 'ground_plus_three', 'ground_plus_four', 'above_ground_plus_four'];


                firstLevel.forEach(firstKey => {
                    secondLevel2d.forEach(secondKey => {
                        if (sourceDoc?.['files']?.[firstKey]?.[secondKey]) {
                            const value = sourceDoc['files'][firstKey][secondKey];
                            const { params, newPaths } = this.newUploadPathS3(value, (initialId + i), secondKey);
                            // const params = this.makeS3Params(newPath, value);
                            processedData.s3Params.push(...params);
                            if (firstKey === 'three_d_cut_iso_jpg') {
                                targetDoc['files']["three_d_cut_iso_jpg"][secondKey].push(...newPaths);
                            } else {
                                targetDoc['files']["two_d_rendered_plan_jpg"][secondKey].push(...newPaths);
                            }
                        }
                    })
                })

                targetDoc["files"]["two_d_rendered_plan_jpg"]["others"] = checkValue(sourceDoc["files"]?.['two_d_rendered_plan_jpg']?.['others']);

                const secondLevel3d = ["front", "right_side", "left_side", "rear_side", "internal"];
                secondLevel3d.forEach(key => {
                    if (sourceDoc?.['files']?.['three_d_design_id']?.[key]) {
                        const value = sourceDoc['files']['three_d_design_id'][key];
                        const { params, newPaths } = this.newUploadPathS3(value, (initialId + i), key);
                        // const params = this.makeS3Params(newPath, value);
                        processedData.s3Params.push(...params);
                        targetDoc['files']['three_d_design_id'][key] = newPaths[0];
                    }
                })

                if (sourceDoc?.['files']?.['linked_dwg_file']?.['linked_dwg_file_id']) {
                    const value = sourceDoc?.['files']['linked_dwg_file']['linked_dwg_file_id'];
                    const { params, newPaths } = this.newUploadPathS3(value, (initialId + i), "rawFile");
                    processedData.s3Params.push(...params);
                    targetDoc?.['files']['linked_dwg_file']['linked_dwg_file_id'].push(...newPaths);
                }

                if (sourceDoc?.['files']?.['linked_stetch_up_file']?.['sketch_up_file_id']) {
                    const value = sourceDoc?.['files']['linked_stetch_up_file']['sketch_up_file_id'];
                    const { params, newPaths } = this.newUploadPathS3(value, (initialId + i), "rawFile");
                    processedData.s3Params.push(...params);
                    targetDoc?.['files']['linked_sketch_up_file']['sketch_up_file_id'].push(...newPaths);
                }

                processedData.data.push(targetDoc);
                processedData.refIds.push(sourceDoc._id);
            }

            return processedData;
        } catch (error) {
            console.log({ step: "processData", error })
            throw error;
        }
    }

    async getDataFromSource() {
        try {

            const bucketInfo = buckets[ENV];

            console.log({ environment: ENV, buckets: buckets[ENV] });
            if (!bucketInfo) throw new Error("no bucket information specified");

            const result = await PlansManagement.find({});
            console.log(JSON.stringify({ file: 'service.js', line: 30, message: "data fetched successfully from source", getDataFromSource: result?.length ? result.length : result }));

            if (!result || !result?.length) throw new Error("data coundn't be fetched or no data found");

            let initialId = 1;
            const [lastDesign = null] = await PlanStyleDesigns.find({}, { unique_id: 1 }).sort({ unique_id: -1 }).limit(1);

            console.log(JSON.stringify({ file: 'service.js', line: 227, lastDesign }));

            if (lastDesign) {
                initialId = lastDesign.unique_id + 1;
            }

            const processedData = this.processData(result, initialId);

            console.log(JSON.stringify({ file: 'service.js', line: 370, processedData_data: processedData.data.length }));
            console.log(JSON.stringify({ file: 'service.js', line: 371, processedData_s3Params: processedData.s3Params.length }));

            return processedData;
        } catch (error) {
            console.log({ step: "getDataFromSource", error })
            throw error;
        }

    }
}

module.exports = PlansDataMigration;