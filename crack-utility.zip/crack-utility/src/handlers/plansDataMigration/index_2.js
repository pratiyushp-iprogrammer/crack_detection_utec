const ConnectMongo = require('./db/docdb-conn');
const PlanStyleDesignsUpdation = require('./service_2');
const service = new PlanStyleDesignsUpdation();

async function execute() {
    try {

        const instance = new ConnectMongo();
        await instance.connect();

        await service.updateRecords();
    
        return ({ status: 200, message: "Record Updation Successfull!" });
    } catch (error) {
        console.log(error);
        throw error;
    }
}

execute().then(response => {
    console.log({ file: 'index.js', line: 22, executionResult: response });
}).catch(error => {
    console.log(error);
})
