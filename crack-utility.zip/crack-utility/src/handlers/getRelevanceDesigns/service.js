const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
const DesignDownload = require('../../models/designDownloadInfo');
const Design = require('../../models/planStyleDesigns');
const redis = require('../../common/redis/redis-connection');
const DBConnector = require('../../common/dbConnector');
const dbConnector = new DBConnector();
const env = process.env.DEPLOYMENT ? process.env.DEPLOYMENT : 'dev';

class GetDesigns {

    async getRelevanceDesigns(requestBody) {
        try {
            let serviceRequestId = requestBody.srId ? requestBody.srId : 0;
            let srTypeId = requestBody.srTypeId ? requestBody.srTypeId : 0;
            let fetchLimit = requestBody.fetchLimit ? requestBody.fetchLimit : 0;
            let userId = requestBody.userId ? requestBody.userId : 0;
            let action = requestBody.action ? requestBody.action : "refresh";
            let redisCacheKey = `dm_design_${serviceRequestId}_${env}`;
            let redisCacheKeyDownload = `dm_design_${serviceRequestId}_${userId}_${env}`;
            let srDetail = await this.fetchSRDetails(serviceRequestId);
            // console.log(JSON.stringify({ file: 'service.js', line: 23, message: `sr info result`, srDetail }));
            let srInfo = srDetail?.sr_info || null;
            let requestStatus = srDetail?.request_status || null;
            if (!srInfo || !requestStatus) {
                throw new Error("SR info not present");
            }
            // requestStatus 26 belongs to Design In-Progress
            if (requestStatus != 26) {
                return { message: "Design suggestions are only available when the SR is in 'Design In-Progress' status." }
            }
            let plotShape = srInfo?.plotDimensions?.plotShape?.toLowerCase() || null;
            if (plotShape !== "rectangle" && plotShape !== "rectangular" && plotShape !== "square") {
                return { message: "For non-rectangular SR's no similar suggestions to be shown." }
            }
            if (action == "init") {
                // check here if data is already present in redis or not , if exist then return that otherwise set new data to key
                // let redisResult = await redis.redisCacheGet(redisCacheKey);
                // if (redisResult) {
                //     return JSON.parse(redisResult);
                // }
                // let result = await this.findMostRelevantDesigns(serviceRequestId, srTypeId, redisCacheKey, fetchLimit);
                // return result;
                throw new Error("Action init not in use.");
            } else if (action == "tab_click") {
                let countQuery = {
                    "sr_id": serviceRequestId,
                    "user_id": userId
                }
                let totalCount = await DesignDownload.countDocuments(countQuery);
                totalCount = totalCount || 0;
                console.log(JSON.stringify({ file: 'service.js', line: 53, totalDownloadCountPerUser: totalCount }));
                if (totalCount >= 2) {
                    let userParams = { serviceRequestId, userId, srTypeId, redisCacheKeyDownload, redisCacheKey };
                    let downloadDesignRes = await this.fetchDownloadedDesign(userParams, action);
                    return downloadDesignRes;
                }
                let result = await this.findMostRelevantDesigns(serviceRequestId, srTypeId, redisCacheKey, fetchLimit, action, srInfo);
                return result;
            } else if (action == "refresh") {
                // updated existing redis key with new data
                let countQuery = {
                    "sr_id": serviceRequestId,
                    "user_id": userId
                }
                let totalCount = await DesignDownload.countDocuments(countQuery);
                totalCount = totalCount || 0;
                console.log(JSON.stringify({ file: 'service.js', line: 69, totalDownloadCountPerUser: totalCount }));
                if (totalCount >= 2) {
                    let userParams = { serviceRequestId, userId, srTypeId, redisCacheKeyDownload, redisCacheKey };
                    let downloadDesignRes = await this.fetchDownloadedDesign(userParams, action);
                    return downloadDesignRes;
                }
                let result = await this.findMostRelevantDesigns(serviceRequestId, srTypeId, redisCacheKey, fetchLimit, action, srInfo);
                return result;
            }

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 53, message: error?.message, error }));
            throw error;
        }
    }

    async fetchSRDetails(srNumber) {
        try {
            const srDetailsQuery = `SELECT srd.sr_info, sr.request_status FROM service_requests AS sr 
            LEFT JOIN service_request_details AS srd ON srd.service_requests_id = sr.id 
            WHERE sr.id = ?;`;
            const srDetailsValue = await dbConnector.queryExecute(srDetailsQuery, [srNumber]);
            const srDetails = srDetailsValue[0];
            if (srDetails == null) return false;
            return srDetails;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 35, message: error?.message, error }));
            throw error;
        }
    }

    // async fetchSRPlotShap(srNumber) {
    //     try {
    //         const query = 'SELECT sr_info FROM service_request_details where service_requests_id = ?;'
    //         const res = await dbConnector.queryExecute(query, [srNumber]);
    //         const srDetails = res[0];
    //         if (srDetails == null) return false;
    //         return srDetails;
    //     } catch (error) {
    //         console.log(JSON.stringify({ file: 'service.js', line: 67, message: error?.message, error }));
    //         throw error;
    //     }
    // }

    async findMostRelevantDesigns(serviceRequestId, srTypeId, redisCacheKey, fetchLimit, action, srInfo) {
        try {
            let designsResult = [];
            if (action == "tab_click") {
                let redisResult = await redis.redisCacheGet(redisCacheKey);
                let finalResult = redisResult ? JSON.parse(redisResult) : null;
                // console.log(JSON.stringify({ file: 'service.js', line: 133, finalResult }));
                if (finalResult) {
                    return finalResult;
                }
            }
            if (srTypeId == 18) {
                designsResult = await this.findMostRelevant2DDesigns(srInfo, fetchLimit);
                if (designsResult.length === 0) {
                    designsResult = { message: "Don't have a relevant design for this SR." };
                    await redis.redisCacheDelete(redisCacheKey);
                    return designsResult;
                }
                let setRedis = await redis.redisCacheSetExpiry(redisCacheKey, JSON.stringify(designsResult), 1296000);
                console.log(JSON.stringify({ file: 'service.js', line: 67, setRedis }));
                // await redis.redisCacheSetExpiry(redisCacheKey, 1296000);
                return designsResult;
            } else if (srTypeId == 19) {
                designsResult = await this.findMostRelevant3DDesigns(srInfo, fetchLimit);
                if (designsResult.length === 0) {
                    designsResult = { message: "Don't have a relevant design for this SR." };
                    await redis.redisCacheDelete(redisCacheKey);
                    return designsResult;
                }
                let setRedis = await redis.redisCacheSetExpiry(redisCacheKey, JSON.stringify(designsResult), 1296000);
                console.log(JSON.stringify({ file: 'service.js', line: 135, setRedis }));
                // cache set expiry to 15 Days
                // await redis.redisCacheSetExpiry(redisCacheKey, 1296000);
                return designsResult;
            } else {
                throw new Error("SR type is invalid");
            }
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 142, message: error?.message, error }));
            throw error;
        }
    }

    async findMostRelevant2DDesigns(srInfo, fetchLimit) {
        try {
            let plotArea = srInfo?.plotDimensions?.plotArea || null;
            // let plotLength = srInfo?.plotDimensions?.plotLength || null;
            let plotLength = srInfo?.plotDimensions?.plotArea / srInfo?.plotDimensions?.plotWidth;
            plotLength = plotLength ? plotLength.toFixed(2) : null;
            let plotWidth = srInfo?.plotDimensions?.plotWidth || null;
            let frontSetBack = srInfo?.sideGap?.one || null;
            let rightSetBack = srInfo?.sideGap?.two || null;
            let rearSetBack = srInfo?.sideGap?.three || null;
            let leftSetBack = srInfo?.sideGap?.four || null;
            let noFloors = null;
            if (srInfo?.houseDetails?.floorCount != null) {
                let floorCase = srInfo?.houseDetails?.floorCount?.toLowerCase();
                floorCase = floorCase.replace(/\s/g, '');
                const floorCountMap = {
                    'groundfloor': 0,
                    'ground+1floor': 1,
                    'ground+2floors': 2,
                    'ground+3floors': 3,
                    'ground+4floors': 4,
                    'ground+5floors': 5,
                    'stiltfloor': 0,
                    'stilt+1floor': 1,
                    'stilt+2floors': 2,
                    'stilt+3floors': 3,
                    'stilt+4floors': 4,
                    'stilt+5floors': 5,
                };
                noFloors = floorCountMap[floorCase] !== undefined ? floorCountMap[floorCase] : null;
            }
            // let bedrooms = srInfo?.projectDetails?.numberOfBedRooms || null;
            let sharedWall = 0, bedrooms = null;
            for (let key in srInfo?.plotSideFacing) {
                if (srInfo?.plotSideFacing[key]?.includes("Shared Wall")) {
                    sharedWall = 1;
                }
            }

            let twoWheelerParking = srInfo?.bikeParking?.numberOfBikes || null;
            let fourWheelerParking = srInfo?.carParking?.numberOfCars || null;
            // const mappedRoom = {
            //     index: 0,
            //     total_bathrooms: null,
            //     attached_bathrooms: null,
            //     split_bathrooms: null,
            //     combined_bathrooms: null,
            //     common_bathrooms: null,
            //     dining_room: null,
            //     living_room: null,
            //     kitchen: null,
            //     master_bedroom: null,
            //     family_room: null,
            //     store_room: null,
            //     pooja_room: null,
            //     shops: null
            // };

            // if (srInfo?.houseDetails?.roomCount?.groundFloor) {
            //     let roomsWithRoomCountOne = srInfo?.houseDetails?.roomCount?.groundFloor;
            //     roomsWithRoomCountOne.forEach(room => {
            //         if (room?.roomName === "Common Bathroom" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.common_bathrooms = room.roomCount;
            //             mappedRoom.total_bathrooms += parseInt(room.roomCount);
            //         }
            //         if (room?.roomName === "Shop" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.shops = room.roomCount;
            //         }
            //         if (room?.roomName === "Separate Bathroom & Toilet" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.split_bathrooms = room.roomCount;
            //             mappedRoom.total_bathrooms += parseInt(room.roomCount);
            //         }
            //         if (room?.roomName === "Bedroom" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.family_room = room.roomCount;
            //             bedrooms += parseInt(room.roomCount);
            //         }
            //         if (room?.roomName === "Dining Room" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.dining_room = room.roomCount;
            //         }
            //         if (room?.roomName === "Kitchen" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.kitchen = room.roomCount;
            //         }
            //         if (room?.roomName === "Living Room" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.living_room = room.roomCount;
            //         }
            //         if (room?.roomName === "Master Bedroom" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.master_bedroom = room.roomCount;
            //             bedrooms += parseInt(room.roomCount);
            //         }
            //         if (room?.roomName === "Pooja Room" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.pooja_room = room.roomCount;
            //         }
            //         if (room?.roomName === "Store Room" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.store_room = room.roomCount;
            //         }
            //         if (room?.roomName === "Wash Area" && parseInt(room?.roomCount) > 0) {
            //             mappedRoom.combined_bathrooms = room.roomCount;
            //         }
            //     });
            // };


            let roomsWithRoomCountOne = [];
            if (srInfo?.houseDetails?.roomCount) {
                roomsWithRoomCountOne = Object.entries(srInfo?.houseDetails?.roomCount)
                    .reduce((rooms, [floor, floorRooms]) => {
                        floor = floor?.toLowerCase()
                        const mappedRoom = {
                            index: null,
                            bedroom: null
                        };

                        if (floor === "groundfloor") {
                            mappedRoom.index = 0;
                        } else if (floor === "firstfloor") {
                            mappedRoom.index = 1;
                        } else if (floor === "secondfloor") {
                            mappedRoom.index = 2;
                        } else if (floor === "thirdfloor") {
                            mappedRoom.index = 3;
                        } else if (floor === "fourthfloor") {
                            mappedRoom.index = 4;
                        } else if (floor === "fifthfloor") {
                            mappedRoom.index = 5;
                        }

                        floorRooms.forEach(room => {
                            if (room?.roomName === "Bedroom" && parseInt(room?.roomCount) > 0) {
                                mappedRoom.bedroom += parseInt(room.roomCount);
                            }
                            if (room?.roomName === "Master Bedroom" && parseInt(room?.roomCount) > 0) {
                                mappedRoom.bedroom += parseInt(room.roomCount);
                            }
                        });

                        return rooms.concat(mappedRoom);
                    }, []).filter(mappedRoom => mappedRoom.index !== null);
                roomsWithRoomCountOne = roomsWithRoomCountOne.sort((obj1, obj2) => obj1.index - obj2.index);
            }

            const indexWiseBedroom = roomsWithRoomCountOne.reduce((acc, { index, bedroom }) => {
                acc[index] = bedroom;
                return acc;
            }, {});

            let params = {
                plotArea: plotArea,
                plotLength: plotLength,
                plotWidth: plotWidth,
                noFloors: noFloors,
                bedrooms: bedrooms,
                sharedWall: sharedWall,
                twoWheelerParking: twoWheelerParking,
                fourWheelerParking: fourWheelerParking,
                // groundFloorRooms: { ...mappedRoom }
                floorBedroom: indexWiseBedroom,
                frontSetBack: frontSetBack,
                rightSetBack: rightSetBack,
                rearSetBack: rearSetBack,
                leftSetBack: leftSetBack

            }
            let result = await this.fetch2DRelevantDesigns(params, fetchLimit);
            return result;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 191, message: error?.message, error }));
            throw error;
        }
    }

    async findMostRelevant3DDesigns(srInfo, fetchLimit) {
        try {
            let plotArea = srInfo?.plotDimensions?.plotArea || null;
            // let plotLength = srInfo?.plotDimensions?.plotLength || null;
            let plotLength = srInfo?.plotDimensions?.plotArea / srInfo?.plotDimensions?.plotWidth;
            plotLength = plotLength ? plotLength.toFixed(2) : null;
            let plotWidth = srInfo?.plotDimensions?.plotWidth || null;
            let noFloors = null;
            if (srInfo?.houseDetails?.floorCount != null) {
                let floorCase = srInfo?.houseDetails?.floorCount?.toLowerCase();
                floorCase = floorCase.replace(/\s/g, '');
                const floorCountMap = {
                    'groundfloor': 0,
                    'ground+1floor': 1,
                    'ground+2floors': 2,
                    'ground+3floors': 3,
                    'ground+4floors': 4,
                    'ground+5floors': 5,
                    'stiltfloor': 0,
                    'stilt+1floor': 1,
                    'stilt+2floors': 2,
                    'stilt+3floors': 3,
                    'stilt+4floors': 4,
                    'stilt+5floors': 5,
                };
                noFloors = floorCountMap[floorCase] !== undefined ? floorCountMap[floorCase] : null;
            }
            let sharedWall = 0;
            for (let key in srInfo?.plotSideFacing) {
                if (srInfo?.plotSideFacing[key]?.includes("Shared Wall")) {
                    sharedWall = 1;
                }
            }
            let twoWheelerParking = srInfo?.bikeParking?.numberOfBikes || null;
            let fourWheelerParking = srInfo?.carParking?.numberOfCars || null;
            let staircaseExternal = null, staircaseInternal = null;
            if (srInfo?.plotDetails?.stairCaseType?.includes("External")) {
                staircaseExternal = 1;
                staircaseInternal = 0;
            } else if (srInfo?.plotDetails?.stairCaseType?.includes("Internal")) {
                staircaseExternal = 0;
                staircaseInternal = 1;
            }
            let params = {
                plotArea: plotArea,
                plotLength: plotLength,
                plotWidth: plotWidth,
                noFloors: noFloors,
                sharedWall: sharedWall,
                twoWheelerParking: twoWheelerParking,
                fourWheelerParking: fourWheelerParking,
                staircaseExternal: staircaseExternal,
                staircaseInternal: staircaseInternal
            }

            let result = await this.fetch3DRelevantDesigns(params, fetchLimit);
            return result;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 377, message: error?.message, error }));
            throw error;
        }
    }

    async fetch3DRelevantDesigns(params, fetchLimit) {
        try {
            console.log(JSON.stringify({ file: 'service.js', line: 384, message: `params to find relevant design`, params, fetchLimit }));
            let { plotArea, plotLength, plotWidth, noFloors, sharedWall, twoWheelerParking, fourWheelerParking, staircaseExternal, staircaseInternal } = params;
            const pipeline = [
                {
                    $match: {
                        "is_approved": 1,
                        "is_active": 1,
                        "files.linked_sketch_up_file.sketch_up_file_id": { $exists: true, $ne: null, $type: 'string' },
                        // $or: [
                        //     { "files.linked_sketch_up_file.sketch_up_file_id": { $exists: true, $ne: null, $type: 'string' } },
                        //     { "files.linked_dwg_file.linked_dwg_file_id": { $exists: true, $ne: null, $type: 'string' } }
                        // ],
                        "files.three_d_design_id": { $exists: true, $ne: {} }
                    }
                },
                {
                    $addFields: {
                        "files_3d_iso_jpg_array": { $objectToArray: "$files.three_d_design_id" }
                    }
                },
                {
                    $match: {
                        "files_3d_iso_jpg_array": {
                            // $not: { $size: 0 }, 
                            $elemMatch: {
                                v: { $not: { $in: [null, "", [], [{}]] } }
                            }
                        }
                    }
                },
                {
                    $project: { "material_treatment": 0, "files.two_d_rendered_plan_jpg": 0, "files_3d_iso_jpg_array": 0, "files.three_d_cut_iso_jpg": 0, "files.linked_sketch_up_file": 0, "files.linked_dwg_file": 0 }
                },
                {
                    $addFields: {
                        relevanceScore: {
                            $add: [
                                {
                                    $cond: [
                                        {
                                            $or: [
                                                { $and: [{ $gte: ["$plot_details.plot_area", 0.9 * plotArea] }, { $lte: ["$plot_details.plot_area", 1.1 * plotArea] }] }
                                            ]
                                        },
                                        20,
                                        0
                                    ]
                                },
                                {
                                    $cond: [
                                        {
                                            $or: [
                                                { $and: [{ $gte: ["$plot_details.plot_length", 0.9 * plotLength] }, { $lte: ["$plot_details.plot_length", 1.1 * plotLength] }] }
                                            ]
                                        },
                                        15,
                                        0
                                    ]
                                },
                                {
                                    $cond: [
                                        {
                                            $or: [
                                                { $and: [{ $gte: ["$plot_details.plot_width", 0.9 * plotWidth] }, { $lte: ["$plot_details.plot_width", 1.1 * plotWidth] }] }
                                            ]
                                        },
                                        15,
                                        0
                                    ]
                                },
                                {
                                    $cond: [{ $eq: ["$project_details.no_floors", noFloors] }, 20, 0]
                                },
                                {
                                    $cond: [{ $eq: ["$project_details.shared_wall", sharedWall] }, 10, 0]
                                },
                                {
                                    $cond: [
                                        {
                                            $or: [
                                                { $and: [{ $gte: ["$parking.two_wheeler_parking", twoWheelerParking - 1] }, { $lte: ["$parking.two_wheeler_parking", twoWheelerParking + 1] }] }
                                            ]
                                        },
                                        5,
                                        0
                                    ]
                                },
                                {
                                    $cond: [
                                        {
                                            $or: [
                                                { $and: [{ $gte: ["$parking.four_wheeler_parking", fourWheelerParking - 1] }, { $lte: ["$parking.four_wheeler_parking", fourWheelerParking + 1] }] }
                                            ]
                                        },
                                        5,
                                        0
                                    ]
                                },
                                {
                                    $cond: [{ $eq: ["$project_details.staircase_external", staircaseExternal] }, 5, 0]
                                },
                                {
                                    $cond: [{ $eq: ["$project_details.staircase_internal", staircaseInternal] }, 5, 0]
                                }
                            ]
                        }
                    }
                },
                {
                    $sort: { relevanceScore: -1 }
                },
                {
                    $limit: fetchLimit
                }
            ]

            // console.log(JSON.stringify({ file: 'service.js', line: 500, message: `Query to find 3D similar data`, pipeline }));
            const designResult = await Design.aggregate(pipeline).allowDiskUse(true).exec();

            return designResult;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 506, message: error?.message, error }));
            throw error;
        }
    }

    async fetch2DRelevantDesigns(params, fetchLimit) {
        try {
            console.log(JSON.stringify({ file: 'service.js', line: 513, message: `params to find relevant design`, params, fetchLimit }));
            let { plotArea, plotLength, plotWidth, noFloors, bedrooms, sharedWall, twoWheelerParking, fourWheelerParking, floorBedroom, frontSetBack, rightSetBack, rearSetBack, leftSetBack } = params;
            const groundFloorBedroom = floorBedroom["0"];
            const firstFloorBedroom = floorBedroom["1"];
            const secondFloorBedroom = floorBedroom["2"];
            const thirdFloorBedroom = floorBedroom["3"];
            const fourthFloorBedroom = floorBedroom["4"];
            const fifthFloorBedroom = floorBedroom["5"];
            plotLength = parseFloat(plotLength) || 0;
            frontSetBack = parseFloat(frontSetBack) || 0;
            rearSetBack = parseFloat(rearSetBack) || 0;
            plotWidth = parseFloat(plotWidth) || 0;
            leftSetBack = parseFloat(leftSetBack) || 0;
            rightSetBack = parseFloat(rightSetBack) || 0;
            let constPlotLength = plotLength - frontSetBack - rearSetBack;
            let constPlotWidth = plotWidth - leftSetBack - rightSetBack;
            constPlotLength = parseFloat(constPlotLength?.toFixed(2)) || 0;
            constPlotWidth = parseFloat(constPlotWidth?.toFixed(2)) || 0;

            let dynamicOrConditions = [], noOfBedrooms = null;
            // Check for each bedroom variable and add conditions dynamically
            if (typeof groundFloorBedroom !== 'undefined' && groundFloorBedroom !== null) {
                dynamicOrConditions.push({ "floorSums.0.sum": groundFloorBedroom });
                noOfBedrooms += parseInt(groundFloorBedroom);
            }
            if (typeof firstFloorBedroom !== 'undefined' && firstFloorBedroom !== null) {
                dynamicOrConditions.push({ "floorSums.1.sum": firstFloorBedroom });
                noOfBedrooms += parseInt(firstFloorBedroom);
            }
            if (typeof secondFloorBedroom !== 'undefined' && secondFloorBedroom !== null) {
                dynamicOrConditions.push({ "floorSums.2.sum": secondFloorBedroom });
                noOfBedrooms += parseInt(secondFloorBedroom);
            }
            if (typeof thirdFloorBedroom !== 'undefined' && thirdFloorBedroom !== null) {
                dynamicOrConditions.push({ "floorSums.3.sum": thirdFloorBedroom });
                noOfBedrooms += parseInt(thirdFloorBedroom);
            }
            if (typeof fourthFloorBedroom !== 'undefined' && fourthFloorBedroom !== null) {
                dynamicOrConditions.push({ "floorSums.4.sum": fourthFloorBedroom });
                noOfBedrooms += parseInt(fourthFloorBedroom);
            }
            if (typeof fifthFloorBedroom !== 'undefined' && fifthFloorBedroom !== null) {
                dynamicOrConditions.push({ "floorSums.5.sum": fifthFloorBedroom });
                noOfBedrooms += parseInt(fifthFloorBedroom);
            }

            // Add an empty object if dynamicOrConditions is empty
            if (dynamicOrConditions.length === 0) {
                dynamicOrConditions.push({});
            }

            let pipeline = [];
            let match = {
                "$match": {
                    "is_approved": 1,
                    "is_active": 1,
                    "files.linked_dwg_file.linked_dwg_file_id": { $exists: true, $ne: null, $type: 'string' },
                    // $or: [
                    //     { "files.linked_sketch_up_file.sketch_up_file_id": { $exists: true, $ne: null, $type: 'string' } },
                    //     { "files.linked_dwg_file.linked_dwg_file_id": { $exists: true, $ne: null, $type: 'string' } }
                    // ],
                    "project_details.no_floors": noFloors,
                    "project_details.shared_wall": sharedWall,
                    "project_details.bedrooms": noOfBedrooms,
                    "plot_details.plot_shape": {
                        $in: ["Rectangle", "Rectangular", "rectangular", "Square"]
                    },
                    "files.two_d_rendered_plan_jpg": { $exists: true, $ne: {} }
                }
            }
            let addFields = {
                "$addFields": {
                    "plot_details.plot_length": { $convert: { input: "$plot_details.plot_length", to: "double", onError: 0, onNull: 0 } },
                    "plot_details.plot_width": { $convert: { input: "$plot_details.plot_width", to: "double", onError: 0, onNull: 0 } },
                    "plot_details.front_set_back": { $convert: { input: "$plot_details.front_set_back", to: "double", onError: 0, onNull: 0 } },
                    "plot_details.rear_set_back": { $convert: { input: "$plot_details.rear_set_back", to: "double", onError: 0, onNull: 0 } },
                    "plot_details.left_set_back": { $convert: { input: "$plot_details.left_set_back", to: "double", onError: 0, onNull: 0 } },
                    "plot_details.right_set_back": { $convert: { input: "$plot_details.right_set_back", to: "double", onError: 0, onNull: 0 } }
                }
            }

            //**************** */ Old logic to calculate plot length  ****************
            // "constructiblePlotLength": {
            //     $subtract: [
            //         "$plot_details.plot_length",
            //         { $add: ["$plot_details.front_set_back", "$plot_details.rear_set_back"] }
            //     ]
            // },
            // "constructiblePlotWidth": {
            //     $subtract: [
            //         "$plot_details.plot_width",
            //         { $add: ["$plot_details.left_set_back", "$plot_details.right_set_back"] }
            //     ]
            // },

            let addFields2 = {
                "$addFields": {
                    "constructiblePlotLength": {
                        $divide: [
                            {
                                $floor: {
                                    "$add": [
                                        {
                                            $multiply: [
                                                {
                                                    $subtract: [
                                                        "$plot_details.plot_length",
                                                        {
                                                            $add: [
                                                                "$plot_details.front_set_back",
                                                                "$plot_details.rear_set_back"
                                                            ]
                                                        }
                                                    ]
                                                },
                                                100
                                            ]
                                        },
                                        0.5
                                    ]
                                }
                            },
                            100
                        ]
                    },
                    "constructiblePlotWidth": {
                        $divide: [
                            {
                                $floor: {
                                    "$add": [
                                        {
                                            $multiply: [
                                                {
                                                    $subtract: [
                                                        "$plot_details.plot_width",
                                                        {
                                                            $add: [
                                                                "$plot_details.left_set_back",
                                                                "$plot_details.right_set_back"
                                                            ]
                                                        }
                                                    ]
                                                },
                                                100
                                            ]
                                        },
                                        0.5
                                    ]
                                }
                            },
                            100
                        ]
                    },
                    "relevanceScore": 100,
                    "floorSums": {
                        $map: {
                            input: "$rooms",
                            as: "room",
                            in: {
                                index: "$$room.index",
                                sum: {
                                    $add: [
                                        { $ifNull: ["$$room.family_room", 0] },
                                        { $ifNull: ["$$room.master_bedroom", 0] }
                                    ]
                                }
                            }
                        }
                    },
                    "files_2d_plan_jpg_array": { $objectToArray: "$files.two_d_rendered_plan_jpg" }
                }
            }

            let match1 = {
                "$match": {
                    "constructiblePlotLength": constPlotLength,
                    "constructiblePlotWidth": constPlotWidth,
                    $and: dynamicOrConditions,
                    "files_2d_plan_jpg_array": {
                        $elemMatch: {
                            v: { $not: { $in: [null, "", [], [{}]] } }
                        }
                    }
                }
            }

            let project = {
                $project: { "material_treatment": 0, "files.three_d_cut_iso_jpg": 0, "files_2d_plan_jpg_array": 0, "files.linked_sketch_up_file": 0, "files.linked_dwg_file": 0, "files.three_d_design_id": 0 }
            }

            let limit = { "$limit": fetchLimit };
            pipeline.push(match, addFields, addFields2, match1, project, limit);
            // console.log(JSON.stringify({ file: 'service.js', line: 705, message: `Query to find 2D similar data`, pipeline }));
            let designResult = await Design.aggregate(pipeline).allowDiskUse(true).exec();

            return designResult;

        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 711, message: error?.message, error }));
            throw error;
        }
    }

    async fetchDownloadedDesign(params, action) {
        try {
            if (action == "tab_click") {
                let redisResult = await redis.redisCacheGet(params.redisCacheKeyDownload);
                let finalResult = redisResult ? JSON.parse(redisResult) : [];
                if (finalResult && finalResult.length) {
                    return finalResult;
                }
            }
            console.log(JSON.stringify({ file: 'service.js', line: 695, message: `params`, params }));
            let pipeline = [];
            let match = {
                "$match": {
                    "sr_id": params.serviceRequestId,
                    "user_id": params.userId
                }
            }

            let lookup = {
                "$lookup": {
                    "from": "plan_style_designs",
                    "localField": "design_id",
                    "foreignField": "unique_id",
                    "as": "data"
                }
            }

            let unwind = {
                "$unwind": "$data"
            }

            let addFields = {
                "$addFields": {
                    "data.relevanceScore": "$relevance_score"
                }
            }

            let replaceRoot = {
                "$replaceRoot": {
                    newRoot: "$data"
                }
            }
            let project;
            if (params?.srTypeId == 19) {
                // In 3D case
                project = {
                    "$project": {
                        "material_treatment": 0,
                        "files.three_d_cut_iso_jpg": 0,
                        "files.two_d_rendered_plan_jpg": 0,
                        "files.linked_dwg_file": 0,
                        "files.linked_sketch_up_file": 0
                    }
                };
            } else {
                // In 2D case
                project = {
                    "$project": {
                        "material_treatment": 0,
                        "files.three_d_cut_iso_jpg": 0,
                        "files.three_d_design_id": 0,
                        "files.linked_dwg_file": 0,
                        "files.linked_sketch_up_file": 0
                    }
                }
            }

            pipeline.push(match, lookup, unwind, addFields, replaceRoot, project);
            console.log(JSON.stringify({ file: 'service.js', line: 722, msg: "fetchDownloadedDesign", pipeline }));
            const docs = await DesignDownload.aggregate(pipeline).allowDiskUse(true).exec();
            // let deleteResult = await redis.redisCacheDelete(params.redisCacheKey);
            let setRedis = await redis.redisCacheSetExpiry(params.redisCacheKeyDownload, JSON.stringify(docs), 86400);
            console.log(JSON.stringify({ file: 'service.js', line: 754, setRedis }));
            return docs;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 726, message: error?.message, error }));
            throw error;
        }
    }
}

module.exports = GetDesigns;