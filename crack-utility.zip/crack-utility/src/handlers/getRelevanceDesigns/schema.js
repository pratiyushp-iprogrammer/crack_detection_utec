const Joi = require("joi");

const schema = Joi.object().keys({
    srId: Joi.alternatives().try(Joi.number().required(), Joi.string().required()),
    srTypeId: Joi.alternatives().try(Joi.number().required().valid(18, 19), Joi.string().required().valid("18", "19")),
    action: Joi.string().valid("init", "refresh", "tab_click").required(),
    fetchLimit: Joi.number().required(),
    userId: Joi.number().required()
});

module.exports = schema;