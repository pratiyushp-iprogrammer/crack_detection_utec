const {LambdaClient, InvokeAsyncCommand} =  require("@aws-sdk/client-lambda");
const lambdaClient = new LambdaClient({region: process.env.AWS_REGION_NAME});
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
const PlansService = require('../../services/plansService');
const StylesService = require('../../services/stylesService');
const Database = require('../../common/database');
const DownloadAssetsSchmea = require('../../schema/downloadAssets');
const DownloadCSV = require('../../common/downloadCsv');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();


let baseResponse = new BaseResponse();
let plansService = new PlansService();
let sytlesService = new StylesService();
let downloadCsv = new DownloadCSV();

exports.downloadAssetsHandler = async(event, context) => {
    try {
        event = Common.reqSanitize(event);
        const params = JSON.parse(event.body);
        var validation = DownloadAssetsSchmea.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid request.");
        }
        let tempObj = {};
        if (params.event_for === 'plans') {
            if (params.event_for === 'plans' && params.allFields) {
                const result = await plansService.fetchPlanDetails(params.unique_id);
                const arrSearchablePlanFields = ["plot_details.plot_area", "plot_details.plot_length", "plot_details.plot_width", "plot_details.plot_shape", "plot_details.open_sides_of_the_plot", "plot_details.left_set_back", "plot_details.right_set_back", "plot_details.front_set_back", "plot_details.rear_set_back", "project_details.typology", "project_details.estimated_cost_of_construction", "project_details.builtup_area", "project_details.floor_plate_area_of_ground_floor", "project_details.floor_plate_length", "project_details.floor_plate_width", "project_details.floors", "project_details.bedrooms", "project_details.shared_wall", "project_details.for_two_shared_wall_adjacent_parallel", "project_details.space_allocation", "project_details.style", "project_details.low_range_budget", "project_details.high_range_budget", "geography.weather_condition", "geography.state", "geography.city", "geography.district", "geography.geo_coordinates", "geography.pincode", "geography.budget", "family_details.total_family_members", "family_details.number_of_senior_citizen", "family_details.number_of_adults", "family_details.number_of_children", "family_details.number_of_infants", "parking.basement", "parking.stilts", "parking.two_wheeler_parking", "parking.four_wheeler_parking", "senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor", "senior_citizen_friendly.one_bhk_on_ground_floor", "senior_citizen_friendly.provision_of_ramp", "vaastu_compliancy.vaastu_compliant", "vaastu_compliancy.entry_direction", "vaastu_compliancy.orientation_of_kitchen", "vaastu_compliancy.orientation_of_pooja_room", "vaastu_compliancy.orientation_of_master_bedrrom", "rooms.total_bathrooms", "rooms.attached_bathrooms", "rooms.common_bathrooms", "rooms.dining_room", "rooms.living_room", "rooms.kitchen", "rooms.family_room", "rooms.store_room", "rooms.pooja_room", "rooms.shops", "open_areas.balcony", "open_areas.porch", "open_areas.verandah", "open_areas.garden", "open_areas.courtyard", "open_areas.frontyard", "open_areas.backyard", "open_areas.terrace", "special_amenities.library", "special_amenities.home_theatre", "special_amenities.pool", "special_amenities.gym", "material_treatment.brick", "material_treatment.stone", "material_treatment.wood", "material_treatment.tile", "material_treatment.aluminium_composite_panel", "material_treatment.glass_curtain_wall", "structural_elements.pergola", "structural_elements.jaali", "structural_elements.green_wall", "structural_elements.planter", "structural_elements.vault", "structural_elements.double_height_open_area", "structural_elements.elevation_element", "colors.color_scheme", "colors.color_used", "partner_details.partner_id", "partner_details.partner_name", "unique_id", "source", "sr_number", "option_number", "design_name", "design_short_description", "design_long_description", "stylized.stylized_configuration", "files.two_d_rendered_plan_jpg.ground", "files.two_d_rendered_plan_jpg.ground_plus_one", "files.two_d_rendered_plan_jpg.ground_plus_two", "files.two_d_rendered_plan_jpg.ground_plus_three", "files.two_d_rendered_plan_jpg.ground_plus_four", "files.two_d_rendered_plan_jpg.above_ground_plus_four", "files.two_d_rendered_plan_jpg.others", "files.two_d_line_drawing_jpg.ground", "files.two_d_line_drawing_jpg.ground_plus_one", "files.two_d_line_drawing_jpg.ground_plus_two", "files.two_d_line_drawing_jpg.ground_plus_three", "files.two_d_line_drawing_jpg.ground_plus_four", "files.two_d_line_drawing_jpg.above_ground_plus_four", "files.two_d_line_drawing_jpg.others", "files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id", "files.three_d_design_id.front", "files.three_d_design_id.right_side", "files.three_d_design_id.left_side", "files.three_d_design_id.rear_side", "files.three_d_design_id.internal", "files.three_d_cut_iso_jpg.ground", "files.three_d_cut_iso_jpg.ground_plus_one", "files.three_d_cut_iso_jpg.ground_plus_two", "files.three_d_cut_iso_jpg.ground_plus_three", "files.three_d_cut_iso_jpg.ground_plus_four", "files.three_d_cut_iso_jpg.above_ground_plus_four", "files.three_d_cut_iso_jpg.others", "files.linked_estimation_id.estimation_id", "files.linked_stetch_up_file.sketch_up_file_id", "files.linked_dwg_file.linked_dwg_file_id", "files.linked_psd_file.linked_psd_file_id", "files.linked_ppt_file.linked_ppt_file_id", "files.utec_pro_link.utec_pro_link_id"];

                let eventBody = {
                    "searchString": "",
                    "filters": {
                        "unique_id": [params.unique_id]
                    },
                    "arrRequiredColumns": arrSearchablePlanFields,
                    "pagination": { "page": 1, "limit": 1 }
                };
                let payload = {
                    "body": JSON.stringify(eventBody)
                };

                const planDetails = await plansService.fetch(payload);
                let filePath = "";
                if (planDetails) {
                    planDetails.forEach((obj) => {
                        delete obj._id;
                    });
                    const csvPayload = await downloadCsv.downloadRecords(payload, planDetails, params.event_for);
                    const bodyData = JSON.parse(csvPayload.body);
                    console.log('plans bodyData', bodyData);
                    filePath = bodyData.payload[0] ? bodyData.payload[0].fileName : "";
                }

                tempObj = { files: result.files, reference_images: result.reference_images, csvFilePath: filePath };
            } else {
                let eventBody = {
                    "searchString": "",
                    "filters": {
                        "unique_id": [params.unique_id]
                    },
                    "arrRequiredColumns": [params.object],
                    "pagination": { "page": 1, "limit": 1 }
                };
                let payload = {
                    "body": JSON.stringify(eventBody)
                };

                const planDetails = await plansService.fetch(payload);

                if (planDetails) {
                    planDetails.forEach((obj) => {
                        delete obj._id;
                        delete obj.score;
                        delete obj.percentage;
                        delete planDetails.totalRecordsCount;
                    });
                }
                tempObj = { files: planDetails };
            }
        }

        if (params.event_for == 'styles') {
            if (params.event_for == 'styles' && params.allFields) {
                const result = await sytlesService.findByUniqueIdGetData(params.unique_id);
                const arrSearchableStylesFields = ["plot_details.plot_area", "plot_details.plot_length", "plot_details.plot_width", "plot_details.plot_shape", "plot_details.left_set_back", "plot_details.right_set_back", "plot_details.front_set_back", "plot_details.rear_set_back", "plot_details.close_sides_of_the_plot", "project_details.typology", "project_details.estimated_cost_of_construction", "project_details.builtup_area", "project_details.floor_plate_area_of_ground_floor", "project_details.floor_plate_length", "project_details.floor_plate_width", "project_details.floors", "project_details.bedrooms", "project_details.shared_wall", "project_details.for_two_shared_wall_adjacent_parallel", "project_details.style", "project_details.low_range_budget", "project_details.high_range_budget", "geography.state", "geography.city", "geography.district", "geography.geo_coordinates", "geography.pincode", "family_details.total_family_members", "family_details.number_of_senior_citizen", "family_details.number_of_adults", "family_details.number_of_children", "family_details.number_of_infants", "parking.basement", "parking.stilts", "parking.two_wheeler_parking", "parking.four_wheeler_parking", "senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor", "senior_citizen_friendly.one_bhk_on_ground_floor", "senior_citizen_friendly.provision_of_ramp", "open_areas.balcony", "open_areas.porch", "open_areas.garden", "open_areas.courtyard", "open_areas.frontyard", "open_areas.backyard", "open_areas.terrace", "roof.roof_type", "special_amenities.pool", "material_treatment.brick", "material_treatment.stone", "material_treatment.wood", "material_treatment.tile", "material_treatment.aluminium_composite_panel", "material_treatment.glass_curtain_wall", "structural_elements.pergola", "structural_elements.jaali", "structural_elements.green_wall", "structural_elements.planter", "structural_elements.vault", "structural_elements.double_height_open_area", "structural_elements.elevation_element", "colors.color_scheme", "colors.color_used", "partner_details.partner_id", "partner_details.partner_name", "unique_id", "element_type", "source", "sr_number", "option_number", "design_name", "design_short_description", "design_long_description", "stylized.stylized_configuration", "reference_images", "element_name", "style", "shape", "material", "location", "shutter", "operation", "material_finish", "accessibility", "height", "type", "railing", "construction", "accessible_terrace", "privacy", "railing_style", "staircase_material", "railing_material", "image_files", "raw_files_availability", "raw_files", "files.two_d_rendered_plan_jpg.ground", "files.two_d_rendered_plan_jpg.ground_plus_one", "files.two_d_rendered_plan_jpg.ground_plus_two", "files.two_d_rendered_plan_jpg.ground_plus_three", "files.two_d_rendered_plan_jpg.ground_plus_four", "files.two_d_rendered_plan_jpg.above_ground_plus_four", "files.two_d_rendered_plan_jpg.others", "files.two_d_line_drawing_jpg.ground", "files.two_d_line_drawing_jpg.ground_plus_one", "files.two_d_line_drawing_jpg.ground_plus_two", "files.two_d_line_drawing_jpg.ground_plus_three", "files.two_d_line_drawing_jpg.ground_plus_four", "files.two_d_line_drawing_jpg.above_ground_plus_four", "files.two_d_line_drawing_jpg.others", "files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id", "files.three_d_design_id.front", "files.three_d_design_id.right_side", "files.three_d_design_id.left_side", "files.three_d_design_id.rear_side", "files.three_d_design_id.internal", "files.three_d_cut_iso_jpg.ground", "files.three_d_cut_iso_jpg.ground_plus_one", "files.three_d_cut_iso_jpg.ground_plus_two", "files.three_d_cut_iso_jpg.ground_plus_three", "files.three_d_cut_iso_jpg.ground_plus_four", "files.three_d_cut_iso_jpg.above_ground_plus_four", "files.three_d_cut_iso_jpg.others", "files.linked_estimation_id.estimation_id", "files.linked_stetch_up_file.sketch_up_file_id", "files.linked_dwg_file.linked_dwg_file_id", "files.linked_psd_file.linked_psd_file_id", "files.linked_ppt_file.linked_ppt_file_id", "files.utec_pro_link.utec_pro_link_id"];

                let eventBody = {
                    "searchString": "",
                    "filters": {
                        "unique_id": [params.unique_id]
                    },
                    "arrRequiredColumns": arrSearchableStylesFields,
                    "pagination": { "page": 1, "limit": 1 }
                };
                let payload = {
                    "body": JSON.stringify(eventBody)
                };
                const styleDetails = await sytlesService.fetch(payload);
                let filePath = "";
                if (styleDetails) {
                    styleDetails.forEach((obj) => {
                        delete obj._id;
                    });
                    const csvPayload = await downloadCsv.downloadRecords(payload, styleDetails, params.event_for);
                    const bodyData = JSON.parse(csvPayload.body);
                    console.log('styles bodyData', bodyData);
                    filePath = bodyData.payload[0] ? bodyData.payload[0].fileName : "";
                }

                tempObj = { files: result.files, image_files: result.image_files, raw_files: result.raw_files, csvFilePath: filePath };
            } else {
                let eventBody = {
                    "searchString": "",
                    "filters": {
                        "unique_id": [params.unique_id]
                    },
                    "arrRequiredColumns": [params.object],
                    "pagination": { "page": 1, "limit": 1 }
                };
                let payload = {
                    "body": JSON.stringify(eventBody)
                };
                const styleDetails = await sytlesService.fetch(payload);
                if (styleDetails) {
                    styleDetails.forEach((obj) => {
                        delete obj._id;
                        delete obj.score;
                        delete obj.percentage;
                        delete styleDetails.totalRecordsCount;
                    });
                }
                tempObj = { files: styleDetails };

            }
        }

        function getNode(inputObj) {
            if (inputObj == null)
                return null;
            if (typeof inputObj !== 'object') {
                return [inputObj];
            }
            var arr = [];
            var array_node = Object.keys(inputObj).map(function(key) {
                if (key != "utec_pro_link") {
                    return inputObj[key];
                }
            });
            for (var i = 0; i < array_node.length; i++) {
                if (typeof array_node[i] == 'string') {
                    if (array_node[i].includes(",")) {
                        array_node[i] = array_node[i].split(",");
                    }
                }
                if (array_node[i] != "") {
                    Array.prototype.push.apply(arr, getNode(array_node[i]));
                }
            }
            return arr;
        }
        let processedArray = getNode(tempObj);
        console.log('processedArray...', JSON.stringify(processedArray));
        let lambda_payload;
        if (Array.isArray(processedArray) && processedArray.length > 0) {
            lambda_payload = {
                keys: processedArray,
                unique_id: params.unique_id
            }
        } else {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "No files to download.");
        }

        var lambda_params = {
            FunctionName: process.env.DM_DOWNLOAD_ZIP_S3_LAMBDA_ARN,
            InvocationType: "RequestResponse",
            InvokeArgs: JSON.stringify(lambda_payload)
        };

        const command = new InvokeAsyncCommand(lambda_params);
        let lambdaResponse = await lambdaClient.send(command);
        console.log('lambdaResponse...', lambdaResponse);
        lambdaResponse.s3BasePath = `${process.env.S3_BUCKET_PATH}/`;

        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, lambdaResponse, "Assets downloaded successfully.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Internal server error: " + e.message);
    }
};