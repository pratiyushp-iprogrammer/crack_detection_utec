const mongoose = require('mongoose');
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const DesignActionService = require('../../services/designActionService');
const PlansService = require('../../services/plansService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const AdminDetails = require('../common/getAdminDetails');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

const UsageDataSchema = require('../../schema/viewUsageData');
let baseResponse = new BaseResponse();
let designActionService = new DesignActionService();
let plansService = new PlansService();
let adminDetails = new AdminDetails();

exports.viewUsageDataHandler = async(event, context) => {
    try {
         event = Common.reqSanitize(event);
        let email = "";
        let isAdmin = false;
        if (event.requestContext.authorizer) {
            let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            isAdmin = authorizerResponse.isAdmin;
            email = authorizerResponse.email;
        }
        // let authorizationToken = event.headers.Authorization;
        // const details = await adminDetails.getAdminDetails(authorizationToken);
        // email = details ? details.name : '';

        const params = JSON.parse(event.body);
        params['user_id'] = email;
        params['is_admin'] = isAdmin;
        var validation = UsageDataSchema.validate(params);

        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.NOT_FOUND, [], "Invalid request.");
        }
        var planObjectId = new mongoose.Types.ObjectId(params._id);
        let result = [];
        const getDataFromPlans = await designActionService.getDataFromPlans(planObjectId);
        const getCount = await designActionService.getActionCountData(planObjectId, email);
        console.log("getCount => ", getCount);
        let updateViewCount;
        if(getDataFromPlans?.number_of_times_viewed !== null || getDataFromPlans?.number_of_times_viewed !== ''){
            updateViewCount = getDataFromPlans?.number_of_times_viewed + 1;
            console.log("updateViewCount=> ",updateViewCount);
        }else{
            updateViewCount = 1;
        }
        getCount.view = updateViewCount
        console.log("get view Count ",getCount.view);
        const reusedPlans = await designActionService.getReusedPlans(planObjectId);
        result.push({
            getDataFromPlans: getDataFromPlans ? getDataFromPlans : [],
            getCount: getCount,
            reusedPlansAndLogData: reusedPlans
        });
        let updateCountObj = {
            unique_id: getDataFromPlans.unique_id,
            number_of_times_reused: getCount.reuse,
            number_of_times_viewed: updateViewCount
        };
        await plansService.updatePlan(updateCountObj);
        console.log("updateCountObj =>", updateCountObj);
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, result, "Usage data fetched successfully!");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}