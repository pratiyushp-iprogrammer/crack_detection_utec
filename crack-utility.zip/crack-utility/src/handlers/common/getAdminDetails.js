const Database = require('../../common/database');
const AdminDetailsService = require('../../services/adminDetailsService');
var axios = require("axios");

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let adminDetailsService = new AdminDetailsService();

class AdminDetails {
    async getAdminDetails(token) {
        try {
            let utecMicroEndpoint = process.env.UTEC_MICRO_BASE_URL;
            console.log("utecMicroEndpoint", utecMicroEndpoint);
            const res = await axios.get(`https://${utecMicroEndpoint}/adminPanelService/getAdminDetails`, {
                headers: {
                    'Authorization': token
                }
            })
            console.log("getAdminDetailsResponse", res?.data);
            if (res.data.status === 'success') {
                const param = {};
                param.resAdminID = res.data.result.resAdminID;
                param.name = res.data.result.name;
                param.email = res.data.result.email;
                param.role = res.data.result.role;
                const result = await adminDetailsService.findById(param.email);
                if (result) {
                    const updateResult = await adminDetailsService.updateAdminDetails(param);
                    return updateResult.value;
                } else {
                    const insertedResult = await adminDetailsService.createAdminDetails(param);
                    return insertedResult;
                }
            } else {
                console.log(error);
            }
        } catch (error) {
            console.log(error);
        }
    }
}
module.exports = AdminDetails;