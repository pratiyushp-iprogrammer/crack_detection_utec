const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const UserProfileActionService = require('../../services/userProfileActionsService');
const HTTP_CODE = require('../../common/constants');
const Database = require('../../common/database');
const UserProfileActionSchema = require('../../schema/userProfileActions');
const mongoose = require('mongoose');
const PlansService = require('../../services/plansService')
const cacheResponse = require('../../common/cacheResponse');

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let userProfileActionService = new UserProfileActionService();
let plansService = new PlansService();
let CacheResponse = new cacheResponse();

// ADD FAVOURITE
exports.addFavoriteHandler = async(event, context) => {
    try {
    event = Common.reqSanitize(event);

        let userId;
        let authorizerResponse;
        if (event.requestContext.authorizer) {
            authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            userId = authorizerResponse.userId;
        }
        if (userId === undefined || userId === null) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, authorizerResponse, "Something went wrong.");
        }
        const params = JSON.parse(event.body);
        var ObjectId = new mongoose.Types.ObjectId(params.object_id);
        params['action'] = 'favourite';
        params['user_id'] = userId;
        params['user_detail'] = authorizerResponse;
        var validation = UserProfileActionSchema.validate(params);
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        const recordExist = await userProfileActionService.checkRecord(ObjectId, userId, params.event_for, params['action']);
        if (recordExist) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], params['action'] + " marked successfully!");
        } else {
            const response = await userProfileActionService.create(params);
            if (response) {
                // await CacheResponse.clearCache(userId, event, params.event_for);
                await CacheResponse.clearRelevantCache(userId, event, params.event_for);
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], params['action'] + " marked successfully.");
            }
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
        }
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}

// REMOVE FAVOURITE
exports.removeFavoriteHandler = async(event, context) => {

    try {
    event = Common.reqSanitize(event);

        let userId;
        let authorizerResponse;
        if (event.requestContext.authorizer) {
            authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            userId = authorizerResponse.userId;
        }

        if (userId === undefined || userId === null) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, authorizerResponse, "Something went wrong.");
        }

        const params = JSON.parse(event.body);
        var ObjectId = new mongoose.Types.ObjectId(params.object_id);
        params['action'] = 'favourite';
        params['user_id'] = userId;
        params['user_detail'] = authorizerResponse;
        var validation = UserProfileActionSchema.validate(params);

        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }

        const recordExist = await userProfileActionService.checkRecord(ObjectId, userId, params.event_for, params['action']);
        if (recordExist) {
            await userProfileActionService.remove(ObjectId, userId, params.event_for, params['action']);
            // await CacheResponse.clearCache(userId, event, params.event_for);
            await CacheResponse.clearRelevantCache(userId, event, params.event_for);
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Removed successfully.");
        }
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}

// ADD LIKE
exports.addLikeHandler = async(event, context) => {
    try {
    event = Common.reqSanitize(event);

        let userId;
        let authorizerResponse;
        const path = event?.path || '/v1/userProfileAction/addLike';
        console.log(path)

        if (event.requestContext.authorizer) {
            authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            userId = authorizerResponse.userId;
        }

        if (userId === undefined || userId === null) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, authorizerResponse, "Something went wrong.");
        }

        const params = JSON.parse(event.body);
        var ObjectId = new mongoose.Types.ObjectId(params.object_id);
        params['action'] = 'like';
        params['user_id'] = userId;
        params['user_detail'] = authorizerResponse;
        var validation = UserProfileActionSchema.validate(params);
        console.log("params:",JSON.stringify(params));
        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }
        const recordExist = await userProfileActionService.checkRecord(ObjectId, userId, params.event_for, params['action']);
        if (recordExist) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], params['action'] + " marked successfully!");
        } else {
            const response = await userProfileActionService.create(params);

            let updateLikeCount
            if(path === '/v1/userProfileAction/addLike') {
                updateLikeCount = await plansService.likeHomeDesigns(ObjectId);
            } else if (path === '/v2/userProfileAction/addLike'){
                updateLikeCount = await plansService.likeHomeDesignsV2(ObjectId);
            }
            
            if (response && updateLikeCount) {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], params['action'] + " marked successfully.");
            }
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
        }
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}

// REMOVE LIKE
exports.removeLikeHandler = async(event, context) => {
    try {
    event = Common.reqSanitize(event);

        let userId;
        let authorizerResponse;
        const path = event?.path || '/v1/userProfileAction/unLike';
        console.log(path)

        if (event.requestContext.authorizer) {
            authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
            userId = authorizerResponse.userId;
        }

        if (userId === undefined || userId === null) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, authorizerResponse, "Something went wrong.");
        }

        const params = JSON.parse(event.body);
        var ObjectId = new mongoose.Types.ObjectId(params.object_id);
        params['action'] = 'like';
        params['user_id'] = userId;
        params['user_detail'] = authorizerResponse;
        var validation = UserProfileActionSchema.validate(params);

        if (validation.error) {
            return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
        }

        const recordExist = await userProfileActionService.checkRecord(ObjectId, userId, params.event_for, params['action']);
        if (recordExist) {
            const response = await userProfileActionService.remove(ObjectId, userId, params.event_for, params['action']);

            let updateLikeCount
            if(path === '/v1/userProfileAction/unLike') {
                updateLikeCount = await plansService.unLikeHomeDesigns(ObjectId);
            } else if (path === '/v2/userProfileAction/unLike'){
                updateLikeCount = await plansService.unLikeHomeDesignsV2(ObjectId); 
            }
            
            if(response && updateLikeCount){
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], "Removed successfully.");
            }
        }
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Something went wrong.");
    } catch (e) {
        // TODO - Need to enhance catch block
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
    }
}