const HTTP_CODE = require('../../common/constants');
const MongoConnection = require('../../common/database');
let instance = new MongoConnection();
const Database = require('../../common/dbConnector');
const dbConnector = new Database();
if (typeof client === 'undefined') var client = instance.connect();
const userActivity = require('../../models/designUserActivity');
const redis = require('../../common/redis/redis-connection');
const env = process.env.DEPLOYMENT ? process.env.DEPLOYMENT : 'dev';

class LogUserActivity {

    async logUserActivity(params) {
        try {
            console.log(JSON.stringify({ file: 'logUserActivity.js', line: 13, message: `params`, params }));
            const { designId, adminEmail, activityName } = params;
            const userDetails = await this.fetchUserDetails(adminEmail, true);
            let userId = userDetails?.adminId || 0;
            delete userDetails?.adminId;
            let updateResult = null;
            if (designId && designId.length) {
                let insertionData = designId.map(value => ({
                    designId: value,
                    userId,
                    userDetails,
                    activityName
                }));
                updateResult = await userActivity.insertMany(insertionData); // Insert multiple documents in one go
            } else {
                let insertionData = {
                    designId,
                    userId,
                    userDetails,
                    activityName
                };
                updateResult = await userActivity.create(insertionData);
            }
            console.log(JSON.stringify({ file: 'logUserActivity.js', line: 23, updateResult }));

            if (updateResult) return true;
            else return false;
        } catch (error) {
            throw error;
        }
    }

    async fetchUserDetails(params, isEmail = false) {
        try {
            if (!params) {
                throw new Error("Input missing");
            }
            let searchBy = "aud.admin_id";
            const redisSearchKey = `active_design_user_details_${params}_${env}`
            if (isEmail) {
                searchBy = "aud.email";
            }
            let redisResult = await redis.redisCacheGet(redisSearchKey);
            if (redisResult) {
                return JSON.parse(redisResult);
            } else {
                const query = `
                SELECT aud.admin_id AS adminId, aud.name AS name, aud.email AS email, aud.mobile AS contact, aw.workgroup_name AS workgroup, awr.role_name AS role 
                FROM 
                    admin_user_details aud
                LEFT JOIN 
                    admin_workgroups aw ON aud.workgroup_id = aw.id
                LEFT JOIN 
                    admin_workgroup_roles awr ON aud.workgroup_roles_id = awr.id
                WHERE 
                    ${searchBy} = ? ;`;

                const [data = null] = await dbConnector.queryExecute(query, [params]);
                console.log(JSON.stringify({ file: 'service.js', line: 73, user_details: data }));
                if (!data) throw ({ message: "User not found!", http_code: HTTP_CODE.BAD_REQUEST });
                let setRedis = await redis.redisCacheSet(redisSearchKey, JSON.stringify(data));
                await redis.redisCacheExpire(redisSearchKey, 86400);
                console.log(JSON.stringify({ file: 'service.js', line: 76, setRedis }));
                return data;
            }

        } catch (error) {
            console.log(JSON.stringify({ file: 'logUserActivity.js', line: 74, message: error?.message }));
            throw error;
        }
    }
}

module.exports = LogUserActivity;
