'use strict';

const { S3Client, GetObjectCommand } =require("@aws-sdk/client-s3"); 
const { Upload } = require("@aws-sdk/lib-storage");
const s3Client = new S3Client();
const archiver = require('archiver');
const BaseResponse = require('../../common/baseResponse');
const common = require('../../common/common');
let Common = new common()
const HTTP_CODE = require('../../common/constants');
let baseResponse = new BaseResponse();

//This returns us a stream.. consider it as a real pipe sending fluid to S3 bucket.. Don't forget it
const streamTo = async (bucketName, keyName) => {
    var stream = require('stream');
    var passThrough = new stream.PassThrough();
    const s3params = {
        Bucket: bucketName, 
        Key: keyName,
        Body: passThrough 
    }

    const parallelUploads3 = new Upload({
        client: new S3Client({}),
        params: s3params
    });
    
    parallelUploads3.on("httpUploadProgress", (progress) => {
        // console.log(progress);
    });
    
    await parallelUploads3.done();
    console.log("upload file", parallelUploads3)

    return passThrough;
};

exports.downloadZipS3Handler = async(event, context, callback) => {
    try {
        // event = Common.reqSanitize(event);
        let fileName = (event.unique_id) ? `downloaded-assets/${event.unique_id}_${baseResponse.currentDatetime()}.zip` : `downloaded-assets/assets.zip`;

        console.log(event);
        console.log(event.keys);
        console.log(event.keys.length);
        console.log("fileName", fileName);

        const keyNames = event.keys;

        var filesList = await Promise.all(keyNames.map(keyName => new Promise( async (resolve, reject) => {
            const getObjectCommand = new GetObjectCommand({ Bucket: process.env.UPLOAD_S3_BUCKET, Key: keyName });
            const file_data = await s3Client.send(getObjectCommand);
        
            const bufferData = await file_data?.Body.transformToByteArray();

            if (bufferData) {
                console.log(`Reading ${keyName}`);
                resolve({ data: bufferData, name: `${keyName.replace(/\//g, "_")}` })
            } else {
                console.log(err);
            }
        }))).catch(error => { console.log(error); throw new Error(error) });
        console.log("filesList", filesList);
        await new Promise(async(resolve, reject) => {
            var myStream = streamTo(process.env.UPLOAD_S3_BUCKET, fileName); //Instantiate the pipe
            var archive = archiver('zip');
            archive.on('error', err => { throw new Error(err); });

            //Your promise gets resolved when the fluid stops running... so that's when you get to close and resolve
            myStream.on('close', resolve);
            myStream.on('end', resolve);
            myStream.on('error', reject);

            archive.pipe(myStream); //Pass that pipe to archive so it can push the fluid straigh down to S3 bucket
            filesList.forEach(item => {
                console.log(`Looping through ${item.name}`);
                archive.append(item.data, { name: item.name });
            }); //And then we start adding files to it
            archive.finalize(); //Tell is, that's all we want to add. Then when it finishes, the promise will resolve in one of those events up there
        }).catch(error => { throw new Error(error) });

        return callback(null, { "status": "Downloading", "downlaodKey": fileName });
    } catch (e) {
        console.log(e);
        return baseResponse.getResponseObject(event, false, HTTP_CODE.BADeventUEST, [], "Error while downloading zip: " + e.message);
    }
};