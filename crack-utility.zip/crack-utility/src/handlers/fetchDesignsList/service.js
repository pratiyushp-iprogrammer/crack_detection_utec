const mongoDatabase = require('../../common/database');
let objDatabase = new mongoDatabase();
if (typeof client === 'undefined') var client = objDatabase.connect();
const PlanDesign = require('../../models/planStyleDesigns');
const GalleryDesigns = require('../../models/designGalleryBookmark');
const S3BaseURL = process.env.S3_BUCKET_PATH ? `${process.env.S3_BUCKET_PATH}/` : 'https://assets-dm.utecbuild.com/';

class GetDesigns {

    async fetchAllDesigns(requestBody) {
        try {
            let responseObj = {
                data: [],
                count: 0,
                s3BasePath: S3BaseURL
            }

            if (requestBody.flag === "savedList") {

                console.log(JSON.stringify({ file: 'service.js', line: 19, params: requestBody }));

                const result = await GalleryDesigns.aggregate([{
                    "$match": {

                        "userId": requestBody?.userId,
                        "isBookmark": 1
                    }
                },
                {
                    "$lookup": {
                        "from": "plan_style_designs",
                        "localField": "designId",
                        "foreignField": "unique_id",
                        "as": "data"
                    }
                },
                {
                    "$unwind": "$data"
                },
                {
                    "$project": {
                        image3D: { "$ifNull": ["$data.files.three_d_design_id", ""] },
                        image2D: { "$ifNull": ["$data.files.two_d_rendered_plan_jpg", ""] },
                        unique_id: "$data.unique_id",
                        built_up_area: { "$ifNull": ["$data.project_details.builtup_area", ""] },
                        plot_area: { "$ifNull": ["$data.plot_details.plot_area", ""] },
                        unique_id: { "$ifNull": ["$data.unique_id", ""] },
                        no_of_floors: { "$ifNull": ["$data.project_details.no_floors", ""] },
                        floors: { "$ifNull": ["$data.project_details.floors", ""] },
                        house_entrance: { "$ifNull": ["$data.vaastu_compliancy.entry_direction", ""] },
                        no_of_rooms: { "$ifNull": ["$data.project_details.bedrooms", 0] },
                        isFav: { $cond: { if: { $and: [{ $eq: ['$isBookmark', 1] }, { $eq: ['$userId', requestBody?.userId] }] }, then: true, else: false } }
                    }
                }])
                console.log(JSON.stringify(result));
                if (result.length === 0) {
                    return responseObj
                }
                else {
                    responseObj = {
                        data: result,
                        count: result.length,
                        s3BasePath: S3BaseURL
                    }
                }
                return responseObj
            }
            if (requestBody.flag === "list") {
                let data = requestBody;
                console.log(JSON.stringify({ file: 'service.js', line: 64, params: data }));

                let sortCondition = requestBody?.sortBy;
                let columns = sortCondition?.columnName ? sortCondition?.columnName : "unique_id";
                let orderBy = sortCondition.sort && sortCondition.sort === "desc" ? -1 : sortCondition.sort === "asc" ? 1 : 1;
                let searchString = requestBody.searchValue ? requestBody.searchValue : ""
                //sort condition 
                let sort
                if (columns === "unique_id") {
                    sort = {
                        $sort: {
                            "unique_id": orderBy
                        }
                    }
                }
                else if (columns === "plot_area") {
                    sort = {
                        $sort: {
                            "plot_details.plot_area": orderBy
                        }
                    }
                }
                // if condition to get bookmark flag true and false 
                let ifCondition = []
                if (data?.userId) {
                    ifCondition.push({ isFav: { $cond: { if: { $and: [{ $eq: ['$favInfo.isBookmark', 1] }, { $eq: ['$favInfo.userId', data.userId] }] }, then: true, else: false } } })
                }
                else {
                    ifCondition.push({ isFav: "false"})
                }
                //project the data object response keys and values
                let project = {
                    $project: {
                        built_up_area: { "$ifNull": ["$project_details.builtup_area", ""] },
                        plot_area: "$plot_details.plot_area",
                        no_of_rooms: "$project_details.bedrooms",
                        house_entrance: "$vaastu_compliancy.entry_direction",
                        plot_width:"$plot_details.plot_width",
                        no_of_floors: "$project_details.no_floors",
                        floors: { "$ifNull": ["project_details.floors", ""] },
                        image2D: {
                            $cond: {
                                if: {
                                    $ne: [
                                        "$files.two_d_rendered_plan_jpg",
                                        null
                                    ]
                                },
                                then: "$files.two_d_rendered_plan_jpg",
                                else: ""
                            }
                        },
                        image3D: {
                            $cond: {
                                if: {
                                    $ne: [
                                        "$files.three_d_design_id",
                                        null
                                    ]
                                },
                                then: "$files.three_d_design_id",
                                else: ""
                            }
                        },
                        "isfav": { ...ifCondition[0].isFav },
                        element_type: 1,
                        unique_id: 1
                    }
                }

                let aggregationPipeline = []
                if(data?.userId){
                    aggregationPipeline.push({
                        $lookup: {
                            from: 'design_gallery_bookmarks',
                            localField: 'unique_id',
                            foreignField: 'designId',
                            as: 'favInfo'
                        }
                    },
                    // Unwind to destructure the favInfo array
                    {
                        $unwind: {
                            path: '$favInfo',
                            preserveNullAndEmptyArrays: true // Preserve styles even if no favourites match
                        }
                    })    
                }
                aggregationPipeline.push(
                    {
                        $match: {
                            element_type: data.elementType,
                            is_active: 1,
                            is_approved:1
                        }
                    },)

                //add filter iif present
                if (data.filters) {
                    let dynamicMatchStages = buildMatchStages(data.filters);
                    aggregationPipeline.push(...dynamicMatchStages)
                }

                //add if string if present
                if (searchString) {
                    aggregationPipeline.push({
                        $match: {
                            $or: [
                                { unique_id: JSON.parse(data.searchValue) },
                                // { "plot_details.plot_area": JSON.parse(data.searchValue) },
                                // { "project_details.bedrooms": JSON.parse(data.searchValue) },
                                // { "project_details.no_floors": JSON.parse(data.searchValue) }
                            ]
                        }
                    })
                }
                aggregationPipeline.push({ $count: 'totalCount' })
                console.log(JSON.stringify({ file: 'service.js', line: 187, countQuery: aggregationPipeline }));
                const countResult = await PlanDesign.aggregate(aggregationPipeline).allowDiskUse(true).exec();
                aggregationPipeline.pop()
                //shuffle by size 
                aggregationPipeline.push({ $sample: { size: requestBody.pagination.fetchLimit } })
                aggregationPipeline.push(sort)
                aggregationPipeline.push(project)

                console.log(JSON.stringify({ file: 'service.js', line: 191, mongQuery:aggregationPipeline }));
                
                const result = await PlanDesign.aggregate(aggregationPipeline).allowDiskUse(true).exec();

                // console.log(JSON.stringify(result));
                if (result.length > 0) {
                    responseObj = {
                        data: result,
                        count: countResult,
                        s3BasePath: S3BaseURL
                    }
                    return responseObj
                }
                else {
                    return responseObj
                }
            }


            function buildMatchStages(filters) {
                const matchStages = [];
                // Build $match stage for plotArea
                if (filters.plotArea && filters.plotArea.length > 0) {
                    const plotAreaMatch = {
                        $or: filters.plotArea.map(area => ({
                            "plot_details.plot_area": {
                                $gte: area.min,
                                $lte: area.max
                            }
                        }))
                    };
                    matchStages.push({ $match: plotAreaMatch });
                }

                // Build $match stage for noOfBedrooms
                if (filters.noOfBedrooms && filters.noOfBedrooms.length > 0) {
                    const bedroomsMatch = {
                        $or: filters.noOfBedrooms.map(bedrooms => ({
                            "project_details.bedrooms": bedrooms
                        }))
                    };
                    matchStages.push({ $match: bedroomsMatch });
                }

                // Build $match stage for noOfFloors
                if (filters.noOfFloors && filters.noOfFloors.length > 0) {
                    const floorsMatch = {
                        $or: filters.noOfFloors.map(floors => ({
                            "project_details.no_floors": floors
                        }))
                    };
                    matchStages.push({ $match: floorsMatch });
                }

                // Build $match stage for houseOfEntrance
                if (filters.houseOfEntrance && filters.houseOfEntrance.length > 0) {
                    const entranceMatch = {
                        $or: filters.houseOfEntrance.map(direction => ({
                            "vaastu_compliancy.entry_direction": direction
                        }))
                    };
                    matchStages.push({ $match: entranceMatch });
                }
                if (filters.plotWidth && filters.plotWidth.length > 0) {
                    const entranceMatch = {
                        $or: filters.plotWidth.map(width => ({
                            "plot_details.plot_width": {
                                $gte: width.min,
                                $lte: width.max
                            }
                        }))
                    };
                    matchStages.push({ $match: entranceMatch });
                }
                let yourArray = filters?.state ? filters?.state : []
                if (yourArray && yourArray.length > 0) {
                    yourArray= yourArray.toString().toUpperCase().split(",");
                    console.log("upperCasedArray", JSON.stringify(yourArray))
                    const stateMatch = {
                        $or: yourArray.map(states => ({
                            "geography.state": states
                        }))
                    };
                    matchStages.push({ $match: stateMatch });
                }
                return matchStages;
            }
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 144, message: error?.message, error }));
            throw error;
        }
    }
}


module.exports = GetDesigns;