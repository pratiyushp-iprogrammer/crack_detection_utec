const BaseResponse = require('../../common/baseResponse');
const HTTP_CODE = require('../../common/constants');
const {schema,schemaV2} = require('./schema');
const GetDesigns = require('./service');
const service = new GetDesigns();
let baseResponse = new BaseResponse();

exports.handler = async (event) => {
    try {
        let email = ""
        let userId = 0
        if (event.resource === "/v1/fetch-designs-list" || event.resource === "/v1/fetch-designs-saved-list") {
            if (event.requestContext.authorizer) {
                let authorizerResponse = JSON.parse(event.requestContext.authorizer.principalId);
                email = authorizerResponse.email;
                userId = authorizerResponse.userId
            }
        }
        console.log(JSON.stringify({ file: 'index.js', line: 19, events:event }));
        
        const requestBody = typeof event?.body === 'string' ? JSON.parse(event.body) : event?.body || {};
        console.log(JSON.stringify({ file: 'controller.js', line: 10, requestBody }));
        if (event.resource === "/v1/fetch-designs-saved-list") {
            
            const isRequestValid = schemaV2.validate(requestBody);
            if (isRequestValid?.error) {
                console.log(JSON.stringify({ file: 'service.js', comment: "Validation Error ", line: 14, isRequestValid: isRequestValid }));
                return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, isRequestValid?.error?.details, "Invalid Request");
            }
            requestBody.userId = Number(userId)
            console.log(JSON.stringify({ file: 'index.js', line: 44, params:requestBody }));
            const designResult = await service.fetchAllDesigns(requestBody);
            console.log(JSON.stringify({ file: 'controller.js', line: 18, designResult }));
            if (designResult) {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, designResult, 'Designs Fetched Successfully.');
            } else {
                return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Error in to featched design');
            }
        }
        const isRequestValid = schema.validate(requestBody);
        if (isRequestValid?.error) {
            console.log(JSON.stringify({ file: 'service.js', comment: "Validation Error ", line: 14, isRequestValid: isRequestValid }));
            return baseResponse.getResponseObject(event, true, HTTP_CODE.BAD_REQUEST, isRequestValid?.error?.details, "Invalid Request");
        }
        requestBody.userId = Number(userId)
        console.log(JSON.stringify({ file: 'index.js', line: 44, params:requestBody }));
        
        const designResult = await service.fetchAllDesigns(requestBody);
        console.log(JSON.stringify({ file: 'controller.js', line: 18, designResult }));
        if (designResult) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, designResult, 'Designs Fetched Successfully.');
        } else {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Error in to featched design');
        }

    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 26, message: error?.message, error }));
        return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], error);
    }
};