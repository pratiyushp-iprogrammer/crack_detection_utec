const Joi = require("joi");

const schema = Joi.object().keys({
    flag:Joi.string().valid("list").required(),
    elementType:Joi.string().required(),
    pagination: Joi.object().keys({
        fetchLimit: Joi.number().required(),
        page: Joi.number().optional()
    }).required(),
    searchValue:Joi.string().allow("").optional().allow(""),
    sortBy:Joi.object().keys({
        columnName:Joi.string().valid("unique_id","plot_area").required(),
        sort:Joi.string().required()
    }).required(),

    filters: Joi.object().keys({
        plotArea:Joi.array().items(Joi.object().keys({
            min:Joi.number().optional().allow(""),
            max:Joi.number().optional().allow("")
        })).optional().allow(""),
        noOfFloors:Joi.array().items(Joi.number().optional()).optional().allow(""),
        noOfBedrooms:Joi.array().items(Joi.number().optional()).optional().allow(""),
        houseOfEntrance:Joi.array().items(Joi.string().optional()).optional().allow(""),
        state:Joi.array().items(Joi.string().optional()).optional().allow(""),
        plotWidth:Joi.array().items(Joi.object().keys({
            min:Joi.number().optional().allow(""),
            max:Joi.number().optional().allow("")
        })).optional().allow("")
            }).required().allow({})
    
});

const schemaV2 = Joi.object().keys({
    flag:Joi.string().valid("savedList").required(),    
});
module.exports = {schema,schemaV2};