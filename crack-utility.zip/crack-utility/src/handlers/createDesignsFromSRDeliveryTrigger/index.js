const BaseResponse = require('../../common/baseResponse');
const HTTP_CODE = require('../../common/constants');
const CreateDesignsFromSRDelivery = require('./service');
const service = new CreateDesignsFromSRDelivery();
let baseResponse = new BaseResponse();

exports.handler = async (event) => {
    try {
        const sqsResult = await service.triggerSQS(event);
        console.log(JSON.stringify({ file: 'controller.js', line: 120, sqsResult }));
        if (sqsResult) {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Created design from SR delivery successfully.');
        } else {
            return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Error in create design from SR delivery trigger');
        }
    } catch (error) {
        console.log(JSON.stringify({ file: 'index.js', line: 22, message: error?.message , error }));
        // return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], error);
        return baseResponse.getResponseObject(event, true, HTTP_CODE.SUCCESS, [], 'Error in create design from SR delivery trigger');
    }
};