const { SendMessageCommand, SQSClient } = require("@aws-sdk/client-sqs");
const sqsClient = new SQSClient({ region: process.env.AWS_REGION_NAME });
const SQS_QUEUE_URL = process.env.SQS_QUEUE_URL;

class CreateDesignsFromSRDelivery {

    sqsPromise(params) {
        return new Promise((resolve, reject) => {
            sqs.sendMessage(params, (err, data) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        });
    }

    async triggerSQS(data) {
        try {
            const params = {
                MessageBody: JSON.stringify(data),
                QueueUrl: SQS_QUEUE_URL
            };
            const command = new SendMessageCommand(params);
            const result = await sqsClient.send(command); 
            console.log(JSON.stringify({ file: 'service.js', line: 25, result }));
            return result;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 28, message: error.message, error }));
            throw error;
        }
    }
}


module.exports = CreateDesignsFromSRDelivery;