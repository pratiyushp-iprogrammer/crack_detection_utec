DELIMITER $$
DROP TRIGGER IF EXISTS after_update_trigger_for_service_request_details$$
CREATE TRIGGER `after_update_trigger_for_service_request_details` AFTER UPDATE ON `service_request_details` FOR EACH ROW BEGIN
        
    DECLARE isSrSubmittedBefore int;
    DECLARE isSrSubmittedAfter int;
    DECLARE currentUser varchar(30);
    DECLARE srTypeId, linkedId, requestStatus BIGINT DEFAULT NULL;
    DECLARE skuType VARCHAR(100) DEFAULT NULL;
    select CURRENT_USER() into currentUser;
    -- select request_type_id INTO srTypeId from service_requests where id = OLD.service_requests_id;
   
    SELECT sr.request_type_id, sr.sku_type, sr.linked_id, sr.request_status INTO srTypeId, skuType, linkedId, requestStatus FROM service_requests AS sr WHERE sr.id = OLD.service_requests_id;
    
    IF currentUser <> 'utec_admin@%' THEN

        SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:service-requests-dev-ServiceRequestHistoryLogger", JSON_OBJECT("action", "update","old", JSON_OBJECT(
        "id", OLD.service_requests_id,
        "request_type_id", srTypeId,
        "case_info", OLD.case_info,
        "data", OLD.data,
        "sr_info", OLD.sr_info,
        "delivery", OLD.delivery,
        "communication_delivery", OLD.communication_delivery,
        "platform_id", OLD.platform_id,
        "raised_by_type", OLD.raised_by_type,
        "site_report_details", OLD.site_report_details, -- new
        "quotation_details", OLD.quotation_details, -- new
        "invoice_and_warranty", OLD.invoice_and_warranty, -- new
        "site_visit_details", OLD.site_visit_details, -- new
        "is_deleted", OLD.is_deleted,
        "created_by", OLD.created_by,
        "updated_by", OLD.updated_by,
        "created_at", OLD.created_at,
        "updated_at", OLD.updated_at
        ), "new", JSON_OBJECT(
        "id", NEW.service_requests_id,
        "request_type_id", srTypeId,
        "case_info", NEW.case_info,
        "data", NEW.data,
        "sr_info", NEW.sr_info,
        "delivery", NEW.delivery,
        "communication_delivery", NEW.communication_delivery,
        "platform_id", NEW.platform_id,
        "raised_by_type", NEW.raised_by_type,
        "site_report_details", NEW.site_report_details, -- new
        "quotation_details", NEW.quotation_details, -- new
        "invoice_and_warranty", NEW.invoice_and_warranty, -- new
        "site_visit_details", NEW.site_visit_details, -- new
        "is_deleted", NEW.is_deleted,
        "created_by", NEW.created_by,
        "updated_by", NEW.updated_by,
        "created_at", NEW.created_at,
        "updated_at", NEW.updated_at
        ))) INTO @response;

        
        SELECT IF(JSON_EXTRACT(OLD.sr_info, '$.isSrSubmitted') IS NULL OR JSON_EXTRACT(OLD.sr_info, '$.isSrSubmitted') like '%null%', 0, cast(JSON_EXTRACT(OLD.sr_info, '$.isSrSubmitted') AS signed)) into isSrSubmittedBefore FROM service_request_details where service_requests_id = OLD.service_requests_id;

        SELECT IF(JSON_EXTRACT(NEW.sr_info, '$.isSrSubmitted') IS NULL OR JSON_EXTRACT(NEW.sr_info, '$.isSrSubmitted') like '%null%', 0, cast(JSON_EXTRACT(NEW.sr_info, '$.isSrSubmitted') AS signed)) into isSrSubmittedAfter FROM service_request_details where service_requests_id = NEW.service_requests_id;
    
        IF isSrSubmittedBefore <> isSrSubmittedAfter AND isSrSubmittedAfter = 1 THEN
        SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:sr-tracker-test-RewardCalculation",  
                JSON_OBJECT(
                    "serviceId", NEW.service_requests_id,
                    "mainModule", "SR Tracker",
                    "subModule", "SR Info",
                    "updatedBy",  NEW.raised_by_type,
                    "isDataCollection", 1,
                    "flag", 1
                )
            )INTO @rewardConfigTrigger;
        END IF;
    END IF;

    IF srTypeId IS NOT NULL AND srTypeId IN (18, 19) AND (NOT(OLD.sr_info <=> NEW.sr_info)) THEN
        SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:utec-design-mgmt-dev-createDesignsFromSRDeliveryTrigger",  
            JSON_OBJECT(
                "SRId", NEW.service_requests_id,
                "request_type_id", srTypeId,
                "request_status", requestStatus,
                "sku_type", skuType,
                "linked_id", linkedId,
                "created_by", NEW.created_by,
                "updated_by", NEW.updated_by,
                "source", "updateDCFlow"
            )
        ) INTO @createDesignsFromSRDeliveryTrigger;
    END IF;

END$$
DELIMITER ;