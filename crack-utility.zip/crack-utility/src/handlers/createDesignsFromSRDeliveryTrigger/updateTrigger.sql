DELIMITER $$
-- DROP TRIGGER IF EXISTS after_update_trigger_for_service_requests$$
CREATE TRIGGER `after_update_trigger_for_service_requests` AFTER UPDATE ON `service_requests` FOR EACH ROW BEGIN
    IF OLD.request_status <> NEW.request_status OR OLD.pending_reason <> NEW.pending_reason OR OLD.payment_status <> NEW.payment_status THEN
		SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:utec-microservices-stage-ccpCallConfigTrigger",  
			JSON_OBJECT(
				"serviceId", NEW.id,
				"userId", NEW.user_id,
				"request_type_id", NEW.request_type_id,
				"request_status", NEW.request_status,
				"mainModule", "SR Tracker",
				"subModule", "Case Info",
				"triggerType", "Request Status",
				"updatedBy",  NEW.raised_by_type,
				"sourceOfRequest", NEW.source_of_request,
				"pendingReason", NEW.pending_reason,
				"paymentStatus", NEW.payment_status,
				"preferredCallerNumber", NEW.preferred_caller_number
			)
		) INTO @callConfigTrigger;
    END IF;
    SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:service-requests-stage-ServiceRequestHistoryLogger", JSON_OBJECT("action", "update","old", JSON_OBJECT(
        "id", OLD.id,
        "user_id", OLD.user_id,
        "request_type_id", OLD.request_type_id,
        "partner_id", OLD.partner_id,
        "pincode_id", OLD.pincode_id,
        "site_id", OLD.site_id,
        "vendor_id", OLD.vendor_id,
        "vendor_name", OLD.vendor_name,
        "assigned_team", OLD.assigned_team,
        "request_owner_name", OLD.request_owner_name,
        "request_owner_id", OLD.request_owner_id,
        "request_status", OLD.request_status,
        "cancellation_reason", OLD.cancellation_reason,
        "pending_reason", OLD.pending_reason,
        "request_status_last_updated_on", OLD.request_status_last_updated_on,
        "estimated_delivery_date", OLD.estimated_delivery_date,
        "actual_delivery_date", OLD.actual_delivery_date,
        "sku_type", OLD.sku_type,
        "linked_id", OLD.linked_id,
        "add_ons", OLD.add_ons,
        "net_amount", OLD.net_amount,
        "payment_status", OLD.payment_status,
        "source_of_request", OLD.source_of_request,
        "platform_id", OLD.platform_id,
        "is_service_referred", OLD.is_service_referred,
        "raised_by_type", OLD.raised_by_type,
        "is_deleted", OLD.is_deleted,
        "created_by", OLD.created_by,
        "updated_by", OLD.updated_by,
        "created_at", OLD.created_at,
        "updated_at", OLD.updated_at,
        "preferred_caller_number", OLD.preferred_caller_number,
    "preferred_caller_name", OLD.preferred_caller_name,
    "estimated_delivery_date_partner", OLD.estimated_delivery_date_partner
    ), "new", JSON_OBJECT(
        "id", NEW.id,
        "user_id", NEW.user_id,
        "request_type_id", NEW.request_type_id,
        "partner_id", NEW.partner_id,
        "pincode_id", NEW.pincode_id,
        "site_id", NEW.site_id,
        "vendor_id", NEW.vendor_id,
        "vendor_name", NEW.vendor_name,
        "assigned_team", NEW.assigned_team,
        "request_owner_name", NEW.request_owner_name,
        "request_owner_id", NEW.request_owner_id,
        "request_status", NEW.request_status,
        "cancellation_reason", NEW.cancellation_reason,
        "pending_reason", NEW.pending_reason,
        "request_status_last_updated_on", NEW.request_status_last_updated_on,
        "estimated_delivery_date", NEW.estimated_delivery_date,
        "actual_delivery_date", NEW.actual_delivery_date,
        "sku_type", NEW.sku_type,
        "linked_id", NEW.linked_id,
        "add_ons", NEW.add_ons,
        "net_amount", NEW.net_amount,
        "payment_status", NEW.payment_status,
        "source_of_request", NEW.source_of_request,
        "platform_id", NEW.platform_id,
        "is_service_referred", NEW.is_service_referred,
        "raised_by_type", NEW.raised_by_type,
        "is_deleted", NEW.is_deleted,
        "created_by", NEW.created_by,
        "updated_by", NEW.updated_by,
        "created_at", NEW.created_at,
        "updated_at", NEW.updated_at,
        "preferred_caller_number", NEW.preferred_caller_number,
    "preferred_caller_name", NEW.preferred_caller_name,
    "estimated_delivery_date_partner", NEW.estimated_delivery_date_partner
    ))) INTO @response;

    IF OLD.request_status <> NEW.request_status AND NEW.request_type_id IN (18, 19) AND NEW.request_status IN (8, 30) THEN 
        SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:utec-design-management-createDesignsFromSRDeliveryTrigger",  
            JSON_OBJECT(
                "SRId", NEW.id,
                "request_type_id", NEW.request_type_id,
                "request_status", NEW.request_status,
                "sku_type", NEW.sku_type,
                "linked_id", NEW.linked_id,
                "created_by", NEW.created_by,
                "updated_by", NEW.updated_by,
                "source", "designDelivered"
            )
        ) INTO @createDesignsFromSRDeliveryTrigger;
    END IF;


IF OLD.request_status <> NEW.request_status AND NEW.request_status = 35 THEN
    SELECT lambda_async("arn:aws:lambda:ap-south-1:950344958975:function:utec-design-management-getRelevanceDesigns",  
	JSON_OBJECT( "body",
	    JSON_OBJECT(
	            "srId", NEW.id,
	            "srTypeId", NEW.request_type_id,
	            "action", "init",
	            "fetchLimit", 6
	    )
	)
    ) INTO @getRelevanceDesigns;
END IF; 	
END$$
DELIMITER ;