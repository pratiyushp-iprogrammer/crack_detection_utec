const jwt = require('jsonwebtoken');
const decodeAlgorithm = 'RS256';

let jwkToPem = require('jwk-to-pem');

const redis = require('../common/redis/redis-connection');
const DBConnector = require('../common/dbConnector');
const dbConnector = new DBConnector();

const originListing = require('../common/utils/originList.json');
const { checkAccessManagementPermission } = require('./accessManagementService');
const deployment = ["master", "prod", "production"].includes(process.env.DEPLOYMENT) ? "prod" : process.env.DEPLOYMENT;
const path = require('path');
const dirPath = path.join(__dirname, `../config/${deployment}/APP_USER_COGNITO_CONFIG_KEY.txt`);
const APP_USER_COGNITO_CONFIG_KEY = require("fs").readFileSync(dirPath, 'utf8');

const validateOrigin = (event) => {
    let origin = event?.headers?.origin || event?.headers?.Origin;
    let domain = origin || "null";
    // let domain = event?.headers?.origin ? event.headers.origin : "null";
    // let originList = process.env.ORIGINLIST;
    let originList = originListing?.validDomains || "";
    const isInList = originList.split(",").find(element => element == domain);
    console.log(JSON.stringify({ file: 'helper.js', line: 227, domain, isInList }));
    if (!isInList) {
        domain = "null";
    }
    return domain;
};

exports.authorizerHandler = async (event, context, callback) => {
    console.log("inside auth function")
    // policy object structure - modify the required values to return the updated policy
    let policy = {
        "principalId": "yyyyyyyy",
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [{
                "Action": "execute-api:Invoke",
                "Effect": "Allow",
                "Resource": "arn:aws:execute-api:{regionId}:{accountId}:{apiId}/{stage}/{httpVerb}/[{resource}/[{child-resources}]]"
            }]
        }
    };

    let custom_headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Headers": "*",
        "Access-Control-Allow-Origin": "null",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
        "Access-Control-Allow-Credentials": true
    };
    let platform = event?.headers?.platform;
    if(!platform){
        platform = 0;
        console.log(JSON.stringify({ file: 'Authorizer.js', line: 50, message:"platform not passed in headers" }));
    }
    console.log(JSON.stringify({ file: 'authorizer.js', line: 53, platform }));


    try {
        console.log("Authorizer Event: ", JSON.stringify(event));
        let endPoint = event?.path;
        let moduleId = event?.headers?.moduleid || event?.headers?.moduleId;
        console.log("moduleId ", moduleId);
        let origin = validateOrigin(event);
        custom_headers["Access-Control-Allow-Origin"] = origin;
        let apiMethod = event?.httpMethod;
        let payload = jwt.decode(event.headers.authorization || event.headers.Authorization, { complete: true })?.payload;
        if(payload){

            payload.isAdmin = payload?.isAdmin == "false" ? false : payload?.isAdmin;
            payload.userId =  payload?.userId > 0 ? parseInt(payload?.userId) : undefined ;
            payload.platformId = payload?.platformId >= 0 ? parseInt(payload?.platformId) : 0 ; 
        }
        let isAdmin = payload?.isAdmin;
        let email = payload?.email;

        console.log("platformId :", payload?.platformId ? payload.platformId : null, "path :", event?.path);
        
        if (!isAdmin) {
            console.log("No admin user found");
        } else if(isAdmin && (moduleId == 22 || moduleId == 58)) {
            console.log("SR TRACKER ACCESS Will be checked");
        } else {
            if(process.env.DEPLOYMENT !== 'dev'){
            let endPointArray = endPoint.split("/");
            if (endPoint.includes("?")) {
                endPointArray = endPoint.split("?");
                endPoint = endPointArray[0];
            } else if (endPointArray.length > 4 && endPointArray[4] != '' && !isNaN(endPointArray[4])) {
                endPoint = `/${endPointArray[1]}/${endPointArray[2]}/${endPointArray[3]}`;
            } else if (endPointArray.length > 3 && endPointArray[3] != '' && !isNaN(endPointArray[3])) {
                endPoint = `/${endPointArray[1]}/${endPointArray[2]}`;
            } else {
                endPoint = endPoint;
            }

            let redisCacheKey = `authorizer_permissions_${email}`;
            console.log("redisCacheKey", redisCacheKey);

            // Call to redisCacheGet
            let redisResult = await redis.redisCacheGet(redisCacheKey);
            let cachedResult;
            console.log("redisResult", redisResult);
            if (!redisResult) {
                // Get All ModuleIds to store in Redis
                // let query = `select group_concat(rap.module_id) AS moduleId from admin_user_details aud INNER JOIN admin_workgroup_roles awr ON awr.workgroup_id = aud.workgroup_id INNER JOIN role_access_permissions rap ON rap.workgroup_role_id = awr.id where aud.email = ? and rap.is_deleted = 0;`;
                let query = `select group_concat(rap.module_id) AS moduleId from admin_user_details aud INNER JOIN role_access_permissions rap ON rap.workgroup_role_id = aud.workgroup_roles_id where aud.email = ? and rap.is_deleted = 0;`;
                var moduleIdsResult = await dbConnector.queryExecute(query, [email]);
                console.log("moduleIdsResult: ", moduleIdsResult);
                let accessManagemtModuleId = await checkAccessManagementPermission(email);
                console.log(JSON.stringify({ file: 'authorizer.js', line: 77, accessManagemtModuleId }));

                if (!moduleIdsResult[0]?.moduleId) {
                    policy.principalId = "Unauthorized";
                    policy.policyDocument.Statement[0].Effect = 'Deny';
                    policy.policyDocument.Statement[0].Resource = event.methodArn;
                    policy.context = custom_headers;
                    console.log(policy);
                    context.succeed(policy);
                    return false;
                } else {
                    // Set moduleIds in redis cache
                    let finalModules;
                    console.info(JSON.stringify({ file: 'authorizer.js', line:91, length: accessManagemtModuleId[0]?.module_id.length}));
                    if (accessManagemtModuleId[0]?.module_id?.length > 0) {
                    console.info(JSON.stringify({ file: 'authorizer.js', line: 93, moduleIdsResult: moduleIdsResult }));

                        finalModules = moduleIdsResult[0]?.moduleId + "," + accessManagemtModuleId[0]?.module_id.join(',');
                    }else{
                        finalModules = moduleIdsResult[0]?.moduleId;
                    }

                    const redisCacheSetResult = await redis.redisCacheSet(redisCacheKey, JSON.stringify(finalModules));
                    console.log("redisCacheSetResult: ", redisCacheSetResult);

                    // Get Redis result except DB call to get recently cached data
                    // redisResult = await redis.redisCacheGet(redisCacheKey);
                    cachedResult = finalModules || "\"\"";
                    console.log("redisResult In Else: ", cachedResult);
                }
            } else {
                cachedResult = JSON.parse(redisResult) || "";
            }
            console.log("cachedResult: ", cachedResult);
            const modulePermissionCheck = cachedResult?.split(",")?.includes(`${moduleId}`);
            console.log("modulePermissionCheck", modulePermissionCheck);
            if (!modulePermissionCheck) {
                policy.principalId = "Unauthorized";
                policy.policyDocument.Statement[0].Effect = 'Deny';
                policy.policyDocument.Statement[0].Resource = event.methodArn;
                policy.context = custom_headers;
                console.log(policy);
                context.succeed(policy);
                return false;
            } else {
                let checkEndpointAccessQuery = `select id from api_module_master amm WHERE (amm.module_id = ? or amm.submodule_id = ?) and amm.api_master_id = ( select id from api_master am WHERE am.api_endpoint LIKE "${endPoint}" and (am.method = '${apiMethod}' OR am.method = '') and am.is_deleted = 0) and amm.is_deleted = 0;`;
                let checkEndpointAccessParams = [moduleId, moduleId];

                const checkEndpointAccessResult = await dbConnector.queryExecute(checkEndpointAccessQuery, checkEndpointAccessParams);
                if (!checkEndpointAccessResult[0]?.id) {
                    policy.principalId = "Unauthorized";
                    policy.policyDocument.Statement[0].Effect = 'Deny';
                    policy.policyDocument.Statement[0].Resource = event.methodArn;
                    policy.context = custom_headers;
                    console.log(policy);
                    context.succeed(policy);
                    return false;
                }
            }
         }
        }
    } catch (err) {
        console.log("Check AdminPermission Block: ", err);
        policy.principalId = "Unauthorized";
        policy.policyDocument.Statement[0].Effect = 'Deny';
        policy.policyDocument.Statement[0].Resource = event.methodArn;
        policy.context = custom_headers;
        console.log(policy);
        context.succeed(policy);
        return false;
    }

    const skipAuthRoutes = [
        "/v1/get-auth-token",
        "/v1/styles/downloadStylesIdeaPDF",
        "/v1/plans/downloadPlansIdeaPDF",
        "/v1/downloadDesignIdeaPDF",
        "/v1/plans/getHomeDesigns"
    ];

    if (skipAuthRoutes.some(e => event.methodArn.includes(e))) {
        let decode = event?.body || {};
        decode.platformId = (decode.platformId == 0 ? platform : decode.platformId) || platform;
        policy.principalId = JSON.stringify(decode);
        policy.policyDocument.Statement[0].Resource = event.methodArn;
        console.log(policy);
        context.succeed(policy);
        return true;
    }

    try {
        let decodedToken = jwt.decode(event.headers.authorization || event.headers.Authorization, { complete: true });
        console.log(decodedToken);
        let tokenHeader = decodedToken.header;
        decodedToken.payload.isAdmin = decodedToken?.payload?.isAdmin == "false" ? false : decodedToken?.payload?.isAdmin;
        decodedToken.payload.userId =  decodedToken.payload?.userId > 0 ? parseInt(decodedToken.payload?.userId) : undefined ;
        decodedToken.payload.platformId = decodedToken.payload?.platformId >= 0 ? parseInt(decodedToken.payload?.platformId) : 0 ; 
        let isAdmin = decodedToken?.payload?.isAdmin;
        let COGNITO_CONFIG_KEY = isAdmin? process.env.COGNITO_CONFIG_KEY : APP_USER_COGNITO_CONFIG_KEY;
        console.log("typeof(COGNITO_CONFIG_KEY):", typeof(COGNITO_CONFIG_KEY));
        console.log("COGNITO_CONFIG_KEY:", COGNITO_CONFIG_KEY);
        // console.log("cognito key", JSON.stringify(COGNITO_CONFIG_KEY))
        let cognitoConfig = JSON.parse(COGNITO_CONFIG_KEY);

        const token = event.headers.authorization || event.headers.Authorization;

        console.log("token", token)


        // check if token header contains kid
        if ('kid' in tokenHeader && tokenHeader.kid) {
            // if the above condition is true,
            // i.e. if token header contains kid,
            // it's an admin token and has to be verified with cognito
            console.log("tokenHeader.kid", tokenHeader.kid);

            if (cognitoConfig) {
                let verifyOptions = {
                    expiresIn: "1d",
                    algorithm: ["RS256"]
                };

                let cognitoPublicKey = jwkToPem(
                    cognitoConfig.keys.filter(item => {
                        console.log(item.kid, "-", tokenHeader.kid);
                        return item.kid === tokenHeader.kid;
                    })[0]
                );

                return jwt.verify(token, cognitoPublicKey, verifyOptions, function (jwtErr, jwtData) {
                    console.log("jwtErr", jwtErr);
                    console.log("jwtData", jwtData);
                    if (jwtData) {
                        jwtData.platformId = (jwtData.platformId == 0 ? platform : jwtData.platformId) || platform;
                        jwtData.isAdmin = jwtData.isAdmin == "false" ? false : jwtData.isAdmin;
                        jwtData.userId =  jwtData?.userId > 0 ? parseInt(jwtData?.userId) : undefined ;
                        jwtData.platformId = jwtData?.platformId >= 0 ? parseInt(jwtData?.platformId) : 0 ; 
                        policy.principalId = JSON.stringify(jwtData);
                        policy.policyDocument.Statement[0].Resource = event.methodArn;
                        context.succeed(policy);
                        return true;
                    } else {
                        policy.principalId = JSON.stringify(jwtErr);
                        policy.policyDocument.Statement[0].Effect = 'Deny';
                        policy.policyDocument.Statement[0].Resource = event.methodArn;
                        policy.context = custom_headers;
                        // To send 401(Unauthorized) status for Expired token, added below line
                        context.fail("Unauthorized");
                        // context.succeed(policy);
                        return false;
                    }
                });
            } else {
                console.log(`Invalid or blank cognitoconfig`);
                throw (`Invalid or blank cognitoconfig`);
            }
        } else {
            console.log("Frontend token");
            // Else, it is a customer app/website token, verify it with jwt
            let seckey = process.env.JWT_PUB_KEY.replace(/\\n/g, '\n');
            seckey = `-----BEGIN PUBLIC KEY-----\n${seckey}\n-----END PUBLIC KEY-----\n`;
            jwt.verify(token, seckey, { algorithm: [decodeAlgorithm] }, function (error, payload) {
                if (error) {
                    console.log(error);
                    policy.principalId = "Invalid Token";
                    policy.policyDocument.Statement[0].Effect = 'Deny';
                    policy.policyDocument.Statement[0].Resource = event.methodArn;
                    policy.context = custom_headers;
                    // To send 401(Unauthorized) status for Expired token, added below line
                    context.fail("Unauthorized");
                    // context.succeed(policy);
                    return false; 
                } else {
                    payload.platformId = (payload.platformId == 0 ? platform : payload.platformId) || platform;
                    payload.isAdmin = payload.isAdmin == "false" ? false : payload.isAdmin;
                    payload.userId =  payload?.userId > 0 ? parseInt(payload?.userId) : undefined ;
                    payload.platformId = payload?.platformId >= 0 ? parseInt(payload?.platformId) : 0 ; 
                    policy.principalId = JSON.stringify(payload);
                    policy.policyDocument.Statement[0].Resource = event.methodArn;
                    context.succeed(policy);
                    return true; 
                }
            });

        }
    } catch (err) {
        console.log(err);
        policy.principalId = "Unauthorized";
        policy.policyDocument.Statement[0].Effect = 'Deny';
        policy.policyDocument.Statement[0].Resource = event.methodArn;
        policy.context = custom_headers;
        console.log(policy);
        context.succeed(policy);
        return false;
    }
}
