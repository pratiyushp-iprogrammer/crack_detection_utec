const redis = require('../common/redis/redis-connection');
const {SecretsManagerClient, GetSecretValueCommand} = require('@aws-sdk/client-secrets-manager') 
const secretsManager = new SecretsManagerClient()


const env = process.env.DEPLOYMENT || 'dev'

let nonprod = ["dev", "test", "stage", "preprod"];
let prod = ["prod", "master", "production"];
let secret_env;
if (prod.includes(env)) {
    console.log(`${env} is present in the array.`);
    secret_env = "prod"
} else {
    console.log(`${env} is not present in the array.`);
    secret_env = "nonprod"

}
const secret_name = `iProCodeBuild/admin/${secret_env}`;

const getSecrateManagerValue = async () => {
    try {
        const command = new GetSecretValueCommand({ SecretId: secret_name });
        let response = await secretsManager.send(command);
        console.log("data",response.SecretString)
 
        const secret = response.SecretString;
        if(!secret){
            return;
        }
        let value = JSON.parse(secret)
        let access = JSON.parse(value.adminAccess)
        access = JSON.stringify(access[env])
        console.log("access", access)
        console.log(JSON.stringify({ file: 'service.js', line: 41, secret }));
        await setAccessManagemetKey(access)
        return access;

    } catch (error) {
        console.log(JSON.stringify({ file: 'service.js', line: 38, message: error.message }));
        throw error;
    }
}

const setAccessManagemetKey = async (access) => {
    try {
        let key = "admin_access_management_access";
        let setKey = await redis.redisCacheSet(key, JSON.stringify(access))
        console.log(JSON.stringify({ file: 'index.js', line: 10, setKey }));

        return;
    } catch (error) {
        console.log(JSON.stringify({ file: 'service.js', line: 13, message: error.message }));
        throw error;
    }

}

const checkAccessManagementPermission = async (email) => {
    try {
        let key = "admin_access_management_access";
        let superAdminData
        superAdminData = await redis.redisCacheGet(key);
        if (!superAdminData) {
            superAdminData = await getSecrateManagerValue();
        } else {
            superAdminData = JSON.parse(superAdminData);
        }
        superAdminData=JSON.parse(superAdminData);


        const filteredData = superAdminData.adminAccess.filter(item => item.admin === email);
        console.log(JSON.stringify({ file: 'accessManagementService.js', line: 87, filteredData }));

        return filteredData;

    } catch (error) {
        console.log(JSON.stringify({ file: 'service.js', line: 80, message: error.message }));
        throw error;
    }
}




module.exports = {
    setAccessManagemetKey,
    checkAccessManagementPermission
}




