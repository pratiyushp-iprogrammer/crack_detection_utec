const mongoose = require('mongoose');

const schema = new mongoose.Schema(
	{
		sr_id: Number,
		design_id: Number,
		user_id: Number, // refers to admin user
		user_details: {
			name: String,
			email: String,
			contact: String,
			workgroup: String,
			role: String,
		},
		relevance_score: Number,
		date: {
			type: String,
			default: new Date().toISOString().split('T')[0],
		},
		download_count: Number,
	},
    {
		timestamps: true,
		versionKey: false,
	}
);

schema.index({ sr_id: 1, design_id: 1, user_id: 1 }, { unique: true });

module.exports = mongoose.model('design_downloads', schema);