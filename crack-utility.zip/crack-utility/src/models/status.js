const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  "queueId": String,
  "transaction_id": String,
  "status_code": Number,
  "message": String,
  "total_records": Number,
  "total_images": Number,
  "total_valid_records": Number,
  "parsing_progress": Number,
  "image_upload_progress": Number,
  "record_image_upload_progress": Number,
  "insertion_progress": Number,
  "type": String,
  "total_valid_images_uploaded": Number,
  "errorLinks": Object,
  "created_by": String,
  "updated_by": String
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }, {
    collection: "bulk_uplad_status"
  });

module.exports = mongoose.model('bulk_uplad_status', schema);