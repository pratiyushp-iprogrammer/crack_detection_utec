const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  "resAdminID": Number,
  "name": String,
  "email": String,
  "role": String,
  "created_by": String,
  "updated_by": String
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }, {
    collection: "adminDetails"
  });

module.exports = mongoose.model('adminDetails', schema);