const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    "unique_id": String,
    "source": String,
    "sr_number": String,
    "option_number": String,
    "design_name": String,
    "design_short_description": String,
    "design_long_description": String,
    "files": {
        "two_d_rendered_plan_jpg": {
            "ground": String,
            "ground_plus_one": String,
            "ground_plus_two": String,
            "ground_plus_three": String,
            "ground_plus_four": String,
            "above_ground_plus_four": String,
            "others": String
        },
        "two_d_line_drawing_jpg": {
            "ground": String,
            "ground_plus_one": String,
            "ground_plus_two": String,
            "ground_plus_three": String,
            "ground_plus_four": String,
            "above_ground_plus_four": String,
            "others": String
        },
        "two_d_line_drawing_pdf": {
            "two_d_line_drawing_pdf_id": String
        },
        "three_d_design_id": {
            "front": String,
            "right_side": String,
            "left_side": String,
            "rear_side": String,
            "internal": String
        },
        "three_d_cut_iso_jpg": {
            "ground": String,
            "ground_plus_one": String,
            "ground_plus_two": String,
            "ground_plus_three": String,
            "ground_plus_four": String,
            "above_ground_plus_four": String,
            "others": String
        },
        "linked_estimation_id": {
            "estimation_id": String
        },
        "linked_stetch_up_file": {
            "sketch_up_file_id": String
        },
        "linked_dwg_file": {
            "linked_dwg_file_id": String
        },
        "linked_psd_file": {
            "linked_psd_file_id": String
        },
        "linked_ppt_file": {
            "linked_ppt_file_id": String
        },
        "utec_pro_link": {
            "utec_pro_link_id": String
        }
    },
    "plot_details": {
        "plot_area": Number,
        "plot_length": Number,
        "plot_width": Number,
        "plot_shape": String,
        "left_setback": Number,
        "right_setback": Number,
        "front_setback": Number,
        "rear_setback": Number,
        "close_sides_of_the_plot": Number
    },
    "project_details": {
        "typology": String,
        "estimated_cost_of_construction": String,
        "builtup_area": Number,
        "floor_plate_area_of_ground_floor": Number,
        "floor_plate_length": Number,
        "floor_plate_width": Number,
        "floors": String,
        "bedrooms": Number,
        "shared_wall": Number,
        "for_two_shared_wall_adjacent_parallel": String,
        "style": String,
        "low_range_budget": String,
        "high_range_budget": String
    },
    "geography": {
        "state": String,
        "city": String,
        "district": String,
        "geo_coordinates": String,
        "pincode": Number
    },
    "family_details": {
        "total_family_members": Number,
        "number_of_senior_citizen": Number,
        "number_of_adults": Number,
        "number_of_children": Number,
        "number_of_infants": Number
    },
    "parking": {
        "basement": String,
        "stilts": String,
        "two_wheeler_parking": Number,
        "four_wheeler_parking": Number
    },
    "senior_citizen_friendly": {
        "max_three_stairs_to_enter_the_ground_floor": String,
        "one_bhk_on_ground_floor": String,
        "provision_of_ramp": String
    },
    "open_areas_configuration": {
        "balcony": Number,
        "porch": String,
        "garden": String,
        "courtyard": String,
        "frontyard": String,
        "backyard": String,
        "terrace": String
    },
    "roof": {
        "roof_type": String
    },
    "stylized": {
        "stylized_configuration": String
    },
    "special_amenities": {
        "pool": String
    },
    "material_treatment": {
        "brick": String,
        "stone": String,
        "wood": String,
        "tile": String,
        "aluminium_composite_panel": String,
        "glass_curtain_wall": String
    },
    "structural_elements": {
        "pergola": String,
        "jaali": String,
        "green_wall": String,
        "planter": String,
        "vault": String,
        "double_height_open_area": String,
        "elevation_element": String
    },
    "colors": {
        "color_scheme": String,
        "color_used": String
    },
    "partner_details": {
        "partner_id": String,
        "partner_name": String
    },
    "reference_images": String,
    "translation_file": Object,
    "is_active": Number,
    "number_of_times_reused": Number,
    "number_of_times_viewed": Number,
    "created_by": Number,
    "updated_by": Number,
    "created_at": {
        type: Date,
        default: Date.now()
    },
    "updated_at": {
        type: Date,
        default: Date.now()
    }
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
}, {
    collection: "style_elevation"
});

module.exports = mongoose.model('style_elevation', schema);