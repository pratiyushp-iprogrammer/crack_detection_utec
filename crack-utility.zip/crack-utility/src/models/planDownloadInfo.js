const mongoose = require('mongoose');

const schema = new mongoose.Schema(
	{
		designId: Number,
		userId: Number,  // refers to IHB and Partner user
		userDetails: {
			name: String,
			userIdAlias: String,
			mobileNumber: String,
			role: String,
			platformId: String,
		},
		date: {
			type: String,
			default: new Date().toISOString().split('T')[0],
		},
		downloadCount: Number,
	},
    {
		timestamps: true,
		versionKey: false,
	}
);

			
schema.index({ designId: 1, userId: 1 }, { unique: true });

module.exports = mongoose.model('plan_downloads', schema);