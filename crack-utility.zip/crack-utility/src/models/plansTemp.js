const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    "unique_id": String,
    "source": String,
    "sr_number": String,
    "option_number": String,
    "design_name": String,
    "design_short_description": String,
    "design_long_description": String,
    "two_d_rendered_plan_jpg_id": String,
    "two_d_rendered_plan_pdf_id": String,
    "two_d_line_drawing_jpg_id": String,
    "three_d_design_id": String,
    "estimation_id": String,
    "plot_details": {
        "plot_area": Number,
        "plot_length": Number,
        "plot_width": Number,
        "plot_shape": String,
        "open_sides_of_the_plot": Number
    },
    "project_details": {
        "typology": String,
        "estimated_cost_of_construction": String,
        "builtup_area": Number,
        "floor_plate_area_of_ground_floor": Number,
        "floor_plate_length": String,
        "floor_plate_width": Number, // Changed from String
        "floor_plate_width_range": String, // New key added wrt floor_plate_width
        "floors": String,
        "bedrooms": Number,
        "shared_wall": Number,
        "for_two_shared_wall_adjacent_parallel": String,
        "space_allocation": String,
        "style": String
    },
    "geography": {
        "weather_condition": String,
        "state": String,
        "city": String,
        "district": String,
        "geo_coordinates": String,
        "pincode": String,
        "budget": String
    },
    "family_details": {
        "total_family_members": String,
        "number_of_senior_citizen": String,
        "number_of_adults": String,
        "number_of_children": String,
        "number_of_infants": String
    },
    "parking": {
        "basement": Number,
        "stilts": Number,
        "two_wheeler_parking": Number,
        "four_wheeler_parking": Number
    },
    "senior_citizen_friendly": {
        "max_three_stairs_to_enter_the_ground_floor": Number,
        "one_bhk_on_ground_floor": Number,
        "provision_of_ramp": Number
    },
    "vaastu_compliancy": {
        "vaastu_compliant": Number,
        "entry_direction": String,
        "orientation_of_kitchen": String,
        "orientation_of_pooja_room": String,
        "orientation_of_master_bedrrom": String
    },
    "rooms": {
        "total_bathrooms": Number,
        "attached_bathrooms": Number,
        "common_bathrooms": Number,
        "dining_room": Number,
        "living_room": Number,
        "kitchen": Number,
        "family_room": Number,
        "store_room": Number,
        "pooja_room": Number,
        "shops": Number
    },
    "open_areas": {
        "balcony": Number,
        "porch": String,
        "verandah": Number,
        "garden": Number,
        "courtyard": Number,
        "frontyard": Number,
        "backyard": Number,
        "terrace": Number
    },
    "special_amenities": {
        "library": Number,
        "home_theatre": Number,
        "pool": Number,
        "gym": Number
    },
    "material_treatment": {
        "brick": Number,
        "stone": Number,
        "wood": Number,
        "tile": Number,
        "aluminium_composite_panel": Number,
        "glass_curtain_wall": Number
    },
    "structural_elements": {
        "pergola": Number,
        "jaali": Number,
        "green_wall": Number,
        "planter": Number,
        "vault": Number,
        "double_height_open_area": Number,
        "elevation_element": Number
    },
    "colors": {
        "color_scheme": String,
        "color_used": String
    },
    "partner_details": {
        "partner_id": String,
        "partner_name": String
    },
    "reference_images": String,
    "is_active": Number,
    "number_of_times_reused": Number,
    "number_of_times_viewed": Number,
    "created_by": Number,
    "updated_by": Number
}, {
        // timestamps: { createdAt: 'created_at', updatedAt: { path: 'updatedAt', setOnInsert: false } }
        timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
    }, {
        collection: "plans_management_temps"
    });

module.exports = mongoose.model('plans_management_temps', schema);