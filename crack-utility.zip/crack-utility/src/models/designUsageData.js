const mongoose = require('mongoose');
const ObjectID = require('mongodb').ObjectID;

const schema = new mongoose.Schema({
    "plan_style_designs_unique_id" : Number,  // plan style design schema
    "design_id": { type: ObjectID }, // insertion id
    "sr_tracker_number": String,
    "action": String, // CREATE, UPDATE, DOWNLOAD
    "created_by": Number
}, {
    timestamps: { createdAt: 'created_at' }
}, {
    collection: "design_log_data"
});

module.exports = mongoose.model('design_log_data', schema);