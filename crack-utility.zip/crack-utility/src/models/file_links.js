const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  "id": String,
  "file_links": [String],
  "is_active": Number,
  "created_by": Number,
  "updated_by": Number
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }, {
    collection: "s3_file_links"
  });

module.exports = mongoose.model('s3_file_links', schema);