const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    "id": { type: Number, unique: true },
    "source": String,
    "event_for": String
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    collection: "unique_id_generations"
});

// Pre-save middleware to auto-increment the 'id' field before saving
schema.pre('save', async function (next) {
    if (!this.isNew) {
        // If the document is being updated, don't auto-increment the 'id' field
        return next();
    }

    try {
        // Find the highest 'id' value in the collection and increment it by 1
        const highestIdDocument = await this.constructor.findOne({}, { id: 1 }).sort({ id: -1 }).limit(1);
        const highestId = highestIdDocument ? highestIdDocument.id : 0;
        this.id = highestId + 1;
        next();
    } catch (error) {
        next(error);
    }
});

module.exports = mongoose.model('unique_id_generations', schema);