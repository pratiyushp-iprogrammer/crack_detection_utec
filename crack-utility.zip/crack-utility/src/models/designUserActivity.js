const mongoose = require('mongoose');

const schema = new mongoose.Schema(
	{
		designId: Number,
		userId: Number, // refers to admin user
		userDetails: {
			name: String,
			email: String,
			contact: String,
			workgroup: String,
			role: String,
		},
		// activityDate: {
		// 	type: Date,
		// 	default: new Date(),
		// },
		activityName: String,
	},
    {
		timestamps: true,
		versionKey: false,
	}
);

module.exports = mongoose.model('design_user_activity', schema);