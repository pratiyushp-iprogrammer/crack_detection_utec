const mongoose = require('mongoose');
var ObjectId = require('mongodb').ObjectId;

const schema = new mongoose.Schema({
    "object_id": { type: ObjectId }, // respective _id from plan or style collection
    "event_for": String, // plan, style
    "app_id": Number, //  web(2), mobile(3)
    "action": String, //   like, favorite
    "user_id": Number,
    "user_detail": Array
}, {
    timestamps: { createdAt: 'created_at' }
}, {
    collection: "user_profile_action_data"
});

module.exports = mongoose.model('user_profile_action_data', schema);