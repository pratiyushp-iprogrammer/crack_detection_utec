const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  "userId": String,
  "type": String,
  "adminPanel": Number,
  "columnsVisible": Object,
  "filterList": Object,
  "editFilterList": Object,
  "created_by": String,
  "updated_by": String
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }, {
    collection: "filterData"
  });

module.exports = mongoose.model('filterData', schema);