const mongoose = require('mongoose');
var ObjectId = require('mongodb').ObjectId;

const schema = new mongoose.Schema({
    "style_id": { type: ObjectId },
    "sr_tracker_number": String,
    "event_for": String, // plan, style
    "app_id": Number, // admin(1), web(2), mobile(3)
    "action": String, // create, view, update, reuse, share, like, save, download, customize
    "is_admin": Boolean,
    "user_id": String
}, {
    timestamps: { createdAt: 'created_at' }
}, {
    collection: "style_usage_data"
});

module.exports = mongoose.model('style_usage_data', schema);