const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    "designId": { type: Number, required: true },
    "userId": { type: Number, required: true },
    "action": String,
    "isBookmark":{type:Number,required:true},
    "userDetails":{
        "userName":String,
        "mobileNumber":String,
        "isAdmin":{type:Number,required:true}
    },
    "createdAt": String,
    "updatedAt": String
}, {
    // timestamps: { createdAt: 'created_at', updatedAt: { path: 'updatedAt', setOnInsert: false } }
    timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' }
}, {
    collection: "design_gallery_bookmark"
});

module.exports = mongoose.model('design_gallery_bookmark', schema);