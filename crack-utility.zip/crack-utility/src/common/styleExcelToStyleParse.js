const json_structure = require('./styles.json');
const { nanoid } = require('nanoid');
const Database = require('../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const hasIn = require("lodash/hasIn");
const set = require('lodash/set');
const fileLinks = require('../services/fileLinksService');
const fileLinksService = new fileLinks();
const readXlsxFile = require('read-excel-file/node');
const UniqueIdGenerationService = require('../services/uniqueIdGeneration');
let uniqueIdGenerationService = new UniqueIdGenerationService();
const stylesServiceDummy = require('../services/styleServiceDummy');
const tempStyleService = new stylesServiceDummy();
const check_file_link = async (data, file_links_array) => {
  try {
    const data_list = data.split(",");
    const result = data_list.map((data_item) => {
      return file_links_array.includes(data_item) ? true : false;
    });
    return result.includes(false) ? false : true;
  } catch (err) {
    return err;
  }
};
const styleExcelToStyleParse = async (excel_data, file_link_id) => {
  console.log("Inside excelToJsonParse Function");
  const first = new Date();
  console.log('first', first);
  const file_link_list_array = await fileLinksService.findById(file_link_id);
  const second = new Date();
  console.log('second', second);
  const difference1 = (second.getTime() - first.getTime()) / 1000;
  console.log('difference1', difference1);
  const result = await readXlsxFile(excel_data.Body).then(async (rows) => {
    const third = new Date();
    console.log('third', third);
    let rowsIndex, columnIndex = '';
    rows.forEach((columns, index1) => {
      columns.forEach((data, index2) => {
        if (columns.includes("Unique ID") && data === "Unique ID") {
          rowsIndex = index1;
          columnIndex = index2;
          return;
        }
      })
      columns.splice(0, columnIndex);
      return;
    });
    rows.splice(0, rowsIndex);
    const headers = rows.shift();
    const valid_data_result_array = [];
    const duplicate_id_result_array = [];
    const invalid_data_entry_array = [];
    const final_array = [];
    const transaction_id = nanoid(10);
    for (let excel_item = 0; excel_item < rows.length; excel_item += 1) {
      // for (let excel_item = 0; excel_item < 5; excel_item += 1) {
      let temp_json = {};
      const construct_json_body = {};
      let duplicate_id_result = false;
      let invalid_data_entry = false;
      for (let index = 0; index < rows[excel_item].length; index += 1) {
        let data = rows[excel_item][index];//value=DG_1_reference_images.jpg 
        const value = json_structure[headers[index]];//value={ type: 'string', key_name: 'unique_id', required: true }
        const check = hasIn(json_structure, headers[index]);//headers[index]='Unique ID'
        if (check) {
          if (value.type === 'string' && headers[index] !== 'Unique ID') {
            if (typeof (data) !== 'string') {
              invalid_data_entry = true;
              console.log('1.', headers[index], "----------", data);
            }
          }
          if (value.type === 'number') {
            if (typeof (data) !== 'number') {
              invalid_data_entry = true;
              console.log('2.', headers[index], "----------", data);
            }
          }
          if (value.type === 'dropdown') {
            if (data.toUpperCase() === "YES" || data.toUpperCase() === "NO") {
              if (value.values.includes(data.toUpperCase())) {
                data = (data.toUpperCase() === 'NO') ? 0 : 1;
              } else {
                invalid_data_entry = true;
                console.log('3.', headers[index], "----------", data);
              }
            } else if (!(value.values.includes(data))) {
              invalid_data_entry = true;
              console.log('4.', headers[index], "----------", data);
            }
          }
          if (value.type === 'image_link') {
            const result = await check_file_link(data, file_link_list_array);
            if (!result) {
              invalid_data_entry = true;
              console.log('5.', headers[index], "----------", data);
            }
          }
          if (headers[index] === 'Unique ID') {
            if (data === null || data === undefined) {
              let params = {};
              params.source = 'DG';
              const response = await uniqueIdGenerationService.generateId(params);
              if (response) {
                const lastRecord = await uniqueIdGenerationService.getLastInsertedRecord();
                let unique_id = `${params.source}_${lastRecord[0].id}`;
                data = unique_id;
              }
            } else {
              duplicate_id_result = true;
            }
          }
          construct_json_body.transaction_id = transaction_id;
          set(construct_json_body, value.key_name, data);
        }
      }

      if (duplicate_id_result) {
        temp_json.duplicate = true;
        construct_json_body.duplicate = true;
        temp_json.temp = JSON.stringify(construct_json_body);
        temp_json.unique_id = construct_json_body.unique_id;
        temp_json.transaction_id = construct_json_body.transaction_id;
        temp_json.source = construct_json_body.source;
        duplicate_id_result_array.push(construct_json_body);
      }
      if (invalid_data_entry) {
        temp_json.invalid = true;
        construct_json_body.invalid = true;
        temp_json.temp = JSON.stringify(construct_json_body);
        temp_json.unique_id = construct_json_body.unique_id;
        temp_json.transaction_id = construct_json_body.transaction_id;
        temp_json.source = construct_json_body.source;
        invalid_data_entry_array.push(construct_json_body);

      }
      if (duplicate_id_result === false && invalid_data_entry === false) {
        construct_json_body.valid = true;
        temp_json = construct_json_body;
        valid_data_result_array.push(construct_json_body);
      }
      final_array.push(temp_json);
    }
    const forth = new Date();
    console.log('forth', forth);
    const difference2 = (forth.getTime() - third.getTime()) / 1000;
    console.log('difference2', difference2);
    console.log('valid_data_result_array-------------', valid_data_result_array.length);
    console.log('duplicate_id_result_array-------------', duplicate_id_result_array.length);
    console.log('invalid_data_entry_array-------------', invalid_data_entry_array.length);
    const fifth = new Date();
    console.log('fifth', fifth);
    await tempStyleService.insert_many(final_array);
    console.log("Data entered in DB sucessfully");
    const sixth = new Date();
    console.log('sixth', sixth);
    const difference3 = (sixth.getTime() - fifth.getTime()) / 1000;
    console.log('difference3', difference3);
    const res = [{
      transaction_id,
      valid_data: valid_data_result_array,
      duplicate_plan: duplicate_id_result_array,
      plans_with_errors: invalid_data_entry_array,
      valid_data_length: valid_data_result_array.length,
      duplicate_plan_length: duplicate_id_result_array.length,
      plans_with_errors_length: invalid_data_entry_array.length,
    }];
    return res;
  }).catch(err => {
    return err;
  });
  return result;
}
module.exports = styleExcelToStyleParse;
