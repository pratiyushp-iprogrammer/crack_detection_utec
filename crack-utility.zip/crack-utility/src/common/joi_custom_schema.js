const Joi = require("joi");
const AlphabetDigitHyphenUnderscore = /^[a-zA-Z][a-zA-Z0-9_]*$/;
const AlphabetDigitHyphenUnderscoreSpace = /^[a-zA-Z][a-zA-Z0-9 _-]*$/;


const stringInputRequired = Joi.string().required();
const stringInput = Joi.string().allow('');
const numberInput = Joi.number().min(0).max(99999999999);
const numberInputRequired = Joi.number().required().min(0).max(99999999999);
const zeroNumberInput = Joi.number().required().min(0).max(99999999999);
const arrayInput = Joi.array();
const objectInput = Joi.object();
const stringInputAlphabetDigitHyphenUnderscore = Joi.string().pattern(new RegExp('^[a-zA-Z][a-zA-Z0-9_]*$')).trim();
const stringInputAlphabetDigitHyphenUnderscoreSpace = Joi.string().pattern(new RegExp('^[a-zA-Z][a-zA-Z0-9 ()_-]*$')).trim();

module.exports = {
    stringInputRequired: stringInputRequired,
    stringInput: stringInput,
    numberInput: numberInput,
    zeroNumberInput: zeroNumberInput,
    arrayInput: arrayInput,
    objectInput: objectInput,
    stringInputAlphabetDigitHyphenUnderscore: stringInputAlphabetDigitHyphenUnderscore,
    stringInputAlphabetDigitHyphenUnderscoreSpace: stringInputAlphabetDigitHyphenUnderscoreSpace,
    numberInputRequired: numberInputRequired
}