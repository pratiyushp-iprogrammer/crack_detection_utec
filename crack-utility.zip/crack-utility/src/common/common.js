
class common {
    reqSanitize (event)  {
        try {
            if(JSON.stringify(JSON.parse(event.body)).length > 0){
                event.body = JSON.parse(event.body);
                event.body = JSON.stringify(event.body);
                event.body = event.body.replace(/(<([^>]+)>)/ig, '');
            }
            if(JSON.stringify(event.queryStringParameters).length > 0){
                event.queryStringParameters = JSON.stringify(event.queryStringParameters);
                event.queryStringParameters = event.queryStringParameters.replace(/(<([^>]+)>)/ig, '');
                event.queryStringParameters = JSON.parse(event.queryStringParameters);
            }
            if(JSON.stringify(event.pathParameters).length > 0){
                event.pathParameters = JSON.stringify(event.pathParameters);
                event.pathParameters = event.pathParameters.replace(/(<([^>]+)>)/ig, '');
                event.pathParameters = JSON.parse(event.pathParameters);
            }
            return event;
        }catch(e){
            console.log('error: ', e);
            return {
                statusCode: 500,
                body: JSON.stringify({
                    message: 'Error!',
                    error: e.stack,
                }),
            };
        }
    }
    
}
module.exports = common;