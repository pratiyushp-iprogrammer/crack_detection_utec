const HTTP_CODE = require('./constants');

const searchType = {
    "freeText": "freeText",
    "fixText": "fixText",
    "fixNumericText": "fixNumericText"
};

const arrPlanFixTextSearchFields = [{ "text": "basement", "key": "parking.basement" }, { "text": "stilts", "key": "parking.stilts" }, { "text": "vaastu", "key": "vaastu_compliancy.vaastu_compliant" }, { "text": "balcony", "key": "open_areas.balcony" }, { "text": "porch", "key": "open_areas.porch" }, { "text": "garden", "key": "open_areas.garden" }, { "text": "courtyard", "key": "open_areas.courtyard" }, { "text": "frontyard", "key": "open_areas.frontyard" }, { "text": "backyard", "key": "open_areas.backyard" }, { "text": "terrace", "key": "open_areas.terrace" }, { "text": "library", "key": "special_amenities.library" }, { "text": "home Theatre", "key": "special_amenities.home_theatre" }, { "text": "pool", "key": "special_amenities.pool" }, { "text": "gym", "key": "special_amenities.gym" }, { "text": "study", "key": "special_amenities.study_room" }, { "text": "game", "key": "special_amenities.game_room" }, { "text": "brick", "key": "material_treatment.brick" }, { "text": "stone", "key": "material_treatment.stone" }, { "text": "wood", "key": "material_treatment.wood" }, { "text": "tile", "key": "material_treatment.tile" }, { "text": "aluminum composite panel", "key": "material_treatment.aluminium_composite_panel" }, { "text": "glass façade", "key": "material_treatment.glass_curtain_wall" }, { "text": "pergola", "key": "structural_elements.pergola" }, { "text": "slats", "key": "structural_elements.vault" }, { "text": "jaali", "key": "structural_elements.jaali" }, { "text": "green wall", "key": "structural_elements.green_wall" }, { "text": "planter", "key": "structural_elements.planter" }, { "text": "double height open area", "key": "structural_elements.double_height_open_area" }, { "text": "elevation element", "key": "structural_elements.elevation_element" }, { "text": "plotAreas", "key": "plot_details.plot_area" }, { "text": "entryFacing", "key": "vaastu_compliancy.entry_direction" }, { "text": "numberOfFloors", "key": "project_details.floors" }, { "text": "numberOfRooms", "key": "project_details.bedrooms" },{ "text": "plotWidth", "key": "plot_details.plot_width" },{ "text": "homeBuildType", "key": "project_details.typology" }];

const arrStyleFixTextSearchFields = [{ "text": "basement", "key": "parking.basement" }, { "text": "stilts", "key": "parking.stilts" }, { "text": "balcony", "key": "open_areas_configuration.balcony" }, { "text": "porch", "key": "open_areas_configuration.porch" }, { "text": "garden", "key": "open_areas_configuration.garden" }, { "text": "courtyard", "key": "open_areas_configuration.courtyard" }, { "text": "frontyard", "key": "open_areas_configuration.frontyard" }, { "text": "backyard", "key": "open_areas_configuration.backyard" }, { "text": "terrace", "key": "open_areas_configuration.terrace" }, { "text": "pool", "key": "special_amenities.pool" }, { "text": "brick", "key": "material_treatment.brick" }, { "text": "stone", "key": "material_treatment.stone" }, { "text": "wood", "key": "material_treatment.wood" }, { "text": "tile", "key": "material_treatment.tile" }, { "text": "aluminum composite panel", "key": "material_treatment.aluminium_composite_panel" }, { "text": "glass façade", "key": "material_treatment.glass_curtain_wall" }, { "text": "pergola", "key": "structural_elements.pergola" }, { "text": "slats", "key": "structural_elements.vault" }, { "text": "jaali", "key": "structural_elements.jaali" }, { "text": "green wall", "key": "structural_elements.green_wall" }, { "text": "planter", "key": "structural_elements.planter" }, { "text": "double height open area", "key": "structural_elements.double_height_open_area" }, { "text": "elevation element", "key": "structural_elements.elevation_element" }];

const arrFixNumericTextSearchFields = [{ "text": "bathrooms", "key": "rooms.total_bathrooms" }, { "text": "attached bathrooms", "key": "rooms.attached_bathrooms" }, { "text": "common bathrooms", "key": "rooms.common_bathrooms" }];


const arrSearchablePlanFields = ["plot_details.plot_area", "plot_details.plot_length", "plot_details.plot_width", "plot_details.plot_shape", "plot_details.open_sides_of_the_plot", "plot_details.left_set_back", "plot_details.right_set_back", "plot_details.front_set_back", "plot_details.rear_set_back", "project_details.typology", "project_details.estimated_cost_of_construction", "project_details.builtup_area", "project_details.floor_plate_area_of_ground_floor", "project_details.floor_plate_length", "project_details.floor_plate_width", "project_details.floors", "project_details.bedrooms", "project_details.shared_wall", "project_details.for_two_shared_wall_adjacent_parallel", "project_details.space_allocation", "project_details.style", "project_details.low_range_budget", "project_details.high_range_budget", "geography.weather_condition", "geography.state", "geography.city", "geography.district", "geography.geo_coordinates", "geography.pincode", "geography.budget", "family_details.total_family_members", "family_details.number_of_senior_citizen", "family_details.number_of_adults", "family_details.number_of_children", "family_details.number_of_infants", "parking.basement", "parking.stilts", "parking.two_wheeler_parking", "parking.four_wheeler_parking", "senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor", "senior_citizen_friendly.one_bhk_on_ground_floor", "senior_citizen_friendly.provision_of_ramp", "vaastu_compliancy.vaastu_compliant", "vaastu_compliancy.entry_direction", "vaastu_compliancy.orientation_of_kitchen", "vaastu_compliancy.orientation_of_pooja_room", "vaastu_compliancy.orientation_of_master_bedrrom", "rooms.total_bathrooms", "rooms.attached_bathrooms", "rooms.common_bathrooms", "rooms.dining_room", "rooms.living_room", "rooms.kitchen", "rooms.family_room", "rooms.store_room", "rooms.pooja_room", "rooms.shops", "open_areas.balcony", "open_areas.porch", "open_areas.verandah", "open_areas.garden", "open_areas.courtyard", "open_areas.frontyard", "open_areas.backyard", "open_areas.terrace", "open_areas.type_of_entrance", "special_amenities.library", "special_amenities.home_theatre", "special_amenities.pool", "special_amenities.gym", "material_treatment.brick", "material_treatment.stone", "material_treatment.wood", "material_treatment.tile", "material_treatment.aluminium_composite_panel", "material_treatment.glass_curtain_wall", "structural_elements.pergola", "structural_elements.jaali", "structural_elements.green_wall", "structural_elements.planter", "structural_elements.vault", "structural_elements.double_height_open_area", "structural_elements.elevation_element", "colors.color_scheme", "colors.color_used", "partner_details.partner_id", "partner_details.partner_name", "unique_id", "source", "sr_number", "option_number", "design_name", "design_short_description", "design_long_description", "stylized.stylized_configuration"];

const arrSearchableStylesFields = ["plot_details.plot_area", "plot_details.plot_length", "plot_details.plot_width", "plot_details.plot_shape", "plot_details.left_set_back", "plot_details.right_set_back", "plot_details.front_set_back", "plot_details.rear_set_back", "plot_details.close_sides_of_the_plot", "project_details.typology", "project_details.estimated_cost_of_construction", "project_details.builtup_area", "project_details.floor_plate_area_of_ground_floor", "project_details.floor_plate_length", "project_details.floor_plate_width", "project_details.floors", "project_details.bedrooms", "project_details.shared_wall", "project_details.for_two_shared_wall_adjacent_parallel", "project_details.style", "project_details.low_range_budget", "project_details.high_range_budget", "geography.state", "geography.city", "geography.district", "geography.geo_coordinates", "geography.pincode", "family_details.total_family_members", "family_details.number_of_senior_citizen", "family_details.number_of_adults", "family_details.number_of_children", "family_details.number_of_infants", "parking.basement", "parking.stilts", "parking.two_wheeler_parking", "parking.four_wheeler_parking", "senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor", "senior_citizen_friendly.one_bhk_on_ground_floor", "senior_citizen_friendly.provision_of_ramp", "open_areas_configuration.balcony", "open_areas_configuration.porch", "open_areas_configuration.garden", "open_areas_configuration.courtyard", "open_areas_configuration.frontyard", "open_areas_configuration.backyard", "open_areas_configuration.terrace", "open_areas_configuration.type_of_entrance", "roof.roof_type", "special_amenities.pool", "material_treatment.brick", "material_treatment.stone", "material_treatment.wood", "material_treatment.tile", "material_treatment.aluminium_composite_panel", "material_treatment.glass_curtain_wall", "structural_elements.pergola", "structural_elements.jaali", "structural_elements.green_wall", "structural_elements.planter", "structural_elements.vault", "structural_elements.double_height_open_area", "structural_elements.elevation_element", "colors.color_scheme", "colors.color_used", "partner_details.partner_id", "partner_details.partner_name", "unique_id", "element_type", "source", "sr_number", "option_number", "design_name", "design_short_description", "design_long_description", "stylized.stylized_configuration", "reference_images", "element_name", "style", "shape", "material", "location", "shutter", "operation", "material_finish", "accessibility", "height", "type", "railing", "construction", "accessible_terrace", "privacy", "railing_style", "staircase_material", "railing_material", "image_files", "raw_files_availability", "raw_files"];

//const arrAdvancedKeySearch = [{ "text": "seniorCitizenFriendly", "condition": "OR", "key": "senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor" }, { "text": "seniorCitizenFriendly", "condition": "OR", "key": "senior_citizen_friendly.provision_of_ramp" }, { "text": "seniorCitizenFriendly", "condition": "AND", "key": "senior_citizen_friendly.one_bhk_on_ground_floor" }, { "text": "vaastu", "condition": "AND", "key": "vaastu_compliancy.entry_direction", "regexValue": ["North", "East", "North East"] }, { "text": "vaastu", "condition": "AND", "key": "vaastu_compliancy.orientation_of_kitchen", "regexValue": ["South East"] }, { "text": "vaastu", "condition": "AND", "key": "vaastu_compliancy.orientation_of_pooja_room", "regexValue": ["North", "East", "North East"] }, { "text": "vaastu", "condition": "AND", "key": "vaastu_compliancy.orientation_of_master_bedrrom", "regexValue": ["South East"] }]
const arrAdvancedKeySearch = [{"text":"seniorCitizenFriendly","condition":"OR","key":"senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor"},{"text":"seniorCitizenFriendly","condition":"OR","key":"senior_citizen_friendly.provision_of_ramp"},{"text":"seniorCitizenFriendly","condition":"AND","key":"senior_citizen_friendly.one_bhk_on_ground_floor"},{"text":"vaastu","condition":"AND","key":"vaastu_compliancy.vaastu_compliant","regexValue":["Yes"]}];

const arrBasicAmenitiesKeySearch = [{"text":"twoWheelerParking","key":"parking.two_wheeler_parking"},{"text":"carParking","key":"parking.four_wheeler_parking"},{"text":"diningRoom","key":"rooms.dining_room"},{"text":"familyRoom","key":"rooms.family_room"},{"text":"shops","key":"rooms.shops"},{"text":"storeRoom","key":"rooms.store_room"},{"text":"poojaRoom","key":"rooms.pooja_room"},]

const arrSpecialAmenitiesKeySearch = [{"text":"library","key":"special_amenities.library"},{"text":"gameRoom","key":"special_amenities.game_room"},{"text":"homeThetre","key":"special_amenities.home_theatre"},{"text":"gym","key":"special_amenities.gym"},{"text":"studyRoom","key":"special_amenities.study_room"},{"text":"swimmingPool","key":"special_amenities.pool"}];

const arrOpenAreasKeySearch = [{"text":"balcony","key":"open_areas.balcony"},{"text":"porch","key":"open_areas.porch"},{"text":"garden","key":"open_areas.garden"},{"text":"courtYard","key":"open_areas.courtyard"},{"text":"frontYard","key":"open_areas.frontyard"},{"text":"backYard","key":"open_areas.backyard"},{"text":"terrace","key":"open_areas.terrace"}];
class QueryBuilder {

    /*
        Input:
        objRequest = {
            searchString: "Griha.1",
            filters: {
                    // Range Query
                    "plot_details.plot_area": [
                        {min: 251, max: 500},
                        {min: 501, max: 750}
                    ],
                    //In Query
                    "project_details.typology": [
                        "Residential",
                        "Commercial"
                    ]
                },
            "requiredColumns":["unique_id", "source", "plot_details.plot_shape", "design_name"]
        }
    */
    buildQueryOld(objRequest) {

        // Free Text, Text based search
        // Comma-separated file Links, File name text search
        // If the user searches with the word <game> all the designs which are marked <game room> field as “Yes” should be shown first
        // "<Numeric value> sqft" word search, the closest numeric match should be shown first
        //"<Rounded off Lakhs Value>" based search

        let objQuery = {};
        let arrSearch = {
            $or: []
        }
        // Free Text, Text based search
        if (objRequest && objRequest.searchString) {
            //Regex to search contains
            let regex = { '$regex': objRequest.searchString, '$options': 'i' };

            arrSearchablePlanFields.forEach(columnName => {
                const objField = {};
                objField[columnName] = regex;
                arrSearch.$or.push(objField);
            });
        }

        //Filter plan
        if (objRequest && objRequest.filters) {
            for (var key in objRequest.filters) {
                if (objRequest.filters.hasOwnProperty(key)) {
                    const arrFieldFilter = objRequest.filters[key];
                    if (arrFieldFilter.length > 0 && typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                        arrFieldFilter.forEach(objFieldFilter => {
                            //Range filter
                            let objRangeFilter = { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max };
                            const objField = {};
                            objField[key] = objRangeFilter;
                            arrSearch.$or.push(objField);
                        });
                    } else {
                        let objInFilter = { "$in": arrFieldFilter }
                        const objField = {};
                        objField[key] = objInFilter;
                        arrSearch.$or.push(objField);
                    }
                }
            }
        }

        if (arrSearch.$or.length > 0) {
            objQuery = arrSearch;
        }

        return objQuery;
    }

    /**
     * Build query for aggregate function
     * 
     * @param {JSON} objRequest 
     * @returns [Array]
     */

    buildQuery(objRequest, queryFor, match_percentage) {
        let pipeline = [];

        let match = {
            "$match": {
                "is_active": 1
            }
        };

        let objectToArray = {
            "_id": "$_id"
        };

        let match1 = {
            "$match": {
                "$or": [

                ]
            }
        };

        if (objRequest && objRequest.searchString) {
            let searchable_fields = {};
            let orFilter = {
                "$or": [

                ]
            };

            let columnsArray = [];
            var searchObject = this.search(objRequest.searchString, queryFor, searchType.fixText);
            let searchBy = searchType.freeText;
            if (searchObject) {
                searchBy = searchType.fixText;
                columnsArray = [searchObject.key];
            } else if (queryFor == "plans") {
                var searchObject = this.search(objRequest.searchString, queryFor, searchType.fixNumericText);
                if (searchObject) {
                    searchBy = searchType.fixNumericText;
                    columnsArray = [searchObject.key];
                } else {
                    searchBy = searchType.freeText;
                    columnsArray = arrSearchablePlanFields;
                }
            } else {
                searchBy = searchType.freeText;
                columnsArray = arrSearchableStylesFields;
            }

            columnsArray.forEach(key => {
                let arrKeySplitted = key.split('.');
                searchable_fields[arrKeySplitted[0]] = "$" + arrKeySplitted[0];

                let valueKey = "plansArray.v." + arrKeySplitted[0];
                if (arrKeySplitted.length > 1) {
                    valueKey = "plansArray.v." + arrKeySplitted[0] + "." + arrKeySplitted[1];
                }

                let regexValue;
                if (searchBy == searchType.fixText) {
                    regexValue = "Yes";
                } else if (searchBy == searchType.fixNumericText) {
                    regexValue = searchObject.value;
                } else {
                    regexValue = { '$regex': objRequest.searchString.replace("(", "\\(").replace(")", "\\)"), '$options': 'i' };
                }

                orFilter.$or.push({
                    "plansArray.k": "searchable_fields",
                    [valueKey]: regexValue
                });
            });

            objectToArray.searchable_fields = searchable_fields;
            match1.$match.$or.push(orFilter);
        }

        if (objRequest && objRequest.filters) {
            for (var key in objRequest.filters) {
                if (objRequest.filters.hasOwnProperty(key)) {
                    const arrFieldFilter = objRequest.filters[key];
                    if (arrFieldFilter.length) {
                        /* // Start old code
                         let arrKeySplitted = key.split('.');
                        let keyName = arrKeySplitted[0];

                        let valueKey = "plansArray.v";
                        objectToArray[keyName] = "$" + keyName;
                            // End old code
                        */
                        // Start new code    
                        let arrKeySplitted = key.split('.');
                        let keyName = key.replace(".", "_");

                        let valueKey = "plansArray.v";
                        objectToArray[keyName] = "$" + arrKeySplitted[0];
                        // End new code

                        if (arrKeySplitted.length > 1) {
                            valueKey = "plansArray.v." + arrKeySplitted[1];
                        }

                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            let orFilter = {
                                "$or": []
                            };
                            arrFieldFilter.forEach(objFieldFilter => {
                                orFilter.$or.push({
                                    "plansArray.k": keyName,
                                    [valueKey]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                            match1.$match.$or.push(orFilter);
                        } else {
                            match1.$match.$or.push({
                                "plansArray.k": keyName,
                                [valueKey]: { "$in": arrFieldFilter }
                            });
                        }
                    }
                }
            }
        }

        let addFields = {
            "$addFields": {
                "plansArray": {
                    $objectToArray: objectToArray
                }
            }
        };

        let objSelectFields = {
            "_id": "$_id"
        };

        objRequest.arrRequiredColumns.forEach(key => {
            let arrKeySplitted = key.split('.');
            objSelectFields[arrKeySplitted[0]] = "$" + arrKeySplitted[0];
        });

        let project1 = {
            "$project": {
                "_id": objSelectFields,
                plansArray: 1
            }
        }

        let unwind = {
            "$unwind": "$plansArray"
        }

        let group = {
            "$group": {
                "_id": "$_id",
                "count": {
                    "$sum": 1
                }
            }
        };

        let project2 = {
            "$project": {

            }
        };

        let arrKeySplitted = [];
        objRequest.arrRequiredColumns.forEach(keyName => {
            arrKeySplitted = keyName.split('.');
            if (arrKeySplitted.length == 1) {
                project2.$project[arrKeySplitted[0]] = "$_id." + arrKeySplitted[0];
            } else {
                if (!project2.$project.hasOwnProperty(arrKeySplitted[0])) {
                    project2.$project[arrKeySplitted[0]] = {};
                }
                if (!project2.$project[arrKeySplitted[0]].hasOwnProperty(arrKeySplitted[1])) {
                    project2.$project[arrKeySplitted[0]][arrKeySplitted[1]] = {};
                }
                project2.$project[arrKeySplitted[0]][arrKeySplitted[1]] = "$_id." + arrKeySplitted[0] + "." + arrKeySplitted[1];
            }
        });

        project2.$project.score = "$count";
        project2.$project.percentage = {
            "$multiply": [{
                // "$round": [{
                "$divide": ["$count", match1.$match.$or.length]
                // }, 4]
            }, 100]
        };

        let sort = {
            "$sort": {
                "score": -1
            }
        };
        let match3 = {
            "$match": {
                "percentage": 100
            }
        };
        if (objRequest?.sort && objRequest?.sort?.column_name) {
            delete sort["$sort"]["score"];
            sort["$sort"][objRequest?.sort?.column_name] = objRequest?.sort?.order === 'desc' ? -1 : 1;
        }

        let skipValue = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
        let skip = { $skip: skipValue };
        // let limit = { $limit: objRequest.totalIsActiveCount };
        // let limit = { $limit: objRequest.totalRecordsCount };
        let limit1 = { $limit: objRequest.pagination.limit };
        if (match_percentage === true) {
            pipeline.push(match, addFields, project1, unwind, match1, group, project2, match3, sort, skip, limit1);
        } else {
            pipeline.push(match, addFields, project1, unwind, match1, group, project2, sort, skip, limit1);
        }
        return pipeline;
    }


    buildQueryCount(objRequest, queryFor, match_percentage) {
        let pipeline = [];

        let match = {
            "$match": {
                "is_active": 1
            }
        };

        let objectToArray = {
            "_id": "$_id"
        };

        let match1 = {
            "$match": {
                "$or": [

                ]
            }
        };

        if (objRequest && objRequest.searchString) {
            let searchable_fields = {};
            let orFilter = {
                "$or": [

                ]
            };

            let columnsArray = [];
            var searchObject = this.search(objRequest.searchString, queryFor, searchType.fixText);
            let searchBy = searchType.freeText;
            if (searchObject) {
                searchBy = searchType.fixText;
                columnsArray = [searchObject.key];
            } else if (queryFor == "plans") {
                var searchObject = this.search(objRequest.searchString, queryFor, searchType.fixNumericText);
                if (searchObject) {
                    searchBy = searchType.fixNumericText;
                    columnsArray = [searchObject.key];
                } else {
                    searchBy = searchType.freeText;
                    columnsArray = arrSearchablePlanFields;
                }
            } else {
                searchBy = searchType.freeText;
                columnsArray = arrSearchableStylesFields;
            }

            columnsArray.forEach(key => {
                let arrKeySplitted = key.split('.');
                searchable_fields[arrKeySplitted[0]] = "$" + arrKeySplitted[0];

                let valueKey = "plansArray.v." + arrKeySplitted[0];
                if (arrKeySplitted.length > 1) {
                    valueKey = "plansArray.v." + arrKeySplitted[0] + "." + arrKeySplitted[1];
                }

                let regexValue;
                if (searchBy == searchType.fixText) {
                    regexValue = "Yes";
                } else if (searchBy == searchType.fixNumericText) {
                    regexValue = searchObject.value;
                } else {
                    regexValue = { '$regex': objRequest.searchString.replace("(", "\\(").replace(")", "\\)"), '$options': 'i' };
                }
                orFilter.$or.push({
                    "plansArray.k": "searchable_fields",
                    [valueKey]: regexValue
                });
            });

            objectToArray.searchable_fields = searchable_fields;
            match1.$match.$or.push(orFilter);
        }

        if (objRequest && objRequest.filters) {
            for (var key in objRequest.filters) {
                if (objRequest.filters.hasOwnProperty(key)) {
                    const arrFieldFilter = objRequest.filters[key];
                    if (arrFieldFilter.length) {
                        /* // Start old code
                         let arrKeySplitted = key.split('.');
                        let keyName = arrKeySplitted[0];

                        let valueKey = "plansArray.v";
                        objectToArray[keyName] = "$" + keyName;
                            // End old code
                        */
                        // Start new code    
                        let arrKeySplitted = key.split('.');
                        let keyName = key.replace(".", "_");

                        let valueKey = "plansArray.v";
                        objectToArray[keyName] = "$" + arrKeySplitted[0];
                        // End new code

                        if (arrKeySplitted.length > 1) {
                            valueKey = "plansArray.v." + arrKeySplitted[1];
                        }

                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            let orFilter = {
                                "$or": []
                            };
                            arrFieldFilter.forEach(objFieldFilter => {
                                orFilter.$or.push({
                                    "plansArray.k": keyName,
                                    [valueKey]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                            match1.$match.$or.push(orFilter);
                        } else {
                            match1.$match.$or.push({
                                "plansArray.k": keyName,
                                [valueKey]: { "$in": arrFieldFilter }
                            });
                        }
                    }
                }
            }
        }

        let addFields = {
            "$addFields": {
                "plansArray": {
                    $objectToArray: objectToArray
                }
            }
        };

        let unwind = {
            "$unwind": "$plansArray"
        }


        let group = {
            "$group": {
                "_id": "$_id",
                "count": {
                    "$sum": 1
                }
            }
        };

        let project2 = {
            "$project": {

            }
        };

        let arrKeySplitted = [];
        objRequest.arrRequiredColumns.forEach(keyName => {
            arrKeySplitted = keyName.split('.');
            if (arrKeySplitted.length == 1) {
                project2.$project[arrKeySplitted[0]] = "$_id." + arrKeySplitted[0];
            } else {
                if (!project2.$project.hasOwnProperty(arrKeySplitted[0])) {
                    project2.$project[arrKeySplitted[0]] = {};
                }
                if (!project2.$project[arrKeySplitted[0]].hasOwnProperty(arrKeySplitted[1])) {
                    project2.$project[arrKeySplitted[0]][arrKeySplitted[1]] = {};
                }
                project2.$project[arrKeySplitted[0]][arrKeySplitted[1]] = "$_id." + arrKeySplitted[0] + "." + arrKeySplitted[1];
            }
        });

        project2.$project.score = "$count";
        project2.$project.percentage = {
            "$multiply": [{
                // "$round": [{
                "$divide": ["$count", match1.$match.$or.length]
                // }, 4]
            }, 100]
        };
        let match3 = {
            "$match": {
                "percentage": 100
            }
        };
        let count = {
            "$count": "totalRecords"
        }

        // let limit = { $limit: objRequest.totalRecordsCount };
        if (match_percentage === true) {
            pipeline.push(match, addFields, unwind, match1, group, project2, match3, count);
        } else {
            pipeline.push(match, addFields, unwind, match1, group, project2, count);
        }
        return pipeline;
    }

    formatRequiredColumns(arrRequiredColumns) {
        //{"unique_id":1, "source": 1, "plot_details.plot_shape": 1, "design_name": 1}
        const objRequiredColumns = {};
        arrRequiredColumns.forEach(requiredColumnName => {
            objRequiredColumns[requiredColumnName] = 1;
        });

        return objRequiredColumns;
    }

    search(textKey, queryFor, type, value) {
        if (textKey === 'advanced' && type == searchType.fixText && value) {
            let arrColumns = arrAdvancedKeySearch;
            for (var i = 0; i < arrColumns.length; i++) {
                if (arrColumns[i].text.toLocaleLowerCase() == value.toLowerCase()) {
                    return arrColumns[i];
                }
            }
        } else if((textKey === "basicAmenities" ||textKey === "specialAmenities" || textKey === "openAreas") && type == searchType.fixText && value ){
            let arrColumns;
             if(textKey === "basicAmenities" ){
                arrColumns =arrBasicAmenitiesKeySearch;
             }else if(textKey === "specialAmenities"){
                arrColumns =arrSpecialAmenitiesKeySearch;
             }else if(textKey === "openAreas"){
                arrColumns =arrOpenAreasKeySearch;
            }

            const newArrColumns = [];
            value.forEach(el=>{
                for(var el2 in arrColumns){
                    if(arrColumns[el2].text.toLowerCase() === el.toLowerCase()){
                        newArrColumns.push(arrColumns[el2]);
                    }
                }
            })
            return newArrColumns;
        }else {
            if (type == searchType.fixText) {
                let arrColumns = queryFor === 'plans' ? arrPlanFixTextSearchFields : arrStyleFixTextSearchFields;
                for (var k = 0; k < arrColumns.length; k++) {
                    if (arrColumns[k].text.toLocaleLowerCase() == textKey.toLowerCase()) {
                        return arrColumns[k];
                    }
                }
            } else {
                let arrKeySplitted = textKey.split(' ');
                if (arrKeySplitted.length == 2 || arrKeySplitted.length == 3) {
                    let prefixNumber = arrKeySplitted[0];
                    if (!isNaN(prefixNumber)) {
                        let valueToCheck = arrKeySplitted[1].toLowerCase();
                        if (arrKeySplitted.length == 3) {
                            valueToCheck = arrKeySplitted[1].toLowerCase() + " " + arrKeySplitted[2].toLowerCase();
                        }
                        for (var i = 0; i < arrFixNumericTextSearchFields.length; i++) {
                            if (arrFixNumericTextSearchFields[i].text.match(eval("/" + valueToCheck + "/i"))) {
                                arrFixNumericTextSearchFields[i].value = parseInt(arrKeySplitted[0]);
                                return arrFixNumericTextSearchFields[i];
                            }
                        }
                    }
                }
            }
        }

    }

    buildQueryMasonryCount(objRequest) {
        let pipeline = [];
        let match = {
            "$match": {
                "is_active": 1,
                "$or": [

                ]
            }
        };


        if (objRequest && objRequest.searchString) {
            arrSearchableStylesFields.forEach(key => {
                let regexValue = { '$regex': objRequest.searchString, '$options': 'i' };
                match.$match.$or.push({
                    [key]: regexValue
                });
            });
        }

        if (objRequest && objRequest.filters) {
            for (var key in objRequest.filters) {
                if (objRequest.filters.hasOwnProperty(key)) {
                    const arrFieldFilter = objRequest.filters[key];
                    if (arrFieldFilter.length) {
                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            arrFieldFilter.forEach(objFieldFilter => {
                                match.$match.$or.push({
                                    [key]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                        } else {
                            match.$match.$or.push({
                                [key]: { "$in": arrFieldFilter }
                            });
                        }
                    }
                }
            }
        }

        let group = {
            "$group": {
                "_id": null,
                "count": {
                    "$sum": 1
                }
            }
        };

        pipeline.push(match, group);
        return pipeline;
    }

    buildQueryMasonary(objRequest) {
        let pipeline = [];
        let match = {
            "$match": {
                "is_active": 1,
                "$or": [

                ]
            }
        };


        if (objRequest && objRequest.searchString) {
            arrSearchableStylesFields.forEach(key => {
                let regexValue = { '$regex': objRequest.searchString, '$options': 'i' };
                match.$match.$or.push({
                    [key]: regexValue
                });
            });
        }

        if (objRequest && objRequest.filters) {
            for (var key in objRequest.filters) {
                if (objRequest.filters.hasOwnProperty(key)) {
                    const arrFieldFilter = objRequest.filters[key];
                    if (arrFieldFilter.length) {
                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            arrFieldFilter.forEach(objFieldFilter => {
                                match.$match.$or.push({
                                    [key]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                        } else {
                            match.$match.$or.push({
                                [key]: { "$in": arrFieldFilter }
                            });
                        }
                    }
                }
            }
        }

        let project = {
            "$project": {
                files: 1,
                image_files: 1,
                unique_id: 1,
                raw_files: 1
            }
        };

        let skipValue = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
        let skip = { $skip: skipValue };

        let limit = { $limit: objRequest.pagination.limit };

        pipeline.push(match, project, skip, limit);
        return pipeline;
    }

    buildHomeDesignsQuery(objRequest) {
        let pipeline = [];

        let match = {
            "$match": {
                "is_active": 1,
            }
        };
        let match1 = {
            "$match": {
                "$and": [

                ]
            }
        }
        let match2 = {
            "$match": {
                "$or": [

                ]
            }
        };
        let sort = {
            "$sort": {
                "project_details.typology": 1
            }
        };

        if (objRequest && objRequest.filter) {
            for (var key in objRequest.filter) {
                if (objRequest.filter.hasOwnProperty(key)) {
                    var searchObject = this.search(key, 'plans', searchType.fixText, objRequest.filter[key]);
                    const arrFieldFilter = objRequest.filter[key];
                    if (arrFieldFilter != null && arrFieldFilter.length) {
                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            arrFieldFilter.forEach(objFieldFilter => {
                                match2.$match.$or.push({
                                    [searchObject.key]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                        }else if(typeof arrFieldFilter == 'object' && (key === "basicAmenities" || key === "specialAmenities" || key === "openAreas") ){
                            let regexValue;
                            if(key === "basicAmenities"){
                                regexValue = {"$gt":0}
                            }else{
                                regexValue = "Yes"
                            }
                            searchObject.forEach((el,i)=>{
                                match1.$match.$and.push({
                                    [searchObject[i].key] : regexValue
                                });
                            })
                        }else {
                            let regexValue;
                            let searchBy = searchType.fixText;
                            if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'seniorCitizenFriendly') {
                                regexValue = "Yes";
                                let arrColumns = arrAdvancedKeySearch;
                                for (var i = 0; i < arrColumns.length; i++) {
                                    if (arrColumns[i].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        if (arrColumns[i].condition == "OR") {
                                            match2.$match.$or.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        } else if (arrColumns[i].condition == "AND") {
                                            match1.$match.$and.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        }
                                    }
                                }
                            } else if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'vaastu') {
                                let arrColumns = arrAdvancedKeySearch;
                                for (var j = 0; j < arrColumns.length; j++) {
                                    if (arrColumns[j].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        match1.$match.$and.push({
                                        [arrColumns[j].key]:{"$exists":true,"$nin":["null",""]},
                                        [arrColumns[j].key]:{"$in":arrColumns[j].regexValue}})
                                    }
                                }
                            } else {
                                if (searchObject != undefined && arrFieldFilter != null) {
                                    match1.$match.$and.push({
                                        [searchObject.key]: arrFieldFilter
                                    });
                                }
                            }
                        }
                    } else {
                        if (searchObject != undefined && arrFieldFilter != null) {
                            match1.$match.$and.push({
                                [searchObject.key]: arrFieldFilter
                            });
                        }
                    }
                }
            }
        }

        let project = {
            "$project": {
                resourcePath: { "$ifNull": ["", ""] },
                imageUrl: { "$ifNull": ["$files.two_d_line_drawing_jpg.ground", ""] },
                imageRender2dUrl: { "$ifNull": ["$files.two_d_rendered_plan_jpg.ground", ""] },
                unique_id: "$unique_id",
                area: { "$ifNull": ["$plot_details.plot_area", ""] },
                suitablePlotArea: { "$ifNull": ["$plot_details.plot_area", ""] },
                title: { "$ifNull": ["$design_name", ""] },
                numberOfFloors: { "$ifNull": ["$project_details.floors", ""] },
                floors: { "$ifNull": ["$project_details.floors", ""] },
                entryFacing: { "$ifNull": ["$vaastu_compliancy.entry_direction", ""] },
                numberOfRooms: { "$ifNull": ["$project_details.bedrooms", 0] },
                numberOfTimesViewed:{ "$ifNull": ["$number_of_times_viewed", ""] },
                budget:{ "$ifNull": ["$geography.budget", ""] },
                numberOfTimesLiked:{ "$ifNull": ["$number_of_times_liked", ""] },
            }
        };

        let skipValue = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
        let skip = { $skip: skipValue };
        let limit = { $limit: objRequest.pagination.limit };
        if (match2.$match.$or.length > 0 && match1.$match.$and.length > 0) {
            pipeline.push(match, match1, match2, project, skip, limit, sort);
        } else if(match2.$match.$or.length > 0){
            pipeline.push(match, match2, project, skip, limit, sort);
        }
        else{
            pipeline.push(match, match1, project, skip, limit, sort);
        }
        console.log('pipeline...', JSON.stringify(pipeline))
        return pipeline;
    }

    buildHomeDesignsQueryV2(objRequest) {
        let pipeline = [];

        let match = {
            "$match": {
                "is_active": 1,
                "is_approved": 1,
                "files.two_d_rendered_plan_jpg.ground": { $exists: true, $ne: null, $type: 'string'}
            }
        };
        let match1 = {
            "$match": {
                "$and": [

                ]
            }
        }
        let match2 = {
            "$match": {
               "$or": [

                ]
            }
        };
        let sort = {
            $sort: {
                "created_at": -1
            }
        };

        if (objRequest && objRequest.filter) {
            for (var key in objRequest.filter) {
                if (objRequest.filter.hasOwnProperty(key)) {
                    var searchObject = this.search(key, 'plans', searchType.fixText, objRequest.filter[key]);
                    const arrFieldFilter = objRequest.filter[key];
                    if (arrFieldFilter != null && arrFieldFilter.length) {
                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            arrFieldFilter.forEach(objFieldFilter => {
                                match2.$match.$or.push({
                                    [searchObject.key]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                        }else if(typeof arrFieldFilter == 'object' && (key === "basicAmenities" || key === "specialAmenities" || key === "openAreas") ){
                            let regexValue;
                            if(key === "basicAmenities"){
                                regexValue = {"$gt":0}
                            }else{
                                regexValue = "Yes"
                            }
                            searchObject.forEach((el,i)=>{
                                match1.$match.$and.push({
                                    [searchObject[i].key] : regexValue
                                });
                            })
                        }else {
                            let regexValue;
                            let searchBy = searchType.fixText;
                            if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'seniorCitizenFriendly') {
                                regexValue = "Yes";
                                let arrColumns = arrAdvancedKeySearch;
                                for (var i = 0; i < arrColumns.length; i++) {
                                    if (arrColumns[i].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        if (arrColumns[i].condition == "OR") {
                                            match2.$match.$or.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        } else if (arrColumns[i].condition == "AND") {
                                            match1.$match.$and.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        }
                                    }
                                }
                            } else if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'vaastu') {
                                let arrColumns = arrAdvancedKeySearch;
                                for (var j = 0; j < arrColumns.length; j++) {
                                    if (arrColumns[j].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        match1.$match.$and.push({
                                        [arrColumns[j].key]:{"$exists":true,"$nin":["null",""]},
                                        [arrColumns[j].key]:{"$in":arrColumns[j].regexValue}})
                                    }
                                }
                            } else {
                                if (searchObject != undefined && arrFieldFilter != null) {
                                    match1.$match.$and.push({
                                        [searchObject.key]: arrFieldFilter
                                    });
                                }
                            }
                        }
                    } else {
                        if (searchObject != undefined && arrFieldFilter != null) {
                            match1.$match.$and.push({
                                [searchObject.key]: arrFieldFilter
                            });
                        }
                    }
                }
            }
        }

        let project = {
            "$project": {
                resourcePath: { "$ifNull": ["", ""] },
                imageUrl: "",
                imageRender2dUrl: { "$ifNull": ["$files.two_d_rendered_plan_jpg.ground", []] },
                unique_id: { "$ifNull": ["$unique_id", ""] },
                // imageUrl: { "$ifNull": ["$files.two_d_line_drawing_jpg.ground", ""] },
                // imageRender2dUrl: { "$ifNull": ["$files.two_d_rendered_plan_jpg.ground", ""] },
                // unique_id: "$unique_id",
                area: { "$ifNull": ["$plot_details.plot_area", ""] },
                suitablePlotArea: { "$ifNull": ["$plot_details.plot_area", ""] },
                title: { "$ifNull": ["$unique_id", ""] },
                numberOfFloors: { "$ifNull": ["$project_details.floors", ""] },
                floors: { "$ifNull": ["$project_details.floors", ""] },
                entryFacing: { "$ifNull": ["$vaastu_compliancy.entry_direction", ""] },
                numberOfRooms: { "$ifNull": ["$project_details.bedrooms", 0] },
                numberOfTimesViewed:{ "$ifNull": ["$number_of_times_viewed", ""] },
                // budget:{ "$ifNull": ["$geography.budget", ""] },
                numberOfTimesLiked:{ "$ifNull": ["$number_of_times_liked", ""] },
            }
        };

        let skipValue = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
        let skip = { $skip: skipValue };
        let limit = { $limit: objRequest.pagination.limit };
        if (match2.$match.$or.length > 0 && match1.$match.$and.length > 0) {
            pipeline.push(match, match1, match2, sort, skip, limit, project);
        } else if(match2.$match.$or.length > 0){
            pipeline.push(match, match2, sort, skip, limit, project);
        }
        else{
            pipeline.push(match, match1, sort, skip, limit, project);
        }
        console.log('pipeline...', JSON.stringify(pipeline))
        return pipeline;
    }

    buildQueryHomeDesignsCount(objRequest) {
        let pipeline = [];
        let match = {
            "$match": {
                "is_active": 1,
            }
        };
        let match1 = {
            "$match": {
                "$and": [

                ]
            }
        }
        let match2 = {
            "$match": {
                "$or": [

                ]
            }
        };
        if (objRequest && objRequest.filter) {
            for (var key in objRequest.filter) {
                if (objRequest.filter.hasOwnProperty(key)) {
                    var searchObject = this.search(key, 'plans', searchType.fixText, objRequest.filter[key]);
                    const arrFieldFilter = objRequest.filter[key];
                    if (arrFieldFilter != null && arrFieldFilter.length) {
                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            arrFieldFilter.forEach(objFieldFilter => {
                                match2.$match.$or.push({
                                    [searchObject.key]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                        }else if(typeof arrFieldFilter == 'object' && (key === "basicAmenities" || key === "specialAmenities" || key === "openAreas") ){
                            let regexValue;
                            if(key === "basicAmenities"){
                                regexValue = {"$gt":0}
                            }else{
                                regexValue = "Yes";
                            }
                            searchObject.forEach((el,i)=>{
                                match1.$match.$and.push({
                                    [searchObject[i].key] : regexValue
                                });
                            })
                        } else {
                            let regexValue;
                            let searchBy = searchType.fixText;
                            if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'seniorCitizenFriendly') {
                                regexValue = "Yes";
                                let arrColumns = arrAdvancedKeySearch;
                                for (var i = 0; i < arrColumns.length; i++) {
                                    if (arrColumns[i].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        if (arrColumns[i].condition == "OR") {
                                            match2.$match.$or.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        } else if (arrColumns[i].condition == "AND") {
                                            match1.$match.$and.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        }
                                    }
                                }
                            } else if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'vaastu') {
                                let arrColumns = arrAdvancedKeySearch;
                                for (var j = 0; j < arrColumns.length; j++) {
                                    if (arrColumns[j].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        match1.$match.$and.push({
                                        [arrColumns[j].key]:{"$exists":true,"$nin":["null",""]},
                                        [arrColumns[j].key]:{"$in":arrColumns[j].regexValue}})
                                    }
                                }
                            } else {
                                if (searchObject != undefined && arrFieldFilter != null) {
                                    match1.$match.$and.push({
                                        [searchObject.key]: arrFieldFilter
                                    });
                                }
                            }
                        }
                    } else {
                        if (searchObject != undefined && arrFieldFilter != null) {
                            match1.$match.$and.push({
                                [searchObject.key]: arrFieldFilter
                            });
                        }
                    }
                }
            }
        }
        let group = {
            "$group": {
                "_id": null,
                "count": {
                    "$sum": 1
                }
            }
        };
        
        if (match2.$match.$or.length > 0 && match1.$match.$and.length > 0) {
          pipeline.push(match, match1, match2, group);
        } else if(match2.$match.$or.length > 0){
            pipeline.push(match, match2, group);
        }else{
            pipeline.push(match, match1, group);
        }
        return pipeline;
    }

    buildQueryHomeDesignsCountV2(objRequest) {
        let pipeline = [];
        let match = {
            "$match": {
                "is_active": 1,
                "is_approved": 1,
                "files.two_d_rendered_plan_jpg.ground": { $exists: true, $ne: null, $type: 'string'}
            }
        };
        let match1 = {
            "$match": {
                "$and": [

                ]
            }
        }
        let match2 = {
            "$match": {
                "$or": [

                ]
            }
        };
        if (objRequest && objRequest.filter) {
            for (var key in objRequest.filter) {
                if (objRequest.filter.hasOwnProperty(key)) {
                    var searchObject = this.search(key, 'plans', searchType.fixText, objRequest.filter[key]);
                    const arrFieldFilter = objRequest.filter[key];
                    if (arrFieldFilter != null && arrFieldFilter.length) {
                        if (typeof arrFieldFilter[0] == 'object' && 'min' in arrFieldFilter[0]) {
                            arrFieldFilter.forEach(objFieldFilter => {
                                match2.$match.$or.push({
                                    [searchObject.key]: { "$gte": objFieldFilter.min, "$lte": objFieldFilter.max }
                                });
                            });
                        }else if(typeof arrFieldFilter == 'object' && (key === "basicAmenities" || key === "specialAmenities" || key === "openAreas") ){
                            let regexValue;
                            if(key === "basicAmenities"){
                                regexValue = {"$gt":0}
                            }else{
                                regexValue = "Yes";
                            }
                            searchObject.forEach((el,i)=>{
                                match1.$match.$and.push({
                                    [searchObject[i].key] : regexValue
                                });
                            })
                        } else {
                            let regexValue;
                            let searchBy = searchType.fixText;
                            if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'seniorCitizenFriendly') {
                                regexValue = "Yes";
                                let arrColumns = arrAdvancedKeySearch;
                                for (var i = 0; i < arrColumns.length; i++) {
                                    if (arrColumns[i].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        if (arrColumns[i].condition == "OR") {
                                            match2.$match.$or.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        } else if (arrColumns[i].condition == "AND") {
                                            match1.$match.$and.push({
                                                [arrColumns[i].key]: regexValue
                                            });
                                        }
                                    }
                                }
                            } else if (searchBy == searchType.fixText && key === 'advanced' && objRequest.filter[key] === 'vaastu') {
                                let arrColumns = arrAdvancedKeySearch;
                                for (var j = 0; j < arrColumns.length; j++) {
                                    if (arrColumns[j].text.toLocaleLowerCase() == objRequest.filter[key].toLowerCase()) {
                                        match1.$match.$and.push({
                                        [arrColumns[j].key]:{"$exists":true,"$nin":["null",""]},
                                        [arrColumns[j].key]:{"$in":arrColumns[j].regexValue}})
                                    }
                                }
                            } else {
                                if (searchObject != undefined && arrFieldFilter != null) {
                                    match1.$match.$and.push({
                                        [searchObject.key]: arrFieldFilter
                                    });
                                }
                            }
                        }
                    } else {
                        if (searchObject != undefined && arrFieldFilter != null) {
                            match1.$match.$and.push({
                                [searchObject.key]: arrFieldFilter
                            });
                        }
                    }
                }
            }
        }
        let group = {
            "$group": {
                "_id": null,
                "count": {
                    "$sum": 1
                }
            }
        };
        
        if (match2.$match.$or.length > 0 && match1.$match.$and.length > 0) {
          pipeline.push(match, match1, match2, group);
        } else if(match2.$match.$or.length > 0){
            pipeline.push(match, match2, group);
        }else{
            pipeline.push(match, match1, group);
        }
        return pipeline;
    }

}

module.exports = QueryBuilder;