const Database = require('../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const PlanService = require('../services/plansService');
const planService = new PlanService();
const StatusService = require('../services/statusService');
let statusService = new StatusService();
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({region: process.env.AWS_REGION_NAME});
// AWS.config.update();
// {
//   accessKeyId: process.env.ACCESS_KEY_ID,
//   secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   region: process.env.DM_AWS_REGION,
//   // region: 'ap-south-1',
// }

const confirmUploadPlans = async (plan_list, supporting_files_links, queue_id) => {
  try {
    let errorStatus;
    let updateQueueStatus;
    console.log("Inside confirmUploadPlans");
    const links = [];
    const confirmUploadProcessInitiated = {
      queueId: queue_id,
      status_code: 4,
      message: "Confirm upload process initiated",
      total_valid_records: plan_list.length
    }
    console.log('confirmUploadProcessInitiated', confirmUploadProcessInitiated);
    updateQueueStatus = await statusService.updateStatus(confirmUploadProcessInitiated);
    console.log('updateQueueStatus', updateQueueStatus);
    var first = new Date();
    console.log("first:", first);
    await plan_list.map(async (plan) => {
      for (let item in plan) {
        if (plan['valid']) {
          let link_path;
          if (item === 'files') {
            if (plan['files']['two_d_rendered_plan_jpg']['ground']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/jpg/g/${plan['files']['two_d_rendered_plan_jpg']['ground']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_jpg']['ground_plus_one']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/jpg/g1/${plan['files']['two_d_rendered_plan_jpg']['ground_plus_one']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_jpg']['ground_plus_two']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/jpg/g2/${plan['files']['two_d_rendered_plan_jpg']['ground_plus_two']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_jpg']['ground_plus_three']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/jpg/g3/${plan['files']['two_d_rendered_plan_jpg']['ground_plus_three']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_jpg']['ground_plus_four']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/jpg/g4/${plan['files']['two_d_rendered_plan_jpg']['ground_plus_four']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_jpg']['above_ground_plus_four']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/jpg/gn/${plan['files']['two_d_rendered_plan_jpg']['above_ground_plus_four']}`;
              links.push(link_path);
            }
            //-------------------------------------------Linked 2D Rendered Plan PDF ID 
            if (plan['files']['two_d_rendered_plan_pdf']['ground']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/pdf/g/${plan['files']['two_d_rendered_plan_pdf']['ground']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_pdf']['ground_plus_one']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/pdf/g1/${plan['files']['two_d_rendered_plan_pdf']['ground_plus_one']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_pdf']['ground_plus_two']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/pdf/g2/${plan['files']['two_d_rendered_plan_pdf']['ground_plus_two']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_pdf']['ground_plus_three']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/pdf/g3/${plan['files']['two_d_rendered_plan_pdf']['ground_plus_three']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_pdf']['ground_plus_four']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/pdf/g4/${plan['files']['two_d_rendered_plan_pdf']['ground_plus_four']}`;
              links.push(link_path);
            }
            if (plan['files']['two_d_rendered_plan_pdf']['above_ground_plus_four']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dRenderedPlan/pdf/gn/${plan['files']['two_d_rendered_plan_pdf']['above_ground_plus_four']}`;
              links.push(link_path);
            }
            //-------------------------------------------Linked 2D Line Drawing JPG ID 
            if (plan['files']['two_d_line_drawing_jpg']['two_d_line_drawing_jpg_id']) {
              link_path = `plans/${plan['unique_id']}/2d/linked2dLineDrawing/jpg/${plan['files']['two_d_line_drawing_jpg']['two_d_line_drawing_jpg_id']}`;
              links.push(link_path);
            }
            //-------------------------------------------Linked 3D Design ID
            if (plan['files']['three_d_design_id']['front']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dLineDrawing/front/${plan['files']['three_d_design_id']['front']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_design_id']['right_side']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dLineDrawing/right/${plan['files']['three_d_design_id']['right_side']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_design_id']['left_side']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dLineDrawing/left/${plan['files']['three_d_design_id']['left_side']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_design_id']['rear_side']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dLineDrawing/rear/${plan['files']['three_d_design_id']['rear_side']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_design_id']['internal']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dLineDrawing/internal/${plan['files']['three_d_design_id']['internal']}`;
              links.push(link_path);
            }
            //-------------------------------------------3D Cut ISO JPG
            if (plan['files']['three_d_cut_iso_jpg']['ground']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dCutIso/jpg/g/${plan['files']['three_d_cut_iso_jpg']['ground']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_cut_iso_jpg']['ground_plus_one']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dCutIso/jpg/g1/${plan['files']['three_d_cut_iso_jpg']['ground_plus_one']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_cut_iso_jpg']['ground_plus_two']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dCutIso/jpg/g2/${plan['files']['three_d_cut_iso_jpg']['ground_plus_two']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_cut_iso_jpg']['ground_plus_three']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dCutIso/jpg/g3/${plan['files']['three_d_cut_iso_jpg']['ground_plus_three']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_cut_iso_jpg']['ground_plus_four']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dCutIso/jpg/g4/${plan['files']['three_d_cut_iso_jpg']['ground_plus_four']}`;
              links.push(link_path);
            }
            if (plan['files']['three_d_cut_iso_jpg']['above_ground_plus_four']) {
              link_path = `plans/${plan['unique_id']}/3d/linked3dCutIso/jpg/gn/${plan['files']['three_d_cut_iso_jpg']['above_ground_plus_four']}`;
              links.push(link_path);
            }
            //-------------------------------------------Linked Estimation ID
            if (plan['files']['linked_estimation_id']['estimation_id']) {
              link_path = `plans/${plan['unique_id']}/2d/linked3dEstimationID/${plan['files']['linked_estimation_id']['estimation_id']}`;
              links.push(link_path);
            }
            //-------------------------------------------Sketch up file ID
            if (plan['files']['linked_stetch_up_file']['sketch_up_file_id']) {
              link_path = `plans/${plan['unique_id']}/2d/sketchUpFile/${plan['files']['linked_stetch_up_file']['sketch_up_file_id']}`;
              links.push(link_path);
            }
            //-------------------------------------------Linked DWG file ID
            if (plan['files']['linked_dwg_file']['linked_dwg_file_id']) {
              link_path = `plans/${plan['unique_id']}/2d/linkedDwgFile/${plan['files']['linked_dwg_file']['linked_dwg_file_id']}`;
              links.push(link_path);
            }
            //-------------------------------------------Linked PSD file ID
            if (plan['files']['linked_psd_file']['linked_psd_file_id']) {
              link_path = `plans/${plan['unique_id']}/2d/linkedPsdFile/${plan['files']['linked_psd_file']['linked_psd_file_id']}`;
              links.push(link_path);
            }
            //------------------------------------------Linked PPT file ID
            if (plan['files']['linked_ppt_file']['linked_ppt_file_id']) {
              link_path = `plans/${plan['unique_id']}/2d/linkedPptFile/${plan['files']['linked_ppt_file']['linked_ppt_file_id']}`;
              links.push(link_path);
            }
            //------------------------------------------Utech PRO file link ID
            if (plan['files']['utec_pro_link']['utec_pro_link_id']) {
              link_path = `plans/${plan['unique_id']}/2d/linkedPptFile/${plan['files']['utec_pro_link']['utec_pro_link_id']}`;
              links.push(link_path);
            }
          }
          if (item === 'reference_images') {
            link_path = `plans/${plan['unique_id']}/referenceImages/${plan['reference_images']}`;
            links.push(link_path);
          }
        }
      };
    });
    var second = new Date();
    console.log("second:", second);
    var difference1 = (second.getTime() - first.getTime()) / 1000;
    console.log('difference1', difference1);
    const third = new Date();
    console.log('third', third);
    console.log('links', links);
    await Promise.all(
      links.map(async (link, index) => {
        const confirmImageUploadInitiated = {
          queueId: queue_id,
          status_code: 5,
          message: "Confirm Image upload process initiated",
          total_images_uploaded: links.length,
          image_upload_progress: index + 1
        }
        console.log('confirmImageUploadInitiated', confirmImageUploadInitiated);
        updateQueueStatus = await statusService.updateStatus(confirmImageUploadInitiated);
        console.log('updateQueueStatus', updateQueueStatus);
        const link_temp = supporting_files_links.split("/").splice(1, 2);
        const link_path = link_temp[0].split(".").splice(0, 1);
        const keyName = `temp/${link_path[0]}`;
        const get_source_link = link.split("/").pop();
        var params = {
          Bucket: "design-management-assets",
          CopySource: "design-management-assets" + "/" + keyName + "/" + get_source_link,
          // Bucket: process.env.UPLOAD_S3_BUCKET,
          // CopySource: process.env.UPLOAD_S3_BUCKET + "/" + keyName + "/" + get_source_link,
          Key: link
        };
        const copyObjectCommand = new CopyObjectCommand(params);    
        const copyObjectResult = await s3Client.send(copyObjectCommand)
        console.log('copyObjectResult', copyObjectResult);
      })
    );

    const confirmImageUploadDone = {
      queueId: queue_id,
      status_code: 6,
      message: "Confirm Image upload process Done",
      total_images_uploaded: links.length
    }
    console.log('confirmImageUploadDone', confirmImageUploadDone);
    updateQueueStatus = await statusService.updateStatus(confirmImageUploadDone);
    console.log('updateQueueStatus', updateQueueStatus);
    const forth = new Date();
    console.log('forth', forth);
    const difference2 = (forth.getTime() - third.getTime()) / 1000;
    console.log('difference2', difference2);
    const fifth = new Date();
    console.log('fifth', fifth);
    const finalArray = [];
    await plan_list.forEach(plan => {
      if (plan.valid) {
        finalArray.push(plan);
      }
    });
    const res = await planService.insert_many(finalArray).then(async (data) => {
      if (data !== true) {
        console.log('err', data);
        errorStatus = {
          queueId: queue_id,
          status_code: 100,
          message: data,
        }
        console.log('errorStatus', errorStatus);
        updateQueueStatus = await statusService.updateStatus(errorStatus);
        console.log('updateQueueStatus', updateQueueStatus);
      } else return data;
    });
    console.log('res', res);
    const confirmPlansInsertedDone = {
      queueId: queue_id,
      status_code: 7,
      message: "Confirm Plan Inserted process Done",
      total_valid_records: plan_list.length
    }
    console.log('confirmPlansInsertedDone', confirmPlansInsertedDone);
    updateQueueStatus = await statusService.updateStatus(confirmPlansInsertedDone);
    console.log('updateQueueStatus', updateQueueStatus);
    const sixth = new Date();
    console.log('sixth', sixth);
    const difference3 = (sixth.getTime() - fifth.getTime()) / 1000;
    console.log('difference3', difference3);
    if (res) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    console.log("Error in confirmUploadPlans:", err);
    errorStatus = {
      queueId: queue_id,
      status_code: 100,
      message: err,
    }
    console.log('errorStatus', errorStatus);
    updateQueueStatus = await statusService.updateStatus(errorStatus);
    console.log('updateQueueStatus', updateQueueStatus);
    return err;
  }
};
module.exports = confirmUploadPlans;