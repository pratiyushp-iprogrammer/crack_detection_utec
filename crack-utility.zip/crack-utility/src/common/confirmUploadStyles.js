
const { S3Client, CopyObjectCommand } = require('@aws-sdk/client-s3');
const s3Client = new S3Client({region: process.env.AWS_REGION_NAME});
const Database = require('../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const StyleService = require('../services/stylesService');
const styleService = new StyleService();
// AWS.config.update({
//   accessKeyId: process.env.ACCESS_KEY_ID,
//   secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   region: process.env.DM_AWS_REGION,
//   // region: 'ap-south-1',
// });

const confirmUploadStyles = async (style_list, supporting_files_links) => {
  // const confirmUploadStyles = async () => {//For local testing uncomment this code
  try {
    console.log("Inside confirmUploadStyles");
    const links = [];
    await style_list.map(async (style) => {
      for (let item in style) {
        if (style['valid']) {
          let link_path;
          if (item === 'image_files') {
            link_path = `styles/${style['unique_id']}/imageFiles/${style.image_files}`;
            links.push(link_path);
          }
          if (item === 'raw_files') {
            link_path = `styles/${style['unique_id']}/rawFiles/${style.raw_files}`;
            links.push(link_path);
          }
        }
      };
    });
    console.log('links', links);
    await Promise.all(
      links.map(async (link) => {
        const link_temp = supporting_files_links.split("/").splice(1, 2);
        const link_path = link_temp[0].split(".").splice(0, 1);
        const keyName = `temp/${link_path[0]}`;
        const get_source_link = link.split("/").pop();
        var params = {
          // Bucket: "design-management-assets",
          Bucket: process.env.UPLOAD_S3_BUCKET,
          CopySource: process.env.S3_BUCKET_PATH + "/" + keyName + "/" + get_source_link,
          Key: link,
          // ACL: "public-read"
        };
        let copyObjectCommand = new CopyObjectCommand(params);    
        const copyObjectResult = await s3Client.send(copyObjectCommand)
        console.log('copyObjectResult', copyObjectResult);
      })
    );
    const finalArray = [];
    await style_list.forEach(style => {
      if (style.valid) {
        finalArray.push(style);
      }
    });
    console.log('finalArray', JSON.stringify(finalArray));
    const res = await styleService.insert_many(finalArray);
    if (res) {
      return true;
    }
  } catch (err) {
    console.log("Error in confirmUploadStyles:", JSON.stringify(err));
    return err;
  }
};
module.exports = confirmUploadStyles;
// confirmUploadStyles();