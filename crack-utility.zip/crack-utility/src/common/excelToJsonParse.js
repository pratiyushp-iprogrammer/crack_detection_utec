const json_structure = require('./plans.json');
const { nanoid } = require('nanoid');
const Database = require('../common/database');
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();
const hasIn = require("lodash/hasIn");
const set = require('lodash/set');
const readXlsxFile = require('read-excel-file/node');
const UniqueIdGenerationService = require('../services/uniqueIdGeneration');
let uniqueIdGenerationService = new UniqueIdGenerationService();
const PlansServiceDummy = require('../services/plansServiceDummy');
const tempPlanService = new PlansServiceDummy();
const StatusService = require('../services/statusService');
let statusService = new StatusService();
const check_file_link = async (data, file_links_array) => {
  try {
    const data_list = data.split(",");
    const result = data_list.map((data_item) => {
      return file_links_array.includes(data_item) ? true : false;
    });
    return result.includes(false) ? false : true;
  } catch (err) {
    return err;
  }
};
const excelToJsonParse = async (excel_data, file_link_list_array, queue_id, transaction_id) => {
  console.log("Inside excelToJsonParse Function");
  const finalResult = await readXlsxFile(excel_data.Body).then(async (rows) => {
    const first = new Date();
    console.log('first', first);
    let rowsIndex, columnIndex = '';
    rows.forEach((columns, index1) => {
      columns.forEach((data, index2) => {
        if (columns.includes("Unique ID") && data === "Unique ID") {
          rowsIndex = index1;
          columnIndex = index2;
          return;
        }
      })
      columns.splice(0, columnIndex);
      return;
    });
    rows.splice(0, rowsIndex);
    const headers = rows.shift();
    const valid_data_result_array = [];
    const duplicate_id_result_array = [];
    const invalid_data_entry_array = [];
    const final_array = [];
    console.log('rows.length', rows.length);
    for (const [i, excel_item] of rows.entries()) {
      let temp_json = {};
      const construct_json_body = {};
      let duplicate_id_result = false;
      let invalid_data_entry = false;
      for (const index of excel_item) {
        const i = excel_item.indexOf(index);
        let data = excel_item[i];
        const value = json_structure[headers[i]];//value={ type: 'string', key_name: 'unique_id', required: true }
        const check = hasIn(json_structure, headers[i]);//headers[i]='Unique ID'
        if (check) {
          if (value.type === 'string' && headers[i] !== 'Unique ID') {
            if (typeof (data) !== 'string') {
              invalid_data_entry = true;
              // console.log('1.', headers[i], "----------", data);
            }
          }
          if (value.type === 'number') {
            if (typeof (data) !== 'number') {
              invalid_data_entry = true;
              // console.log('2.', headers[i], "----------", data);
            }
          }
          if (value.type === 'dropdown') {
            if (data.toUpperCase() === "YES" || data.toUpperCase() === "NO") {
              if (value.values.includes(data.toUpperCase())) {
                data = (data.toUpperCase() === 'NO') ? 0 : 1;
              } else {
                invalid_data_entry = true;
                // console.log('3.', headers[i], "----------", data);
              }
            } else if (!(value.values.includes(data))) {
              invalid_data_entry = true;
              // console.log('4.', headers[i], "----------", data);
            }
          }
          if (value.type === 'image_link') {
            const result = await check_file_link(data, file_link_list_array);
            if (!result) {
              invalid_data_entry = true;
              // console.log('5.', headers[i], "----------", data);
            }
          }
          if (headers[i] === 'Unique ID') {
            if (data === null || data === undefined) {
              let params = {};
              params.source = 'DG';
              const response = await uniqueIdGenerationService.generateId(params);
              if (response) {
                const lastRecord = await uniqueIdGenerationService.getLastInsertedRecord();
                let unique_id = `${params.source}_${lastRecord[0].id}`;
                data = unique_id;
              }
            } else {
              duplicate_id_result = true;
            }
          }
          construct_json_body.transaction_id = transaction_id;
          set(construct_json_body, value.key_name, data);
        }
      }
      //Updating record for individual reocrd
      const parsingInprogressStatus = {
        queueId: queue_id,
        status_code: 2,
        message: "Excel data parsing initiated",
        total_records: rows.length,
        total_images: file_link_list_array.length,
        parsing_progress: i
      }
      const updateQueueStatus = await statusService.updateStatus(parsingInprogressStatus);
      console.log('updateQueueStatus', updateQueueStatus);
      //Checking if queue has aborted status code
      const check_queue_status = await statusService.findByQueueId(queue_id);
      if (check_queue_status.status_code == 99) {
        return '';
      }
      if (duplicate_id_result) {
        temp_json.duplicate = true;
        construct_json_body.duplicate = true;
        temp_json.temp = JSON.stringify(construct_json_body);
        temp_json.unique_id = construct_json_body.unique_id;
        temp_json.transaction_id = construct_json_body.transaction_id;
        temp_json.source = construct_json_body.source;
        duplicate_id_result_array.push(construct_json_body);
      }
      if (invalid_data_entry) {
        temp_json.invalid = true;
        construct_json_body.invalid = true;
        temp_json.temp = JSON.stringify(construct_json_body);
        temp_json.unique_id = construct_json_body.unique_id;
        temp_json.transaction_id = construct_json_body.transaction_id;
        temp_json.source = construct_json_body.source;
        invalid_data_entry_array.push(construct_json_body);

      }
      if (duplicate_id_result === false && invalid_data_entry === false) {
        construct_json_body.valid = true;
        temp_json = construct_json_body;
        valid_data_result_array.push(construct_json_body);
      }
      final_array.push(temp_json);
    }
    //Updating status i=once all data is processed and parsed
    const parsingDoneStatus = {
      queueId: queue_id,
      status_code: 3,
      message: "Excel data parsing Done.",
      total_records: rows.length,
      total_images: file_link_list_array.length,
      parsing_progress: rows.length,
      total_valid_records: valid_data_result_array.length
    }
    console.log('parsingDoneStatus', parsingDoneStatus);
    const updateQueueStatusResult = await statusService.updateStatus(parsingDoneStatus);
    console.log('updateQueueStatusResult', updateQueueStatusResult);
    const second = new Date();
    console.log('second', second);
    const difference1 = (second.getTime() - first.getTime()) / 1000;
    console.log('difference1', difference1);
    console.log('valid_data_result_array-------------', valid_data_result_array.length);
    console.log('duplicate_id_result_array-------------', duplicate_id_result_array.length);
    console.log('invalid_data_entry_array-------------', invalid_data_entry_array.length); const third = new Date();
    console.log('third', third);
    await tempPlanService.insert_many(final_array);
    console.log("Data entered in DB sucessfully");
    const forth = new Date();
    console.log('forth', forth);
    const difference2 = (forth.getTime() - third.getTime()) / 1000;
    console.log('difference2', difference2);
    return ([{
      transaction_id,
      valid_data: valid_data_result_array,
      duplicate_plan: duplicate_id_result_array,
      plans_with_errors: invalid_data_entry_array,
      valid_data_length: valid_data_result_array.length,
      duplicate_plan_length: duplicate_id_result_array.length,
      plans_with_errors_length: invalid_data_entry_array.length,
    }]);
  }).catch((err) => {
    const errorStatus = {
      queueId: queue_id,
      status_code: 100,
      message: err,
    }
    console.log('errorStatus', errorStatus);
    // updateQueueStatus = await statusService.updateStatus(errorStatus);
    // console.log('updateQueueStatus', updateQueueStatus);
    return err;
  });
  return finalResult;
}
module.exports = excelToJsonParse;
