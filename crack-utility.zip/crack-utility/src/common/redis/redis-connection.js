const redis = require("ioredis");
const env = process?.env?.DEPLOYMENT || 'dev';
const config = require(`./configs/${env}/redisConfig.json`);

const options = {
    "password" : config.options.password
};

const clusterEnvList = [];
let client = null;
if (!client) {
    console.log(JSON.stringify({ file: 'redis-connection.js', line: 13, message: 'redis connection try to connect' }));
    if (!clusterEnvList?.includes(config?.environment)) {
        client = redis.createClient(config.options.port, config.options.host, options);
    } else {
        client = new redis.Cluster(config.redisCluster);
    }
}

client.on('connect', function() {
    console.log('Redis client connected');
    // redisScheduler.notificationScheduler(logger);
});

client.on('error', (error) => {
    console.log("Error" + error);
});

exports.checkConnection = function(callback){
    client.keys("*", function(error, result) {
        callback(error);
    });
}

exports.redisCacheSet = function(key, value, callback) {
    
    return new Promise((resolve, reject) => {
        client.set(key, value, (err, result) => {
        if (err) {
            return reject(err);
        } else {
            console.log("setting data in redis");
            console.log("Key:" + key);
            // console.log("Value:" + value);
            resolve(result);
        }
        });
    });

}

exports.redisCacheSetExpiry = function(key, value, expiryTime, callback) {
    return new Promise((resolve, reject) => {
        client.set(key, value, function(error, result) {
            if (error) {
                return reject(error);
            }
            console.log("setting data in redis, Key:" + key);
            // Set expire date and resolve it
            client.expire(key, expiryTime);
            resolve(result);
        });
    });
}

exports.redisCacheGet = async function(key, callback) {
    return new Promise((resolve, reject) => {
        client.get(key, (err, result) => {
            if (err) {
                return reject(err);
            }
            console.log("fetching data from redis");
            console.log("Key:" + key);
            // console.log("Value:" + result);
            if (result != null) {
                resolve(result);
            }
            
            resolve(null);
        });
    });
}

exports.redisCacheSadd = function(key, value, callback) {
    client.sadd(key, value, function(error, result) {
        if (error) {
            logger.error(error);
            if(typeof callback === "function"){
                callback(error, null);
            }
        } else {
            logger.debug("setting data in redis");
            if(typeof callback === "function"){
                callback(null, result);
            }
        }
    });
}

exports.redisCacheSmembers = function(key, callback) {
    client.smembers(key, function(error, result) {
        if(error) {
            logger.error(error);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("fetching data from redis");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisKeys = function(key, callback) {
    return new Promise((resolve, reject) => {
        client.keys(key, function(error, result) {
            if(error) {
                console.log(error);
                return reject(err);
           } else {
                console.log("fetching Keys");
                resolve(result);
           }
        });
    })
}
exports.redisCacheHset = function (hkey, key, value, callback) {
    client.hset(hkey, key, value, function(error, result) {
        if (error) {
            logger.error(error);
            if(typeof callback === "function"){
                callback(error, null);
            }
        } else {
            logger.debug("setting data in redis");
            if(typeof callback === "function"){
                callback(null, result);
            }
        }
    });
}

exports.redisHgetall = function (Hkey, callback) {
    client.hgetall(Hkey, function(error, result) {
        if(error) {
            logger.error(error);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("fetching data from redis");
            logger.debug("Key:" + Hkey);
            logger.debug("Value:" + result);
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisCacheDelete = function (key, callback) {
    return new Promise((resolve, reject) => {
        client.del(key, function(error, result) {
            if(error) {
                console.log(error);
                return reject(err);
           } else {
                console.log("deleting data from redis");
                console.log("Key:" + key);
                console.log("Value:" + result);
                resolve(result);
           }
        });
    })
}

exports.redisCacheSismember = function(key, svalue, callback) {

    client.sismember(key, svalue, function(error, result) {
        if(error) {
            logger.error(error);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("fetching data from redis");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisCacheExpire = function(key, time, callback) {
    client.expire(key, time, function(error, result) {
        if(error) {
            console.log(JSON.stringify({ file: 'redis-connection.js', line: 197, error }));
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            console.log("expire time successfully set");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}
exports.redisCacheHmSet = function(key, field, value, callback) {
    logger.debug("key:" + key);
    logger.debug("field: " + field);
    logger.debug("value: " + value);
    client.hmset(key, {[field] : value}, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("successfully Added hash set");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
  }

  exports.redisCacheHmGetAll = function(category, callback) {
    client.hgetall(category, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
  }

  exports.redisCacheHdel = function(category, field, callback) {
    client.hdel(category, field, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("Favourite deleted from Redis");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisCacheHexists = function(category, field, callback) {
    client.hexists(category, field, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisCacheHlen = function(category, key, callback) {
    client.hlen(category, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("size of hash in Redis is:");
            logger.debug(result);
            var obj = {};
            obj.favouriteType = key;
            obj.count = result;
            if(typeof callback === "function"){
                callback(null, obj);
            }
       }
    });
}

exports.redisCacheHmGetIsLiked = function(category, field, callback) {
    client.hget(category, field, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

/* increment hash filed value by 1*/
exports.redisCacheIncrementHashFieldValue = function(field, key, callback) {
    logger.debug("field:" + field);
    logger.debug("key: " + key);
    client.hincrby(field, key, 1, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("increment hash filed value by one");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisCacheHmGetTotalViewCount = function(category, field, callback) {
    logger.debug("redisCacheHmGetTotalViewCount-category: " + JSON.stringify(category));
    logger.debug("redisCacheHmGetTotalViewCount-field: " + JSON.stringify(field));
    client.hget(category, field, function(error, result) {
        if(error) {
            logger.error(error.stack);
            if(typeof callback === "function"){
                callback(error, null);
            }
       } else {
            logger.debug("get resource total view count");
            if(typeof callback === "function"){
                callback(null, result);
            }
       }
    });
}

exports.redisZAdd = function(key, taskDetails, time, callback) {
    client.zadd(key, time, taskDetails, function(error, result) {
        if (error) {
            logger.error(error.stack);
            if(typeof callback === "function") {
                callback(error, null);
            }
        } else {
            logger.debug("Notification Scheduled in Redis");
            if(typeof callback === "function") {
                callback(null, result);
            }
        }
    });
}

exports.redisZRem = function(key, data, callback) {
    client.zrem(key, data, function(error, result) {
        if (error) {
            logger.error(error.stack);
            if(typeof callback === "function") {
                callback(error, null);
            }
        } else {
            if(typeof callback === "function") {
                callback(null, result);
            }
        }
    });
}

exports.redisZRevRangeByScore = function(key, callback) {
    client.zrevrangebyscore([
        key,
        Math.floor(+new Date() / 1000),
        0,
        "WITHSCORES",
        "LIMIT",
        0,
        1
      ], function(error, result) {
        if (error) {
            logger.error(error.stack);
            if(typeof callback === "function") {
                callback(error, null);
            }
        } else {
            if(typeof callback === "function") {
                callback(null, result);
            }
        }
    });
}

exports.redisZScan = function(key, pattern, callback) {
    client.zscan(key, 0, 'MATCH', pattern, function(error, result) {
        if (error) {
            logger.error(error.stack);
            if(typeof callback === "function") {
                callback(error, null);
            }
        } else {
            if(typeof callback === "function") {
                callback(null, result);
            }
        }
    });
}