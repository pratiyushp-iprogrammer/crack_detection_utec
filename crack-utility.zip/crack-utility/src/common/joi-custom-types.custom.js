module.exports = (joi) => {
    return {
        type: "string",
        base: joi.string(),
        messages: {
            "string.validateFile": '"{{#label}}" has an invalid file extensions',
        },
        rules: {
            validateFile: {
                method({ extensions }) {
                    // console.log("extensions: ****************** ", extensions);
                    return this.$_addRule({ name: 'validateFile', args: { extensions } });
                },
                validate(value, helpers, args, options) {
                    const extension = value.split('.').pop().toLowerCase();
                    // console.log("*********** args *********", args);
                    if (args.extensions.includes(extension)) {
                        return value;
                    } else {
                        return helpers.error('string.validateFile', { value });
                    }
                },
            },
        },
    };
};