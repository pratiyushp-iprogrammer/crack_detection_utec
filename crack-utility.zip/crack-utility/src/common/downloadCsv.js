const BaseResponse = require("../common/baseResponse");
const HTTP_CODE = require("../common/constants");
const { Parser } = require("json2csv");
const { S3Client, PutObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();
const plans_json_structure = require('../handlers/plans/plans.json');
const styles_json_structure = require('../handlers/styles/styles.json');


let baseResponse = new BaseResponse();

class DownloadCSV {

    async downloadRecords(event = {},req, data, event_for) {
        try {
            const objRequest = JSON.parse(req.body);
            const fields = objRequest.arrRequiredColumns;
            const columnNameWithKeys = [];
            let json_structure;
            if (event_for === 'plans') {
                json_structure = plans_json_structure;
            }

            if (event_for === 'styles') {
                json_structure = styles_json_structure;
            }
            for (let names in json_structure) {
                const jsonData = {}
                jsonData[json_structure[names].key_name] = names;
                columnNameWithKeys.push(jsonData);
            }
            const columnNames = [];
            fields.forEach(item => {
                var findColName = columnNameWithKeys.find(function (post) {
                    if (Object.keys(post)[0] === item)
                        return true;
                });
                if (findColName) {
                    let field = {};
                    field.label = Object.values(findColName)[0];
                    field.value = Object.keys(findColName)[0];
                    columnNames.push(field)
                }
            })
            const opts = { fields: columnNames };
            // const opts = { fields };
            const parser = new Parser(opts);
            const csvFileContent = parser.parse(data);
            // const filePath = `temp/exported/${event_for}/${event_for}-${baseResponse.getCurrentDateTime()}-${baseResponse.generateFourDigitUniqueID()}.csv`;
            const filePath = `temp/exported/${event_for}/${objRequest.filters.unique_id}_${baseResponse.currentDatetime()}.xlsx`;

            var params = {
                // ACL: "public-read-write",
                Bucket: process.env.UPLOAD_S3_BUCKET,
                Key: filePath,
                Body: csvFileContent,
                ContentType: "application/octet-stream",
                CacheControl: "public, max-age=86400",
            };
            const command = new PutObjectCommand(params);
            const objS3Response = await s3Client.send(command);
            if (objS3Response) {
                console.log(filePath, " uploaded sucessfully on s3", objS3Response);
                const downloadURL = `${process.env.S3_BUCKET_PATH}/${filePath}`;

                let arrResponse = [{ filePath: downloadURL, s3Response: objS3Response, fileName: filePath }];

                return baseResponse.getResponseObject(
                    event,
                    true,
                    HTTP_CODE.SUCCESS,
                    arrResponse,
                    "Plans list exported to csv successfully."
                );
            } else {
                let arrResponse = [{ filePath: "", s3Response: objS3Response }];
                return baseResponse.getResponseObject(
                    event,
                    false,
                    HTTP_CODE.INTERNAL_SERVER_ERROR,
                    arrResponse,
                    "Error while putting csv file to s3 "
                );
            }
        } catch (error) {
            console.log(error);
            return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], "Error while generating csv file: " + error.message);
        }
    }

}
module.exports = DownloadCSV;