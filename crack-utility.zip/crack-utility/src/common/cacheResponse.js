let env = process.env.DEPLOYMENT;
const HTTP_CODE = require('../common/constants');
const redisApiConfig = require(`../config/${env}/redisApiConfig.json`);
const redis = require('../common/redis/redis-connection');
const BaseResponse = require('../common/baseResponse');
let baseResponse = new BaseResponse();

class CacheResponse {
    constructor() {
        this.userId = "";
        this.prefix = "";
        this.requestPath = "";
        this.httpMethod = "";
        this.isCacheable = false;
        let requestBody = "";
        let requestQuery = "";
        this.expiry = 1;
        this.redisCacheKey = "";
        this.keysToBeDeleted = [];

        this.getRequestBody = () => {
            return requestBody;
        }
        this.setRequestBody = (reqBody) => {
            reqBody = JSON.parse(reqBody);
            requestBody = reqBody ? JSON.stringify(this.sortObj(reqBody)) : "";
            console.log("CacheResponse: requestBody:", requestBody)
        }
        this.getRequestQuery = () => {
            return requestQuery;
        }
        this.setRequestQuery = (reqQuery) => {
            requestQuery = reqQuery ? JSON.stringify(this.sortObj(reqQuery)) : "";
            console.log("CacheResponse: requestQuery:", requestQuery)
        }
    }

    sortObj(x) {
        if (typeof x !== 'object' || !x)
            return x;
        if (Array.isArray(x)) {
            return x.sort().map(this.sortObj.bind(this));
        }
        return Object.keys(x).sort().reduce((o, k) => ({ ...o, [k]: this.sortObj.call(this, x[k]) }), {});
    }

    setRequestDetails(userId, request) {
        this.userId = userId || "anon";
        this.requestPath = request.path;
        this.httpMethod = request.httpMethod;
        let apiConfig = redisApiConfig[this.requestPath];

        console.log("CacheResponse:request.path:", this.requestPath, this.httpMethod, typeof request.body);
        this.setRequestBody(request.body);
        this.setRequestQuery(request.queryStringParameters);
        this.keysToBeDeleted = apiConfig.deleteKeys;
        this.isCacheable = (apiConfig && apiConfig['cacheable'] && this.httpMethod == 'GET' ||
            (apiConfig && apiConfig["post"] && apiConfig["post"]['cacheable'])) || false;
        console.log("this.getRequestBody():", this.getRequestBody());
        if (this.isCacheable) {
            this.prefix = apiConfig.prefix || "";
            this.expiry = apiConfig.ttl || 1;
            this.redisCacheKey = [this.prefix, this.userId,
            this.getRequestBody(), this.getRequestQuery(), this.requestPath].join("_");
        }
        console.log("CacheResponse: redisCacheKey:", this.isCacheable, this.redisCacheKey);
    }

    async getCacheResponse(userId, request) {
        let cacheResponse = { status: false, data: null };
        try {
            this.setRequestDetails(userId, request);
            if (this.isCacheable) {
                //get from cache
                let redisResult = await redis.redisCacheGet(this.redisCacheKey);
                console.log("CacheResponse: redisResult:", typeof redisResult);
                if (redisResult) {
                    redisResult = JSON.parse(redisResult);
                    let { status, statusCode, payload, message } = redisResult;
                    cacheResponse = {
                        status: true,
                        data: baseResponse.getResponseObject(request, status, statusCode, payload, message)
                    };
                }
            }
        } catch (e) {
            console.log("CacheResponse: getCacheResponse error:", e);
        }
        console.log("CacheResponse: cacheData:", JSON.stringify(cacheResponse));
        return cacheResponse;
    }

    async respond(event = {}, status = true, statusCode = HTTP_CODE.SUCCESS, payload = [], message = '') {
        //store in cache if cacheable
        console.log("CacheResponse: response isCacheable:", this.isCacheable);
        if (this.isCacheable) {
            try {
                let cacheObj = {
                    status, statusCode, payload, message
                };
                console.log("CacheResponse: caching response:", this.redisCacheKey, this.expiry);
                await redis.redisCacheSetExpiry(this.redisCacheKey, JSON.stringify(cacheObj), this.expiry);
            } catch (e) {
                console.log("CacheResponse: Unable to cache response:", e);
            }
        }
        //respond
        return baseResponse.getResponseObject(event, status, statusCode, payload, message);
    }

    async clearCache(userId, request, type) {
        try {
            this.setRequestDetails(userId, request);
            //find keys with prefix
            console.log("CacheResponse: keysToBeDeleted:", type, this.keysToBeDeleted);
            this.keysToBeDeleted = this.keysToBeDeleted.filter(k => type == null || k.type == type);
            for (let { prefix } of this.keysToBeDeleted) {
                let keyPrefix = prefix + "_" + this.userId + "*";
                console.log("CacheResponse: keyPrefix:", keyPrefix)
                let keys = await redis.redisKeys(keyPrefix);
                console.log("CacheResponse: keys", keys);

                //loop keys & delete
                for (let key of keys) {
                    await this.deleteCacheKey(key);
                }
            }
            return { status: true };
        } catch (e) {
            console.log("CacheResponse: clearCache error:", e);
            return { status: false };
        }
    }

    async deleteCacheKey(key) {
        console.log("CacheResponse: deleteCacheKey:", key);
        await redis.redisCacheDelete(key);
    }

    async clearRelevantCache(uniqueId, event, type){
        try {
            const identifier = uniqueId || "anon";
            const apiConfig = redisApiConfig[event.path]["deleteKeys"];
            const filtered = apiConfig.filter(el => type == null || el.type == type );
            for (let { prefix, suffix } of filtered) {
                const key = `${prefix}_${identifier}___${suffix}`;
                await redis.redisCacheDelete(key);
            }
            return true;
        } catch (error) {
            console.log(JSON.stringify({ file: 'service.js', line: 370, error }));
            throw error;
        }
    }

}

module.exports = CacheResponse;