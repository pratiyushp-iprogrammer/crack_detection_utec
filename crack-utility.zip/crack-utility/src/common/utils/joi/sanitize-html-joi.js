const BaseJoi = require("joi");
const { required } = require("joi");
const { dateFormatHypenYMD, dateFormatSlashYMD, mobileRegex, pinCodeRegix } = require("./joi-custom-input-rules");
const customType = require("./joi-custom-types.custom.js");
const Joi = BaseJoi.extend(customType);

const StringInput = Joi.string().trim().htmlStrip(); // .unescape();
const NumberInput =Joi.number().positive().integer();
const ValidateRange = StringInput.validateRange();

const stringRequirdMessage = "is required.";
module.exports.stringOptions = {
    messages: {
        string: {
            regex: {
                base: stringRequirdMessage,
            },
            base: stringRequirdMessage,
        },
    },
};
const numberOptions = {
    messages: {
        number: {
            base: "is required.",
        },
        any: {
            allowOnly: "invalid",
        },
    },
};

// "string.pattern.base": "Please enter a valid numeric PIN."

module.exports.inputDateSlashYMD = StringInput.pattern(new RegExp(dateFormatSlashYMD)).options({
    messages: {
        // "string.pattern.base": "{{#label}} should be a date."
        en_US: {
            "string.pattern.base": "{{#label}} should be a date.",
        },
    },
});
const inputDateHypenYMD = StringInput.pattern(new RegExp(dateFormatHypenYMD)).options({
    messages: {
        // "string.pattern.base": "{{#label}} should be a date."
        en_US: {
            "string.pattern.base": "{{#label}} should be a date.",
        },
    },
});

const ValidateDateRange = inputDateHypenYMD.validateDateRange();
module.exports.DateRangeAlternatives = Joi.alternatives()
    .try(inputDateHypenYMD, ValidateDateRange)
    .options({
        messages: {
            // "alternatives.match": "Invalid {{#label}} range format."
            en_US: {
                "alternatives.match": "Invalid {{#label}} range format.",
            },
        },
    });
module.exports.tableDefaultParams = {
    pageNumber: NumberInput.options(numberOptions),
    pageSize: NumberInput.options(numberOptions),
    sortField: StringInput.allow(""),
    sortOrder: StringInput.lowercase().allow(""),
};

module.exports.StringInput = StringInput;
module.exports.NumberInput = Joi.number().positive().integer();
module.exports.CapFirstLetter = StringInput.capFirst();
module.exports.ValidateRange = ValidateRange;
module.exports.RangeAlternatives = Joi.alternatives().try(Joi.number().positive(), ValidateRange);
module.exports.numberOptions = numberOptions;
module.exports.ValidateDateRange = ValidateDateRange;
module.exports.inputDateHypenYMD = inputDateHypenYMD;