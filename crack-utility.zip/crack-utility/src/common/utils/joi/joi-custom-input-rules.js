module.exports.mobileRegex = /^([4-9][0-9]{9,11})$/;
module.exports.dateFormatSlashYMD = /([12]\d{3}\/(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01]))/;
module.exports.dateFormatHypenYMD = /^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))$/;
module.exports.pinCodeRegix = /^[1-9][0-9]{5}$/;
module.exports.rangeFormat = /^\d:\d$/;
module.exports.emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/;
// module.exports.emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
module.exports.rangeDateFormatHypenYMD = /^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])):([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))$/;
module.exports.csvInjectionRegex = /^[+=@-].*/;
