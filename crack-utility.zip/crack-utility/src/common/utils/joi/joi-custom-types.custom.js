const _ = require("lodash");
const sanitizeHtml = require("sanitize-html");
const { dateFormatHypenYMD, rangeDateFormatHypenYMD, rangeFormat, csvInjectionRegex } = require("./joi-custom-input-rules");
module.exports = (joi) => {
    return {
        type: "string",
        base: joi.string(),
        messages: {
            "string.htmlStrip": '"{{#label}}" content invalid',
            "string.capFirst": '"{{#label}}" content invalid',
            "string.csvSanetize": '"{{#label}}" content invalid',
            "string.csvInjection": '"{{#label}}" content invalid',
            "string.validMobile": '"{{#label}}" content invalid',
            "string.validateRange": '"{{#label}}" invalid range',
            "string.validateDateRange": 'invalid "{{#label}}" date range format',
            "string.validateDateRange.min": "From Date should be less than To Date: {{#value}}",
            "string.validateDate": 'invalid "{{#label}}" date format',
            "string.validateDate.min": '{{#label}} date should not be less than: 1920-01-01',
            "string.validateFile": '{{#label}} has an invalid file extensions',
        },
        rules: {
            validateFile: {
                method({ extensions }) {
                    return this.$_addRule({ name: 'validateFile', args: { extensions } });
                },
                validate(value, helpers, args, options) {
                    const extension = value.split('.').pop().toLowerCase();
                    if (args.extensions.includes(extension)) {
                        return value;
                    } else {
                        return helpers.error('string.validateFile', { value });
                    }
                },
            },
            unescape: {
                validate(value, helpers, args, options) {
                    const clean = _.unescape(value);
                    if (clean) {
                        return clean;
                    }

                    return helpers.error("string.unescape", { value });
                },
            },
            sanetize: {
                validate(value, helpers, args, options) {
                    const clean = value.replace(/[|&;$%@"<>()+,]/g, "");
                    if (clean) {
                        return clean;
                    }

                    return helpers.error("string.sanetize", { value });
                },
            },
            // Protect against CSV injection - ensure cells don't have ( ), or start with = @ + - unless followed by digit
            csvSanetize: {
                validate(value, helpers, args, options) {
                    const clean = value
                        .replace(/([()])/g, "")
                        .replace(/(^|[,\n\r])([=@+-]+)(?=[\D\.])/g, (match, offset, string) => {
                            return match.replace(/[^,\n\r]/g, "");
                        });
                    if (clean) {
                        return clean;
                    }

                    return helpers.error("string.csvSanetize", { value });
                },
            },
            csvInjection: {
                validate(value, helpers, args, options) {
                    const clean = value;
                    return csvInjectionRegex.test(clean) ? helpers.error("string.csvInjection", { value }) : clean;
                },
            },
            capFirst: {
                validate(value, helpers, args, options) {
                    const clean = _.startCase(_.toLower(value));
                    if (clean) {
                        return clean;
                    }
                    return helpers.error("string.capFirst", { value });
                },
            },
            validMobile: {
                validate(value, helpers, args, options) {
                    if (value && value.length) {
                        if (value.length > 10) {
                            return value.slice(-10);
                        }
                        return value;
                    }
                    return helpers.error("string.validMobile", { value });
                },
            },
            validateRange: {
                validate(value, helpers, args, options) {
                    if (value && value.length && rangeFormat.test(value)) {
                        const splitArray = value.split(":");
                        const fromFieldValue = parseFloat(splitArray[0]);
                        const toFieldValue = parseFloat(splitArray[1]);
                        if (fromFieldValue !== null && toFieldValue !== null && fromFieldValue < toFieldValue) {
                            return value;
                        }

                        return helpers.error("string.validateRange", { value });
                    }
                },
            },
            // Removes HTML tags from string
            htmlStrip: {
                validate(value, helpers, args, options) {
                    const clean = sanitizeHtml(value, {
                        allowedTags: [],
                        allowedAttributes: {},
                    });

                    if (clean) {
                        return _.unescape(clean);
                    }

                    return helpers.error("string.htmlStrip", { value });
                },
            },
            validateDateRange: {
                validate(value, helpers, args, options) {
                    if (value && value.length && !rangeDateFormatHypenYMD.test(value)) {
                        return helpers.error("string.validateDateRange", { value });
                    }
                    const splitArray = value.split(":");
                    const fromFieldValue = splitArray[0];
                    const toFieldValue = splitArray[1];
                    const isFromField = dateFormatHypenYMD.test(splitArray[0]);
                    const isToField = dateFormatHypenYMD.test(splitArray[1]);
                    // const isValidaDates = (new Date(fromFieldValue) < new Date(toFieldValue));
                    const isValidaDates = new Date(fromFieldValue).getTime() <= new Date(toFieldValue).getTime();

                    if (fromFieldValue !== null && toFieldValue !== null && isFromField && isToField && isValidaDates) {
                        return value;
                    }
                    return helpers.error("string.validateDateRange.min", { value });
                },
            },
            validateDate: {
                validate(value, helpers, args, options) {
                    if (!value) {
                        return helpers.error("string.validateDate", { value });
                    }
                    const isValidaDates = new Date("1920-01-01").getTime() <= new Date(value).getTime();
                    if (isValidaDates !== null && isValidaDates) {
                        return value;
                    }
                    return helpers.error("string.validateDate.min", { value });
                },
            },
        },
    };
};
