	CREATE TABLE temp_DM_SrMigration (
                module_id VARCHAR(250),
                last_update VARCHAR(250),
                updated_value VARCHAR(250),
                sr_info JSON,
                case_info JSON,
                sr_id VARCHAR(250),
                linked_id VARCHAR(250),
                delivery JSON,
                pincode_id VARCHAR(10),
                state_name VARCHAR(50), 
                city_name VARCHAR(50),
                district_name VARCHAR(50), 
                latitude VARCHAR(50),
                longitude VARCHAR(50), 
                geo_pincode VARCHAR(10),
                request_type_id VARCHAR(5),
                total_built_up_area VARCHAR(50)
                );

DELIMITER $$
DROP PROCEDURE IF EXISTS sqlToMongoMigration;

CREATE PROCEDURE sqlToMongoMigration(IN input JSON)
sqlToMongoMigration:BEGIN
  DECLARE code CHAR(5) DEFAULT '00000';
  DECLARE result json DEFAULT JSON_ARRAY();
  DECLARE ifDataExist VARCHAR(255);
  DECLARE msg TEXT;
  DECLARE i,limiting,offsetting INT DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET DIAGNOSTICS CONDITION 1
      code = RETURNED_SQLSTATE, msg = MESSAGE_TEXT;          
    SELECT JSON_OBJECT('status', 'FAILURE', 'message', msg, 'data', JSON_OBJECT('statusCode', 500), 'statusCode', 500) AS response;
  END;

IF JSON_TYPE(input) <> "OBJECT" THEN
SELECT JSON_OBJECT("status", "FAILURE", "statusCode", 500, "message", "Invalid input", "data", JSON_OBJECT(), "error", JSON_OBJECT("message", "Invalid input", "details", JSON_ARRAY())) AS response;
LEAVE sqlToMongoMigration;
END IF;
  SET offsetting = JSON_UNQUOTE(JSON_EXTRACT(input, '$.OFFSET'));
  SET limiting = JSON_UNQUOTE(JSON_EXTRACT(input, '$.LIMIT'));


  INSERT INTO temp_DM_SrMigration (module_id, last_update, updated_value,sr_info,case_info,sr_id,linked_id, delivery,pincode_id, 
    state_name, city_name, district_name, latitude, longitude, geo_pincode, request_type_id, total_built_up_area)
  SELECT t2.module_id, t2.last_update, t2.updated_value,t2.sr_info,t2.case_info,t2.id,t2.linked_id,t2.delivery,t2.pincode_id,
  t2.state_name, t2.city_name, t2.district_name, t2.latitude, t2.longitude, t2.pincode, t2.request_type_id, t2.total_built_up_area
    FROM
    (SELECT t1.module_id, t1.last_update, t1.updated_value, t1.sr_info, t1.case_info,t1.id,t1.linked_id,t1.delivery, t1.pincode_id,
        t1.state_name, t1.city_name, t1.district_name, t1.latitude, t1.longitude, t1.pincode,t1.request_type_id, t1.total_built_up_area
        FROM
        (SELECT distinct ch.module_id, ch.last_update, ch.updated_value,srd.sr_info, srd.case_info,sr.id,sr.linked_id, srd.delivery, sr.pincode_id,
        ult.state_name, ult.city_name, ult.district_name, ult.latitude, ult.longitude, ult.pincode,sr.request_type_id,  sd.total_built_up_area
          FROM service_requests AS sr
          LEFT JOIN service_request_details AS srd ON sr.id = srd.service_requests_id
          LEFT JOIN change_history AS ch ON ch.module_id = srd.service_requests_id
          LEFT JOIN user_locations_table AS ult ON ult.id = sr.pincode_id 
          LEFT JOIN site_details AS sd ON sd.id = sr.site_id
          WHERE ch.sub_field = 'request_status' AND 
          sr.request_type_id IN ('18','19') AND (JSON_UNQUOTE(JSON_EXTRACT(srd.case_info,'$.iterationCount')) IN (0, 'null') OR JSON_EXTRACT(srd.case_info,'$.iterationCount') IS null)
          AND ch.updated_value IN ('8','30') 
          order by ch.last_update desc
          ) t1 group by t1.module_id) t2
          LIMIT limiting OFFSET offsetting;
          
    SELECT JSON_OBJECT("status", "SUCCESS", "statusCode", 200, "message", "Data Added Successfully") AS response;     
END sqlToMongoMigration$$;
DELIMITER ;