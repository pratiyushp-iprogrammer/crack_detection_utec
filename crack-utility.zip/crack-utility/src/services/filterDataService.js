const Filter = require('../models/filter');

class FilterService {
  async createFilter(data) {
    try {
      const objFilter = new Filter(data);
      const result = await objFilter.save();
      if (result) {
        return true
      }
      return false
    } catch (error) {
      console.log(error);
    }
  }
  async findByUserId(id, Type) {
    try {
      const result = await Filter.findOne({ userId: id, type: Type });
      if (result === null) return false;
      return true;
    } catch (error) {
      console.log(error);
    }
  }
  async fetchFilterDetails(id, Type) {
    try {
      const result = await Filter.find({ userId: id, type: Type }).sort({ created_at: 1 }).lean();
      if (result === null) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
}

module.exports = FilterService;