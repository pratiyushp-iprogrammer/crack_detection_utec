const UserProfileAction = require('../models/userProfileAction');
const Plans = require('../models/plans.js');

class UserProfileActionService {

    async create(data) {
        try {
            const userProfileAction = new UserProfileAction(data);
            const result = await userProfileAction.save();
            if (result) {
                return true
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async checkRecord(id, userId, eventFor, action) {
        try {
            const result = await UserProfileAction.findOne({ object_id: id, user_id: userId, event_for: eventFor, action: action });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async checkUserRecord(id, userId) {
        try {
            const result = await UserProfileAction.findOne({ object_id: id, user_id: userId });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async remove(_id, userId, eventFor, action) {
        try {
            const result = await UserProfileAction.deleteOne({ object_id: _id, user_id: userId, event_for: eventFor, action: action });
            return result;
        } catch (error) {
            console.log(error);
        }
    }


    async getActionCountData(styleObjectId) {
        try {
            if (styleObjectId === undefined || styleObjectId === null) {
                return false;
            }

            const result = await UserProfileAction.aggregate([{
                    "$match": {
                        "object_id": styleObjectId,
                    }
                },
                {
                    "$group": {
                        "_id": {
                            "action": "$action"
                        },
                        "count": {
                            "$sum": 1
                        }
                    }
                },
                {
                    "$project": {
                        "action": "$_id.action",
                        "count": "$count"
                    }
                }
            ]);

            if (result === null) return false;

            let counts = {};
            result.forEach(element => {
                counts[element.action] = element.count;
            });

            let arrAction = ["favourite", "like"];
            arrAction.forEach(action => {
                if (!counts.hasOwnProperty(action)) {
                    counts[action] = 0;
                }
            });

            return counts;
        } catch (error) {
            console.log(error.message);
        }        
    }
    
    async getCountData(styleObjectId, userId) {
        try {
            if (styleObjectId === undefined || styleObjectId === null || userId === undefined || userId === null ) {
                return false;
            }

            const result = await UserProfileAction.aggregate([
                    {
                        $match: { object_id : styleObjectId, "user_id": userId } 
                    }, 
                   
                    {
                        $group : {
                            "_id": {
                                "_id": "$_id",
                                "action": "$action",
                                "event_for": "$event_for",
                                "user_id" : "$user_id"
                            },
                            "likeCount": {
                                "$sum": 1
                            },
                        }
                    },
                    
                    {
                        $project: {
                            // _id : "$_id._id",
                            isFavourite: {
                                $cond: { if: { $and: [ { $eq: [ "$_id.action", "favourite" ] }, { $eq: ["$_id.user_id", userId]}] },  then: true, else: false}
                            },
                            isLiked: {
                                $cond: { if: { $and: [ { $eq: [ "$_id.action", "like" ] }, { $eq: ["$_id.user_id", userId]}] },  then: true, else: false}, 
                            },
                            likeCount: {
                                $cond: { if: { $and: [ { $eq: [ "$_id.action", "like" ] }, { $eq: ["$_id.user_id", userId]}] },  then: "$likeCount", else: 0},     
                            },
                            // user_id : "$_id.user_id"
                        //   $and: [ { $eq: [ "$_id.action", "favourite" ] }, { $eq: ["$_id.user_id", 11100]}]
                        }
                    },
                
                ]);

            if (result.length === 0) return false;
            console.log(JSON.stringify(result));
            return result;
        } catch (error) {
            console.log(error.message);
        }
    }

    async listFavouritePlans(params) {
        try {
            let pipeline = [];

            let match = {
                "$match": {
                    "event_for": params.event_for,
                    "action": params.action,
                    "user_id": params.user_id
                }
            }

            let lookup = {
                "$lookup": {
                    "from": "plan_style_designs",
                    "localField": "object_id",
                    "foreignField": "_id",
                    "as": "data"
                }
            }

            let unwind = {
                "$unwind": "$data"
            }

            let project = {
                "$project": {
                    plan_id: "$data._id",
                    resourcePath: { "$ifNull": ["", ""] },
                    // imageUrl: { "$ifNull": ["$data.files.two_d_line_drawing_jpg.ground", ""] },
                    imageUrl: "",
                    imageRender2dUrl: { "$ifNull": ["$data.files.two_d_rendered_plan_jpg.ground", []] },
                    unique_id: "$data.unique_id",
                    area: { "$ifNull": ["$data.plot_details.plot_area", ""] },
                    suitablePlotArea: { "$ifNull": ["$data.plot_details.plot_area", ""] },
                    title: { "$ifNull": ["$data.unique_id", ""] },
                    numberOfFloors: { "$ifNull": ["$data.project_details.floors", ""] },
                    floors: { "$ifNull": ["$data.project_details.floors", ""] },
                    entryFacing: { "$ifNull": ["$data.vaastu_compliancy.entry_direction", ""] },
                    numberOfRooms: { "$ifNull": ["$data.project_details.bedrooms", 0] },
                }
            };

            pipeline.push(match, lookup, unwind, project);
            const docs = await UserProfileAction.aggregate(pipeline).allowDiskUse(true).exec();

            if (!docs) {
              console.error('Error in aggregation');
              return false;
            }
            return docs;
        } catch (error) {
            console.log(error);
        }
    }

    async listFavouriteStyles(params) {
        try {
            let pipeline = [];

            let lookup = {
                $lookup: {
                    from: "styles",
                    localField: "object_id",
                    foreignField: "_id",
                    as: "data"
                }
            }

            let match = {
                $match: {
                    event_for: params.event_for,
                    action: params.action,
                    user_id: params.user_id
                }
            }

            let unwind = {
                $unwind: "$data"
            }

            let group = {
                $group: {
                    _id: "$data.element_type",
                    count: { "$sum": 1 },
                    details: {
                        $push: {
                            _id: "$_id",
                            style_id: '$data._id',
                            front: '$data.files.three_d_design_id.front',
                            image_files: '$data.image_files',
                            unique_id: '$data.unique_id',
                            element_type: '$data.element_type'
                        }
                    }
                }
            }


            let project = {
                $project: {
                    _id: 0,
                    element_type: '$_id',
                    count: "$count",
                    data: "$details"
                }
            };

            pipeline.push(lookup, match, unwind, group, project);
            const result = await UserProfileAction.aggregate(pipeline).allowDiskUse(true).exec();
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = UserProfileActionService;