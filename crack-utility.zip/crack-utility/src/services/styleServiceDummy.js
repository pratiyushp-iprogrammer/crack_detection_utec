const Styles = require('../models/styleDummy');
class StylesServiceDummy {
  async insert_many(items) {
    try {
      await Styles.insertMany(items);//TODO: handle error correctly
    } catch (error) {
      console.log(error);
    }
  }
  async findByTransactionId(transactionId) {
    try {
      const result = await Styles.find({ transaction_id: transactionId });
      if (result.length === 0) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
  async findByAllTransactionId(transactionId) {
    try {
      const result = await Styles.find({ transaction_id: transactionId });
      if (result.length === 0) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
  async deleteRecords(transactionId, uniqueId) {
    try {
      let result = '';
      if (uniqueId)
        result = await Styles.deleteOne({ transaction_id: transactionId, unique_id: uniqueId, duplicate: 1 });
      else
        result = await Styles.deleteMany({ transaction_id: transactionId, duplicate: 1 });
      if (result.length === 0) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
}
module.exports = StylesServiceDummy;