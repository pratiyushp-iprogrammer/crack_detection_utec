const UniqueId = require('../models/uniqueIdSchema');

class UniqueIdService {
    async generateId(data) {
        try {
            const obj = new UniqueId(data);
            const result = await obj.save();
            if (result) {
                return true
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async getLastInsertedRecord() {
        try {
            const result = await UniqueId.find({}).sort({ 'created_at': -1 }).limit(1);
            return result;
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = UniqueIdService;