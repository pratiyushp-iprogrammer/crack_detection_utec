const StyleUsageData = require('../models/styleUsagaData.js');
const Styles = require('../models/styles');

class StyleUsageDataService {

    /**
     * Save style usage data
     * @param {Object} data 
     * @returns {Object}
     */
    async create(data) {
        try {
            const objUsageData = new StyleUsageData(data);
            const result = await objUsageData.save();
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    /**
     * Remove record
     * @param {ObjectId} _id 
     * @returns {Array}
     */
    async remove(_id) {
            try {
                const result = await StyleUsageData.deleteOne({ _id });
                return result;
            } catch (error) {
                console.log(error);
            }
        }
        /**
         * Fetch action details count
         * @param {ObjectId} styleId 
         * @returns {Array}
         */
    async getActionCount(styleId, userId) {
        try {
            const result = await StyleUsageData.aggregate([{
                    "$match": {
                        "style_id": styleId,
                        "$and": [
                            { "user_id": userId }
                        ]
                    }
                },
                {
                    "$group": {
                        "_id": {
                            "action": "$action"
                        },
                        "count": {
                            "$sum": 1
                        }
                    }
                },
                {
                    "$project": {
                        "action": "$_id.action",
                        "count": "$count"
                    }
                }
            ]);
            let counts = {};
            result.forEach(element => {
                counts[element.action] = element.count;
            });

            let arrAction = ["reuse", "like", "view", "save", "share", "download", "customization"];
            arrAction.forEach(action => {
                if (!counts.hasOwnProperty(action)) {
                    counts[action] = 0;
                }
            });

            return counts;
        } catch (error) {
            console.log(error.message);
        }
    }
    async getDataFromStyles(_id) {
        try {
            if (_id === undefined || _id === null) {
                return false;
            }
            let fields = { created_at: 1, updated_at: 1, created_by: 1, updated_by: 1, unique_id: 1 };
            const result = await Styles.findById({ _id }, fields);
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error.message);
        }
    }

    async getReusedStyles(styleId) {
        try {
            if (styleId === undefined || styleId === null) {
                return false;
            }
            let fields = { sr_tracker_number: 1, action: 1, user_id: 1, created_at: 1 };
            const result = await StyleUsageData.find({ "style_id": styleId }, fields);
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error.message);
        }
    }
}

module.exports = StyleUsageDataService;