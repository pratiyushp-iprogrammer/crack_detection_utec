const FileLinks = require('../models/file_links');

class FileLinksService {
  async saveFileLinks(data) {
    try {
      const objFileLink = new FileLinks(data);
      const result = await objFileLink.save();
      if (result) {
        return result._id;
      }
      return false
    } catch (error) {
      console.log(error);
    }
  }

  async findById(id) {
    try {
      const result = await FileLinks.find({ _id: id });
      if (result.length === 0) return false;
      return result[0].file_links;
    } catch (error) {
      console.log(error);
    }
  }
}

module.exports = FileLinksService;