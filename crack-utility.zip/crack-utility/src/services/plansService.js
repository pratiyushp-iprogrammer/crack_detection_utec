const Plans = require('../models/plans.js');
const planStyleDesigns = require('../models/planStyleDesigns.js');
const QueryBuilder = require('../common/queryBuilder');
const BaseResponse = require('../common/baseResponse');
const json_structure = require('../handlers/plans//additionalMetaTags.json');
const hasIn = require("lodash/hasIn");
const set = require('lodash/set');
const uniqBy = require('lodash/uniqBy')

let baseResponse = new BaseResponse();

let queryBuilder = new QueryBuilder();

class PlansService {

    isEmpty(value) {
        let isValid = true;
        if (typeof value == "string") {
            isValid = (value === undefined || value == null || value.length <= 0) ? true : false;
        }
        if (typeof value == "object") {
            if (Object.keys(value).length > 0) {
                const isBelowThreshold = (currentValue) => (currentValue === null || currentValue.length == 0);
                let arrToCheck = Object.values(value);
                let checkedArr = arrToCheck.every(isBelowThreshold);
                isValid = checkedArr ? true : false;
                return isValid;
            }
            isValid = (value === undefined || value == null || Object.keys(value).length <= 0) ? true : false;
        }
        return isValid;
    }

    async fetch(event) {
        try {
            const objRequest = JSON.parse(event.body);
            let match_percentage = (objRequest.match_percentage) ? objRequest.match_percentage : false;
            const objRequiredColumns = queryBuilder.formatRequiredColumns(objRequest.arrRequiredColumns);
            if (this.isEmpty(objRequest.searchString) && this.isEmpty(objRequest.filters)) {
                const totalRecordsCount = await Plans.countDocuments({ "is_active": 1 });
                let options = {};
                options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
                options.limit = objRequest.pagination.limit;
                options.sort = { "created_at": -1 };
                if (objRequest?.sort && objRequest?.sort?.column_name) {
                    delete options["sort"]["created_at"];
                    options["sort"][objRequest?.sort?.column_name] = objRequest?.sort?.order === 'desc' ? -1 : 1;
                }
                const docs = await Plans.find({ "is_active": 1 }, objRequiredColumns, options);
                docs["totalRecordsCount"] = totalRecordsCount;
                return docs;
            } else {
                const countPipeline = queryBuilder.buildQueryCount(objRequest, 'plans', match_percentage);
                console.log(JSON.stringify({ countPipeline }));
                const totalCount = await Plans.aggregate(countPipeline).allowDiskUse(true).exec();
                console.log(JSON.stringify({ totalCount }));
                // objRequest['totalIsActiveCount'] = totalRecords;
                const pipeline = queryBuilder.buildQuery(objRequest, 'plans', match_percentage);
                const docs = await Plans.aggregate(pipeline).allowDiskUse(true).exec();
                docs["totalRecordsCount"] = totalCount[0]?.totalRecords || 0;
                return docs;
            }
        } catch (error) {
            throw error;
        }
    }
    async createPlan(data) {
        try {
            const objPlan = new Plans(data);
            const result = await objPlan.save();
            if (result) {
                return true
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async updatePlan(params) {
        try {
            console.log("Inside Update Plan");
            let result = await Plans.updateOne({ unique_id: params.unique_id }, params, { upsert: true, timestamps: false});
            console.log("updatePlan result=> ", result);
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async findByUniqueId(uniqueId) {
        try {
            const result = await Plans.findOne({ unique_id: uniqueId, is_active: 1 });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async findByUniqueIdV2(uniqueId) {
        try {
            const result = await planStyleDesigns.findOne({ unique_id: uniqueId, is_active: 1 });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async findByTransactionId(transactionId) {
        try {
            const result = await Plans.find({ transaction_id: transactionId });
            if (result === null) return false;
            return true;
            // return result;
        } catch (error) {
            console.log(error);
        }
    }
    async findOneById(_id) {
        try {
            if (_id === undefined || _id === null) {
                return false;
            }
            const result = await Plans.findById({ _id });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }
    async insert_many(items) {
        try {
            console.log('items.length', items.length);
            const result = await Plans.insertMany(items); //TODO: handle error correctly
            console.log('result.length', result.length);
            console.log('result', JSON.stringify(result));
            if (result === null) return false;
            return true;
        } catch (error) {
            if (error)
                return error;
        }
    }
    async fetchPlanDetails(uniqueId) {
        try {
            const result = await Plans.findOne({ unique_id: uniqueId }).lean();
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async getCount() {
        try {
            const result = await Plans.countDocuments();
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async getDistictValues(columnName) {
        try {
            const result = await Plans.distinct(columnName);
            return result;
        } catch (error) {
            console.log(error);
        }
    }
    async getUniqueIdDataSet(items) {
        try {
            const result = await Plans.find({ unique_id: { $in: items }, is_active: 1 });
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async fetchHomeDesigns(event) {
        try {
            const objRequest = JSON.parse(event.body);
            if (objRequest.filter.plotAreas && typeof objRequest.filter.plotAreas === "number") {
                const newRange = baseResponse.getRange(objRequest.filter.plotAreas, "plot_details.plot_area", "plans");
                let newPlotAreas
                if (newRange[0].includes("<")) {
                    newPlotAreas = [{
                        min: 0,
                        max: 10
                    }];
                } else if (newRange[0].includes(">")) {
                    newPlotAreas = [{
                        min: 9999,
                        max: 99999
                    }];
                } else {
                    const newArrRange = newRange.split("-");
                    newPlotAreas = [{
                        min: parseInt(newArrRange[0]),
                        max: parseInt(newArrRange[1])
                    }];
                }
                objRequest.filter.plotAreas = newPlotAreas;
            }
            if (objRequest.filter.plotWidth && typeof objRequest.filter.plotWidth === "number") {
                const newRange = baseResponse.getRange(objRequest.filter.plotWidth, "plot_details.plot_width", "plans");
                const newArrRange = newRange.split("-");
                let newPlotWidth;
                if (newRange[0].includes("<")) {
                    newPlotWidth = [{
                        min: 0,
                        max: 10
                    }];
                } else if (newRange[0].includes(">")) {
                    newPlotWidth = [{
                        min: 999,
                        max: 9999
                    }];
                } else {
                    newPlotWidth = [{
                        min: parseInt(newArrRange[0]),
                        max: parseInt(newArrRange[1])
                    }]
                }
                objRequest.filter.plotWidth = newPlotWidth;
            }
            if (this.isEmpty(objRequest.filter)) {
                const totalRecordsCount = await Plans.countDocuments({ "is_active": 1 });
                let pipeline = [];

                let match = {
                    "$match": {
                        "is_active": 1
                    }
                };

                let project = {
                    "$project": {
                        resourcePath: { "$ifNull": ["", ""] },
                        imageUrl: { "$ifNull": ["$files.two_d_line_drawing_jpg.ground", ""] },
                        imageRender2dUrl: { "$ifNull": ["$files.two_d_rendered_plan_jpg.ground", ""] },
                        unique_id: "$unique_id",
                        area: { "$ifNull": ["$plot_details.plot_area", ""] },
                        suitablePlotArea: { "$ifNull": ["$plot_details.plot_area", ""] },
                        title: { "$ifNull": ["$design_name", ""] },
                        numberOfFloors: { "$ifNull": ["$project_details.floors", ""] },
                        floors: { "$ifNull": ["$project_details.floors", ""] },
                        entryFacing: { "$ifNull": ["$vaastu_compliancy.entry_direction", ""] },
                        numberOfRooms: { "$ifNull": ["$project_details.bedrooms", 0] },
                    }
                };
                let skipValue = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
                let skip = { $skip: skipValue };
                let limit = { $limit: objRequest.pagination.limit };
                let sort = {
                    "$sort": {
                        "created_at": -1
                    }
                };
                pipeline.push(match, project, skip, limit, sort);
                let docs = await Plans.aggregate(pipeline).allowDiskUse(true).exec();
                // console.log(JSON.stringify(docs))
                if (docs.length > 0) {
                    docs["totalRecordsCount"] = totalRecordsCount;
                } else {
                    docs["totalRecordsCount"] = 0;
                }

                return docs;

            } else {

                objRequest.filter.plotAreas = objRequest?.filter?.plotAreas?.length === 0 ? null : objRequest.filter.plotAreas;
                objRequest.filter.plotWidth = objRequest?.filter?.plotWidth?.length === 0 ? null : objRequest.filter.plotWidth;

                const totalIsActiveCount = await Plans.countDocuments({ "is_active": 1 });
                const pipeline = queryBuilder.buildQueryHomeDesignsCount(objRequest);
                let doc = await Plans.aggregate(pipeline).allowDiskUse(true).exec();
                objRequest.totalIsActiveCount = totalIsActiveCount;
                const pipeline1 = queryBuilder.buildHomeDesignsQuery(objRequest);
                let docs = await Plans.aggregate(pipeline1).allowDiskUse(true).exec();
                if (docs.length > 0) {
                    // docs["totalRecordsCount"] = doc[0] ? doc[0].count : 0;
                    docs["totalRecordsCount"] = doc[0].count;
                } else {
                    docs["totalRecordsCount"] = 0;
                }
                return docs;
            }

        } catch (error) {
            console.log(error);
        }
    }

    async fetchHomeDesignsV2(event) {
        try {
            const objRequest = JSON.parse(event.body);
            if (objRequest.filter.plotAreas && typeof objRequest.filter.plotAreas === "number") {
                const newRange = baseResponse.getRange(objRequest.filter.plotAreas, "plot_details.plot_area", "plans");
                let newPlotAreas;
                if (newRange[0].includes("<")) {
                    newPlotAreas = [{
                        min: 0,
                        max: 10
                    }];
                } else if (newRange[0].includes(">")) {
                    newPlotAreas = [{
                        min: 9999,
                        max: 99999
                    }];
                } else {
                    const newArrRange = newRange.split("-");
                    newPlotAreas = [{
                        min: parseInt(newArrRange[0]),
                        max: parseInt(newArrRange[1])
                    }];
                }
                objRequest.filter.plotAreas = newPlotAreas;
            }
            if (objRequest.filter.plotWidth && typeof objRequest.filter.plotWidth === "number") {
                const newRange = baseResponse.getRange(objRequest.filter.plotWidth, "plot_details.plot_width", "plans");
                const newArrRange = newRange.split("-");
                let newPlotWidth;
                if (newRange[0].includes("<")) {
                    newPlotWidth = [{
                        min: 0,
                        max: 10
                    }];
                } else if (newRange[0].includes(">")) {
                    newPlotWidth = [{
                        min: 999,
                        max: 9999
                    }];
                } else {
                    newPlotWidth = [{
                        min: parseInt(newArrRange[0]),
                        max: parseInt(newArrRange[1])
                    }]
                }
                objRequest.filter.plotWidth = newPlotWidth;
            }
            if (this.isEmpty(objRequest.filter)) {
                const totalRecordsCount = await planStyleDesigns.countDocuments({ "is_active": 1 , "is_approved" : 1, "files.two_d_rendered_plan_jpg.ground": { $exists: true, $ne: null, $type: 'string'}});
                let pipeline = [];

                let match = {
                    "$match": {
                        "is_active": 1,
                        "is_approved" : 1,
                        "files.two_d_rendered_plan_jpg.ground": { $exists: true, $ne: null, $type: 'string'}
                    }
                };

                let project = {
                    $project: {
                        resourcePath: { "$ifNull": ["", ""] },
                        // imageUrl: { "$ifNull": ["$files.two_d_line_drawing_jpg.ground", ""] },
                        imageUrl: "",
                        imageRender2dUrl: { "$ifNull": ["$files.two_d_rendered_plan_jpg.ground", []] },
                        unique_id: { "$ifNull": ["$unique_id", ""] },
                        area: { "$ifNull": ["$plot_details.plot_area", ""] },
                        suitablePlotArea: { "$ifNull": ["$plot_details.plot_area", ""] },
                        title: { "$ifNull": ["$unique_id", ""] },
                        numberOfFloors: { "$ifNull": ["$project_details.floors", ""] },
                        floors: { "$ifNull": ["$project_details.floors", ""] },
                        entryFacing: { "$ifNull": ["$vaastu_compliancy.entry_direction", ""] },
                        numberOfRooms: { "$ifNull": ["$project_details.bedrooms", 0] },
                    }
                };
                let skipValue = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
                let skip = { $skip: skipValue };
                let limit = { $limit: objRequest.pagination.limit };
                let sort = {
                    $sort: {
                        "created_at": -1
                    }
                };
                pipeline.push(match, sort, skip, limit, project);
                console.log(JSON.stringify(pipeline));
                let docs = await planStyleDesigns.aggregate(pipeline).allowDiskUse(true).exec();
                if (docs.length > 0) {
                    docs["totalRecordsCount"] = totalRecordsCount;
                } else {
                    docs["totalRecordsCount"] = 0;
                }

                return docs;

            } else {

                objRequest.filter.plotAreas = objRequest?.filter?.plotAreas?.length === 0 ? null : objRequest.filter.plotAreas;
                objRequest.filter.plotWidth = objRequest?.filter?.plotWidth?.length === 0 ? null : objRequest.filter.plotWidth;

                // const totalIsActiveCount = await planStyleDesigns.countDocuments({ "is_active": 1, "is_approved" : 1 });
                const pipeline = queryBuilder.buildQueryHomeDesignsCountV2(objRequest);
                let doc = await planStyleDesigns.aggregate(pipeline).allowDiskUse(true).exec();
                // objRequest.totalIsActiveCount = totalIsActiveCount;
                const pipeline1 = queryBuilder.buildHomeDesignsQueryV2(objRequest);
                let docs = await planStyleDesigns.aggregate(pipeline1).allowDiskUse(true).exec();
                if (docs.length > 0) {
                    // docs["totalRecordsCount"] = doc[0] ? doc[0].count : 0;
                    docs["totalRecordsCount"] = doc[0].count;
                } else {
                    docs["totalRecordsCount"] = 0;
                }
                return docs;
            }

        } catch (error) {
            console.log(error);
        }
    }


    async fetchHomeDesignsDetails(uniqueId) {
        let pipeline = []
        try {
            let match = {
                "$match": {
                    "unique_id": uniqueId
                }
            };
            let project = {
                "$project":{
                    "totalArea":{"$ifNull":["$plot_details.plot_area",""]},
                    "planName":{"$ifNull":["$design_name",""]},
                    "style":{"$ifNull":["$project_details.typology",""]},
                    "floors":{"$ifNull":["$project_details.floors",""]},
                    "numberOfBedrooms":{"$ifNull":["$project_details.bedrooms",""]},
                    "planPDFLink":{"$ifNull":["$files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id",""]},
                    "facingEntry":{"$ifNull":["$vaastu_compliancy.entry_direction",""]},
                    "designNumber":{"$ifNull":["$unique_id",""]},
                    "suitablePlotArea":{"$ifNull":["$plot_details.plot_area",""]},
                    "suitablePlotLength":{"$ifNull":["$plot_details.plot_length",""]},
                    "suitablePlotWidth":{"$ifNull":["$plot_details.plot_width",""]},
                    "suitablePlotEntrance":{"$ifNull":["$plot_details.plot_entrance_width_range",""]},
                    "totalBuildUpArea":{"$ifNull":["$project_details.builtup_area",""]},
                    "states":{"$ifNull":["$geography.state",""]},
                    "attachedBathroom":{"$sum":{"$ifNull":["$rooms.attached_bathrooms",0]}},
                    "commonBathroom":{"$sum":{"$ifNull":["$rooms.common_bathrooms",0]}},
                    "threeDimensionalImages":{"$ifNull":["$files.three_d_design_id",{}]},
                    "buildUpArea":{"$ifNull":["$project_details.builtup_area",""]},
                    "typology":{"$ifNull":["$project_details.typology",""]},
                    "estimatedCostOfConstruction":{"$ifNull":["$project_details.estimated_cost_of_construction",""]},
                    "pool":{"$ifNull":["$special_amenities.pool",""]},
                    "renderImages2d":{"$ifNull":["$files.two_d_rendered_plan_jpg",{}]},
                    "lineDrawingImages2d":{"$ifNull":["$files.two_d_line_drawing_jpg",{}]},
                    "budget":{"$ifNull":["$geography.budget",""]},
                    "designShortDescription":{"$ifNull":["$design_short_description",""]},
                    "designLongDescription":{"$ifNull":["$design_long_description",""]},
                    "twoWheelerParking":{"$ifNull":["$parking.two_wheeler_parking",""]},
                    "fourWheelerParking":{"$ifNull":["$parking.four_wheeler_parking",""]},
                    "maxThreeStairs":{"$ifNull":["$senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor",""]},
                    "oneBhkOnGroundFloor":{"$ifNull":["$senior_citizen_friendly.one_bhk_on_ground_floor",""]},
                    "provisionOfRamp":{"$ifNull":["$senior_citizen_friendly.provision_of_ramp",""]},
                    "vaastuCompliant":{"$ifNull":["$vaastu_compliancy.vaastu_compliant",""]},
                    "orientationOfKitchen":{"$ifNull":["$vaastu_compliancy.orientation_of_kitchen",""]},
                    "orientationOfPoojaRoom":{"$ifNull":["$vaastu_compliancy.orientation_of_pooja_room",""]},
                    "orientationOfMasterBedroom":{"$ifNull":["$vaastu_compliancy.orientation_of_master_bedrrom",""]},
                    "threeDLinkedDesignId":{"$ifNull":["$three_d_linked_design_id",""]},
                    "numberOfLikes":{"$ifNull":["$number_of_times_liked",0]},
                    "numberOfViews":{"$ifNull":["$number_of_times_viewed",0]},
                    "totalBathrooms":{"$sum":{"$ifNull":["$rooms.total_bathrooms",0]}},
                    "kitchen":{"$sum":{"$ifNull":["$rooms.kitchen",0]}},
                    "diningRoom":{"$sum":{"$ifNull":["$rooms.dining_room",0]}},
                    "studyRoom":{"$ifNull":["$special_amenities.study_room",""]},
                    "storeRoom":{"$sum":{"$ifNull":["$rooms.store_room",0]}},
                    "balcony":{"$ifNull":["$open_areas.balcony",""]},
                    "terrace":{"$ifNull":["$open_areas.terrace",""]},
                    "poojaRoom":{"$sum":{"$ifNull":["$rooms.pooja_room",0]}},
                    "courtyard":{"$ifNull":["$open_areas.courtyard",""]},
                    "garden":{"$ifNull":["$open_areas.garden",""]},
                }
            };
            // Note : Updating the response keys=> threeDimensionalImages, renderImages2d, lineDrawingImages2d (setting empty object if data is not present)
            pipeline.push(match, project);
            
            const docs = await Plans.aggregate(pipeline).allowDiskUse(true).exec();
            if (!docs) {
              console.error('Error in aggregation');
              return false;
            }
            return docs;
        } catch (error) {
            console.log(error);
        }
    }

    async fetchHomeDesignsDetailsV2(uniqueId) {
        let pipeline = []
        try {
            let match = {
                "$match": {
                    "unique_id": uniqueId
                }
            };
            let project = {
                "$project":{
                    "totalArea":{"$ifNull":["$plot_details.plot_area",""]},
                    // "planName":{"$ifNull":["$design_name",""]},
                    "planName": {"$ifNull":["$unique_id",""]},
                    "style":{"$ifNull":["$project_details.typology",""]},
                    "floors":{"$ifNull":["$project_details.floors",""]},
                    "numberOfBedrooms":{"$ifNull":["$project_details.bedrooms",""]},
                    // "planPDFLink":{"$ifNull":["$files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id",""]},
                    "planPDFLink": "",
                    "facingEntry":{"$ifNull":["$vaastu_compliancy.entry_direction",""]},
                    "designNumber":{"$ifNull":["$unique_id",""]},
                    "suitablePlotArea":{"$ifNull":["$plot_details.plot_area",""]},
                    "suitablePlotLength":{"$ifNull":["$plot_details.plot_length",""]},
                    "suitablePlotWidth":{"$ifNull":["$plot_details.plot_width",""]},
                    // "suitablePlotEntrance":{"$ifNull":["$plot_details.plot_entrance_width_range",""]},
                    "totalBuildUpArea":{"$ifNull":["$project_details.builtup_area",""]},
                    "states":{"$ifNull":["$geography.state",""]},
                    "attachedBathroom":{"$sum":{"$ifNull":["$rooms.attached_bathrooms",0]}},
                    "commonBathroom":{"$sum":{"$ifNull":["$rooms.common_bathrooms",0]}},
                    "threeDimensionalImages":{"$ifNull":["$files.three_d_design_id",{}]},
                    "buildUpArea":{"$ifNull":["$project_details.builtup_area",""]},
                    "typology":{"$ifNull":["$project_details.typology",""]},
                    // "estimatedCostOfConstruction":{"$ifNull":["$project_details.estimated_cost_of_construction",""]},
                    "pool":{"$ifNull":["$special_amenities.pool",""]},
                    "renderImages2d":{"$ifNull":["$files.two_d_rendered_plan_jpg",{}]},
                    // "lineDrawingImages2d":{"$ifNull":["$files.two_d_line_drawing_jpg",{}]},
                    "lineDrawingImages2d": {"$ifNull":[{},{}]},
                    // "budget":{"$ifNull":["$geography.budget",""]},
                    // "designShortDescription":{"$ifNull":["$design_short_description",""]},
                    // "designLongDescription":{"$ifNull":["$design_long_description",""]},
                    // "twoWheelerParking":{"$ifNull":["$parking.two_wheeler_parking",""]},
                    // "fourWheelerParking":{"$ifNull":["$parking.four_wheeler_parking",""]},
                    // "maxThreeStairs":{"$ifNull":["$senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor",""]},
                    // "oneBhkOnGroundFloor":{"$ifNull":["$senior_citizen_friendly.one_bhk_on_ground_floor",""]},
                    // "provisionOfRamp":{"$ifNull":["$senior_citizen_friendly.provision_of_ramp",""]},
                    // "vaastuCompliant":{"$ifNull":["$vaastu_compliancy.vaastu_compliant",""]},
                    // "orientationOfKitchen":{"$ifNull":["$vaastu_compliancy.orientation_of_kitchen",""]},
                    // "orientationOfPoojaRoom":{"$ifNull":["$vaastu_compliancy.orientation_of_pooja_room",""]},
                    // "orientationOfMasterBedroom":{"$ifNull":["$vaastu_compliancy.orientation_of_master_bedrrom",""]},
                    // "threeDLinkedDesignId":{"$ifNull":["$three_d_linked_design_id",""]},
                    "numberOfLikes":{"$ifNull":["$number_of_times_liked",0]},
                    "numberOfViews":{"$ifNull":["$number_of_times_viewed",0]},
                    "totalBathrooms":{"$sum":{"$ifNull":["$rooms.total_bathrooms",0]}},
                    "kitchen":{"$sum":{"$ifNull":["$rooms.kitchen",0]}},
                    "diningRoom":{"$sum":{"$ifNull":["$rooms.dining_room",0]}},
                    "studyRoom":{"$ifNull":["$special_amenities.study_room",""]},
                    "storeRoom":{"$sum":{"$ifNull":["$rooms.store_room",0]}},
                    "balcony":{"$ifNull":["$open_areas.balcony",""]},
                    "terrace":{"$ifNull":["$open_areas.terrace",""]},
                    "poojaRoom":{"$sum":{"$ifNull":["$rooms.pooja_room",0]}},
                    "courtyard":{"$ifNull":["$open_areas.courtyard",""]},
                    "garden":{"$ifNull":["$open_areas.garden",""]},
                }
            };
            // Note : Updating the response keys=> threeDimensionalImages, renderImages2d, lineDrawingImages2d (setting empty object if data is not present)
            pipeline.push(match, project);
            
            const docs = await planStyleDesigns.aggregate(pipeline).allowDiskUse(true).exec();
            if (!docs) {
              console.error('Error in aggregation');
              return false;
            }
            return docs;
        } catch (error) {
            console.log(error);
        }
    }

    async deleteRecord(uniqueId) {
        try {
            const result = await Plans.deleteOne({ unique_id: uniqueId });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }
    async likeHomeDesigns(uniqueId) {
        try {
            // const result = await Plans.findByIdAndUpdate(uniqueId,{$inc:{number_of_times_liked:1}})
            const result = await Plans.updateOne({ _id: uniqueId }, { $inc: { number_of_times_liked: 1 } })
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error)
        }
    }

    async likeHomeDesignsV2(uniqueId) {
        try {
            // const result = await Plans.findByIdAndUpdate(uniqueId,{$inc:{number_of_times_liked:1}})
            const result = await planStyleDesigns.updateOne({ _id: uniqueId }, { $inc: { number_of_times_liked: 1 } })
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error)
        }
    }

    async unLikeHomeDesigns(uniqueId) {
        try {
            // const result = await Plans.findByIdAndUpdate(uniqueId,{$inc:{number_of_times_liked:-1}})
            const checkNumberOfTimesLiked = await Plans.findOne({_id: uniqueId}, {number_of_times_liked:1});
            if(checkNumberOfTimesLiked?.number_of_times_liked === undefined || checkNumberOfTimesLiked?.number_of_times_liked === 0){
                return true;                
            }else{
                const result = await Plans.updateOne({_id: uniqueId},{$inc:{number_of_times_liked:-1}})
                if (result === null) return false;
                return true;
            }
            
        } catch(error){
            console.log(error)
        }
    }

    async unLikeHomeDesignsV2(uniqueId) {
        try {
            // const result = await Plans.findByIdAndUpdate(uniqueId,{$inc:{number_of_times_liked:-1}})
            const checkNumberOfTimesLiked = await planStyleDesigns.findOne({_id: uniqueId}, {number_of_times_liked:1});
            if(checkNumberOfTimesLiked?.number_of_times_liked === undefined || checkNumberOfTimesLiked?.number_of_times_liked === 0){
                return true;                
            }else{
                const result = await planStyleDesigns.updateOne({_id: uniqueId},{$inc:{number_of_times_liked:-1}})
                if (result === null) return false;
                return true;
            }
            
        } catch(error){
            console.log(error)
        }
    }

    async viewCountHomeDesigns(objectId) {
        try {
            const result = await Plans.updateOne({ _id: objectId }, { $inc: { number_of_times_viewed: 1 } });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error)
        }
    }

    async viewCountHomeDesignsV2(objectId) {
        try {
            const result = await planStyleDesigns.updateOne({ _id: objectId }, { $inc: { number_of_times_viewed: 1 } });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error)
        }
    }

    async fetchUniqueFloors() {
        try {
            const result = await Plans.distinct("project_details.floors", { "project_details.floors": { $nin: [null, ''] } });
            if (result.length == 0) return false;
            return result;
        } catch (error) {
            throw error;
        }
    }

    async getExistingFloorsRecord(data) {
        try {
            const result = await Plans.find({ "project_details.floors": { $in: data }, $or: [{ "rooms": { $type: 4 } }, { "rooms": { $not: { $type: 4 } } }] }, { "project_details.floors": 1, rooms: 1 });
            if (result.length == 0) return false;
            return result;
        } catch (error) {
            throw error;
        }
    }
    async bulkUpdateRecords(records) {
        try {
            let match = [];
            records.map((element) => {
                match.push({
                    updateOne: {
                        filter: { _id: element._id },
                        update: {
                            $set: { "rooms": element.rooms }
                        },
                        setDefaultsOnInsert: true
                    }
                })
            })
            console.log('match query---', JSON.stringify(match));
            const result = await Plans.bulkWrite(match);
            return result;
        } catch (error) {
            throw error
        }
    }

    async processFileData(data) {
        try {
            let rows = data;
            console.log('rows....', rows);
            let rowsIndex = 0;
            rows.forEach((columns, index1) => {
                const res = columns.every(element => element === null)
                if (res) {
                    rowsIndex = index1 + 1;
                }
                return;
            });
            console.log('rowsIndex', rowsIndex);
            rows.splice(0, rowsIndex);
            const headers = rows.shift();
            console.log('headers.length', headers)
            let rooms;
            const distinctFloors = ['G', 'G+1', 'G+2', 'G+3', 'G+4'];
            const valid_data_result_array = [];
            const invalid_data_entry_array = [];

            function generateRoomsArray(floorValue) {
                let finalArr = [];
                let range = distinctFloors.indexOf(floorValue) + 1;
                for (var i = 0; i < range; i++) {
                    let roomsObj = {
                        "index": null,
                        "floor": null,
                        "total_bathrooms": null,
                        "attached_bathrooms": null,
                        "split_bathrooms": null,
                        "combined_bathrooms": null,
                        "common_bathrooms": null,
                        "dining_room": null,
                        "living_room": null,
                        "kitchen": null,
                        "master_bedroom": null,
                        "family_room": null,
                        "store_room": null,
                        "pooja_room": null,
                        "shops": null
                    };
                    roomsObj.index = i;
                    roomsObj.floor = distinctFloors[i];
                    finalArr.push(roomsObj)

                }
                return finalArr;
            }
            const floorIndex = headers.indexOf('Floors');
            let floorValue;
            let floorsToCheck;
            for (const [i, excel_item] of rows.entries()) {
                // read data of excel file row-wise
                // i = 0
                // excel item  = 1st row of excel file(excluding headers)

                const construct_json_body = {};
                let invalid_data_entry = false;

                console.log('i......', i);
                console.log('excel_item......', excel_item);
                if (headers[floorIndex] === 'Floors') {
                    floorValue = excel_item[floorIndex];
                    if (floorValue !== null || floorValue !== '') {
                        rooms = await generateRoomsArray(floorValue);

                        var arr = [{
                                floorValue: "G",
                                valueToTraverse: ["G"]
                            },
                            {
                                floorValue: "G+1",
                                valueToTraverse: ["G", "G+1"]
                            },
                            {
                                floorValue: "G+2",
                                valueToTraverse: ["G", "G+1", "G+2"]
                            },
                            {
                                floorValue: "G+3",
                                valueToTraverse: ["G", "G+1", "G+2", "G+3"]
                            },
                            {
                                floorValue: "G+4",
                                valueToTraverse: ["G", "G+1", "G+2", "G+3", "G+4"]
                            }
                        ];

                        for (let i = 0; i < arr.length; i++) {
                            if (floorValue === arr[i].floorValue) {
                                floorsToCheck = arr[i].valueToTraverse;
                            }
                        }
                    }

                }

                for (const [cellInd, cellValue] of excel_item.entries()) {
                    // ind = index of first cell of a row
                    // index = the value of cell 
                    // console.log('cellInd......', cellInd);
                    // console.log('cellValue......', cellValue);

                    // const i = excel_item.indexOf(cellValue);
                    // console.log('i at line 207.............', i)
                    let data = excel_item[cellInd];
                    console.log('data.............', data)


                    const value = json_structure[headers[cellInd]]; //value={ type: 'string', key_name: 'unique_id', required: true }
                    // console.log(JSON.stringify({ file: 'updateAdditionalMetaTags.js', line: 213, value }));
                    const check = hasIn(json_structure, headers[cellInd]); //headers[ind]='Unique ID'
                    // console.log('check....', check)

                    if (check) {
                        if (value.type === 'string') {
                            if (data === null) {
                                data = '';
                            }
                        }

                        if (value.required === true) {
                            if (value.type === 'number') {
                                if (data === null) {
                                    data = 0;
                                }
                                let roomIndex;
                                if (headers[cellInd].indexOf("Total Bathrooms") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].total_bathrooms = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[cellInd].indexOf("Attached Bathrooms") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].attached_bathrooms = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }

                                    }
                                }

                                if (headers[cellInd].indexOf("Common Bathrooms") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].common_bathrooms = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[cellInd].indexOf("Dining Room") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].dining_room = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }


                                if (headers[cellInd].indexOf("Living Room") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].living_room = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[cellInd].indexOf("Family Room") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].family_room = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[cellInd].indexOf("Kitchen") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].kitchen = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[cellInd].indexOf("Store Room") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].store_room = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[cellInd].indexOf("Pooja Room") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].pooja_room = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[cellInd].indexOf("Shops") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].shops = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[cellInd].indexOf("Split Bathrooms") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].split_bathrooms = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }

                                if (headers[cellInd].indexOf("Combined Bathrooms") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].combined_bathrooms = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                                if (headers[cellInd].indexOf("Master Bedroom") !== -1) {
                                    let headerTitle = headers[cellInd];
                                    let splitValue = headerTitle.split('_');
                                    if (floorsToCheck.includes(splitValue[1])) {
                                        roomIndex = distinctFloors.indexOf(splitValue[1]);
                                        if (rooms.length > 0) {
                                            rooms[roomIndex].master_bedroom = excel_item[cellInd];
                                            set(construct_json_body, 'rooms', rooms);
                                        }
                                    }
                                }
                            }
                            set(construct_json_body, value.key_name, data);
                            // if (headers[cellInd] === 'Unique Id') {
                            //     console.log('data', data);
                            //     const data_array = await plansService.findByUniqueId(data);
                            //     console.log('data_array...', data_array);
                            //     if (data === null || data === undefined || data_array === false) {
                            //         // invalid_data_entry = true;
                            //         invalid_data_entry_array.push(data);
                            //         console.log('rows...............................', rows)
                            //         rows

                            //         // error_message.push('Incorrect Data Entry in field ' + headers[cellInd])
                            //         // console.log('error_message.........', error_message);
                            //     } else {
                            //         set(construct_json_body, value.key_name, data);
                            //     }

                            // }
                        } else {
                            invalid_data_entry_array.push({ 'error': `${headers[cellInd]}----${value.key_name}` })
                                // console.log(headers[cellInd], '----', value.key_name);
                        }
                    }

                }
                valid_data_result_array.push(construct_json_body);
                console.log('valid_data_result_array', JSON.stringify(valid_data_result_array))
                console.log('invalid_data_entry_array', JSON.stringify(invalid_data_entry_array))
            }
            return { 'valid_data_result_array': valid_data_result_array, 'invalid_data_entry_array': invalid_data_entry_array }
        } catch (error) {
            throw error
        }
    }

    async bulkUpdateAdditionalMetaTags(processData) {
        try {
            let records = processData.valid_data_result_array;
            let match = [];
            records.map((element) => {
                match.push({
                    updateOne: {
                        filter: { "unique_id": element.unique_id },
                        update: {
                            $set: {
                                "rooms": element.rooms,
                                "project_details.staircase_internal": element?.project_details?.staircase_internal,
                                "project_details.staircase_external": element?.project_details?.staircase_external,
                                "project_details.floors": element?.project_details?.floors,
                                "partner_details.partner_id": element?.partner_details?.partner_id,
                                "partner_details.partner_name": element?.partner_details?.partner_name,
                                "partner_details.project_id": element?.partner_details?.project_id,
                                "partner_details.partner_number" : element?.partner_details?.partner_number,
                                "partner_details.project_title" : element?.partner_details?.project_title,
                            }
                        },
                        setDefaultsOnInsert: true
                    }
                })
            })
            console.log('match query---', JSON.stringify(match));
            const result = await Plans.bulkWrite(match);
            return result;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = PlansService;