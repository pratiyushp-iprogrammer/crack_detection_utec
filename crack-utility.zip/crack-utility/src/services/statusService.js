const Status = require('../models/status');

class StatusService {
  async insertStatus(data) {
    try {
      console.log('data', data)
      const status = new Status(data);
      const result = await status.save();
      if (result) {
        return true
      }
      return false
    } catch (error) {
      console.log(error);
    }
  }

  async updateStatus(params) {
    try {
      let result = await Status.updateOne({ queueId: params.queueId }, params, { upsert: true })
      return result;
    } catch (error) {
      console.log(error);
    }
  }

  async findByQueueId(QueueId) {
    try {
      const result = await Status.findOne({ queueId: QueueId });
      if (result === null) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
}

module.exports = StatusService;