const UsageData = require('../models/designAction');
const Plans = require('../models/plans.js');

class DesignActionService {

    async create(data) {
        try {
            const objUsageData = new UsageData(data);
            const result = await objUsageData.save();
            if (result) {
                return true
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async getDataFromPlans(_id) {
        try {
            if (_id === undefined || _id === null) {
                return false;
            }
            let fields = { created_at: 1, updated_at: 1, created_by: 1, updated_by: 1, unique_id: 1, number_of_times_viewed: 1 };
            const result = await Plans.findById({ _id }, fields);
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error.message);
        }
    }

    async getActionCountData(planObjectId, userId) {
        try {
            if (planObjectId === undefined || planObjectId === null) {
                return false;
            }

            const result = await UsageData.aggregate([{
                    "$match": {
                        "object_id": planObjectId,
                        "$and": [
                            { "user_id": userId }
                        ]
                    }
                },
                {
                    "$group": {
                        "_id": {
                            "action": "$action"
                        },
                        "count": {
                            "$sum": 1
                        }
                    }
                },
                {
                    "$project": {
                        "action": "$_id.action",
                        "count": "$count"
                    }
                }
            ]);

            if (result === null) return false;
            console.log("result =>", result);

            let counts = {};
            result.forEach(element => {
                counts[element.action] = element.count;
            });

            let arrAction = ["reuse", "like", "view", "save", "share", "download", "customization"];
            arrAction.forEach(action => {
                if (!counts.hasOwnProperty(action)) {
                    counts[action] = 0;
                }
            });
            console.log("count=> ", counts);

            return counts;
        } catch (error) {
            console.log(error.message);
        }
    }

    async getReusedPlans(_id) {
        try {
            if (_id === undefined || _id === null) {
                return false;
            }
            let fields = { sr_tracker_number: 1, action: 1, user_id: 1, created_at: 1 };
            const result = await UsageData.find({ "object_id": _id }, fields);
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error.message);
        }
    }
}

module.exports = DesignActionService;