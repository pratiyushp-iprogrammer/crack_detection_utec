const Styles = require('../models/styles.js');
const QueryBuilder = require('../common/queryBuilder');
const set = require('lodash/set');
const ObjectId = require('mongodb').ObjectId;

let queryBuilder = new QueryBuilder();


class StylesService {

    async createStyle(data) {
        try {
            const objStyle = new Styles(data);
            const result = await objStyle.save();
            if (result) {
                return true
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async updateStyle(params) {
        try {
            let result = await Styles.updateOne({ unique_id: params.unique_id }, params, { upsert: true })
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async findByUniqueId(uniqueId) {
        try {
            const result = await Styles.findOne({ unique_id: uniqueId, is_active: 1 });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async findByUniqueIdGetData(uniqueId) {
        try {
            const result = await Styles.findOne({ unique_id: uniqueId }).lean();
            if (result === null) return [];
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async findOneById(_id) {
        try {
            if (_id === undefined || _id === null) {
                return false;
            }
            const result = await Styles.findById({ _id });
            if (result === null) return false;
            return result;
        } catch (error) {
            console.log(error);
        }
    }
    async insert_many(items) {
        try {
            const result = await Styles.insertMany(items, { ordered: false });
            console.log('result', JSON.stringify(result));
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    paginate(arr, page_size, page_number) {
        let result = arr.slice((page_number - 1) * page_size, page_number * page_size);
        return result;
    }

    isEmpty(value) {
        let isValid = true;
        if (typeof value == "string") {
            isValid = (value === undefined || value == null || value.length <= 0) ? true : false;
        }
        if (typeof value == "object") {
            isValid = (value === undefined || value == null || Object.keys(value).length <= 0) ? true : false;
        }
        return isValid;
    }

    async fetch(event) {
        try {
            // const promise = new Promise((resolve, reject) => {
            //     const objRequest = JSON.parse(event.body);
            //     let match_percentage = (objRequest.match_percentage) ? objRequest.match_percentage : false;
            //     // console.log("match_percentage:", match_percentage)
            //     const objRequiredColumns = queryBuilder.formatRequiredColumns(objRequest.arrRequiredColumns);

            //     if (this.isEmpty(objRequest.searchString) && this.isEmpty(objRequest.filters)) {
            //         const promise1 = new Promise((resolve, reject) => {
            //             const totalRecordsCount = Styles.countDocuments({ "is_active": 1 });
            //             resolve(totalRecordsCount);
            //         });
            //         promise1.then((totalRecordsCount) => {
            //             let options = {};
            //             options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
            //             options.limit = objRequest.pagination.limit;
            //             options.sort = { "created_at": -1 };
            //             if (objRequest?.sort && objRequest?.sort?.column_name) {
            //                 delete options["sort"]["created_at"];
            //                 options["sort"][objRequest?.sort?.column_name] = objRequest?.sort?.order === 'desc' ? -1 : 1;
            //             }
            //             Styles.find({ "is_active": 1 }, objRequiredColumns, options, function (err, docs) {
            //                 if (err) return console.error(err);
            //                 docs["totalRecordsCount"] = totalRecordsCount;
            //                 resolve(docs);
            //             });
            //         });

            //     } else {
            //         const promise2 = new Promise((resolve, reject) => {
            //             const totalIsActiveCount = Styles.countDocuments({ "is_active": 1 });
            //             resolve(totalIsActiveCount);
            //         }).then((totalIsActiveCount) => {
            //             const pipeline = queryBuilder.buildQueryCount(objRequest, 'styles', match_percentage);
            //             // console.log(JSON.stringify(pipeline));
            //             Styles.aggregate(pipeline).allowDiskUse(true).exec(async function (err, doc) {
            //                 if (err) return console.error(err);

            //                 objRequest.totalIsActiveCount = totalIsActiveCount;
            //                 const pipeline1 = queryBuilder.buildQuery(objRequest, 'styles', match_percentage);
            //                 Styles.aggregate(pipeline1).allowDiskUse(true).exec(function (err, docs) {
            //                     if (err) return console.error(err);
            //                     if (docs.length > 0) {
            //                         docs["totalRecordsCount"] = doc[0].totalRecords;
            //                     } else {
            //                         docs["totalRecordsCount"] = 0;
            //                     }
            //                     resolve(docs);
            //                 });
            //             });
            //         })
            //     }
            // });
            // return promise;

            const objRequest = JSON.parse(event.body);
            let match_percentage = (objRequest.match_percentage) ? objRequest.match_percentage : false;
            const objRequiredColumns = queryBuilder.formatRequiredColumns(objRequest.arrRequiredColumns);
            if (this.isEmpty(objRequest.searchString) && this.isEmpty(objRequest.filters)) {
                const totalRecordsCount = await Styles.countDocuments({ "is_active": 1 });
                let options = {};
                options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
                options.limit = objRequest.pagination.limit;
                options.sort = { "created_at": -1 };
                if (objRequest?.sort && objRequest?.sort?.column_name) {
                    delete options["sort"]["created_at"];
                    options["sort"][objRequest?.sort?.column_name] = objRequest?.sort?.order === 'desc' ? -1 : 1;
                }
                const docs = await Styles.find({ "is_active": 1 }, objRequiredColumns, options);
                docs["totalRecordsCount"] = totalRecordsCount;
                return docs;
            } else {
                const countPipeline = queryBuilder.buildQueryCount(objRequest, 'styles', match_percentage);
                const [{ totalRecords = 0 } = {}] = await Styles.aggregate(countPipeline).allowDiskUse(true).exec();
                // objRequest['totalIsActiveCount'] = totalRecords;
                const pipeline = queryBuilder.buildQuery(objRequest, 'styles', match_percentage);
                const docs = await Styles.aggregate(pipeline).allowDiskUse(true).exec();
                docs["totalRecordsCount"] = totalRecords;
                return docs;
            }


        } catch (error) {
            console.log(error);
        }
    }

    async getDistictValues(columnName) {
        try {
            const result = await Styles.distinct(columnName);
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async getUniqueIdDataSet(items) {
        try {
            const result = await Styles.find({ unique_id: { $in: items }, is_active: 1 });
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async fetchMasonary(event) {
        try {
          const objRequest = JSON.parse(event.body);
      
          if (this.isEmpty(objRequest.searchString) && this.isEmpty(objRequest.filters)) {
            const totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });
      
            let options = {};
            options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
            options.limit = objRequest.pagination.limit;
            options.sort = { "created_at": -1 };
      
            const docs = await Styles.find({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] }, { files: 1, image_files: 1, unique_id: 1, raw_files: 1 }, options);
      
            const res = [];
            docs.forEach(obj => {
              const construct_json_body = {};
              let newdata = ({ ...obj }._doc);
              const flatten = (obj, roots = [], sep = '.') => Object.keys(obj).reduce((memo, prop) => Object.assign({}, memo, Object.prototype.toString.call(obj[prop]) === '[object Object]' ? flatten(obj[prop], roots.concat([prop])) : {
                [roots.concat([prop]).join(sep)]: obj[prop]
              }), {});
              const flattenObject1 = flatten(newdata);
              for (let data in flattenObject1) {
                if (flattenObject1[data]) {
                  set(construct_json_body, data, flattenObject1[data]);
                }
              }
              if (Object.keys(construct_json_body).length > 1)
                res.push(construct_json_body);
            });
      
            return { listing: res, count: totalRecordsCount };
          } else {
            const pipeline = queryBuilder.buildQueryMasonryCount(objRequest);
            const totalRecordsCount = await Styles.aggregate(pipeline);
      
            let options = {};
            options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
            options.limit = objRequest.pagination.limit;
            options.sort = { "created_at": -1 };
      
            const pipeline1 = queryBuilder.buildQueryMasonary(objRequest);
            const docs = await Styles.aggregate(pipeline1);
      
            return { listing: docs, count: totalRecordsCount };
          }
        } catch (error) {
          console.log('error', error);
          console.log(error);
          return null;
        }
      }
    // async fetchMasonary(event) {
    //     try {
    //         const promise = new Promise((resolve, reject) => {
    //             const objRequest = JSON.parse(event.body);

    //             if (this.isEmpty(objRequest.searchString) && this.isEmpty(objRequest.filters)) {
    //                 const promise1 = new Promise((resolve, reject) => {
    //                     const totalRecordsCount = Styles.countDocuments({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });
    //                     resolve(totalRecordsCount);
    //                 });
    //                 promise1.then((totalRecordsCount) => {
    //                     let options = {};
    //                     options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
    //                     options.limit = objRequest.pagination.limit;
    //                     options.sort = { "created_at": -1 };
    //                     Styles.find({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] }, { files: 1, image_files: 1, unique_id: 1, raw_files: 1 }, options, function (err, docs) {
    //                         const res = []
    //                         docs.forEach(obj => {
    //                             const construct_json_body = {};
    //                             let newdata = ({ ...obj }._doc);
    //                             // delete newdata._id;
    //                             const flatten = (obj, roots = [], sep = '.') => Object.keys(obj).reduce((memo, prop) => Object.assign({}, memo, Object.prototype.toString.call(obj[prop]) === '[object Object]' ? flatten(obj[prop], roots.concat([prop])) : {
    //                                 [roots.concat([prop]).join(sep)]: obj[prop]
    //                             }), {})
    //                             const flattenObject1 = flatten(newdata);
    //                             for (let data in flattenObject1) {
    //                                 if (flattenObject1[data]) {
    //                                     set(construct_json_body, data, flattenObject1[data]);
    //                                 }
    //                             }
    //                             if (Object.keys(construct_json_body).length > 1)
    //                                 res.push(construct_json_body);
    //                         });
    //                         // console.log("--->", res);
    //                         if (err) return console.error(err);
    //                         resolve({ listing: res, count: totalRecordsCount });
    //                     });
    //                 });

    //             } else {
    //                 const promise2 = new Promise((resolve, reject) => {
    //                     const pipeline = queryBuilder.buildQueryMasonryCount(objRequest);
    //                     // console.log("#####", JSON.stringify(pipeline))
    //                     Styles.aggregate(pipeline, function (err, totalRecordsCount) {
    //                         resolve(totalRecordsCount);
    //                     });



    //                 });
    //                 promise2.then((totalRecordsCount) => {
    //                     // console.log("#####", JSON.stringify(totalRecordsCount))
    //                     let options = {};
    //                     options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
    //                     options.limit = objRequest.pagination.limit;
    //                     options.sort = { "created_at": -1 };
    //                     const pipeline1 = queryBuilder.buildQueryMasonary(objRequest);
    //                     Styles.aggregate(pipeline1, function (err, docs) {
    //                         if (err) return console.error(err);
    //                         resolve({ listing: docs, count: totalRecordsCount });
    //                     });
    //                 });
    //             }
    //         });
    //         return promise;
    //     } catch (error) {
    //         console.log('error', error);
    //         console.log(error);
    //     }
    // }

    // async fetchDesignElements(event) {

    //     try {
    //         console.log('at line 239');
    //         const objRequest = JSON.parse(event.body);
    //         console.log('objRequest', objRequest);
    //         let result;
    //         let totalRecordsCount;
    //         const res = []
    //         if (this.isEmpty(objRequest.filters.category)) {
    //             console.log('at line 246');
    //             totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });
    //             let options = {};
    //             options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
    //             options.limit = objRequest.pagination.limit;
    //             options.sort = { "created_at": -1 };
    //             await Styles.find({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] }, { "files.three_d_design_id.front": 1, "image_files": 1, "unique_id": 1 }, options, function(err, docs) {
    //                 console.log('docs', docs);
    //                 docs.forEach(async obj => {
    //                     const construct_json_body = {};
    //                     let newdata = ({...obj }._doc);
    //                     delete newdata._id;
    //                     const flatten = (obj, roots = [], sep = '.') => Object.keys(obj).reduce((memo, prop) => Object.assign({}, memo, Object.prototype.toString.call(obj[prop]) === '[object Object]' ? flatten(obj[prop], roots.concat([prop])) : {
    //                         [roots.concat([prop]).join(sep)]: obj[prop]
    //                     }), {})
    //                     const flattenObject1 = flatten(newdata);
    //                     for (let data in flattenObject1) {
    //                         if (flattenObject1[data]) {
    //                             set(construct_json_body, data, flattenObject1[data]);
    //                         }
    //                     }
    //                     if (Object.keys(construct_json_body).length > 1)
    //                         await res.push(construct_json_body);
    //                 });
    //                 if (err)
    //                     console.log('err', err);
    //                 return console.error(err);
    //             });
    //         } else {
    //             console.log('at line 274');
    //             const categoryName = objRequest.filters.category;
    //             console.log('categoryName', categoryName);
    //             totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { "element_type": categoryName }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });
    //             console.log('totalRecordsCount', totalRecordsCount);
    //             let options = {};
    //             options.skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
    //             options.limit = objRequest.pagination.limit;
    //             options.sort = { "created_at": -1 };
    //             await Styles.find({ $and: [{ "is_active": 1 }, { "element_type": categoryName }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] }, { "files.three_d_design_id.front": 1, "image_files": 1, "unique_id": 1 }, options, function(err, docs) {
    //                 console.log('docs', docs);
    //                 docs.forEach(obj => {
    //                     const construct_json_body = {};
    //                     let newdata = ({...obj }._doc);
    //                     delete newdata._id;
    //                     const flatten = (obj, roots = [], sep = '.') => Object.keys(obj).reduce((memo, prop) => Object.assign({}, memo, Object.prototype.toString.call(obj[prop]) === '[object Object]' ? flatten(obj[prop], roots.concat([prop])) : {
    //                         [roots.concat([prop]).join(sep)]: obj[prop]
    //                     }), {})
    //                     const flattenObject1 = flatten(newdata);
    //                     for (let data in flattenObject1) {
    //                         if (flattenObject1[data]) {
    //                             set(construct_json_body, data, flattenObject1[data]);
    //                         }
    //                     }
    //                     if (Object.keys(construct_json_body).length > 1)
    //                         res.push(construct_json_body);
    //                 });
    //                 if (err)
    //                     console.log('err', err);
    //                 return console.error(JSON.stringify(err));
    //             });
    //         }
    //         // let paginatedArray = this.paginate(res, limit, skip);
    //         // result = { listing: paginatedArray, count: res.length };
    //         result = { listing: res, count: totalRecordsCount }
    //         return result;
    //     } catch (error) {
    //         console.log('error', error);
    //     }
    // }

    async getStyleDesignDetails(uniqueId,userId) {
        try {

            const query=[
                {
                    $match: { unique_id: uniqueId, "is_active": 1} 
                }, 
                {
                    $lookup: {
                        from: "user_profile_action_datas",
                        localField: "_id",
                        foreignField: "object_id",
                        as: "userProfile"
                    }
                },
                {
                    $unwind: { path: "$userProfile" , preserveNullAndEmptyArrays: true}
                },
                {
                    "$group": {
                        "_id": {
                            _id: "$_id",
                            updatedAt:"$userProfile.updatedAt",
                            user_id: "$userProfile.user_id",
                            action: "$userProfile.action",
                            event_for: "$userProfile.event_for",
                            imageCarousel: {
                              $cond: { if: { $or:[ { $eq: [ { $type : "$files"}, 'missing']} , { $and: [ { $ne: [ { $type : "$files"}, 'missing']}, { $eq: ["$files", ""]}]} ]  }, then: [""], else: ["$files.three_d_design_id.front"] }
                            },
                            image: {
                              $cond: { if: { $or:[ { $eq: [ { $type : "$files"}, 'missing']} , { $and: [ { $ne: [ { $type : "$files"}, 'missing']}, { $eq: ["$files", ""]}]} ] }, then: "$image_files", else: "$files.three_d_design_id.front" }
                            },
                             Wood: {
                                $cond: { if: { $eq: ["$material_treatment" , null || "" ]}, then: "", else: {
                                    $cond: { if: { $or:[ { $eq: [ { $type : "$material_treatment.wood"}, 'missing']} , { $and: [ { $ne: [ { $type : "$material_treatment.wood"}, 'missing']}, { $eq: ["$material_treatment.wood", ""]}]} ] }, then: "", else: "$material_treatment.wood" }
                                    }, }
                            },
                            Concrete: "",
                            PaintPlaster: "",
                            ElementNo: "",
                            Stone: {
                                $cond: { if: { $eq: ["$material_treatment" , null || "" ]}, then: "", else:  {
                                    $cond: { if: { $or:[ { $eq: [ { $type : "$material_treatment.stone"}, 'missing']} , { $and: [ { $ne: [ { $type : "$material_treatment.stone"}, 'missing']}, { $eq: ["$material_treatment.stone", ""]}]} ] }, then: "", else: "$material_treatment.stone" }
                                    }, }
                            },
                            Style: {
                                  $cond: { if: { $or:[ { $eq: [ { $type : "$style"}, 'missing']} , { $and: [ { $ne: [ { $type : "$style"}, 'missing']}, { $eq: ["$style", ""]}]} ] }, then: "", else: "$style" }
                            },                            
                            Metal: "",
                            Brick: {
                                $cond: { if: { $eq: ["$material_treatment" , null || "" ]}, then: "", else: {
                                    $cond: { if: { $or:[ { $eq: [ { $type : "$material_treatment.brick"}, 'missing']} , { $and: [ { $ne: [ { $type : "$material_treatment.brick"}, 'missing']}, { $eq: ["$material_treatment.brick", ""]}]} ] }, then: "", else: "$material_treatment.brick" }
                                }, }
                            },
                            nomenclature: "",
                        },
                        "count": {
                            "$sum": 1
                        }
                    }
                },
                { $sort : { "_id.updatedAt" : -1 } },
                {
                    $project: {
                        _id : 0,
                        // action : "$_id.action",
                        // event_for : "$_id.event_for",
                        updatedAt:"$_id.updatedAt",
                        _id: "$_id._id",
                        image : "$_id.image",
                        user_id: "$_id.user_id",
                        detailData: [{
                            title: "About",
                            detail: {
                                Wood: "$_id.Wood",
                                Concrete: "$_id.Concrete",
                                "Paint Plaster": "$_id.PaintPlaster",
                                "Element No": "$_id.ElementNo",
                                Stone: "$_id.Stone",
                                Style: "$_id.Style",
                                Metal: "$_id.Metal",
                                Brick: "$_id.Brick",
                                nomenclature: "$_id.nomenclature",
                            }
                        }],
                        imageCarousel : "$_id.imageCarousel",
                        isFavourite: {
                            $cond: [
                                {
                                    $and: [
                                        { $eq: ["$_id.action", "favourite"] },
                                        { $eq: ["$_id.user_id", userId] }
                                    ]
                                }, true, false
                            ]
                        },
                        isLiked: {
                            $cond: [
                                {
                                    $and: [
                                        { $eq: ["$_id.action", "like"] },
                                        { $eq: ["$_id.user_id", userId] }
                                    ]
                                }, true, false
                            ]
                        },
                        likeCount: {
                            $cond: { if: { $eq: [ "$_id.action", "like" ] },  then: "$count", else: 0},     
                        },
                        viewCount : "0",
                    }
                },
            
            ];
            console.log("query: ", JSON.stringify(query));
            let docs = await Styles.aggregate(query);
            let designItemList = [];
            if (docs.find((items) => { return items.user_id === userId })) {
                designItemList = docs.find((items) => { return items.user_id === userId })
            } else {
                designItemList = docs[0];
            }
            console.log("Docs after find: ", designItemList);
            let sum=0;
            docs.forEach((item)=>{
                if(item.likeCount) sum+=item.likeCount
            });
            designItemList.likeCount=sum;
            console.log("Docs after sum: ", designItemList);
            return { "data": designItemList }; 
        } catch (error) {
            console.log('error', error);
        }
    }

    async fetchDesignElements(event) {

        try {

            const objRequest = JSON.parse(event.body);

            const skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
            const limit = objRequest.pagination.limit;

            if (this.isEmpty(objRequest.filters.category)) {
                
                const totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });
                const docs = await Styles.aggregate([
                    {
                        $match:{
                            $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }]
                        },
                    }, 
                    {
                        $sort: {
                            "created_at": -1
                        }
                    },
                    {
                        $skip : skip
                    },
                    {
                        $limit : limit
                    },
                    {
                        $lookup: {
                            from: "user_profile_action_datas",
                            localField: "_id",
                            foreignField: "object_id",
                            as: "userProfile"
                        }
                    },
                    {
                        $unwind: { path: "$userProfile", preserveNullAndEmptyArrays: true }
                    },
                    {
                        "$group": {
                            "_id": {
                                _id: "$_id",
                                action: "$userProfile.action",
                                event_for: "$userProfile.event_for",
                                unique_id: "$unique_id",
                                imageUrl: "$files.three_d_design_id.front",
                                imageFiles : "$image_files"
                            },
                            "count": {
                                "$sum": 1
                            }
                        }
                    },
                    {
                        $project: {
                            _id : 0,
                            // action : "$_id.action",
                            // event_for : "$_id.event_for",
                            isFavourite: {
                                $cond: { if: { $eq: [ "$_id.action", "favourite" ] },  then: true, else: false}
                            },
                            isLiked: {
                                $cond: { if: { $eq: [ "$_id.action", "like" ] },  then: true, else: false}, 
                            },
                            likeCount: {
                                $cond: { if: { $eq: [ "$_id.action", "like" ] },  then: "$count", else: 0},     
                            },
                            viewCount : "0",
                            unique_id: "$_id.unique_id",
                            imageUrl: {"$ifNull":["$_id.imageUrl","$_id.imageFiles"]},
                        }
                    },
                
                ])
                docs["totalRecordsCount"] = totalRecordsCount;
                return docs;            

            } else {

                const categoryName = objRequest.filters.category;                
                const totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { "element_type": categoryName }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });

                const docs = await Styles.aggregate([  
                    {
                        $match:{
                            $and: [{ "is_active": 1 }, { "element_type": categoryName }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }]
                        },
                    }, 
                    {
                        $sort: {
                            "created_at": -1
                        }
                    },
                    {
                        $skip : skip
                    },
                    {
                        $limit : limit
                    },
                    {
                        $lookup: {
                            from: "user_profile_action_datas",
                            localField: "_id",
                            foreignField: "object_id",
                            as: "userProfile"
                        }
                    },
                    {
                        $unwind: { path: "$userProfile", preserveNullAndEmptyArrays: true }
                    },
                    {
                        "$group": {
                            "_id": {
                                _id: "$_id",
                                action: "$userProfile.action",
                                event_for: "$userProfile.event_for",
                                unique_id: "$unique_id",
                                imageUrl: "$files.three_d_design_id.front",
                                imageFiles : "$image_files"
                            },
                            "count": {
                                "$sum": 1
                            }
                        }
                    },
                    {
                        $project: {
                            _id : 0,
                            // action : "$_id.action",
                            // event_for : "$_id.event_for",
                            isFavourite: {
                                $cond: { if: { $eq: [ "$_id.action", "favourite" ] },  then: true, else: false}
                            },
                            isLiked: {
                                $cond: { if: { $eq: [ "$_id.action", "like" ] },  then: true, else: false}, 
                            },
                            likeCount: {
                                $cond: { if: { $eq: [ "$_id.action", "like" ] },  then: "$count", else: 0},     
                            },
                            viewCount : "0",
                            unique_id: "$_id.unique_id",
                            imageUrl: {"$ifNull":["$_id.imageUrl","$_id.imageFiles"]},
                        }
                    },
                
                ])

                docs["totalRecordsCount"] = totalRecordsCount;
                return docs;            
            }

        } catch (error) {
            console.log('error', error);
            console.log(error);
        }
    }


    async getDesignElements(event) {

        try {

            const objRequest = JSON.parse(event.body);

            const skip = objRequest.pagination.page ? (objRequest.pagination.page - 1) * objRequest.pagination.limit : 0;
            const limit = objRequest.pagination.limit;

            if (this.isEmpty(objRequest.filters.category)) {
                
                const totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });
                const docs = await Styles.aggregate([
                    {
                        $match:{
                            $and: [{ "is_active": 1 }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }]
                        },
                    }, 
                    {
                        $sort: {
                            "created_at": -1
                        }
                    },
                    {
                        $skip : skip
                    },
                    {
                        $limit : limit
                    },
                    // {
                    //     $lookup: {
                    //         from: "user_profile_action_datas",
                    //         localField: "_id",
                    //         foreignField: "object_id",
                    //         as: "userProfile"
                    //     }
                    // },
                    // {
                    //     $unwind: { path: "$userProfile", preserveNullAndEmptyArrays: true }
                    // },
                    {
                        "$group": {
                            "_id": {
                                _id: "$_id",
                                element_type: "$element_type",
                                unique_id: "$unique_id",
                                imageUrl: "$files.three_d_design_id.front",
                                imageFiles : "$image_files"
                            },
                            "count": {
                                "$sum": 1
                            }
                        }
                    },
                    {
                        $project: {
                            // files : {
                            //     three_d_design_id : {
                            //         front: { "$ifNull": ["$_id.imageUrl", "$_id.imageFiles" ] },
                            //     }
                            // },
                            files : {
                                three_d_design_id : {
                                    front: {
                                        $cond:{
                                            if: {
                                                $eq:[{$ifNull:["$_id.imageUrl", ""]}, ""]
                                            },
                                            then: "$_id.imageFiles",
                                            else: "$_id.imageUrl"
                                        }
                                    }
                                }
                            },
                            _id : "$_id._id",
                            unique_id: "$_id.unique_id",
                            element_type : "$_id.element_type",
                            
                        }
                    },
                
                ]);
                docs["totalRecordsCount"] = totalRecordsCount;
                return docs;            

            } else {

                const categoryName = objRequest.filters.category;                
                const totalRecordsCount = await Styles.countDocuments({ $and: [{ "is_active": 1 }, { "element_type": categoryName }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }] });

                const docs = await Styles.aggregate([  
                    {
                        $match:{
                            $and: [{ "is_active": 1 }, { "element_type": categoryName }, { $or: [{ "image_files": { "$exists": true, "$nin": ["", null] } }, { "files.three_d_design_id.front": { "$exists": true, "$nin": ["", null] } }] }]
                        },
                    }, 
                    {
                        $sort: {
                            "created_at": -1
                        }
                    },
                    {
                        $skip : skip
                    },
                    {
                        $limit : limit
                    },
                    // {
                    //     $lookup: {
                    //         from: "user_profile_action_datas",
                    //         localField: "_id",
                    //         foreignField: "object_id",
                    //         as: "userProfile"
                    //     }
                    // },
                    // {
                    //     $unwind: { path: "$userProfile", preserveNullAndEmptyArrays: true }
                    // },
                    {
                        "$group": {
                            "_id": {
                                _id: "$_id",
                                element_type: "$element_type",
                                unique_id: "$unique_id",
                                imageUrl: "$files.three_d_design_id.front",
                                imageFiles : "$image_files"
                            },
                            "count": {
                                "$sum": 1
                            }
                        }
                    },
                    {
                        $project: {
                            // files : {
                            //     three_d_design_id : {
                            //         front: { "$ifNull": ["$_id.imageUrl", "$_id.imageFiles" ] },
                            //     }
                            // },
                            files : {
                                three_d_design_id : {
                                    front: {
                                        $cond:{
                                            if: {
                                                $eq:[{$ifNull:["$_id.imageUrl", ""]}, ""]
                                            },
                                            then: "$_id.imageFiles",
                                            else: "$_id.imageUrl"
                                        }
                                    }
                                }
                            },
                            _id : "$_id._id",
                            unique_id: "$_id.unique_id",
                            element_type : "$_id.element_type",
                            
                        }
                    },

                    
                
                ]);

                docs["totalRecordsCount"] = totalRecordsCount;
                return docs;            
            }

        } catch (error) {
            console.log('error', error);
            console.log(error);
        }
    }



    async deleteRecord(uniqueId) {
        try {
            const result = await Styles.deleteOne({ unique_id: uniqueId });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

}

module.exports = StylesService;