const Plans = require('../models/plansDummy.js');
class PlansServiceDummy {
  async insert_many(items) {
    try {
      await Plans.insertMany(items);//TODO: handle error correctly
    } catch (error) {
      console.log(error);
    }
  }
  async findByTransactionId(transactionId) {
    try {
      const result = await Plans.find({ transaction_id: transactionId });
      if (result.length === 0) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
  async findByAllTransactionId(transactionId) {
    try {
      const result = await Plans.find({ transaction_id: transactionId });
      if (result.length === 0) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
  async deleteRecords(transactionId, uniqueId) {
    try {
      let result = '';
      if (uniqueId)
        result = await Plans.deleteOne({ transaction_id: transactionId, unique_id: uniqueId, duplicate: 1 });
      else
        result = await Plans.deleteMany({ transaction_id: transactionId, duplicate: 1 });
      if (result.length === 0) return false;
      return result;
    } catch (error) {
      console.log(error);
    }
  }
}
module.exports = PlansServiceDummy;