const StyleElevations = require('../models/styleElevations.js');

class StyleElevationsService {

    async createStyleElevation(data) {
        try {
            console.log("Two");
            const objStyleElevation = new StyleElevations(data);
            const result = await objStyleElevation.save();
            if (result) {
                return true
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async findByUniqueId(uniqueId) {
        try {
            const result = await StyleElevations.findOne({ unique_id: uniqueId });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async findOneById(_id) {
        try {
            if (_id === undefined || _id === null) {
                return false;
            }
            const result = await StyleElevations.findById({ _id });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }

    async findByUniqueIdGetData(uniqueId) {
        try {
            const result = await StyleElevations.findOne({ unique_id: uniqueId });
            if (result === null) return [];
            return result;
        } catch (error) {
            console.log(error);
        }
    }

    async updateStyleElevation(params) {
        try {
            let result = await StyleElevations.updateOne({ unique_id: params.unique_id }, params, { upsert: true });
            return result;
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = StyleElevationsService;