const AdminDetails = require('../models/adminDetails');

class AdminDetailsService {
    async createAdminDetails(data) {
        try {
            const objAdminDetails = new AdminDetails(data);
            const result = await objAdminDetails.save();
            if (result) {
                return result
            }
            return false
        } catch (error) {
            console.log(error);
        }
    }

    async updateAdminDetails(params) {
        try {
            let result = await AdminDetails.findOneAndUpdate({ email: params.email }, params, { rawResult: true })
            return result;
        } catch (error) {
            console.log(error);
        }
    }
    async findById(email) {
        try {
            if (email === undefined || email === null) {
                return false;
            }
            const result = await AdminDetails.findOne({ email: email });
            if (result === null) return false;
            return true;
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = AdminDetailsService;