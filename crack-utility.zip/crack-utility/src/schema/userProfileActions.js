const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const UserProfileActionSchema = Joi.object().keys({
    object_id: JoiCustomSchema.stringInputRequired,
    event_for: JoiCustomSchema.stringInput,
    app_id: JoiCustomSchema.numberInput,
    action: JoiCustomSchema.stringInputRequired,
    user_id: JoiCustomSchema.numberInputRequired,
    user_detail: JoiCustomSchema.objectInput
});

module.exports = UserProfileActionSchema;