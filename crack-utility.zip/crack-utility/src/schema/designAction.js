const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const DesignActionSchema = Joi.object().keys({
    object_id: JoiCustomSchema.stringInput,
    sr_tracker_number: JoiCustomSchema.stringInputAlphabetDigitHyphenUnderscore,
    event_for: JoiCustomSchema.stringInputRequired,
    app_id: JoiCustomSchema.numberInput,
    is_admin: Joi.boolean(),
    user_id: JoiCustomSchema.stringInput,
    action: JoiCustomSchema.stringInputRequired.valid('like', 'reuse', 'save', 'view', 'share', 'download', 'customization', 'create', 'update')
});

module.exports = DesignActionSchema;