const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const DownloadAssetsSchema = Joi.object().keys({
    unique_id: JoiCustomSchema.stringInputAlphabetDigitHyphenUnderscore,
    event_for: JoiCustomSchema.stringInputRequired.valid('plans', 'styles'),
    allFields: Joi.boolean(),
    object: JoiCustomSchema.stringInput
});

module.exports = DownloadAssetsSchema;