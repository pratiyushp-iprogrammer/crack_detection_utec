const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const updateAdditionalMetaTagsSchema = Joi.object().keys({
    fileName: JoiCustomSchema.stringInputRequired
});

module.exports = updateAdditionalMetaTagsSchema;