const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const DeleteStyleSchema = Joi.object().keys({
    unique_id: JoiCustomSchema.stringInputAlphabetDigitHyphenUnderscore,
    is_active: JoiCustomSchema.numberInput,
    updated_by: JoiCustomSchema.stringInput
});

module.exports = DeleteStyleSchema;