const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const MigrateStyleFromPlanSchema = Joi.object().keys({
    limit: JoiCustomSchema.numberInputRequired
});

module.exports = MigrateStyleFromPlanSchema;