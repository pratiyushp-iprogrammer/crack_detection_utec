const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const UpdateSyleElevationSchema = Joi.object().keys({
    unique_id: JoiCustomSchema.stringInputAlphabetDigitHyphenUnderscore,
    source: JoiCustomSchema.stringInputAlphabetDigitHyphenUnderscoreSpace,
    sr_number: JoiCustomSchema.stringInput,
    option_number: JoiCustomSchema.stringInput,
    design_name: JoiCustomSchema.stringInput,
    design_short_description: JoiCustomSchema.stringInput,
    design_long_description: JoiCustomSchema.stringInput,
    files: Joi.object({
        two_d_rendered_plan_jpg: Joi.object({
            ground: JoiCustomSchema.stringInput,
            ground_plus_one: JoiCustomSchema.stringInput,
            ground_plus_two: JoiCustomSchema.stringInput,
            ground_plus_three: JoiCustomSchema.stringInput,
            ground_plus_four: JoiCustomSchema.stringInput,
            above_ground_plus_four: JoiCustomSchema.stringInput,
            others: JoiCustomSchema.stringInput
        }),
        two_d_line_drawing_jpg: Joi.object({
            ground: JoiCustomSchema.stringInput,
            ground_plus_one: JoiCustomSchema.stringInput,
            ground_plus_two: JoiCustomSchema.stringInput,
            ground_plus_three: JoiCustomSchema.stringInput,
            ground_plus_four: JoiCustomSchema.stringInput,
            above_ground_plus_four: JoiCustomSchema.stringInput,
            others: JoiCustomSchema.stringInput
        }),
        two_d_line_drawing_pdf: Joi.object({
            two_d_line_drawing_pdf_id: JoiCustomSchema.stringInput
        }),
        three_d_design_id: Joi.object({
            front: JoiCustomSchema.stringInput,
            right_side: JoiCustomSchema.stringInput,
            left_side: JoiCustomSchema.stringInput,
            rear_side: JoiCustomSchema.stringInput,
            internal: JoiCustomSchema.stringInput
        }),
        three_d_cut_iso_jpg: Joi.object({
            ground: JoiCustomSchema.stringInput,
            ground_plus_one: JoiCustomSchema.stringInput,
            ground_plus_two: JoiCustomSchema.stringInput,
            ground_plus_three: JoiCustomSchema.stringInput,
            ground_plus_four: JoiCustomSchema.stringInput,
            above_ground_plus_four: JoiCustomSchema.stringInput,
            others: JoiCustomSchema.stringInput
        }),
        linked_estimation_id: Joi.object({
            estimation_id: JoiCustomSchema.stringInput
        }),
        linked_stetch_up_file: Joi.object({
            sketch_up_file_id: JoiCustomSchema.stringInput
        }),
        linked_dwg_file: Joi.object({
            linked_dwg_file_id: JoiCustomSchema.stringInput
        }),
        linked_psd_file: Joi.object({
            linked_psd_file_id: JoiCustomSchema.stringInput
        }),
        linked_ppt_file: Joi.object({
            linked_ppt_file_id: JoiCustomSchema.stringInput
        }),
        utec_pro_link: Joi.object({
            utec_pro_link_id: JoiCustomSchema.stringInput
        })
    }),
    plot_details: Joi.object({
        plot_area: JoiCustomSchema.numberInput,
        plot_length: JoiCustomSchema.numberInput,
        plot_width: JoiCustomSchema.numberInput,
        plot_shape: JoiCustomSchema.stringInput,
        left_setback: JoiCustomSchema.numberInput,
        right_setback: JoiCustomSchema.numberInput,
        front_setback: JoiCustomSchema.numberInput,
        rear_setback: JoiCustomSchema.numberInput,
        close_sides_of_the_plot: JoiCustomSchema.numberInput
    }),
    project_details: Joi.object({
        typology: JoiCustomSchema.stringInput,
        estimated_cost_of_construction: JoiCustomSchema.stringInput,
        builtup_area: JoiCustomSchema.numberInput,
        floor_plate_area_of_ground_floor: JoiCustomSchema.numberInput,
        floor_plate_length: JoiCustomSchema.numberInput,
        floor_plate_width: JoiCustomSchema.numberInput,
        floors: JoiCustomSchema.stringInput,
        bedrooms: JoiCustomSchema.numberInput,
        shared_wall: JoiCustomSchema.numberInput,
        for_two_shared_wall_adjacent_parallel: JoiCustomSchema.stringInput,
        style: JoiCustomSchema.stringInput,
        low_range_budget: JoiCustomSchema.stringInput,
        high_range_budget: JoiCustomSchema.stringInput
    }),
    geography: Joi.object({
        state: JoiCustomSchema.stringInput,
        city: JoiCustomSchema.stringInput,
        district: JoiCustomSchema.stringInput,
        geo_coordinates: JoiCustomSchema.stringInput,
        pincode: JoiCustomSchema.numberInput
    }),
    family_details: Joi.object({
        total_family_members: JoiCustomSchema.numberInput,
        number_of_senior_citizen: JoiCustomSchema.numberInput,
        number_of_adults: JoiCustomSchema.numberInput,
        number_of_children: JoiCustomSchema.numberInput,
        number_of_infants: JoiCustomSchema.numberInput
    }),
    parking: Joi.object({
        basement: JoiCustomSchema.stringInput,
        stilts: JoiCustomSchema.stringInput,
        two_wheeler_parking: JoiCustomSchema.numberInput,
        four_wheeler_parking: JoiCustomSchema.numberInput
    }),
    senior_citizen_friendly: Joi.object({
        max_three_stairs_to_enter_the_ground_floor: JoiCustomSchema.stringInput,
        one_bhk_on_ground_floor: JoiCustomSchema.stringInput,
        provision_of_ramp: JoiCustomSchema.stringInput
    }),
    open_areas_configuration: Joi.object({
        balcony: JoiCustomSchema.numberInput,
        porch: JoiCustomSchema.stringInput,
        garden: JoiCustomSchema.stringInput,
        courtyard: JoiCustomSchema.stringInput,
        frontyard: JoiCustomSchema.stringInput,
        backyard: JoiCustomSchema.stringInput,
        terrace: JoiCustomSchema.stringInput
    }),
    roof: Joi.object({
        roof_type: JoiCustomSchema.stringInput
    }),
    stylized: Joi.object({
        stylized_configuration: JoiCustomSchema.stringInput
    }),
    special_amenities: Joi.object({
        pool: JoiCustomSchema.stringInput
    }),
    material_treatment: Joi.object({
        brick: JoiCustomSchema.stringInput,
        stone: JoiCustomSchema.stringInput,
        wood: JoiCustomSchema.stringInput,
        tile: JoiCustomSchema.stringInput,
        aluminium_composite_panel: JoiCustomSchema.stringInput,
        glass_curtain_wall: JoiCustomSchema.stringInput
    }),
    structural_elements: Joi.object({
        pergola: JoiCustomSchema.stringInput,
        jaali: JoiCustomSchema.stringInput,
        green_wall: JoiCustomSchema.stringInput,
        planter: JoiCustomSchema.stringInput,
        vault: JoiCustomSchema.stringInput,
        double_height_open_area: JoiCustomSchema.stringInput,
        elevation_element: JoiCustomSchema.stringInput
    }),
    colors: Joi.object({
        color_scheme: JoiCustomSchema.stringInput,
        color_used: JoiCustomSchema.stringInput
    }),
    partner_details: Joi.object({
        partner_id: JoiCustomSchema.stringInput,
        partner_name: JoiCustomSchema.stringInput
    }),
    translation_file: JoiCustomSchema.objectInput,
    reference_images: JoiCustomSchema.stringInput,
    is_active: JoiCustomSchema.numberInput,
    number_of_times_reused: JoiCustomSchema.zeroNumberInput,
    number_of_times_viewed: JoiCustomSchema.zeroNumberInput,
    created_by: JoiCustomSchema.numberInput,
    updated_by: JoiCustomSchema.zeroNumberInput
});

module.exports = UpdateSyleElevationSchema;