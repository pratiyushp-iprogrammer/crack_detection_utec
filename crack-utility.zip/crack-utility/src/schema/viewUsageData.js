const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const ViewUsageDataSchema = Joi.object().keys({
    _id: JoiCustomSchema.stringInputRequired,
    is_admin: Joi.boolean(),
    user_id: JoiCustomSchema.stringInput,
});

module.exports = ViewUsageDataSchema;