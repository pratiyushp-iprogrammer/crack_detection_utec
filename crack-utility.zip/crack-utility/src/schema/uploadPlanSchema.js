let Joi = require("joi");
Joi = Joi.extend(require('../common/joi-custom-types.custom.js'));
let extensions = ["csv", "xlsx", "xls", "xlt", "xla", "zip", "xlsm", "xlsb", "pdf", "rar","ppt","skp","psd","dwg","jpg","jpeg","png"];

const uploadPlanSchema = Joi.object().keys({        
    payload: Joi.object().keys({
        created_by: Joi.string().optional(),
        file_link : Joi.string().validateFile({extensions : extensions}).optional(),
        file_link_list : Joi.array().empty(Joi.array().length(0)).optional()
    })
});

module.exports = { uploadPlanSchema };