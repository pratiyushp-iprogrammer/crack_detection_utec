const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const SyleViewUsageDataSchema = Joi.object().keys({
    style_id: JoiCustomSchema.stringInputRequired,
    is_admin: Joi.boolean(),
    user_id: JoiCustomSchema.stringInput,
});

module.exports = SyleViewUsageDataSchema;