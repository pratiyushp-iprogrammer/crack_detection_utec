const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const ViewPlanDetailsSchema = Joi.object().keys({
    unique_id: JoiCustomSchema.stringInputAlphabetDigitHyphenUnderscore,
});

module.exports = ViewPlanDetailsSchema;