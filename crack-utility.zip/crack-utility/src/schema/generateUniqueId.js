const Joi = require("joi");
const JoiCustomSchema = require('../common/joi_custom_schema');

const GenerateUniqueIdSchema = Joi.object().keys({
    source: JoiCustomSchema.stringInputRequired,
    event_for: JoiCustomSchema.stringInputRequired.valid('plans', 'styles')
});

module.exports = GenerateUniqueIdSchema;