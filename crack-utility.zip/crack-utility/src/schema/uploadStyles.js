let Joi = require("joi");
Joi = Joi.extend(require('../common/joi-custom-types.custom.js'));
let extensions = ["csv","xlsx","xls","xlt","xla", "zip","xlsm","xlsb",
"pdf","rar","ppt","skp","psd","dwg","jpg","jpeg","png"];

const uploadStylesSchema = Joi.object().keys({
    payload: Joi.object({
        file_link: Joi.string().validateFile({ extensions: extensions }).required(),
        file_link_list: Joi.array().items(Joi.string().validateFile({ extensions: extensions })).optional(),
    })
})

module.exports = uploadStylesSchema;