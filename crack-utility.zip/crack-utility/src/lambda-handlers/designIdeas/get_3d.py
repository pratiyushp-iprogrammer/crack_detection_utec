import pandas as pd
import numpy as np
import traceback
import boto3
import os
import io
from pymongo import MongoClient
from collections import OrderedDict


def isnan(value):
    try:
        import math
        return math.isnan(float(value))
    except:
        return False


def get_floors(data, no_of_floors, no_of_options):
    sort = None
    temp = None
    temp = data.loc[data["# Floors"] == no_of_floors]
    sort = data.loc[data["# Floors"] == no_of_floors]
    sort = sort.sort_values(by="# Floors")
    if len(sort) > no_of_options:
        return sort, temp, 1
    else:
        return sort, temp, 0

def convertToInt(value):
    if value is np.nan or value == 'nan':
        return 0
    elif value != "":
        newValue = str(value).split("'")[0]
        if "." in newValue:
            return int(float(newValue))
        elif newValue is np.nan or newValue == 'nan':
            return 0
        else:
            return int(newValue)

def get_3ddesigns(final, no_of_options_2d, no_of_options_3d, plot_area, plot_entrance_width, no_of_floors, no_of_bedrooms):
    try:
        print("================= in get_3ddesigns function:")
        # UPLOAD_S3_BUCKET = os.environ['UPLOAD_S3_BUCKET']
        # DM_AWS_REGION = os.environ['DM_AWS_REGION']

        # client = boto3.client('s3', aws_access_key_id=aws_id, aws_secret_access_key=aws_secret)
        # client = boto3.client('s3')

        env_deploy = os.environ['DEPLOYMENT']
        if env_deploy == 'stage' or env_deploy == 'prod' or env_deploy == 'preprod' or env_deploy == 'production':
            dirname = os.path.dirname(__file__)
            dbclient = MongoClient(os.environ['MONGO_DB_CONN_STRING'], tls=True, tlsCAFile=os.path.join(dirname, 'ca.pem'))
        else:
            dbclient = MongoClient(os.environ['MONGO_DB_CONN_STRING'])

        dbclient.admin.authenticate(os.environ['DB_USER'], os.environ['DB_PASSWORD'])
        db = dbclient['plansManagement']

        # bucket_name = 'design-management-assets'
        # object_key = 'Design Picker Database.xlsx'
        # sheet_name = "3D_Metadata"

        # obj = client.get_object(Bucket=bucket_name, Key=object_key)
        # df2 = pd.read_excel(io.BytesIO(
        #     obj['Body'].read()), sheet_name="3D_Metadata")

        # df2 = pd.ExcelFile(io.BytesIO(obj['Body'].read()))

        # df2.parse(sheet_name)

        # plot_entrance_width = plot_entrance_width - 5
        no_of_options_3d_act = no_of_options_3d
        # df2 = pd.read_excel('Design Picker Database.xlsx', sheet_name="3D_Metadata")

        # 3D Design Picker
        plot_entrance_array = ["0-9", "10-14", "15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49",
                               "50-54", "55-59", "60-64", "65-69", "70-74", "75-79", "80-84", "85-89", "90-94", "95-99", "100-999", "> 999"]
        plot_area_range_array = ["< 500", "500-749", "750-999", "1000-1249", "1250-1499", "1500-1999",
                                 "2000-2499", "2500-2999", "3000-3999", "4000-4999", "5000-5999", "6000-9999", "> 9999"]

        Plot_Entrance_Range = ''
        if plot_entrance_width < 9:
            Plot_Entrance_Range = plot_entrance_array[(plot_entrance_width // 10)]
        elif plot_entrance_width < 99:
            Plot_Entrance_Range = plot_entrance_array[(plot_entrance_width // 5) - 1]
        elif plot_entrance_width < 1000:
            Plot_Entrance_Range = plot_entrance_array[(plot_entrance_width // 1000) + 19]
        else:
            Plot_Entrance_Range = plot_entrance_array[20]

        Plot_Entrance_Range_one_down = plot_entrance_array[plot_entrance_array.index(Plot_Entrance_Range)]
        if plot_entrance_array.index(Plot_Entrance_Range) != 0:
            Plot_Entrance_Range_one_down = plot_entrance_array[plot_entrance_array.index(Plot_Entrance_Range) - 1]

        Plot_Entrance_Range_one_up = plot_entrance_array[plot_entrance_array.index(Plot_Entrance_Range)]
        if plot_entrance_array.index(Plot_Entrance_Range) != (len(plot_entrance_array) - 1):
            Plot_Entrance_Range_one_up = plot_entrance_array[plot_entrance_array.index(Plot_Entrance_Range) + 1]
        print("range", Plot_Entrance_Range)

        # if plot_area < 1500:
        #     Plot_Area_Range = plot_area_range_array[((plot_area // 250) - 1)]
        # elif plot_area < 3000:
        #     Plot_Area_Range = plot_area_range_array[((plot_area // 500) + 2)]
        # elif plot_area < 6000:
        #     Plot_Area_Range = plot_area_range_array[((plot_area // 1000) + 3)]
        # elif plot_area < 10000:
        #     Plot_Area_Range = plot_area_range_array[((plot_area // 6000) + 10)]
        # else:
        #     Plot_Area_Range = plot_area_range_array[len(plot_area_range_array) - 1]

        # Plot_Area_Range_one_up = plot_area_range_array[plot_area_range_array.index(
        #     Plot_Area_Range)]
        # if plot_area_range_array.index(Plot_Area_Range) != (len(plot_area_range_array) - 1):
        #     Plot_Area_Range_one_up = plot_area_range_array[plot_area_range_array.index(
        #         Plot_Area_Range) + 1]

        # Plot_Area_Range_one_down = plot_area_range_array[plot_area_range_array.index(
        #     Plot_Area_Range)]
        # if plot_area_range_array.index(Plot_Area_Range) != 0:
        #     Plot_Area_Range_one_down = plot_area_range_array[plot_area_range_array.index(
        #         Plot_Area_Range) - 1]

        linked_3d_designs = []
        final_2d = []
        count_of_final = len(final)
        designs_linked_3d = []
        
        if count_of_final > 0:
            fetch_count = count_of_final if count_of_final < 5 else 5
            print("fetch_count", fetch_count)
            final_2d = final.iloc[:fetch_count]
            print('final_2d["Linked 3D Designs"] LENGTH::', len(final_2d["Linked 3D Designs"]))
            final_2d.dropna(subset = ["Linked 3D Designs"], inplace=True)
            if(len(final_2d) > 0):
                linked_3d_designs = final_2d["Linked 3D Designs"]
                print("linked_3d_designs", linked_3d_designs)
                nan_count = 0
        
                for data in linked_3d_designs.values.tolist():
                    if isnan(data) or not data:
                        nan_count = nan_count + 1
                    else:
                        designs_linked_3d.extend(data)
        
                # designs_linked_3d.drop_duplicates(subset=None, keep='first', inplace=True)
                designs_linked_3d = list(OrderedDict.fromkeys(designs_linked_3d))

        print("designs_linked_3d", designs_linked_3d)
        
        df2 = pd.DataFrame(list(db.styles.aggregate([{
            "$match": {
                "$or": [
                {
                "$and": [
                    {
                        "element_type": "Elevations", 
                    },
                    {
                        "is_active": 1
                    }
                ]
                },{
                    "unique_id": {
                        "$in": designs_linked_3d
                    }
                }
                ]
            }
        },
            {
                "$project": {
                    "_id": 0,
                    "3D Unique ID": "$unique_id",
                    "Batch Number": "",
                    "# Floors": "$project_details.floors",
                    "Plot Entrance Width": "$project_details.floor_plate_width",
                    "Plot Entrance Width Range": "$project_details.floor_plate_width_range",
                    "Usage": "",
                    "# Shared Wall (building)": "$project_details.shared_wall",
                    "# Bedrooms": "$project_details.bedrooms",
                    "Stylized Configuration": "$stylized.stylized_configuration",
                    "Plot Shape": "$plot_details.plot_shape",
                    "Comments": "",
                    "Files": "$files.three_d_design_id.front",
                    "element_type": "$element_type"
                }
        }
        ])))

        plot_width_flag_3d = 0

        print("designs_linked_3d - len", len(designs_linked_3d))
        print("no_of_options_3d ", no_of_options_3d)
        if len(designs_linked_3d) > 0 and len(designs_linked_3d) < no_of_options_3d:
            final_3d = df2.loc[df2['3D Unique ID'].isin(designs_linked_3d)]
            no_of_options_3d = no_of_options_3d - len(designs_linked_3d)
            ref_3d = designs_linked_3d[0]
            print("ref_3d",ref_3d)
            print("for compare", df2['3D Unique ID'] == ref_3d)
            print("sndjfiw", (df2.loc[df2['3D Unique ID'] == ref_3d])['# Floors'])
            ref_floors = (df2.loc[df2['3D Unique ID'] == ref_3d])['# Floors'].tolist()[0]

            print("ref_floors", ref_floors)

            df2['Plot Entrance Width'] = df2['Plot Entrance Width'].fillna(0)
            ref_plotwidth = int((df2.loc[df2['3D Unique ID'] == ref_3d])['Plot Entrance Width'].tolist()[0])
            
            print("ref_plotwidth", ref_plotwidth)

            ref_plotwidth_range = ''
            if ref_plotwidth < 9:
                ref_plotwidth_range = plot_entrance_array[(ref_plotwidth // 10)]
            elif ref_plotwidth < 99:
                ref_plotwidth_range = plot_entrance_array[(ref_plotwidth // 5) - 1]
            elif ref_plotwidth < 1000:
                ref_plotwidth_range = plot_entrance_array[19]
            else:
                ref_plotwidth_range = plot_entrance_array[20]

            for data in designs_linked_3d:
                df2.drop(df2[df2['3D Unique ID'] == data].index.tolist()[0], inplace=True)

            # No of Floors
            sort_3d, temp_3d, floors_flag_3d = get_floors(df2, ref_floors, no_of_options_3d)

            # plot entrance
            print("step 1 check floor entrance")
            if floors_flag_3d == 1:
                temp_3d = sort_3d.loc[sort_3d['Plot Entrance Width']== ref_plotwidth]
                if len(temp_3d) > no_of_options_3d:
                    plot_width_flag_3d = 1
                elif plot_entrance_array.index(ref_plotwidth_range) > 0:
                    temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width Range'] == plot_entrance_array[plot_entrance_array.index(ref_plotwidth_range) - 1]]
                    temp_3d = temp_3d.append(temp_1)
                    if len(temp_3d) > no_of_options_3d:
                        plot_width_flag_3d = 1
                    elif plot_entrance_array.index(ref_plotwidth_range) < (len(plot_entrance_array) - 1):
                        temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width Range'] == plot_entrance_array[plot_entrance_array.index(ref_plotwidth_range) + 1]]
                        temp_3d = temp_3d.append(temp_1)
                        if len(temp_3d) > no_of_options_3d:
                            plot_width_flag_3d = 1

            print("step 1 drop_duplicates")
            temp_3d.drop_duplicates(
                subset='3D Unique ID', keep="first", inplace=True)
            sort_3d.drop_duplicates(
                subset='3D Unique ID', keep="first", inplace=True)

            if plot_width_flag_3d == 1:
                sort_3d = temp_3d

            # No of bedrooms
            print("step 1 check bedrooms")
            if plot_width_flag_3d == 1:
                temp_3d = sort_3d.loc[sort_3d['# Bedrooms'] == no_of_bedrooms]
                if len(temp_3d) > no_of_options_3d:
                    bedroom_flag_3d = 1
                else:
                    temp_1 = sort_3d.loc[sort_3d['# Bedrooms'] == no_of_bedrooms + 1]
                    temp_3d = temp_3d.append(temp_1)
                    if len(temp_3d) > no_of_options_3d:
                        bedroom_flag_3d = 1
                    else:
                        temp_1 = sort_3d.loc[sort_3d['# Bedrooms'] == no_of_bedrooms - 1]
                        temp_3d = temp_3d.append(temp_1)
                    if len(temp_3d) > no_of_options_3d:
                        bedroom_flag_3d = 1

            print("step 1 drop_duplicates")
            temp_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=True)
            sort_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=True)

            # final sort
            print("step 1 final sort")
            if len(temp_3d) != 0:
                cond = sort_3d['3D Unique ID'].isin(temp_3d['3D Unique ID'])
                sort_3d.drop(sort_3d[cond].index, inplace=True)
            if len(temp_3d) != 0 and len(temp_3d) < no_of_options_3d:
                final_3d = final_3d.append(temp_3d)
                if len(final_3d) < no_of_options_3d:
                    cond = sort_3d['3D Unique ID'].isin(final_3d['3D Unique ID'])
                    sort_3d.drop(sort_3d[cond].index, inplace=True)
                    final_3d = final_3d.append(sort_3d.sort_values(by=["# Shared Wall (building)"]))

            elif len(temp_3d) == no_of_options_3d:
                final_3d = final_3d.append(temp_3d)
            elif len(temp_3d) == 0:
                sort_3d = sort_3d.sort_values(by=["# Shared Wall (building)"])
                final_3d = final_3d.append(sort_3d)
            else:
                temp_3d = temp_3d.sort_values(by=["# Shared Wall (building)"])
                final_3d = final_3d.append(temp_3d)
            # first for loop on final_3d
            # for data in final_3d.iloc[:, [1, 12]].values.tolist():
            #     for temp in data:
            #         designs_linked_3d.append(temp)
            # final_3d = designs_linked_3d

        elif len(designs_linked_3d) == no_of_options_3d:
            print("step 2")
            final_3d = designs_linked_3d
        ################################################################################################################################################

        elif len(designs_linked_3d) > no_of_options_3d:
            print("step 3")
            dummy = None
            # for data in designs_linked_3d:
            dummy = (df2.loc[df2['3D Unique ID'].isin(designs_linked_3d)])
            final_3d = dummy.sort_values(by=["# Shared Wall (building)"])

            # second for loop on final_3d
            # to_list = []
            # for data in final_3d.iloc[:, np.r_[1,12]].values.tolist():
            #     print(data)
            #     for temp in data:
            #         to_list.append(temp)
            # final_3d = to_list

        else:
            print("2d to 3d")
            # use 2d to 3d mapping
            # No of floors
            sort_3d, temp_3d, floors_flag_3d = get_floors(df2, no_of_floors, no_of_options_3d)
            print("columns")
            print(sort_3d.columns)
            # plot entrance
            print("floors_flag_3d", floors_flag_3d)
            # if floors_flag_3d == 1:
            # print("value as it is", sort_3d['Plot Entrance Width'])
            # print("converted value: ", sort_3d['Plot Entrance Width'].apply(convertToInt))
            temp_3d = sort_3d.loc[sort_3d['Plot Entrance Width'].apply(convertToInt) == plot_entrance_width]
            print("plot_entrance_width", plot_entrance_width)
            print("temp_3d 1:", len(temp_3d))
            print("sort_3d 1:", len(sort_3d))
            if plot_entrance_width < 10:
                print("line 300")
                # filter out results that are either less than equal to 10 ( 0 2 8 )
                temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width'].apply(convertToInt) == plot_entrance_width]
                # sort results on col Flot Ent Width Range, Ascending order
                temp_3d = temp_3d.append(temp_1.sort_values(by='Plot Entrance Width', ascending=True))
                print("temp_3d 2:", len(temp_3d))
                print("sort_3d 2:", len(sort_3d))
            elif plot_entrance_width >= 10 and plot_entrance_width < 100:
                print("line 344")
                # filter out results that are greater than equal to 10
                temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width'].apply(convertToInt) >= plot_entrance_width]
                # sort results on col Flot Ent Width Range, Ascending order
                temp_3d = temp_3d.append(temp_1.sort_values(by='Plot Entrance Width', ascending=True))
                print("temp_3d 3:", len(temp_3d))
                print("sort_3d 3:", len(sort_3d))
            elif plot_entrance_width >= 100 and plot_entrance_width < 1000:
                print("line 312")
                # filter out results that are less than 1000
                temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width'].apply(convertToInt) <= plot_entrance_width]
                # sort results on col Flot Ent Width Range, Ascending order
                temp_3d = temp_3d.append(temp_1.sort_values(by='Plot Entrance Width', ascending=True))
                print("temp_3d 4:", len(temp_3d))
                print("sort_3d 4:", len(sort_3d))
            else:
                print("line 318")
                # filter out results that are greater than 1000
                temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width'].apply(convertToInt) == plot_entrance_width]
                # sort results on col Flot Ent Width Range, Ascending order
                temp_3d = temp_3d.append(temp_1.sort_values(by='Plot Entrance Width', ascending=True))
                print("temp_3d 5:", len(temp_3d))
                print("sort_3d 5:", len(sort_3d))

            # if plot_entrance_width < 10:
            #     temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width Range'] >= Plot_Entrance_Range_one_up]
            #     temp_3d = temp_3d.append(temp_1)
            #     if len(temp_3d) > no_of_options_3d:
            #         plot_width_flag_3d = 1
            # elif plot_entrance_width >= 10:
            #     print("line 320")
            #     print("Plot_Entrance_Range_one_down", Plot_Entrance_Range_one_down)
            #     temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width Range'] >= Plot_Entrance_Range_one_down]
            #     temp_3d = temp_3d.append(temp_1)
            #     if len(temp_3d) > no_of_options_3d:
            #         plot_width_flag_3d = 1
            # elif plot_entrance_width < 1000:
            #     temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width Range']
            #                             <= Plot_Entrance_Range_one_up]
            #     temp_3d = temp_3d.append(temp_1)
            #     if len(temp_3d) > no_of_options_3d:
            #         plot_width_flag_3d = 1
            # else:
            #     temp_1 = sort_3d.loc[sort_3d['Plot Entrance Width Range']
            #                             <= Plot_Entrance_Range_one_up]
            #     temp_3d = temp_3d.append(temp_1)
            #     if len(temp_3d) > no_of_options_3d:
            #         plot_width_flag_3d = 1
            print("line 348")
            temp_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=False)
            sort_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=False)
            print("temp_3d 6:", len(temp_3d))
            print("sort_3d 6:", len(sort_3d))

            if len(temp_3d) < no_of_options_3d:
                plot_width_flag_3d = 1

            # No of bedrooms
            if plot_width_flag_3d == 1:
                temp_3d = sort_3d.loc[sort_3d['# Bedrooms'] == no_of_bedrooms]
                if len(temp_3d) > no_of_options_3d:
                    bedroom_flag_3d = 1
                else:
                    temp_1 = sort_3d.loc[sort_3d['# Bedrooms'] == no_of_bedrooms + 1]
                    temp_3d = temp_3d.append(temp_1)
                    if len(temp_3d) > no_of_options_3d:
                        bedroom_flag_3d = 1
                    else:
                        temp_1 = sort_3d.loc[sort_3d['# Bedrooms'] == no_of_bedrooms - 1]
                        temp_3d = temp_3d.append(temp_1)
                    if len(temp_3d) > no_of_options_3d:
                        bedroom_flag_3d = 1

            temp_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=False)
            sort_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=False)

            # Final Sort
            if len(temp_3d) != 0:
                cond = sort_3d['3D Unique ID'].isin(temp_3d['3D Unique ID'])
                sort_3d.drop(sort_3d[cond].index, inplace=False)
            if len(temp_3d) != 0 and len(temp_3d) < no_of_options_3d:
                final_3d = temp_3d
                if len(final_3d) < no_of_options_3d:
                    cond = sort_3d['3D Unique ID'].isin(final_3d['3D Unique ID'])
                    sort_3d.drop(sort_3d[cond].index, inplace=False)
                    final_3d = final_3d.append(sort_3d.sort_values(by=["# Shared Wall (building)"]))

            elif len(temp_3d) == no_of_options_3d:
                final_3d = temp_3d

            elif len(temp_3d) == 0:
                final_3d = sort_3d.sort_values(by=["# Shared Wall (building)"])

            else:
                final_3d = temp_3d.sort_values(by=["# Shared Wall (building)"])

            final_3d = final_3d.drop_duplicates(subset='3D Unique ID', keep="first", inplace=False)
            # third for loop on final_3d
            # to_list = []
            # for data in final_3d.iloc[:, [1, 12]].values.tolist():
            #     for temp in data:
            #         to_list.append(temp)
            # final_3d = to_list

        list_3d = []
        final_3d = final_3d[["3D Unique ID", "Files"]]
        for data in final_3d.iloc[:, np.r_[0:2]].values.tolist():
            images = []
            if not(pd.isnull(data[1])):
                if ',' in data[1]:
                    img_list = data[1].split(",")
                    for img in img_list:
                        if img != "" and not(pd.isnull(img)):
                            images.append(img)
                else:
                    if data[1] != "" and not(pd.isnull(data[1])):
                        images.append(data[1])

            list_3d.append({
                "unique_id": data[0],
                "image_url": images
            })

            # for temp in data:
            #     to_list.append(temp)
        final_3d = list_3d

        # there are no results found in elevations
        # print("check for final elevations: ", len(final_3d), final_3d)
        if len(final_3d) < 3:
            # elevations_data = df2.loc[df2['element_type'] == "Elevations"]
            # default_data = elevations_data.tail(6)
            default_data = df2 #.loc[df2['element_type'] == "Elevations"]
            default_data = default_data[["3D Unique ID", "Files"]]

            # iterate on default data
            for data in default_data.iloc[:, np.r_[0:2]].values.tolist():
                images = []
                if not(pd.isnull(data[1])):
                    if ',' in data[1]:
                        img_list = data[1].split(",")
                        for img in img_list:
                            if img != "" and not(pd.isnull(img)):
                                images.append(img)
                    else:
                        if data[1] != "" and not(pd.isnull(data[1])):
                            images.append(data[1])

                # check for duplicates in already assigned list_3d
                if any(obj['unique_id'] == data[0] for obj in list_3d):
                    continue
                else:
                    list_3d.append({
                        "unique_id": data[0],
                        "image_url": images
                    })

                # break the for loop once 3 elevations are avaible
                if len(list_3d) == 3:
                    final_3d = list_3d
                    break

        return (final_3d[:no_of_options_3d_act])

    except Exception as err:
        print(err)
        traceback.print_exc()
