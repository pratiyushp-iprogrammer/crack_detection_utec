import pandas as pd
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))


def get_floors(data, no_of_floors, no_of_options):
    sort = None
    temp = None
    sort = data.loc[data["Floors"] == no_of_floors]
    temp = sort
    if len(sort) > no_of_options:
        return sort, temp, 1
    else:
        return sort, temp, 0


def isnan(value):
    try:
        import math
        return math.isnan(float(value))
    except:
        return False


def sort_items(data):
    temp_2d = data.loc[(data['Stilts'] == "No")]
    temp_2d = temp_2d.loc[(temp_2d['Shared Wall (building)'] <= 1)]
    # Lb Ratio to be added when the dataset size increases
    if not temp_2d.empty:
        cond = data['Unique ID'].isin(temp_2d['Unique ID'])
        data = data.drop(data[cond].index, inplace=True)
    return temp_2d, data


def chk_count(data_1, length):
    if len(data_1) > length:
        return 1
    else:
        return 0


def final_2d_colab(items, final2d, second_2d, options_2d, options_2d_actual):
    flag = 0
    final_2d_len = 0
    if not items.empty:
        flag = 1
        temp_2d, second_temp_2d, = sort_items(items)
        if temp_2d is not None:
            if final2d is None:
                final2d = temp_2d
            else:
                final2d = final2d.append(temp_2d)
            options_2d = options_2d - len(temp_2d)

        if second_temp_2d is not None:
            if second_2d is None:
                second_2d = second_temp_2d
            else:
                second_2d = second_2d.append(second_temp_2d)

        if not final2d is None :
            final_2d_len = len(final2d)

        if final_2d_len > options_2d_actual:
            # call a function to make the string of presentable format
            # get return statement here
            print("program breaks here")

    return final2d, second_2d, options_2d, flag


def get_designs_floorwise(no_of_floors, plot_area, plot_entrance_width, no_of_bedrooms, df, no_of_options_2d_actual):
    df_floor = df.loc[(df['Floors'] == no_of_floors)]
    plot_entrance_array = ["0-9", "10-14", "15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49",
                           "50-54", "55-59", "60-64", "65-69", "70-74", "75-79", "80-84", "85-89", "90-94", "95-99", "100-999", "> 999"]
    plot_area_range_array = ["< 500", "500-749", "750-999", "1000-1249", "1250-1499", "1500-1999",
                        "2000-2499", "2500-2999", "3000-3999", "4000-4999", "5000-5999", "6000-9999", "> 9999"]
    no_floors_array = ["G", "G+1", "G+2", "G+3", "G+4"]

    no_of_options_2d = no_of_options_2d_actual
    no_of_options_3d = 5
    no_of_options_3d_actual = no_of_options_3d

    final_2d = None
    second_final_2d = None

    if plot_area < 1500:
        Plot_Area_Range = plot_area_range_array[((plot_area // 250) - 1)]
    elif plot_area < 3000:
        Plot_Area_Range = plot_area_range_array[((plot_area // 500) + 2)]
    elif plot_area < 6000:
        Plot_Area_Range = plot_area_range_array[((plot_area // 1000) + 3)]
    elif plot_area < 10000:
        Plot_Area_Range = plot_area_range_array[((plot_area // 6000) + 10)]
    else:
        Plot_Area_Range = plot_area_range_array[len(plot_area_range_array) - 1]

    Plot_Area_Range_one_up = plot_area_range_array[plot_area_range_array.index(
        Plot_Area_Range)]
    if plot_area_range_array.index(Plot_Area_Range) != (len(plot_area_range_array) - 1):
        Plot_Area_Range_one_up = plot_area_range_array[plot_area_range_array.index(
            Plot_Area_Range) + 1]

    Plot_Area_Range_one_down = plot_area_range_array[plot_area_range_array.index(
        Plot_Area_Range)]
    if plot_area_range_array.index(Plot_Area_Range) != 0:
        Plot_Area_Range_one_down = plot_area_range_array[plot_area_range_array.index(
            Plot_Area_Range) - 1]

    Plot_Entrance_Range = ''
    if plot_entrance_width < 9:
        Plot_Entrance_Range = plot_entrance_array[0]
    elif plot_entrance_width < 99:
        Plot_Entrance_Range = plot_entrance_array[(
            plot_entrance_width // 5) - 1]
    elif plot_entrance_width < 1000:
        Plot_Entrance_Range = plot_entrance_array[19]
    else:
        Plot_Entrance_Range = plot_entrance_array[20]

    Plot_Entrance_Range_one_up = plot_entrance_array[plot_entrance_array.index(
        Plot_Entrance_Range)]
    if plot_entrance_array.index(Plot_Entrance_Range) != (len(plot_entrance_array) - 1):
        Plot_Entrance_Range_one_up = plot_entrance_array[plot_entrance_array.index(
            Plot_Entrance_Range) + 1]

    Plot_Entrance_Range_one_down = plot_entrance_array[plot_entrance_array.index(
        Plot_Entrance_Range)]
    if plot_entrance_array.index(Plot_Entrance_Range) != 0:
        Plot_Entrance_Range_one_down = plot_entrance_array[plot_entrance_array.index(
            Plot_Entrance_Range) - 1]

    Max_no_of_floors = no_floors_array[-1]

    # Actual Items
    act_items = df_floor.loc[
        (df_floor['Bedrooms'] >= no_of_bedrooms) & (
            df_floor['Plot Area Range'] == Plot_Area_Range)
        & (df_floor['Plot Entrance Width Range'] == Plot_Entrance_Range)]

    if not act_items.empty:
        temp_2d, second_temp_2d, = sort_items(act_items)
        if temp_2d is not None:
            final_2d = temp_2d
            no_of_options_2d = no_of_options_2d - len(temp_2d)

        if second_temp_2d is not None:
            second_final_2d = second_temp_2d

        # if chk_count(final_2d, no_of_options_2d_actual):
        #     # call a function to make the string of presentable format
        #     # get return statement here
        #     print("program breaks here")

    # Pw_items down
    pw_items_down = df_floor.loc[
        (df_floor['Bedrooms'] == no_of_bedrooms) & (
            df_floor['Plot Area Range'] == Plot_Area_Range)
        & (df_floor['Plot Entrance Width Range'] == Plot_Entrance_Range_one_down)]

    final_2d, second_final_2d, no_of_options_2d, pw_items_down_flag = \
        final_2d_colab(pw_items_down, final_2d, second_final_2d,
                       no_of_options_2d, no_of_options_2d_actual)

    # Pw_items up
    pw_items_up = df_floor.loc[
        (df_floor['Bedrooms'] == no_of_bedrooms) & (
            df_floor['Plot Area Range'] == Plot_Area_Range)
        & (df_floor['Plot Entrance Width Range'] == Plot_Entrance_Range_one_up)]

    final_2d, second_final_2d, no_of_options_2d, pw_items_up_flag = \
        final_2d_colab(pw_items_up, final_2d, second_final_2d,
                       no_of_options_2d, no_of_options_2d_actual)

    # Pa_items down
    pa_items_down = df_floor.loc[
        (df_floor['Bedrooms'] == no_of_bedrooms) & (
            df_floor['Plot Area Range'] == Plot_Area_Range_one_down)
        & (df_floor['Plot Entrance Width Range'] == Plot_Entrance_Range)]

    pa_items_down = pa_items_down.append(df_floor.loc[(df_floor['Bedrooms'] == no_of_bedrooms) & (
        df_floor['Plot Area Range'] == Plot_Area_Range_one_down)
        & (df_floor[
            'Plot Entrance Width Range'] == Plot_Entrance_Range_one_down)])

    pa_items_down = pa_items_down.append(df_floor.loc[(df_floor['Bedrooms'] == no_of_bedrooms) & (
        df_floor['Plot Area Range'] == Plot_Area_Range_one_down)
        & (df_floor[
            'Plot Entrance Width Range'] == Plot_Entrance_Range_one_up)])

    final_2d, second_final_2d, no_of_options_2d, pa_items_down_flag = \
        final_2d_colab(pa_items_down, final_2d, second_final_2d,
                       no_of_options_2d, no_of_options_2d_actual)

    # Pa_items up
    pa_items_up = df_floor.loc[
        (df_floor['Bedrooms'] == no_of_bedrooms) & (
            df_floor['Plot Area Range'] == Plot_Area_Range_one_up)
        & (df_floor['Plot Entrance Width Range'] == Plot_Entrance_Range)]

    pa_items_up = pa_items_up.append(df_floor.loc[(df_floor['Bedrooms'] == no_of_bedrooms) & (
        df_floor['Plot Area Range'] == Plot_Area_Range_one_up)
        & (df_floor[
            'Plot Entrance Width Range'] == Plot_Entrance_Range_one_down)])

    pa_items_up = pa_items_up.append(df_floor.loc[(df_floor['Bedrooms'] == no_of_bedrooms) & (
        df_floor['Plot Area Range'] == Plot_Area_Range_one_up)
        & (df_floor[
            'Plot Entrance Width Range'] == Plot_Entrance_Range_one_up)])

    final_2d, second_final_2d, no_of_options_2d, pa_items_up_flag = \
        final_2d_colab(pa_items_up, final_2d, second_final_2d,
                       no_of_options_2d, no_of_options_2d_actual)

    return final_2d, second_final_2d


def get_designs(df_act, no_of_floors_act, plot_area_act, plot_entrance_width_act, no_of_bedrooms_act):
    no_of_options_2d_act = 5
    # df_act = pd.read_csv(r"2D_Layouts.csv")

    act_2d, second_2d_act = get_designs_floorwise(no_of_floors_act, plot_area_act,
                                                  plot_entrance_width_act, no_of_bedrooms_act, df_act,
                                                  no_of_options_2d_act)

    act_2d_len = 0
    second_2d_act_len = 0
    if not act_2d is None:
        act_2d_len = len(act_2d)
    if not second_2d_act is None:
        second_2d_act_len = len(second_2d_act)

    # Chk for act_2d, sec 2d none

    # Reality Chk
    reality_flag = 0
    final_2d_act = None
    if (act_2d_len + second_2d_act_len) >= no_of_options_2d_act:
        final_2d_act = act_2d
        if final_2d_act is None:
            final_2d_act = second_2d_act
        else:
            final_2d_act = final_2d_act.append(second_2d_act)

    else:
        reality_flag = 1
        final_2d_act = act_2d
        if final_2d_act is None:
            final_2d_act = second_2d_act
        elif not second_2d_act is None:
            final_2d_act = final_2d_act.append(second_2d_act)

        final_2d_act_len = 0
        if not final_2d_act is None:
            final_2d_act_len = len(final_2d_act)

        no_of_bedrooms = no_of_bedrooms_act
        while (no_of_bedrooms <= 9) and ((final_2d_act_len) < no_of_options_2d_act):

            no_of_bedrooms = no_of_bedrooms + 1
            act_2d, second_2d_act = get_designs_floorwise(no_of_floors_act, plot_area_act,
                                                          plot_entrance_width_act, no_of_bedrooms, df_act,
                                                          (no_of_options_2d_act - final_2d_act_len))

            act_2d_len = 0
            second_2d_act_len = 0
            if not act_2d is None:
                act_2d_len = len(act_2d)
            if not second_2d_act is None:
                second_2d_act_len = len(second_2d_act)

            if not final_2d_act is None:
                if not act_2d is None:
                    final_2d_act = final_2d_act.append(act_2d)
            elif not act_2d is None:
                final_2d_act = act_2d

            if not final_2d_act is None:
                if not second_2d_act is None:
                    final_2d_act = final_2d_act.append(second_2d_act)
            elif not second_2d_act is None:
                final_2d_act = second_2d_act

    return final_2d_act
