import sys
import os
from io import StringIO
import json
import traceback
import pandas as pd
import numpy as np
import boto3
import option_1
import option_2
import get_3d
from pymongo import MongoClient


def getRecommendationsHandler(event, context):
    try:
        # path = sys.path.append(os.path.join(os.path.dirname(__file__)))

        UPLOAD_S3_BUCKET = os.environ['UPLOAD_S3_BUCKET']
        DM_AWS_REGION = os.environ['DM_AWS_REGION']
        S3_BUCKET_PATH = os.environ['S3_BUCKET_PATH']
        # client = boto3.client('s3', aws_access_key_id=aws_id, aws_secret_access_key=aws_secret)

        # client = boto3.client('s3')
        # bucket_name = 'design-management-assets'
        # object_key = '2D_Layouts.csv'
        # csv_obj = client.get_object(Bucket=bucket_name, Key=object_key)
        # body = csv_obj['Body']
        # csv_string = body.read().decode('utf-8')
        # df = pd.read_csv(StringIO(csv_string))

        # client = boto3.client('s3')

        env_deploy = os.environ['DEPLOYMENT']
        if env_deploy == 'stage' or env_deploy == 'prod' or env_deploy == 'preprod' or env_deploy == 'production':
            dirname = os.path.dirname(__file__)
            dbclient = MongoClient(
                os.environ['MONGO_DB_CONN_STRING'], tls=True, tlsCAFile=os.path.join(dirname, 'ca.pem'))
        else:
            dbclient = MongoClient(os.environ['MONGO_DB_CONN_STRING'])

        dbclient.admin.authenticate(
            os.environ['DB_USER'], os.environ['DB_PASSWORD'])
        db = dbclient['plansManagement']
        # uncomment below line to print all rows and columns while printing dataframe
        # pd.set_option("display.max_rows", None, "display.max_columns", None)
        df = pd.DataFrame(list(db.plans_managements.aggregate([
            {
                "$match": {
                    "$and": [
                        {
                            "unique_id": {
                                "$nin": [None, ""]
                        }
                        },{
                            "is_active": 1
                        }
                    ]
                }
            },
            {
                "$project": {
                    "_id": 0,
                    "Unique ID": "$unique_id",
                    "Source": "$source",
                    "Design Label": "$design_name",
                    "Linked 2D Rendered Plan JPG ID G": "$files.two_d_rendered_plan_jpg.ground",
                    "Linked 2D Rendered Plan JPG ID G+1": "$files.two_d_rendered_plan_jpg.ground_plus_one",
                    "Linked 2D Rendered Plan JPG ID G+2": "$files.two_d_rendered_plan_jpg.ground_plus_two",
                    "Linked 2D Rendered Plan JPG ID G+3": "$files.two_d_rendered_plan_jpg.ground_plus_three",
                    "Linked 2D Rendered Plan JPG ID G+4": "$files.two_d_rendered_plan_jpg.ground_plus_four",
                    "Linked 2D Rendered Plan JPG ID G+n": "$files.two_d_rendered_plan_jpg.above_ground_plus_four",
                    "Linked 2D Rendered Plan JPG ID G+n Others": "$files.two_d_rendered_plan_jpg.others",
                    "Linked 2D Line drawing JPG G": "$files.two_d_line_drawing_jpg.ground",
                    "Linked 2D Line drawing JPG G+1": "$files.two_d_line_drawing_jpg.ground_plus_one",
                    "Linked 2D Line drawing JPG G+2": "$files.two_d_line_drawing_jpg.ground_plus_two",
                    "Linked 2D Line drawing JPG G+3": "$files.two_d_line_drawing_jpg.ground_plus_three",
                    "Linked 2D Line drawing JPG G+4": "$files.two_d_line_drawing_jpg.ground_plus_four",
                    "Linked 2D Line drawing JPG G+n": "$files.two_d_line_drawing_jpg.above_ground_plus_four",
                    "Linked 2D Line drawing JPG Others": "$files.two_d_line_drawing_jpg.others",
                    "Linked 2D Rendered Plan PDF ID G": "$files.two_d_line_drawing_pdf.two_d_line_drawing_pdf_id",
                    "Linked 3D Design ID Front": "$files.three_d_design_id.front",
                    "Linked 3D Design ID Right": "$files.three_d_design_id.right_side",
                    "Linked 3D Design ID Left": "$files.three_d_design_id.left_side",
                    "Linked 3D Design ID Rear": "$files.three_d_design_id.rear_side",
                    "Linked 3D Design ID Internal": "$files.three_d_design_id.internal",
                    "3D Cut ISO JPG- G": "$files.three_d_cut_iso_jpg.ground",
                    "3D Cut ISO JPG- G+1": "$files.three_d_cut_iso_jpg.ground_plus_one",
                    "3D Cut ISO JPG- G+2": "$files.three_d_cut_iso_jpg.ground_plus_two",
                    "3D Cut ISO JPG- G+3": "$files.three_d_cut_iso_jpg.ground_plus_three",
                    "3D Cut ISO JPG- G+4": "$files.three_d_cut_iso_jpg.ground_plus_four",
                    "3D Cut ISO JPG- G+n": "$files.three_d_cut_iso_jpg.above_ground_plus_four",
                    "3D Cut ISO JPG- others": "$files.three_d_cut_iso_jpg.others",
                    "Linked Estimation ID": "$files.linked_estimation_id.estimation_id",
                    "Sketch up file ID": "$files.linked_stetch_up_file.sketch_up_file_id",
                    # "Linked DWG file ID": "$files.linked_dwg_file.linked_dwg_file_id",
                    # "Linked PSD file ID": "$files.linked_psd_file.linked_psd_file_id",
                    # "Linked PPT file ID": "$files.linked_ppt_file.linked_ppt_file_id",
                    # "Utech PRO file link ID": "$files.utec_pro_link.utec_pro_link_id",
                    "Plot Area Range": "$plot_details.plot_area_range",
                    "Plot Entrance Width Range": "$plot_details.plot_entrance_width_range",
                    "Suitable Plot Area": "$plot_details.plot_area",
                    "Suitable Plot Length": "$plot_details.plot_length",
                    "Suitable Plot Width": "$plot_details.plot_width",
                    # "Plot Shape": "$plot_details.plot_shape",
                    # "Open Sides of the Plot": "$plot_details.open_sides_of_the_plot",
                    # "Left Set Back": "$plot_details.left_set_back",
                    # "Right Set Back": "$plot_details.right_set_back",
                    # "Front Set Back": "$plot_details.front_set_back",
                    # "Rear Set Back": "$plot_details.rear_set_back",
                    # "Typology": "$project_details.typology",
                    # "Estimated Cost of Construction": "$project_details.estimated_cost_of_construction",
                    # "Built up area": "$project_details.builtup_area",
                    # "Floor Plate Area of Ground Floor": "$project_details.floor_plate_area_of_ground_floor",
                    # "Floor Plate Length": "$project_details.floor_plate_length",
                    # "Floor Plate Width (Entrance Side)": "$project_details.floor_plate_width",
                    # "Floor Plate Width Range": "$project_details.floor_plate_width_range",
                    "Floors": "$project_details.floors",
                    "Bedrooms": "$project_details.bedrooms",
                    "Shared Wall (building)": "$project_details.shared_wall",
                    # "For 2 Shared wall": "$project_details.for_two_shared_wall_adjacent_parallel",
                    # "Space Allocation": "$project_details.space_allocation",
                    # "Style": "$project_details.style",
                    "Low Range Budget": "$project_details.low_range_budget",
                    "High Range Budget": "$project_details.high_range_budget",
                    # "Weather Conditions": "$geography.weather_condition",
                    # "State": "$geography.state",
                    # "City": "$geography.city",
                    # "District": "$geography.district",
                    # "Geo Coordinates": "$geography.geo_coordinates",
                    # "Pincode": "$geography.pincode",
                    # "Budget": "$geography.budget",
                    # "Total Number of Family Members": "$family_details.total_family_members",
                    # "Number of Senior Citizens (age 60+)": "$family_details.number_of_senior_citizen",
                    # "Number of Adults (age 20 - 60)": "$family_details.number_of_adults",
                    # "Number of Children (age  4 - 19)": "$family_details.number_of_children",
                    # "Number of Infants (age 0 - 3)": "$family_details.number_of_infants",
                    # "Basement": "$parking.basement",
                    "Stilts": "$parking.stilts",
                    # "2 Wheeler Parking": "$parking.two_wheeler_parking",
                    # "4 Wheeler Parking": "$parking.four_wheeler_parking",
                    # "Maximum 3 stairs to enter the Ground Floor": "$senior_citizen_friendly.max_three_stairs_to_enter_the_ground_floor",
                    # "1 BHK present on the Ground Floor": "$senior_citizen_friendly.one_bhk_on_ground_floor",
                    # "Provision of Ramp": "$senior_citizen_friendly.provision_of_ramp",
                    # "Vaastu Compliant": "$vaastu_compliancy.vaastu_compliant",

                    # "Entry Direction": "$vaastu_compliancy.entry_direction",
                    # "Orientation of the Kitchen": "$vaastu_compliancy.orientation_of_kitchen",
                    # "Orientation of Pooja Room": "$vaastu_compliancy.orientation_of_pooja_room",
                    # "Orientation of Master Bedroom": "$vaastu_compliancy.orientation_of_master_bedrrom",
                    # "Total Bathrooms": "$rooms.total_bathrooms",
                    # "Attached Bathrooms": "$rooms.attached_bathrooms",
                    # "Common Bathrooms": "$rooms.common_bathrooms",
                    # "Dining Room": "$rooms.dining_room",
                    # "Living Room": "$rooms.living_room",
                    # "Kitchen": "$rooms.kitchen",
                    # "Family Room": "$rooms.family_room",
                    # "Store Room": "$rooms.store_room",
                    # "Pooja Room": "$rooms.pooja_room",
                    # "Shops": "$rooms.shops",
                    # "Balcony": "$open_areas.balcony",
                    # "Porch": "$open_areas.porch",
                    # "Verandah": "$open_areas.verandah",
                    # "Garden": "$open_areas.garden",
                    # "Courtyard": "$open_areas.courtyard",
                    # "Front Yard": "$open_areas.frontyard",
                    # "Back Yard"	: "$open_areas.backyard",
                    # "Terrace": "$open_areas.terrace",
                    # "Library": "$special_amenities.library",
                    # "Game Room": "$special_amenities.game_room",
                    # "Study Room": "$special_amenities.study_room",
                    # "Home Theatre": "$special_amenities.home_theatre",
                    # "Pool": "$special_amenities.pool",
                    # "Gym": "$special_amenities.gym",
                    # "Brick": "$material_treatment.brick",
                    # "Stone": "$material_treatment.stone",
                    # "Wood": "$material_treatment.wood",
                    # "Tile": "$material_treatment.tile",
                    # "Aluminium composite panel": "$material_treatment.aluminium_composite_panel",
                    # "Glass curtain wall": "$material_treatment.glass_curtain_wall",
                    # "Pergola": "$structural_elements.pergola",
                    # "Jaali": "$structural_elements.jaali",
                    # "Green wall": "$structural_elements.green_wall",
                    # "Planter": "$structural_elements.planter",
                    # "Vault": "$structural_elements.vault",
                    # "Double height open area": "$structural_elements.double_height_open_area",
                    # "Elevation element": "$structural_elements.elevation_element",
                    # "Color scheme": "$colors.color_scheme",
                    # "Color used": "$colors.color_used",
                    # "Partner id": "$partner_details.partner_id",
                    # "Partner name": "$partner_details.partner_name",
                    # "SR Number / Library code": "$sr_number",
                    # "Option": "$option_number",
                    # "Design Description": "$design_short_description",
                    "Design Long Description": "$design_long_description",
                    "Reference images": "$reference_images",
                    # "Is Active": "$is_active",
                    # "Number of times reused": "$number_of_times_reused",
                    # "Number of times viewed": "$number_of_times_viewed",
                    # "Created By": "$created_by",
                    # "Updated By": "$updated_by",
                    # "Created At": "$created_at",
                    "Linked 3D Designs": "$three_d_linked_design_id"
                }
            }
        ])))

        print("final2d Records found", len(df))
        # df = pd.read_csv(r'2D_Layouts.csv')
        # anvil.server.connect("5DCHSPEOVGTA4ETLUYZXRO4S-WDE6BLLIFSPUGPHM")

        req_body = json.loads(event["body"])
        print("req body", req_body)
        no_of_options_2d_venum = req_body["result_count"] if "result_count" in req_body.keys(
        ) else 5
        no_of_options_3d_venum = req_body["result_count_3d"] if "result_count_3d" in req_body.keys(
        ) else 5
        no_of_floors_1 = req_body["no_of_floors"]  # "G"
        plot_area_1 = req_body["plot_area"]  # 400
        plot_entrance_width_1 = req_body["plot_entrance_width"]  # 9
        no_of_bedrooms_1 = req_body["no_of_bedrooms"]  # 1

        final_2d = option_1.get_designs(
            df,
            no_of_floors_1,
            plot_area_1,
            plot_entrance_width_1,
            no_of_bedrooms_1
        )

        print("final2d step 1", final_2d)
        if final_2d is None:
            temp = option_2.get_designs(
                df,
                no_of_floors_1,
                plot_area_1,
                plot_entrance_width_1,
                no_of_bedrooms_1
            )
            final_2d = temp

        elif len(final_2d) < no_of_options_2d_venum:
            temp = option_2.get_designs(
                df, no_of_floors_1, plot_area_1, plot_entrance_width_1, no_of_bedrooms_1)
            final_2d = final_2d.append(temp)

        floors_arr = []
        count = 1

        if not final_2d.empty and len(final_2d) > 0:
            # final_2d.loc[final_2d.astype(str).drop_duplicates().index]
            final_2d.drop_duplicates(
                subset='Unique ID', keep='first', inplace=True)
            final_2d["Floors"].apply(str)
        # index -fields mapping picked up from np.r_ method below
        # 0:3-Unique ID, Source, Design Name
        # 53,54-Floors, Bedrooms
        # 59,60-Low Range Budget, High Range Budget
        # 129-Design Long Description
        # 3:30-Image files
        # 130-Reference Images
        # 137-Linked 3D

        image_column_names = [
            'Linked 2D Rendered Plan JPG ID G',
            'Linked 2D Rendered Plan JPG ID G+1',
            'Linked 2D Rendered Plan JPG ID G+2',
            'Linked 2D Rendered Plan JPG ID G+3',
            'Linked 2D Rendered Plan JPG ID G+4',
            'Linked 2D Rendered Plan JPG ID G+n Others',
            'Linked 2D Line drawing JPG G',
            'Linked 2D Line drawing JPG G+1',
            'Linked 2D Line drawing JPG G+2',
            'Linked 2D Line drawing JPG G+3',
            'Linked 2D Line drawing JPG G+4',
            'Linked 2D Line drawing JPG G+n',
            'Linked 2D Line drawing JPG Others',
            'Linked 2D Rendered Plan PDF ID G',
            'Linked 3D Design ID Front',
            'Linked 3D Design ID Right',
            'Linked 3D Design ID Left',
            'Linked 3D Design ID Rear',
            'Linked 3D Design ID Internal',
            '3D Cut ISO JPG- G',
            '3D Cut ISO JPG- G+1',
            '3D Cut ISO JPG- G+2',
            '3D Cut ISO JPG- G+3',
            '3D Cut ISO JPG- G+4',
            '3D Cut ISO JPG- G+n',
            '3D Cut ISO JPG- others',
            'Linked Estimation ID',
            'Sketch up file ID',
            # 'Linked DWG file ID',
            # 'Linked PSD file ID',
            # 'Linked PPT file ID',
            # 'Utech PRO file link ID'
        ]

        if final_2d is None or len(final_2d) == 0:
            final_2d = df

        for index, row in final_2d.iterrows():
            images = []
            for x in image_column_names:
                if not(pd.isnull(row[x])) and not(pd.api.types.is_float(row[x])):
                    if ',' in row[x]:
                        img_list = row[x].split(",")
                        for img in img_list:
                            if img != '' and ".pdf" not in img and "plans/" in img:
                                images.append(img)
                    else:
                        if row[x] != '' and ".pdf" not in row[x] and "plans/" in row[x]:
                            images.append(row[x])
            objectRow = {
                "unique_id": row['Unique ID'],
                "design_name": row['Design Label'],
                "floors": row['Floors'] if not pd.isnull(row['Floors']) else "",
                "bedrooms": row['Bedrooms'] if not pd.isnull(row['Bedrooms']) else 0,
                "low_range_budget": row['Low Range Budget'] if not pd.isnull(row['Low Range Budget']) else '',
                "high_range_budget": row['High Range Budget'] if not pd.isnull(row['High Range Budget']) else '',
                "design_long_description": row['Design Long Description'] if not pd.isnull(row['Design Long Description']) else "",
                "plot_area": row['Suitable Plot Area'] if not pd.isnull(row['Suitable Plot Area']) else "",
                "image_url": images
            }

            if (len(floors_arr) >= no_of_options_2d_venum):
                break
            else:
                floors_arr.append(objectRow)

        # for data in final_2d.iloc[:no_of_options_2d_venum, np.r_[0:3, 40, 41, 43, 44, 46, 3:30, 47, 48]].values.tolist():
        #     images = []
        #     # images.append(data[8])
        #     # images.append(data[9])
        #     # images.append(data[10])
        #     for x in range(8, 36):
        #         if not(pd.isnull(data[x])) and not(pd.api.types.is_float(data[x])):
        #             if ',' in data[x]:
        #                 img_list = data[x].split(",")
        #                 for img in img_list:
        #                     if img != '' and ".pdf" not in img and "plans/" in img:
        #                         images.append(img)
        #             else:
        #                 if data[x] != '' and ".pdf" not in data[x] and "plans/" in data[x]:
        #                     images.append(data[x])
        #     objectRow = {
        #         "unique_id": data[0],
        #         "design_name": data[2],
        #         "floors": data[3] if not pd.isnull(data[3]) else "",
        #         "bedrooms": data[4] if not pd.isnull(data[4]) else 0,
        #         "low_range_budget": data[5] if not pd.isnull(data[5]) else 0,
        #         "high_range_budget": data[6] if not pd.isnull(data[6]) else 0,
        #         "design_long_description": data[7] if not pd.isnull(data[7]) else "",
        #         "image_url": images
        #     }
        # for idx, field in data:
        #     if not isinstance(field, str):
        #         field = str(field)
        #     str_2d += idx + "-" + str(count) + "-" + field + "\n"
        #     floors_arr.append(field)
        #     count += 1
        # floors_arr.append(objectRow)

        final_elevations = get_3d.get_3ddesigns(
            final_2d, no_of_options_2d_venum, no_of_options_3d_venum, plot_area_1, plot_entrance_width_1, no_of_floors_1, no_of_bedrooms_1)
        print("============ Response from get_3d.py ============")
        print(final_elevations)
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "access-control-allow-origin": "*",
                "access-control-allow-methods": "GET,POST,OPTIONS",
                "access-control-allow-headers": "*",
                "access-control-allow-credentials": "'*'"
            },
            "body": json.dumps({
                "status": "SUCCESS",
                "statusCode": 200,
                "message": "Design ideas recommendations fetched successfully.",
                "payload": {
                    "s3BasePath": S3_BUCKET_PATH + "/",
                    "floors": floors_arr,
                    "elevations": final_elevations
                }
            })
        }
        # return (str_2d)

    except Exception as e:
        print("Error Occured:")
        print(e)
        # printing stack trace
        traceback.print_exc()
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "access-control-allow-origin": "*",
                "access-control-allow-methods": "GET,POST,OPTIONS",
                "access-control-allow-headers": "*",
                "access-control-allow-credentials": "'*'"
            },
            "body": json.dumps({
                "status": "SUCCESS",
                "statusCode": 200,
                "message": "Error occurred.",
                "payload": ""
            })
        }
