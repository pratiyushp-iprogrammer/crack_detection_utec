import traceback
import pandas as pd
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))


def get_floors(data, no_of_floors, no_of_options):
    sort = None
    temp = None
    sort = data.loc[data["Floors"] == no_of_floors]
    temp = sort
    if len(sort) > no_of_options:
        return sort, temp, 1
    else:
        return sort, temp, 0


def isnan(value):
    try:
        import math
        return math.isnan(float(value))
    except:
        return False


def get_designs(df, no_of_floors, plot_area, plot_entrance_width, no_of_bedrooms):
    try:
        # df = pd.read_csv(r"2D_Layouts.csv")

        plot_entrance_array = ["0-9", "10-14", "15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49",
                               "50-54", "55-59", "60-64", "65-69", "70-74", "75-79", "80-84", "85-89", "90-94", "95-99", "100-999","> 999"]
        plot_area_range_array = ["< 500", "500-749", "750-999", "1000-1249", "1250-1499", "1500-1999",
                            "2000-2499", "2500-2999", "3000-3999", "4000-4999", "5000-5999", "6000-9999", "> 9999"]
        no_floors_array = ["G", "G+1", "G+2", "G+3", "G+4"]

        no_of_options_2d = 5

        floors_flag_2d = 0

        plot_width_flag_2d = 0

        stilt_flag_2d = 0

        bedroom_flag_2d = 0

        plot_area_flag_2d = 0
        lb_flag_2d = 0

        if plot_area < 1500:
            Plot_Area_Range = plot_area_range_array[((plot_area // 250) - 1)]
        elif plot_area < 3000:
            Plot_Area_Range = plot_area_range_array[((plot_area // 500) + 2)]
        elif plot_area < 6000:
            Plot_Area_Range = plot_area_range_array[((plot_area // 1000) + 3)]
        elif plot_area < 10000:
            Plot_Area_Range = plot_area_range_array[((plot_area // 6000) + 10)]
        else:
            Plot_Area_Range = plot_area_range_array[len(plot_area_range_array) - 1]

        Plot_Area_Range_one_down = plot_area_range_array[plot_area_range_array.index(
            Plot_Area_Range)]
        if plot_area_range_array.index(Plot_Area_Range) != 0:
            Plot_Area_Range_one_down = plot_area_range_array[plot_area_range_array.index(
                Plot_Area_Range) - 1]

        Plot_Area_Range_one_up = plot_area_range_array[plot_area_range_array.index(
            Plot_Area_Range)]
        if plot_area_range_array.index(Plot_Area_Range) != (len(plot_area_range_array) - 1):
            Plot_Area_Range_one_up = plot_area_range_array[plot_area_range_array.index(
                Plot_Area_Range) + 1]

        Plot_Entrance_Range = ''
        if plot_entrance_width < 9:
            Plot_Entrance_Range = plot_entrance_array[0]
        elif plot_entrance_width < 99:
            Plot_Entrance_Range = plot_entrance_array[(
                plot_entrance_width // 5) - 1]
        elif plot_entrance_width < 1000:
            Plot_Entrance_Range = plot_entrance_array[19]
        else:
            Plot_Entrance_Range = plot_entrance_array[20]

        Plot_Entrance_Range_one_down = plot_entrance_array[plot_entrance_array.index(
            Plot_Entrance_Range)]
        if plot_entrance_array.index(Plot_Entrance_Range) != 0:
            Plot_Entrance_Range_one_down = plot_entrance_array[plot_entrance_array.index(
                Plot_Entrance_Range) - 1]

        Plot_Entrance_Range_one_up = plot_entrance_array[plot_entrance_array.index(
            Plot_Entrance_Range)]
        if plot_entrance_array.index(Plot_Entrance_Range) != (len(plot_entrance_array) - 1):
            Plot_Entrance_Range_one_up = plot_entrance_array[plot_entrance_array.index(
                Plot_Entrance_Range) + 1]

        Max_no_of_floors = no_floors_array[-1]

        # No of Floors

        sort_2d, temp_2d, floors_flag_2d = get_floors(
            df, no_of_floors, no_of_options_2d)

        # Stilt
        if floors_flag_2d == 1:
            if no_of_floors != Max_no_of_floors:
                temp_2d = sort_2d.loc[(sort_2d['Stilts'] == "No")]
                no_of_floors_one_up = no_floors_array[no_floors_array.index(
                    no_of_floors) + 1]
                temp_1 = df.loc[df["Floors"] == no_of_floors_one_up]
                temp_1 = temp_1.loc[(temp_1['Stilts'] == "Yes")]
                temp_2d = temp_2d.append(temp_1)
                if len(temp_2d) > no_of_options_2d:
                    stilt_flag_2d = 1
            else:
                stilt_flag_2d = 1

        temp_2d.drop_duplicates(subset='Unique ID', keep="first", inplace=True)
        sort_2d.drop_duplicates(subset='Unique ID', keep="first", inplace=True)

        if stilt_flag_2d == 1:
            sort_2d = temp_2d

        # No of bedrooms
        if stilt_flag_2d == 1:
            temp_2d = sort_2d.loc[sort_2d['Bedrooms'] == no_of_bedrooms]
            if len(temp_2d) > no_of_options_2d:
                bedroom_flag_2d = 1
            else:
                temp_1 = sort_2d.loc[sort_2d['Bedrooms']
                                     == no_of_bedrooms + 1]
                temp_2d = temp_2d.append(temp_1)
                if len(temp_2d) > no_of_options_2d:
                    bedroom_flag_2d = 1
                else:
                    temp_1 = sort_2d.loc[sort_2d['Bedrooms']
                                         == no_of_bedrooms - 1]
                    temp_2d = temp_2d.append(temp_1)
                if len(temp_2d) > no_of_options_2d:
                    bedroom_flag_2d = 1

        temp_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)
        sort_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)

        if bedroom_flag_2d == 1:
            sort_2d = temp_2d

        # Plot Area Range
        if bedroom_flag_2d == 1:
            temp_2d = sort_2d.loc[sort_2d['Plot Area Range']
                                  == Plot_Area_Range]
            if len(temp_2d) > no_of_options_2d:
                plot_area_flag_2d = 1
            elif plot_area >= 500:
                temp_1 = sort_2d.loc[sort_2d['Plot Area Range']
                                     == Plot_Area_Range_one_down]
                temp_2d = temp_2d.append(temp_1)
                if len(temp_2d) > no_of_options_2d:
                    plot_area_flag_2d = 1
                elif plot_area < 5000:
                    temp_1 = sort_2d.loc[sort_2d['Plot Area Range']
                                         == Plot_Area_Range_one_up]
                temp_2d = temp_2d.append(temp_1)
                if len(temp_2d) > no_of_options_2d:
                    plot_area_flag_2d = 1

        temp_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)
        sort_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)

        if plot_area_flag_2d == 1:
            sort_2d = temp_2d

        # Lb Ratio
        if plot_area_flag_2d == 1:
            # for typecasting from string to numeric
            sort_2d['Suitable Plot Length'] = pd.to_numeric(
                sort_2d['Suitable Plot Length'])
            sort_2d["Lb_Ratio"] = sort_2d['Suitable Plot Length'] / \
                sort_2d['Suitable Plot Width']
            user_lb_ratio = (plot_area / plot_entrance_width) / \
                plot_entrance_width
            temp_2d = sort_2d.loc[
                (sort_2d['Lb_Ratio'] <= user_lb_ratio + .1) & (sort_2d['Lb_Ratio'] >= user_lb_ratio - .1)]
            if len(temp_2d) > no_of_options_2d:
                lb_flag_2d = 1
                sort_2d = temp_2d

        temp_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)
        sort_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)

        # Plot Entrance width
        if lb_flag_2d == 1:
            temp_2d = sort_2d.loc[sort_2d['Plot Entrance Width Range']
                                  == Plot_Entrance_Range]
            if len(temp_2d) > no_of_options_2d:
                plot_width_flag_2d = 1
            elif plot_entrance_width >= 10:
                temp_1 = sort_2d.loc[sort_2d['Plot Entrance Width Range']
                                     == Plot_Entrance_Range_one_down]
                temp_2d = temp_2d.append(temp_1)
                if len(temp_2d) > no_of_options_2d:
                    plot_width_flag_2d = 1
                elif plot_entrance_width < 105:
                    temp_1 = sort_2d.loc[sort_2d['Plot Entrance Width Range']
                                         == Plot_Entrance_Range_one_up]
                    temp_2d = temp_2d.append(temp_1)
                    if len(temp_2d) > no_of_options_2d:
                        plot_width_flag_2d = 1

        temp_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)
        sort_2d.drop_duplicates(subset='Unique ID',
                                keep="first", inplace=True)

        if plot_width_flag_2d == 1:
            sort_2d = temp_2d

        # Final Sort
        if plot_width_flag_2d != 1:
            cond = sort_2d['Unique ID'].isin(temp_2d['Unique ID'])
            sort_2d.drop(sort_2d[cond].index, inplace=True)
        if len(temp_2d) != 0 and len(temp_2d) < no_of_options_2d:
            final = temp_2d
            linked_3d = sort_2d.loc[~sort_2d['Linked 3D Designs'].isnull(
            )]
            if len(linked_3d) != 0:
                linked_3d = linked_3d.sort_values(
                    by=["Shared Wall (building)"])
                final = final.append(linked_3d)
            if len(final) < no_of_options_2d:
                cond = sort_2d['Unique ID'].isin(final['Unique ID'])
                sort_2d.drop(sort_2d[cond].index, inplace=True)
                final = final.append(sort_2d.sort_values(
                    by=["Shared Wall (building)"]))

        elif len(temp_2d) == no_of_options_2d:
            final = temp_2d

        elif len(temp_2d) == 0:
            linked_3d = sort_2d.loc[~sort_2d['Linked 3D Designs'].isnull(
            )]
            if len(linked_3d) != 0:
                linked_3d = linked_3d.sort_values(
                    by=["Shared Wall (building)"])
                final = linked_3d
                if len(final) < no_of_options_2d:
                    cond = sort_2d['Unique ID'].isin(final['Unique ID'])
                    sort_2d.drop(sort_2d[cond].index, inplace=True)
                    final = final.append(sort_2d.sort_values(
                        by=["Shared Wall (building)"]))
            else:
                final = sort_2d.sort_values(by=["Shared Wall (building)"])

        else:
            linked_3d = temp_2d.loc[~temp_2d['Linked 3D Designs'].isnull(
            )]
            if len(linked_3d) != 0:
                linked_3d = linked_3d.sort_values(
                    by=["Shared Wall (building)"])
                final = linked_3d
                if len(final) < no_of_options_2d:
                    cond = temp_2d['Unique ID'].isin(final['Unique ID'])
                    temp_2d.drop(temp_2d[cond].index, inplace=True)
                    final = final.append(temp_2d.sort_values(
                        by=["Shared Wall (building)"]))
            else:
                final = sort_2d.sort_values(by=["Shared Wall (building)"])

        return (final)

    except Exception as err:
        print(err)
        traceback.print_exc()
        return ("something went wrong", "try again")
