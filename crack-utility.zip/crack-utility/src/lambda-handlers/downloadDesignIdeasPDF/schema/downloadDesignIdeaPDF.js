const Joi = require("joi");
const JoiCustomSchema = require('./joi_custom_schema');

const downloadDesignIdeaPDFSchema = Joi.object().keys({    
    s3BasePath: JoiCustomSchema.stringInputRequired,
    srNumber: Joi.number().required(),
    customerDetails: {
        name: JoiCustomSchema.stringInputRequired,
        mobileNumber: JoiCustomSchema.stringInput,
        plotAddress: JoiCustomSchema.stringInput,
        plotArea: JoiCustomSchema.numberInput,
        plotEntranceWidth: JoiCustomSchema.numberInput,
        numberOfFloors: JoiCustomSchema.numberInput,
        numberOfRooms: JoiCustomSchema.numberInput,
        typeOfHome: JoiCustomSchema.numberInput,
        homeBuildingBudget: JoiCustomSchema.numberInput
    },
    floor_plans: JoiCustomSchema.arrayInput.items(Joi.object()),
    elevations: JoiCustomSchema.arrayInput.items(Joi.object())
});

module.exports = downloadDesignIdeaPDFSchema;