const { S3Client, PutObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();
const BaseResponse = require("./common/baseResponse");
const common = require('./common/common');
let Common = new common()
const HTTP_CODE = require("./common/constants");
const chromium = require("@sparticuz/chromium");
const puppeteer = require("puppeteer-core");
const fs = require("fs");
const path = require("path");
const handlebars = require("handlebars");
const mergePDFStream = require('./mergePDF');
const downloadDesignIdeaPDFSchema = require('./schema/downloadDesignIdeaPDF');

let baseResponse = new BaseResponse();

exports.downloadDesignIdeaPDFHandler = async (event, context) => {
  try {
    event = Common.reqSanitize(event);
    const params = JSON.parse(event.body);

    if (!params?.s3BasePath) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Invalid request.");
    }

    /* const validation = downloadDesignIdeaPDFSchema.validate(params, { allowUnknown: true });
    if (validation.error) {
      return baseResponse.getResponseObject(event,false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
    } */

    handlebars.registerHelper("if", function (value, index, options) {
      if (index == value) {
        return options.fn(this);
      }
      return options.inverse(this);
    });

    handlebars.registerHelper("arrayExists", function (arrayTemp, index, options) {
      if (arrayTemp.length > index) {
        return options.fn(this);
      }
    });

    let data = JSON.parse(event.body);

    if ('customerDetails' in data && 'name' in data.customerDetails) {
      const arrNames = data.customerDetails.name.split(" ");
      if (arrNames.length > 0) {
        data.customerDetails.firstName = arrNames[0];
      }
    }

    if ('customerDetails' in data && 'numberOfFloors' in data.customerDetails) {
      const floorsCount = data.customerDetails.numberOfFloors;
      if (floorsCount == '0') data.customerDetails.numberOfFloors = 'G';
      else if (floorsCount == '1') data.customerDetails.numberOfFloors = 'G+1';
      else if (floorsCount == '2') data.customerDetails.numberOfFloors = 'G+2';
      else if (floorsCount == '3') data.customerDetails.numberOfFloors = 'G+3';
      else if (floorsCount == '4') data.customerDetails.numberOfFloors = 'G+4';
    }

    if (data['floor_plans'].length > 0) {
      data['floor_plans'].forEach(floor_plan => {

        const image_urls = floor_plan['image_url'];
        const floors = floor_plan['floors'];

        if (image_urls.length > 0) {
          let g0 = [];
          let g1 = [];
          let g2 = [];
          let g3 = [];
          let g4 = [];

          image_urls.forEach(image_url => {
            if (image_url.includes("G-0")) {
              g0.push(image_url)
            } else if (image_url.includes("G-1")) {
              g1.push(image_url)
            } else if (image_url.includes("G-2")) {
              g2.push(image_url)
            } else if (image_url.includes("G-3")) {
              g3.push(image_url)
            } else if (image_url.includes("G-4")) {
              g4.push(image_url)
            }
          });

          let final_image_url = []
          if (floors == "G") {
            if (g0 && g0[0]) final_image_url.push(g0[0]);
          } else if (floors == "G+1") {
            if (g0 && g0[0]) final_image_url.push(g0[0])
            if (g1 && g1[0]) final_image_url.push(g1[0])
          } else if (floors == "G+2") {
            if (g0 && g0[0]) final_image_url.push(g0[0])
            if (g1 && g1[0]) final_image_url.push(g1[0])
            if (g2 && g2[0]) final_image_url.push(g2[0])
          } else if (floors == "G+3") {
            if (g0 && g0[0]) final_image_url.push(g0[0])
            if (g1 && g1[0]) final_image_url.push(g1[0])
            if (g2 && g2[0]) final_image_url.push(g2[0])
            if (g3 && g3[0]) final_image_url.push(g3[0])
          } else if (floors == "G+4") {
            if (g0 && g0[0]) final_image_url.push(g0[0])
            if (g1 && g1[0]) final_image_url.push(g1[0])
            if (g2 && g2[0]) final_image_url.push(g2[0])
            if (g3 && g3[0]) final_image_url.push(g3[0])
            if (g4 && g4[0]) final_image_url.push(g4[0])
          }

          floor_plan.image_url = final_image_url;
        }
      });

      data['elevations'].forEach((elevation, index) => {
        elevation.indexFlag = index + 1;
        if (elevation.image_url && elevation.image_url[0]) {
          elevation.image_url = [elevation.image_url[0]];
        }
      });
    }

    console.log(">> process started", data.s3BasePath);

    var baseTemplateDirectory = path.join(
      __dirname,
      "assets/html-templates/design-ideas/"
    );

    //Reading html template file
    const file1 = fs.readFileSync(
      baseTemplateDirectory + "1-home-page.html",
      "utf8"
    );
    const template1 = handlebars.compile(file1);
    const page1 = template1(data);

    //Reading html template file
    const file2 = fs.readFileSync(
      baseTemplateDirectory + "2-designs.html",
      "utf8"
    );
    const template2 = handlebars.compile(file2);
    const page2 = template2(data);

    //Reading html template file
    const file3 = fs.readFileSync(
      baseTemplateDirectory + "3-plan-a.html",
      "utf8"
    );
    const template3 = handlebars.compile(file3);
    const page3 = template3(data);

    //Reading html template file
    const file4 = fs.readFileSync(
      baseTemplateDirectory + "4-plan-b.html",
      "utf8"
    );
    const template4 = handlebars.compile(file4);
    const page4 = template4(data);

    //Reading html template file
    const file5 = fs.readFileSync(
      baseTemplateDirectory + "5-personal-details.html",
      "utf8"
    );
    const template5 = handlebars.compile(file5);
    const page5 = template5(data);

    //Reading html template file
    const file6 = fs.readFileSync(
      baseTemplateDirectory + "6-contact.html",
      "utf8"
    );
    const template6 = handlebars.compile(file6);
    const page6 = template6(data);

    //Reading html template file
    const file7 = fs.readFileSync(
      baseTemplateDirectory + "7-disclaimer.html",
      "utf8"
    );
    const template7 = handlebars.compile(file7);
    const page7 = template7(data);

    let browser = null;
    let height = 980;
    try {
      const customViewport = chromium.defaultViewport;
      customViewport.width = 480;
      //Initialising browser object using  chromium.puppeteer
      browser = await puppeteer.launch({
        args: chromium.args,
        defaultViewport: customViewport,
        executablePath: await chromium.executablePath(),
        headless: chromium.headless,
      });

      const tab1 = await browser.newPage();
      console.log(">> browser.newPage done");
      const loaded = tab1.waitForNavigation({ waitUntil: "load" })
      await tab1.setContent(page1);
      await tab1.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded;
      const pdf1 = await tab1.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: "890px",//"9.27in"
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0
        }
      });
      console.log(">> pdf1 generated")

      const tab2 = await browser.newPage();
      const loaded2 = tab2.waitForNavigation({ waitUntil: "load" });
      await tab2.setContent(page2);
      await tab2.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded2;
      const pdf2 = await tab2.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: "890px",//"9.27in"
      });

      const tab3 = await browser.newPage();
      const loaded3 = tab3.waitForNavigation({ waitUntil: "load" });
      await tab3.setContent(page3);
      await tab3.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded3;
      height = await tab3.evaluate(() => {
        return document.getElementById("maincontent").scrollHeight + 1;
      });
      console.log("page3 height: ", height);
      const pdf3 = await tab3.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: height + "px",//"9.27in"
      });

      const tab4 = await browser.newPage();
      const loaded4 = tab4.waitForNavigation({ waitUntil: "load" });
      await tab4.setContent(page4);
      await tab4.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded4;
      height = await tab4.evaluate(() => {
        return document.getElementById("maincontent").scrollHeight + 1;
      });
      console.log("page4 height: ", height);
      const pdf4 = await tab4.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: height + "px",//"9.27in"
      });

      const tab5 = await browser.newPage();
      const loaded5 = tab5.waitForNavigation({ waitUntil: "load" });
      await tab5.setContent(page5);
      await tab5.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded5;
      height = await tab5.evaluate(() => {
        return document.getElementById("maincontent").offsetHeight + 1;
      });
      console.log("page5 height: ", height);
      const pdf5 = await tab5.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: height + "px",//"9.27in"
      });

      const tab6 = await browser.newPage();
      const loaded6 = tab6.waitForNavigation({ waitUntil: "load" });
      await tab6.setContent(page6);
      await tab6.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded6;
      height = await tab6.evaluate(() => {
        return document.getElementById("maincontent").offsetHeight + 1;
      });
      console.log("page6 height: ", height);
      const pdf6 = await tab6.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: height + "px",//"9.27in"
      });

      const tab7 = await browser.newPage();
      const loaded7 = tab7.waitForNavigation({ waitUntil: "load" });
      await tab7.setContent(page7);
      await tab7.evaluateHandle('document.fonts.ready');//wait until all fonts are loaded
      await loaded7;
      height = await tab7.evaluate(() => {
        return document.getElementById("maincontent").offsetHeight;
      });
      console.log("page7 height: ", height);
      const pdf7 = await tab7.pdf({
        printBackground: true,
        preferCSSPageSize: true,
        width: "480px",//"5in"
        height: height + "px",//"9.27in"
      });

      console.log(">> all pdfs done");

      let pdfMergedBuffer;
      if(data["elevations"]?.length){
        pdfMergedBuffer = await mergePDFStream([pdf1, pdf2, pdf3, pdf4, pdf5, pdf6, pdf7]);
      } else {
        pdfMergedBuffer = await mergePDFStream([pdf1, pdf3, pdf4, pdf5, pdf6, pdf7]);
      }

      await tab1.close();
      await tab2.close();
      await tab3.close();
      await tab4.close();
      await tab5.close();
      await tab6.close();
      await tab7.close();

      console.log(">> page.pdf done");

      const output_filename = `${data.srNumber}_${baseResponse.currentDatetime()}.pdf`;
      const filePath = `design-ideas/pdfs/${baseResponse.generateUniqueID()}/${output_filename}`;
      const s3Params = {
        // ACL: "public-read-write",
        Bucket: process.env.UPLOAD_S3_BUCKET,
        Key: filePath,
        Body: pdfMergedBuffer,
        ContentType: "application/pdf"
      };
      const command = new PutObjectCommand(s3Params);
      const objS3Response = await s3Client.send(command);
      if (objS3Response) {
        console.log("PDF put done on path ", s3Params);

        console.log(filePath, " uploaded sucessfully on s3", objS3Response);
        const downloadURL = `${process.env.S3_BUCKET_PATH}/${filePath}`;

        let arrResponse = [
          { filePath: downloadURL, s3Response: objS3Response },
        ];

        return baseResponse.getResponseObject(
          event,
          true,
          HTTP_CODE.SUCCESS,
          arrResponse,
          "Download design ideas pdf successfully."
        );
      } else {
        let arrResponse = [{ filePath: "", s3Response: objS3Response }];
        return baseResponse.getResponseObject(
          event,
          false,
          HTTP_CODE.INTERNAL_SERVER_ERROR,
          arrResponse,
          "Error while putting csv file to s3 "
        );
      }
    } catch (error) {
      let arrResponse = [{ filePath: "", s3Response: error }];
      return baseResponse.getResponseObject(
        event,
        false,
        HTTP_CODE.INTERNAL_SERVER_ERROR,
        arrResponse,
        "Error while putting csv file to s3 "
      );
    } finally {
    }
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(
      event,
      false,
      HTTP_CODE.BAD_REQUEST,
      [],
      "Internal server error: " + e.message
    );
  }
};