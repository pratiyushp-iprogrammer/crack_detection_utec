const { S3Client, PutObjectCommand, GetObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();
const sharp = require("sharp");

//  //For local testing uncomment this three variables
// const s3 = new AWS.S3({
//   accessKeyId: "AKIAXBXKDH5EBYK757WO",
//   secretAccessKey: "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",
//   region: "ap-south-1",
// });

exports.CreateThumbnails = async (event) => {
  // const CreateThumbnails = async (event) => {
  //For local testing uncomment this code
  try {
    if (!event || !event.Records[0]) {
      console.log("Invalid Event");
      return;
    }
    if (event.Records[0].s3) {
      console.log("Reading options from event:\n", event.Records[0].s3);

      // Get Bucket Name
      const bucketName = event.Records[0].s3.bucket.name;
      console.log("bucketName: ", bucketName);

      //  Get Image Name to be Thumbnailed
      const srcKeyName = decodeURIComponent(
        event.Records[0].s3.object.key.replace(/\+/g, " ")
      );
      console.log("srcKeyName: ", srcKeyName);

      // Prefix for thumbnail images
      const thumbKeyPrefix = "thumbnails/";
      console.log("thumbKeyPrefix: ", thumbKeyPrefix);

      // Prefix for Optimized images
      const optimizedKeyPrefix = "optimized/";
      console.log("optimizedKeyPrefix: ", thumbKeyPrefix);

      // Checking if thumbnail is already created or not.
      if (srcKeyName.includes(`${thumbKeyPrefix}`)) {
        console.log("Thumbnail already created !");
        return;
      }

      //check if optimized image is already created or not.
      if (srcKeyName.includes(`${optimizedKeyPrefix}`)) {
        console.log("Optimized image already created !");
        return;
      }

      // Infer the image type from the file suffix.
      const typeMatch = srcKeyName.match(/\.([^.]*)$/);
      if (!typeMatch) {
        console.log("Could not determine the image type.");
        return;
      }

      // Check that the image type is supported
      const imageType = typeMatch[1].toLowerCase();
      if (
        imageType != "jpg" &&
        imageType != "png" &&
        imageType != "gif" &&
        imageType != "jpeg" &&
        imageType != "tiff"
      ) {
        console.log(`Unsupported image type: ${imageType}`);
        return;
      }

      // Creating thumbnails only for Required Folders in S3.

      // if (srcKeyName.startsWith("temp/thumbtest/")) {
      if (srcKeyName.startsWith("plans/") || srcKeyName.startsWith("styles/") || srcKeyName.startsWith("delivery_catalog/")) {
        // // Reference to AWS S3 client
        // AWS.config.update({
        //   accessKeyId: process.env.ACCESS_KEY_ID,
        //   secretAccessKey: process.env.SECRET_ACCESS_KEY,
        //   region: process.env.REGION,
        // });
        
        // Downloading uploaded file in S3 Bucket in a specific folder
        try {
          console.log("Inside getImage");
          const params = {
            Bucket: bucketName,
            Key: srcKeyName,
          };
          const getObjectCommand = new GetObjectCommand(params);
          const objectRes = await s3Client.send(getObjectCommand);  
          var originalImage = await objectRes.Body.transformToByteArray();
        } catch (error) {
          console.log("Error in getImage : ", error);
          return;
        }

        // Generating thumbnail for downloaded file
        try {
          console.log("Inside generateThumbnails");
          // set thumbnail width. Resize will set the height automatically to maintain aspect ratio.
          const width = 200;
          var buffer = await sharp(originalImage).resize(width).toBuffer();
        } catch (error) {
          console.log("Error in generateThumbnails : ", error);
          return;
        }

        // Uploading the thumbanail file in "thumbnails/{path-of-originalFile}" folder in same bucket
        try {
          console.log("Inside uploadThumbnails");
          var finalDestKey = `${thumbKeyPrefix}` + srcKeyName;
          console.log("finalDestKey", finalDestKey);

          const destParams = {
            Bucket: bucketName,
            Key: finalDestKey,
            Body: buffer,
            ContentType: "image",
            Metadata: {
              thumbnail: "TRUE",
            },
            // ACL: "public-read",
          };
          const command = new PutObjectCommand(destParams);
          const putResult = await s3Client.send(command);
          console.log("putResult", putResult);
        } catch (error) {
          console.log("Error in uploadThumbnails : ", error);
          return;
        }
        console.log(
          `Thumbnail created  for '${bucketName}/${srcKeyName}' as '${bucketName}/${finalDestKey}'`
        );
        
        if(imageType!="gif"){
          
          //Generating Optimized images
          try{
            const optimizedWidth=1000;
            const qualityFactor = 70; //integer 1-100 
            var optimizedBuffer = await sharp(originalImage)
            .jpeg({
              mozjpeg: true,
              quality: qualityFactor,
            })
            .png({
                compressionLevel:8,
                quality : 70,
            })
            .tiff({
                quality : qualityFactor,
                compression: "jpeg",
            })
            .resize({
              width: optimizedWidth,
            })
            .toFormat(imageType)
            .toBuffer();
          }catch(error){
            console.log("Error in generateOptimizedImgs : ", error);
            return;
          }

          // Uploading the Optimized file in "optimized/{path-of-originalFile}" folder in same bucket
          try{
            var finalDestKey = `${optimizedKeyPrefix}` + srcKeyName;
            console.log("finalDestKey", finalDestKey);
            const destParams = {
              Bucket: bucketName,
              Key: finalDestKey,
              Body: optimizedBuffer,
              ContentType: "image",
              Metadata: {
                thumbnail: "FALSE",
              },
              // ACL: "public-read",
            };
            const command = new PutObjectCommand(destParams);
            const putResult = await s3Client.send(command);
            console.log("putResult", putResult);
          }catch(error){
            console.log("Error in uploadOptimized images : ", error);
            return;
          }
        }
        
      } else {
        console.log("This folder is not allowed to create thumbnail");
      }
    } else {
      console.log("Inalid Records in Event");
    }
  } catch (error) {
    console.log(
      "Error while Creating Thumbnails 'Lambda_Handler : createThumbnails' : ",
      error
    );
    return;
  }
};

// // For local testing uncomment this code
// CreateThumbnails({
//   Records: [
//     {
//       s3: {
//         bucket: {
//           name: "design-management-assets",
//         },
//         object: {
//           key: "temp/thumbtest/logo.jpg",
//         },
//       },
//     },
//   ],
// });
