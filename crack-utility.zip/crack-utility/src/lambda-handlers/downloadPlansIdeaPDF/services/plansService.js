// const Plans = require('../models/plans.js');
const Plans = require('../models/plan_style_designs.js');

class PlansService {
    async fetchPlansImagesMinMax(params) {
        try {
            let pipeline = [];
            let addFields = {
                "$addFields": {
                    "ground_images": {
                        "$ifNull": [
                            "$files.two_d_rendered_plan_jpg.ground",
                            ""
                        ]
                    },
                    "ground_plus_one_images": {
                        "$ifNull": [
                            "$files.two_d_rendered_plan_jpg.ground_plus_one",
                            ""
                        ]
                    },
                }
            };
            let match = {
                "$match": {
                    "$and": [{
                        "plot_details.plot_area": {
                            "$gte": params.min,
                            "$lte": params.max
                        }
                    },
                    {
                        "ground_images": { $exists: true, $ne: "", $type: 'string' },
                        "ground_plus_one_images": { $exists: true, $ne: "", $type: 'string' }
                    },
                    {
                        "is_active": 1,
                        "is_approved": 1
                    }
                    ]
                }
            };
            let project = {
                "$project": {
                    "ground": {
                        $concat: [
                            params.s3BasePath,
                            {
                                $arrayElemAt: ["$files.two_d_rendered_plan_jpg.ground", 0]
                            }
                        ]

                    },
                    "ground_plus_one": {
                        $concat: [
                            params.s3BasePath,
                            {
                                $arrayElemAt: ["$files.two_d_rendered_plan_jpg.ground_plus_one", 0]
                            }
                        ]
                    },
                    "bedrooms": "$project_details.bedrooms",
                    "design_long_description": { "$ifNull": ["$design_long_description", ""] },
                    "_id": 0
                }
            };
            let limit = {
                $limit: 1
            };

            pipeline.push(addFields, match, project, limit);
            return await Plans.aggregate(pipeline).allowDiskUse(true).exec();
        } catch (error) {
            throw error;
        }
    }

    async fetchPlansImagesRandom(params) {
        try {
            let pipeline = [];
            let addFields = {
                "$addFields": {
                    "ground_images": {
                        "$ifNull": [
                            "$files.two_d_rendered_plan_jpg.ground",
                            ""
                        ]
                    },
                    "ground_plus_one_images": {
                        "$ifNull": [
                            "$files.two_d_rendered_plan_jpg.ground_plus_one",
                            ""
                        ]
                    },
                }
            };
            let match = {
                "$match": {
                    "$and": [
                    {
                        "ground_images":{ $exists: true, $ne: "", $type: 'string' },
                        "ground_plus_one_images": { $exists: true, $ne: "", $type: 'string' }
                    },
                    {
                        "is_active": 1,
                        "is_approved": 1
                    }
                    ]
                }
            };
            let project = {
                "$project": {
                    "ground": {
                        $concat: [
                            params.s3BasePath,
                            {
                                $arrayElemAt: ["$files.two_d_rendered_plan_jpg.ground", 0]
                            }
                        ]

                    },
                    "ground_plus_one": {
                        $concat: [
                            params.s3BasePath,
                            {
                                $arrayElemAt: ["$files.two_d_rendered_plan_jpg.ground_plus_one", 0]
                            }
                        ]
                    },
                    "bedrooms": "$project_details.bedrooms",
                    "design_long_description": { "$ifNull": ["$design_long_description", ""] },
                    "_id": 0
                }
            };
            let limit = {
                $limit: 1
            };

            pipeline.push(addFields, match, project, limit);
            console.log("Pipeline", JSON.stringify(pipeline));
            return await Plans.aggregate(pipeline).allowDiskUse(true).exec();

        } catch (error) {
            throw error;
        }
    }
}

module.exports = PlansService;