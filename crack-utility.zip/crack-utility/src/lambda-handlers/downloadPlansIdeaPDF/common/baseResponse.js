const HTTP_CODE = require('./constants');
const originListing = require('../configs/originList.json');
class BaseResponse {

    objResponse = {
        isBase64Encoded: false,
        statusCode: 200,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Origin": "null",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
            "Access-Control-Allow-Credentials": true
        },
        body: {
            status: 'SUCCESS',
            statusCode: HTTP_CODE.SUCCESS,
            message: '',
            payload: []
        }
    }

    getResponseObject(event = {}, status = true, statusCode = HTTP_CODE.SUCCESS, payload = [], message = '') {
        if (Array.isArray(payload) && !payload.length && !message) {
            this.objResponse.body.message = 'Data not found';
        } else if ((Array.isArray(payload)) || (typeof payload === 'object' && Object.keys(payload).length)) {
            this.objResponse.body.payload = payload;
            this.objResponse.body.message = message !== '' ? message : '';
            this.objResponse.body.statusCode = statusCode !== '' ? statusCode : 200;
            this.objResponse.body.status = status ? 'SUCCESS' : 'FAILURE';
        } else if (payload === null) {
            this.objResponse.body.message = 'Internal server error';
            statusCode = HTTP_CODE.BAD_REQUEST;
            this.objResponse.body.statusCode = HTTP_CODE.BAD_REQUEST;
        }
        if (event) {
            let origin = this.validateOrigin(event);
            this.objResponse.headers["Access-Control-Allow-Origin"] = origin;
        }

        return {
            ...this.objResponse,
            statusCode: statusCode,
            body: JSON.stringify(this.objResponse.body)
        };
    }

    generateUniqueID = () => {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
            const r = (Math.random() * 16) | 0;
            const v = c === "x" ? r : (r & 3) | 8;
            return v.toString(16);
        });
    };

    generateFourDigitUniqueID = () => {
        return "xxxx".replace(/[xy]/g, function (c) {
            const r = (Math.random() * 4) | 0;
            const v = c === "x" ? r : (r & 3) | 2;
            return v.toString(4);
        });
    };

    getCurrentDateTime = () => {
        var date = new Date,
            dformat = [date.getMonth() + 1,
            date.getDate(),
            date.getFullYear()
            ].join('-') + '-' + [date.getHours(),
            date.getMinutes(),
            date.getSeconds()
            ].join('-');
        return dformat;
    }
    currentDatetime() {
        let today = new Date();
        let date = ('0' + today.getDate()).slice(-2) + '' + ('0' + (today.getMonth() + 1)).slice(-2) + '' + today.getFullYear();
        // let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
        return date;
    }
    validateOrigin = (event) => {
        let origin = event?.headers?.origin || event?.headers?.Origin;
        let domain = origin || "null";
        // let domain = event?.headers?.origin ? event.headers.origin : "null";
        // let originList = process.env.ORIGINLIST;
        let originList = originListing?.validDomains || "";
        const isInList = originList.split(",").find(element => element == domain);
        console.log(JSON.stringify({ file: 'baseResponse.js', line: 85, domain, isInList }));
        if (!isInList) {
            domain = "null";
        }
        return domain;
    };
}

module.exports = BaseResponse;