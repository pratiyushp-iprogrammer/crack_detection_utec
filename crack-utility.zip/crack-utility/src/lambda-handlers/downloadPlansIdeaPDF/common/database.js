const mongoose = require('mongoose');
let connectionConfig;
let path = require('path');
class Database {

  async connect(
    // dbConnString = 'mongodb://65.1.205.67:27017/plansManagement',
    // authSource = 'admin',
    // user = 'root',
    // pwd = 'wz;h/$$E3##cu(W]',
    // poolSize = 10
    dbConnString = process.env.MONGO_DB_CONN_STRING,
    authSource = 'admin',
    user = process.env.DB_USER,
    pwd = process.env.DB_PASSWORD,
    // poolSize = 10
  ) {
    try {
      connectionConfig = {
        useNewUrlParser: true,
        useUnifiedTopology: false,
        retryWrites: false,
        authSource: authSource,
        user: user,
        pass: pwd,
        // poolSize: poolSize
      };
      const env_deploy = process.env.DEPLOYMENT;
      dbConnString = `mongodb://${dbConnString}/plansManagement?retryWrites=false&maxPoolSize=10`;
      console.log(dbConnString);

      if (env_deploy == 'stage' || env_deploy == 'prod'|| env_deploy == 'production' || env_deploy == 'dev' || env_deploy == 'preprod') {
        // var ca = [fs.readFileSync(__dirname + "/ca.pem")];
        let ca = path.join(__dirname, '/ca.pem');
        // connectionConfig.ssl = true;
        // connectionConfig.sslValidate = true;
        // connectionConfig.sslCA = ca;
        connectionConfig.tlsInsecure = false;
        connectionConfig.tls= true;
        connectionConfig.tlsCAFile= ca;
        console.log(JSON.stringify(connectionConfig));

        return mongoose.connect(dbConnString, connectionConfig);
      }

      console.log(dbConnString);
      console.log(JSON.stringify(connectionConfig));

      return mongoose.connect(dbConnString, connectionConfig);
    } catch (err) {
      console.log(err);
      return err;
    }


  }

}
// const db = new Database();
// db.connect();
module.exports = Database;