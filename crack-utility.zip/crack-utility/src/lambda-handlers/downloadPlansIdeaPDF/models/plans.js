const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    "unique_id": String,
    "source": String,
    "sr_number": String,
    "option_number": String,
    "design_name": String,
    "design_short_description": String,
    "design_long_description": String,
    "three_d_linked_design_id": String,
    "files": {
        "two_d_rendered_plan_jpg": {
            "ground": String,
            "ground_plus_one": String,
            "ground_plus_two": String,
            "ground_plus_three": String,
            "ground_plus_four": String,
            "above_ground_plus_four": String,
            "others": String
        },
        "two_d_line_drawing_pdf": {
            "two_d_line_drawing_pdf_id": String
        },
        "two_d_line_drawing_jpg": {
            "ground": String,
            "ground_plus_one": String,
            "ground_plus_two": String,
            "ground_plus_three": String,
            "ground_plus_four": String,
            "above_ground_plus_four": String,
            "others": String
        },
        "three_d_design_id": {
            "front": String,
            "right_side": String,
            "left_side": String,
            "rear_side": String,
            "internal": String
        },
        "three_d_cut_iso_jpg": {
            "ground": String,
            "ground_plus_one": String,
            "ground_plus_two": String,
            "ground_plus_three": String,
            "ground_plus_four": String,
            "above_ground_plus_four": String,
            "others": String
        },
        "linked_estimation_id": {
            "estimation_id": String
        },
        "linked_stetch_up_file": {
            "sketch_up_file_id": String
        },
        "linked_dwg_file": {
            "linked_dwg_file_id": String
        },
        "linked_psd_file": {
            "linked_psd_file_id": String
        },
        "linked_ppt_file": {
            "linked_ppt_file_id": String
        },
        "utec_pro_link": {
            "utec_pro_link_id": String
        }
    },
    "plot_details": {
        "plot_area": Number,
        "plot_area_range": String,
        "plot_length": String,
        "plot_width": Number,
        "plot_entrance_width_range": String,
        "plot_shape": String,
        "open_sides_of_the_plot": Number,
        "left_set_back": String,
        "right_set_back": String,
        "front_set_back": String,
        "rear_set_back": String
    },
    "project_details": {
        "typology": String,
        "estimated_cost_of_construction": Number,
        "builtup_area": Number,
        "floor_plate_area_of_ground_floor": Number,
        "floor_plate_length": String,
        "floor_plate_width": String,
        "floors": String,
        "bedrooms": Number,
        "shared_wall": Number,
        "for_two_shared_wall_adjacent_parallel": String,
        "space_allocation": String,
        "style": String,
        "low_range_budget": Number,
        "high_range_budget": Number
    },
    "geography": {
        "weather_condition": String,
        "state": String,
        "city": String,
        "district": String,
        "geo_coordinates": String,
        "pincode": Number,
        "budget": String
    },
    "family_details": {
        "total_family_members": Number,
        "number_of_senior_citizen": Number,
        "number_of_adults": Number,
        "number_of_children": Number,
        "number_of_infants": Number
    },
    "parking": {
        "basement": String,
        "stilts": String,
        "two_wheeler_parking": Number,
        "four_wheeler_parking": Number
    },
    "senior_citizen_friendly": {
        "max_three_stairs_to_enter_the_ground_floor": String,
        "one_bhk_on_ground_floor": String,
        "provision_of_ramp": String
    },
    "vaastu_compliancy": {
        "vaastu_compliant": String,
        "entry_direction": String,
        "orientation_of_kitchen": String,
        "orientation_of_pooja_room": String,
        "orientation_of_master_bedrrom": String
    },
    "rooms": {
        "total_bathrooms": Number,
        "attached_bathrooms": Number,
        "common_bathrooms": Number,
        "dining_room": Number,
        "living_room": Number,
        "kitchen": Number,
        "family_room": Number,
        "store_room": Number,
        "pooja_room": Number,
        "shops": Number
    },
    "open_areas": {
        "balcony": String,
        "porch": String,
        "verandah": String,
        "garden": String,
        "courtyard": String,
        "frontyard": String,
        "backyard": String,
        "terrace": String,
        "type_of_entrance": String
    },
    "special_amenities": {
        "library": String,
        "home_theatre": String,
        "pool": String,
        "gym": String,
        "study_room": String,
        "game_room": String
    },
    "material_treatment": {
        "brick": String,
        "stone": String,
        "wood": String,
        "tile": String,
        "aluminium_composite_panel": String,
        "glass_curtain_wall": String
    },
    "structural_elements": {
        "pergola": String,
        "jaali": String,
        "green_wall": String,
        "planter": String,
        "vault": String,
        "double_height_open_area": String,
        "elevation_element": String
    },
    "colors": {
        "color_scheme": String,
        "color_used": String
    },
    "partner_details": {
        "partner_id": String,
        "partner_name": String
    },
    "roof": {
        "roof_type": String
    },
    "stylized": {
        "stylized_configuration": String
    },
    "reference_images": String,
    "translation_file": Object,
    "is_active": Number, // 0 = Inactive, 1 = active, 2 = delete
    "number_of_times_reused": Number,
    "number_of_times_viewed": Number,
    "created_by": String,
    "updated_by": String
}, {
    // timestamps: { createdAt: 'created_at', updatedAt: { path: 'updatedAt', setOnInsert: false } }
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
}, {
    collection: "plans_management"
});

module.exports = mongoose.model('plans_management', schema);