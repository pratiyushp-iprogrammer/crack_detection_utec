const hummus = require('hummus');
const memoryStreams = require('memory-streams');
const PDFRStreamForBuffer = require('./pdfr-stream-for-buffer.js');

function appendPDFPageFromPDFWithAnnotations(pdfWriter, sourceBuffer) {
  var cpyCxt = pdfWriter.createPDFCopyingContext(new PDFRStreamForBuffer(sourceBuffer));
  var cpyCxtParser = cpyCxt.getSourceDocumentParser();

  var pageDictionary = cpyCxtParser.parsePageDictionary(0);
  if (!pageDictionary.exists('Annots')) {
    // no annotation. append as is
    cpyCxt.appendPDFPageFromPDF(0);
  }
  else {
    // this var here will save any reffed objects from the copied annotations object.
    // they will be written after the page copy writing as to not to disturb the
    // page object writing itself.
    var reffedObjects;

    pdfWriter.getEvents().once('OnPageWrite', function (params) {
      // using the page write event, write the new annotations. just copy the object
      // as is, saving any referenced objects for future writes
      params.pageDictionaryContext.writeKey('Annots');
      reffedObjects = cpyCxt.copyDirectObjectWithDeepCopy(pageDictionary.queryObject('Annots'))
    })

    // write page. this will trigger the event  
    cpyCxt.appendPDFPageFromPDF(0);

    // now write the reffed object (should be populated cause onPageWrite was written)
    // note that some or all annotations may be embedded, in which case this array
    // wont hold all annotation objects
    if (reffedObjects && reffedObjects.length > 0)
      cpyCxt.copyNewObjectsForDirectObject(reffedObjects)
  }
}

/**
 * Merges an array of PDF buffers into one single PDF buffer 
 * 
 * @param {Buffer[]} buffers - a list of PDF buffers to be merged
 * 
 * @returns {Buffer} merged pdf buffer
 */
module.exports = async buffers => {
  const [first] = buffers;
  
  const outStream = new memoryStreams.WritableStream();
  const firstPdfStream = new hummus.PDFRStreamForBuffer(first);

  const pdfWriter = hummus.createWriterToModify(
    firstPdfStream,
    new hummus.PDFStreamForResponse(outStream),
  );

  buffers.shift();
  buffers.map(async (buffer) => {
    await appendPDFPageFromPDFWithAnnotations(pdfWriter, buffer, outStream);
    // const newPdfStream = new hummus.PDFRStreamForBuffer(buffer);
    // pdfWriter.appendPDFPagesFromPDF(newPdfStream);
  });

  pdfWriter.end();
  return outStream.toBuffer();
};