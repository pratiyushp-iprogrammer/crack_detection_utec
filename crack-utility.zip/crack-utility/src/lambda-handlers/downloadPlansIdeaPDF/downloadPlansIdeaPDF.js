const BaseResponse = require("./common/baseResponse");
const HTTP_CODE = require("./common/constants");
const chromium = require("@sparticuz/chromium");
const puppeteer = require("puppeteer-core");
const handlebars = require("handlebars");
const { S3Client, PutObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();
const fs = require("fs");
const path = require("path");
const isEmpty = require("lodash");
const mergePDFStream = require('./mergePDF');
const DownloadPlansIdeaPDFSchema = require('./schema/downloadPlansIdeaPDF');
const PlansService = require('./services/plansService');
const Database = require('./common/database');
const common = require('./common/common');
let Common = new common()

let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
let plansService = new PlansService();

exports.downloadPlansIdeaPDFHandler = async (event, context) => {
  try {
    event = Common.reqSanitize(event);
    /* const s3Params = {
      accessKeyId: process.env.ACCESS_KEY_ID,
      secretAccessKey: process.env.SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION_NAME
    };

    s3.config.update(s3Params); */
    const params = JSON.parse(event.body);
    var validation = DownloadPlansIdeaPDFSchema.validate(params);
    if (validation.error) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
    }
    const s3BasePath = `${process.env.S3_BUCKET_PATH}/`;
    let total_plot_area = params?.plotArea || 0;
    let data = {
      min: 0,
      max: 0,
      s3BasePath: s3BasePath
    };

    if (total_plot_area && total_plot_area > 1000) {
      data.min = total_plot_area - 1000;
      data.max = total_plot_area + 1000;
    } else {
      data.min = 0;
      data.max = total_plot_area + 1000;
    }

    const plansPdfGenFunc = async (data) => {
      // Old PDF Logic
      handlebars.registerHelper("if", function (value, index, options) {
        if (index == value) {
          return options.fn(this);
        }
        return options.inverse(this);
      });

      handlebars.registerHelper("arrayExists", function (arrayTemp, index, options) {
        if (arrayTemp.length > index) {
          return options.fn(this);
        }
      });

      if (data) {
        data['numberOfFloors'] = 'G+1';
      }

      var baseTemplateDirectory = path.join(
        __dirname,
        "assets/html-templates/design-ideas/"
      );

      //Reading html template file
      const file1 = fs.readFileSync(
        baseTemplateDirectory + "1-home-page.html",
        "utf8"
      );
      const template1 = handlebars.compile(file1);
      const page1 = template1(data);

      //Reading html template file
      const file2 = fs.readFileSync(
        baseTemplateDirectory + "2-plan-a.html",
        "utf8"
      );
      const template2 = handlebars.compile(file2);
      const page2 = template2(data);

      //Reading html template file
      /* const file3 = fs.readFileSync(
        baseTemplateDirectory + "3-view-more.html",
        "utf8"
      );
      const template3 = handlebars.compile(file3);
      const page3 = template3(data); */

      let browser = null;
      let height = 980;

      try {
        const customViewport = chromium.defaultViewport;
        customViewport.width = 480;
        //Initialising browser object using  chromium.puppeteer
        browser = await puppeteer.launch({
          args: chromium.args,
          defaultViewport: customViewport,
          executablePath: await chromium.executablePath(),
          headless: chromium.headless,
        });

        const tab1 = await browser.newPage();

        const loaded = tab1.waitForNavigation({
          waitUntil: "load"
        })
        await tab1.setContent(page1);
        await loaded;
        const pdf1 = await tab1.pdf({
          printBackground: true,
          preferCSSPageSize: true,
          width: "480px",
          height: "740px",
          margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          }
        });

        const tab2 = await browser.newPage();
        const loaded2 = tab2.waitForNavigation({
          waitUntil: "load"
        });
        await tab2.setContent(page2);
        await loaded2;
        height = await tab2.evaluate(() => {
          return document.getElementById("maincontent").scrollHeight + 1;
        });

        const pdf2 = await tab2.pdf({
          printBackground: true,
          preferCSSPageSize: true,
          width: "480px", //"5in"
          height: height + "px", //"9.27in"
        });

        /* const tab3 = await browser.newPage();
        const loaded3 = tab3.waitForNavigation({
          waitUntil: "load"
        });
        await tab3.setContent(page3);
        await loaded3;
        const pdf3 = await tab3.pdf({
          printBackground: true,
          preferCSSPageSize: true,
          width: "480px", //"5in"
          height: "890px", //"9.27in"
        }); */
        console.log(">> all pdfs done");

        const pdfMergedBuffer = await mergePDFStream([pdf1, pdf2]);

        await tab1.close();
        await tab2.close();

        const output_filename = `plan_${baseResponse.currentDatetime()}.pdf`;
        const filePath = `plan-ideas/pdfs/${baseResponse.generateUniqueID()}/${output_filename}`;
        const s3Params = {
          // ACL: "public-read-write",
          Bucket: process.env.UPLOAD_S3_BUCKET,
          Key: filePath,
          Body: pdfMergedBuffer,
          ContentType: "application/pdf"
        };
        const command = new PutObjectCommand(s3Params);
        const objS3Response = await s3Client.send(command);
        if (objS3Response) {
          const downloadURL = `${process.env.S3_BUCKET_PATH}/${filePath}`;
          let arrResponse = [{
            filePath: downloadURL,
            s3Response: objS3Response
          },];

          return baseResponse.getResponseObject(
            event,
            true,
            HTTP_CODE.SUCCESS,
            arrResponse,
            "Download plans ideas pdf successfully."
          );
        } else {
          let arrResponse = [{
            filePath: "",
            s3Response: objS3Response
          }];
          return baseResponse.getResponseObject(
            event,
            false,
            HTTP_CODE.INTERNAL_SERVER_ERROR,
            arrResponse,
            "Error while putting pdf file to s3 "
          );
        }
      } catch (error) {
        let arrResponse = [{
          filePath: "",
          s3Response: error
        }];
        return baseResponse.getResponseObject(
          event,
          false,
          HTTP_CODE.INTERNAL_SERVER_ERROR,
          arrResponse,
          "Error while putting pdf file to s3 "
        );
      } finally {
      }
    }

    const minMaxResult = await plansService.fetchPlansImagesMinMax(data);

    if (minMaxResult) {
      minMaxResult[0]['s3BasePath'] = s3BasePath;
      minMaxResult[0]['toSeeMoreImages'] = process.env.WEB_URL_PLANS;
      return await plansPdfGenFunc(minMaxResult[0]);
    } else {
      const randomResult = await plansService.fetchPlansImagesRandom(data);
      randomResult[0]['s3BasePath'] = s3BasePath;
      randomResult[0]['toSeeMoreImages'] = process.env.WEB_URL_PLANS;
      return await plansPdfGenFunc(randomResult[0]);
    }
    // return baseResponse.getResponseObject(event,false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], "Something went wrong.");
  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Internal server error: " + e.message);
  }
};