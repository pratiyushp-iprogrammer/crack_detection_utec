const pdflib = require('pdf-lib');

const mergePDFStream = async (buffers) => {
    try {

        const doc = await pdflib.PDFDocument.create();

        for (const buffer of buffers) {
            const pdfDoc = await pdflib.PDFDocument.load(buffer);
            const pages = await doc.copyPages(pdfDoc, pdfDoc.getPageIndices());
            doc.addPage(...pages);
        }

        const merged = await doc.save();
        const buffer = Buffer.from(merged);

        return buffer;

    } catch (error) {
        console.log("error while merging")
    }
}

module.exports = mergePDFStream