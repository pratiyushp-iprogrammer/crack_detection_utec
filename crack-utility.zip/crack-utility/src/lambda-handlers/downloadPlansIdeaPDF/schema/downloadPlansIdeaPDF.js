const Joi = require("joi");
const JoiCustomSchema = require('./joi_custom_schema');

const DownloadPlansIdeaPDFSchema = Joi.object().keys({
    plotArea: JoiCustomSchema.numberInput
});

module.exports = DownloadPlansIdeaPDFSchema;