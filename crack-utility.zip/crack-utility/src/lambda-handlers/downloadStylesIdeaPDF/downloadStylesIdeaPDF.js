const BaseResponse = require("./common/baseResponse");
const HTTP_CODE = require("./common/constants");
const chromium = require("@sparticuz/chromium");
const puppeteer = require("puppeteer-core");
const handlebars = require("handlebars");
const { S3Client, PutObjectCommand } =require("@aws-sdk/client-s3"); 
const s3Client = new S3Client();
const fs = require("fs");
const path = require("path");
const mergePDFStream = require('./mergePDF');
const DownloadStylesIdeaPDFSchema = require('./schema/downloadStylesIdeaPDF');
const StylesService = require('./services/stylesService');
const Database = require('./common/database');
const common = require('./common/common');
let Common = new common()
let objDatabase = new Database();
if (typeof client === 'undefined') var client = objDatabase.connect();

let baseResponse = new BaseResponse();
const stylesService = new StylesService();

exports.downloadStylesIdeaPDFHandler = async (event, context) => {
  try {
    event = Common.reqSanitize(event);

    /* const s3Params = {
      accessKeyId: process.env.ACCESS_KEY_ID,
      secretAccessKey: process.env.SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION_NAME
    };

    s3.config.update(s3Params); */
    const params = JSON.parse(event.body);
    var validation = DownloadStylesIdeaPDFSchema.validate(params);
    if (validation.error) {
      return baseResponse.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
    }

    const s3BasePath = `${process.env.S3_BUCKET_PATH}/`;
    params['s3BasePath'] = s3BasePath;
    const stylesPdfGenFunc = async (data) => {

      var baseTemplateDirectory = path.join(
        __dirname,
        "assets/html-templates/design-ideas/"
      );

      //Reading html template file
      const file1 = fs.readFileSync(
        baseTemplateDirectory + "home-page.html",
        "utf8"
      );
      const template1 = handlebars.compile(file1);
      const page1 = template1(data);

      //Reading html template file
      const file2 = fs.readFileSync(
        baseTemplateDirectory + "element-types.html",
        "utf8"
      );

      const elements = [];
      let iterations = data?.length;
      for (const element of data) {
        element['s3BasePath'] = s3BasePath;
        if (!--iterations) {
          element['isLast'] = true;
          element['toSeeMoreImages'] = process.env.WEB_URL_STYLES;
        }
        if (element?.imageUrls?.length) {
          const template2 = handlebars.compile(file2);
          const page2 = template2(element);
          elements.push({ template2, page2 });
        }
      }
      //Reading html template file
      /* const file3 = fs.readFileSync(
        baseTemplateDirectory + "view-more.html",
        "utf8"
      );
      data['toSeeMoreImages'] = process.env.WEB_URL_STYLES;
      const template3 = handlebars.compile(file3);
      const page3 = template3(data); */

      let browser = null;
      let height = 980;
      try {
        const customViewport = chromium.defaultViewport;
        customViewport.width = 480;
        //Initialising browser object using  chromium.puppeteer
        browser = await puppeteer.launch({
          args: chromium.args,
          defaultViewport: customViewport,
          executablePath: await chromium.executablePath(),
          headless: chromium.headless,
        });

        const tab1 = await browser.newPage();

        const loaded = tab1.waitForNavigation({
          waitUntil: "load"
        })
        await tab1.setContent(page1);
        await loaded;
        const pdf1 = await tab1.pdf({
          printBackground: true,
          preferCSSPageSize: true,
          width: "480px", //"5in"
          height: "740px", //"9.27in"
          margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          }
        });

        const elementPages = [];
        for (const content of elements) {
          const tab2 = await browser.newPage();
          const loaded2 = tab2.waitForNavigation({
            waitUntil: "load"
          });
          await tab2.setContent(content.page2);
          await loaded2;
          height = await tab2.evaluate(() => {
            return document.getElementById("maincontent").scrollHeight + 1;
          });
          const pdf2 = await tab2.pdf({
            printBackground: true,
            preferCSSPageSize: true,
            width: "480px",
            height: height + "px",
          });
          elementPages.push(pdf2);

          await tab2.close();
        }

        /* const tab3 = await browser.newPage();
        const loaded3 = tab3.waitForNavigation({
          waitUntil: "load"
        });
        await tab3.setContent(page3);
        await loaded3;

        const pdf3 = await tab3.pdf({
          printBackground: true,
          preferCSSPageSize: true,
          width: "480px",
          height: "740px",
        }); */
        await tab1.close();

        const pdfMergedBuffer = await mergePDFStream([pdf1, ...elementPages]);
        const output_filename = `styles_${baseResponse.currentDatetime()}.pdf`;
        const filePath = `style-ideas/pdfs/${baseResponse.generateUniqueID()}/${output_filename}`;
        const s3Params = {
          // ACL: "public-read-write",
          Bucket: process.env.UPLOAD_S3_BUCKET,
          Key: filePath,
          Body: pdfMergedBuffer,
          ContentType: "application/pdf"
        };


        const command = new PutObjectCommand(s3Params);
        const objS3Response = await s3Client.send(command);

        if (objS3Response) {
          const downloadURL = `${process.env.S3_BUCKET_PATH}/${filePath}`;

          let arrResponse = [{
            filePath: downloadURL,
            s3Response: objS3Response
          },];

          return baseResponse.getResponseObject(event,
            true,
            HTTP_CODE.SUCCESS,
            arrResponse,
            "Download design ideas pdf successfully."
          );
        } else {
          let arrResponse = [{
            filePath: "",
            s3Response: objS3Response
          }];
          return baseResponse.getResponseObject(
            event,
            false,
            HTTP_CODE.INTERNAL_SERVER_ERROR,
            arrResponse,
            "Error while putting pdf file to s3 "
          );
        }
      } catch (error) {
        let arrResponse = [{
          filePath: "",
          s3Response: error
        }];
        return baseResponse.getResponseObject(
          event,
          false,
          HTTP_CODE.INTERNAL_SERVER_ERROR,
          arrResponse,
          "Error while putting pdf file to s3 "
        );
      } finally {
      }
    }

    const finalResult = await stylesService.fetchStylesImages(params);
    console.log("finalResult", JSON.stringify(finalResult))
    if (finalResult) {
      finalResult.s3BasePath = s3BasePath;
      return await stylesPdfGenFunc(finalResult);
    }

    return baseResponse.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], "Something went wrong.");

  } catch (e) {
    // TODO - Need to enhance catch block
    return baseResponse.getResponseObject(
      event,
      false,
      HTTP_CODE.BAD_REQUEST,
      [],
      "Internal server error: " + e.message
    );
  }
};