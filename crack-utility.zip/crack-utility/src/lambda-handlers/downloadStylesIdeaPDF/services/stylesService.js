const Styles = require('../models/styles.js');

class StylesService {
    async fetchStylesImages(params) {
        try {

            let pipeline = [];

            let addFields = {
                "$addFields": {
                    "image_files": {
                        $ifNull: [
                            "$image_files",
                            ""
                        ]
                    },
                    "elevations_images": {
                        $ifNull: [
                            "$files.three_d_design_id.front",
                            ""
                        ]
                    },


                }
            };

            let match = {
                "$match": {
                    $and: [
                        {
                            "element_type": {
                                $in: params.elementType
                            }
                        },
                        {
                            $or: [{
                                "image_files": {
                                    $ne: ""
                                }
                            },
                            {
                                "elevations_images": {
                                    $ne: ""
                                }
                            },

                            ]
                        },
                        {
                            "is_active": 1
                        }
                    ]
                }
            };
            let group = {
                "$group": {
                    _id: "$element_type",
                    element_details: {
                        $push: {
                            $concat: [
                                params.s3BasePath,
                                {
                                    $arrayElemAt: [
                                        {
                                            $split: [
                                                {
                                                    $cond: [
                                                        { $ne: ["$image_files", ""] }, "$image_files", "$elevations_images"
                                                    ]
                                                },
                                                ","]
                                        }, 0]
                                }
                            ]
                        }
                    }
                }
            };
            let project = {
                "$project": {
                    "_id": 0,
                    "elementType": "$_id",
                    "imageUrls": {
                        "$slice": [
                            "$element_details",
                            params.imageCount // 10
                        ]
                    }
                }
            };
            let sort = {
                "$sort": { "elementType": 1 }
            };

            pipeline.push(addFields, match, group, project, sort);
            console.log("Pipeline", JSON.stringify(pipeline));

            return await Styles.aggregate(pipeline).allowDiskUse(true).exec();
        } catch (error) {
            throw error;
        }
    }

}

module.exports = StylesService;