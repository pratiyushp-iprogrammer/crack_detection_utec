const Joi = require("joi");
const JoiCustomSchema = require('./joi_custom_schema');

const DownloadStylesIdeaPDFSchema = Joi.object().keys({
    imageCount: JoiCustomSchema.numberInput,
    elementType: JoiCustomSchema.arrayInput
});

module.exports = DownloadStylesIdeaPDFSchema;