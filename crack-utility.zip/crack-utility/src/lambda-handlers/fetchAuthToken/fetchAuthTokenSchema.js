const Joi = require("joi");
const JoiCustomSchema = require('./joi_custom_schema');

const fetchAuthTokenSchema = Joi.object().keys({
    user_name: JoiCustomSchema.stringInputRequired,
    password: JoiCustomSchema.stringInputRequired,
});

module.exports = fetchAuthTokenSchema;