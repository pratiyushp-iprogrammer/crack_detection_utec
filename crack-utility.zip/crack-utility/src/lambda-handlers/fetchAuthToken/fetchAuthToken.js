const {
  CognitoUserPool,
  CognitoUser,
  AuthenticationDetails
} = require('amazon-cognito-identity-js');
const HTTP_CODE = {
  SUCCESS: 200,
  BAD_REQUEST: 400,
  UNAUTHORISED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  REQUEST_TIMEOUT: 408,
  INTERNAL_SERVER_ERROR: 500,
  BAD_GATEWAY: 502,
  SERVICE_UNAVAILABLE: 503,
  INSUFFICIENT_STORAGE: 507,
  FAILURE: 520,
  DUPLICATE: 422
};
const Helper = require("./helper");
const common = require('./common');
let helper = new Helper();
let Common = new common()
const fetchAuthTokenSchema = require("./fetchAuthTokenSchema");

exports.handler = async (event, context, callback) => {
  try {
    event = Common.reqSanitize(event);
    const reqPayload = JSON.parse(event.body);
    console.log("reqPayload: ", JSON.stringify(reqPayload))
    var validation = fetchAuthTokenSchema.validate(reqPayload);
    if (validation.error) {
      return helper.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, validation.error, "Invalid request.");
    }
    console.log(process.env.USER_POOL_ID);
    let Pool = {
      UserPoolId: process.env.USER_POOL_ID, // "ap-south-1_94CpMoq3X"
      ClientId: process.env.CLIENT_ID // "kddgne7e0uoadk7m531d2hnq3"
    };
    console.log(Pool);
    let userPool = new CognitoUserPool(Pool);

    var authenticationData = {
      Username: reqPayload.user_name, // "rakeshb@iprogrammer.com",
      Password: reqPayload.password // "Aress1234$"
    };
    const authDetails = new AuthenticationDetails(authenticationData);

    let cognitoUser = new CognitoUser({
      Username: reqPayload.user_name, // "rakeshb@iprogrammer.com",
      Pool: userPool
    });

    try {
      const getTokenSessions = async (cognitoUser) => {
        return new Promise(async (resolve, reject) => {
            cognitoUser.authenticateUser(authDetails, {
              onSuccess: (data) => {
                if (data) {
                  console.log("data.accessToken.jwtToken", JSON.stringify(data.accessToken.jwtToken));
                  resolve(data);
                }
              },
              onFailure: (err) => {
                console.log("err: ", err.message, JSON.stringify(err));
                reject(err);
              },
            });
        });
      }
      const FinalResponse = await getTokenSessions(cognitoUser);
      if (FinalResponse) {
        const response = {
          idToken: FinalResponse.idToken.jwtToken,
          refreshToken: FinalResponse.refreshToken.token,
          accessToken: FinalResponse.accessToken.jwtToken,
        }
        return helper.getResponseObject(event, true, HTTP_CODE.SUCCESS, response, "User token fetched successfully.");
      }
    } catch (error) {
      console.log("Error: ", error);
      return helper.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], error.message);
    }

    return helper.getResponseObject(event, false, HTTP_CODE.INTERNAL_SERVER_ERROR, [], "Something went wrong.");
  } catch (e) {
    // TODO - Need to enhance catch block
    return helper.getResponseObject(event, false, HTTP_CODE.BAD_REQUEST, [], "Error while connecting to db: " + e.message);
  }
};